param(
  [ValidateSet('status','install','repair','remove')][string]$Action = 'status',
  [ValidateSet('mp3-bot-pro','yazici-pro','teknik-servis-pro','client-yonetim-pro','cv-olustur-pro')][string]$Component = 'mp3-bot-pro'
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$InstallRoot = 'C:\KafePin'
$ProRoot = 'C:\KafePinPro'
$ArchiveRoot = Join-Path $InstallRoot 'pro-components'
$RecoveryRoot = Join-Path $ProRoot '_kaldirilanlar'
$PreserveNames = @('.env','state.json','favorites.json','saved_locations.json','settings.json','user-settings.json')

$Components = @{
  'mp3-bot-pro' = @{ Name='MP3 Bot PRO'; Folder='MP3BotPRO'; Archive='mp3-bot-pro.zip'; Setup='KURULUM.cmd'; Start='mp3' }
  'yazici-pro' = @{ Name='Yazici PRO'; Folder='YaziciPRO'; Archive='yazici-pro.zip'; Setup='KURULUM.cmd'; Start='yazici' }
  'teknik-servis-pro' = @{ Name='Teknik Servis PRO'; Folder='TeknikServisPRO'; Archive='teknik-servis-pro.zip'; Setup='START_TEKNIK_SERVIS_PRO.cmd'; Start='teknik' }
  'client-yonetim-pro' = @{ Name='Client Yonetim PRO'; Folder='ClientYonetimPRO'; Archive='client-yonetim-pro.zip'; Setup='INSTALL_ELEVATED_SERVICE.ps1'; Start='client' }
  'cv-olustur-pro' = @{ Name='CV Olustur PRO'; Folder='CVOlusturPRO'; Archive='cv-olustur-pro.zip'; Setup=''; Start='cv' }
}

function Test-EveryCafePresent {
  $candidates = @(
    'C:\Program Files (x86)\EveryCafe', 'C:\Program Files\EveryCafe',
    'C:\EveryCafe', 'C:\ecmdata.ecm',
    (Join-Path $InstallRoot 'everycafe-path.txt'),
    (Join-Path $InstallRoot 'config\everycafe.json')
  )
  return [bool]($candidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1)
}

function Get-ComponentInfo([string]$Key) {
  $item = $Components[$Key]
  $target = Join-Path $ProRoot $item.Folder
  $archive = Join-Path $ArchiveRoot $item.Archive
  [pscustomobject]@{
    id=$Key; name=$item.Name; installed=(Test-Path -LiteralPath $target); available=(Test-Path -LiteralPath $archive)
    target=$target; clientRequiresEveryCafe=($Key -eq 'client-yonetim-pro'); everyCafePresent=(Test-EveryCafePresent)
  }
}

function Copy-ComponentFiles([string]$Source,[string]$Target,[bool]$Preserve) {
  New-Item -ItemType Directory -Force -Path $Target | Out-Null
  Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
    $destination = Join-Path $Target $_.Name
    if ($Preserve -and $PreserveNames -contains $_.Name -and (Test-Path -LiteralPath $destination)) { return }
    if ($_.PSIsContainer) {
      Copy-Item -LiteralPath $_.FullName -Destination $destination -Recurse -Force
    } else {
      Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
    }
  }
}

function Start-Component([string]$Key,[string]$Target) {
  $item=$Components[$Key]
  if($item.Start -eq 'mp3') {
    # MP3 arayüzü ve kullanıcı verisi Session 0'da çalışamaz. Bu yönetici
    # SYSTEM oturumundan çağrıldıysa servis burada başlatılmaz; KafePin
    # masaüstündeki MP3 sekmesi START_WEB.ps1 ile interaktif kullanıcıda açar.
    $sessionId = [int][System.Diagnostics.Process]::GetCurrentProcess().SessionId
    if($sessionId -le 0) { return $false }
    $launcher=Join-Path $Target 'START_WEB.ps1'
    if(Test-Path -LiteralPath $launcher){
      Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',$launcher) -WorkingDirectory $Target -WindowStyle Hidden | Out-Null
      return $true
    }
    return $false
  } elseif($item.Start -eq 'yazici') {
    $serviceHostPath=Join-Path $Target 'KafePin_YaziciPRO_ServiceHost.ps1'
    if(Test-Path -LiteralPath $serviceHostPath){ Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',$serviceHostPath,'-InstallRoot',$Target) -WindowStyle Hidden | Out-Null }
  } elseif($item.Start -eq 'teknik') {
    $starter=Join-Path $Target 'START_TEKNIK_SERVIS_PRO.cmd'
    if(Test-Path -LiteralPath $starter){ Start-Process -FilePath 'cmd.exe' -ArgumentList @('/d','/c',$starter) -WorkingDirectory $Target -WindowStyle Hidden | Out-Null }
  } elseif($item.Start -eq 'cv') {
    $service=Join-Path $Target 'web_service.py'
    $pyw=(Get-Command pythonw.exe -ErrorAction SilentlyContinue)
    if(-not $pyw){ $pyw=(Get-Command python.exe -ErrorAction SilentlyContinue) }
    if($pyw -and (Test-Path -LiteralPath $service)){ Start-Process -FilePath $pyw.Source -ArgumentList @('-B',$service) -WorkingDirectory $Target -WindowStyle Hidden | Out-Null; return $true }
    return $false
  } elseif($item.Start -eq 'client') {
    $installer=Join-Path $Target 'INSTALL_ELEVATED_SERVICE.ps1'
    if(Test-Path -LiteralPath $installer){ Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',$installer) -WorkingDirectory $Target -WindowStyle Hidden -Wait | Out-Null }
  }
}

function Install-Or-Repair([string]$Key) {
  $info=Get-ComponentInfo $Key
  if(-not $info.available){ throw "$($info.name) kurulum paketi bulunamadı." }
  if($Key -eq 'client-yonetim-pro' -and -not $info.everyCafePresent -and -not $info.installed){ throw 'Client Yonetim PRO yalniz EveryCafe bu bilgisayarda algilaninca eklenebilir.' }
  $temp=Join-Path ([IO.Path]::GetTempPath()) ('kafepin-component-'+[Guid]::NewGuid().ToString('N'))
  try {
    New-Item -ItemType Directory -Force -Path $temp | Out-Null
    Expand-Archive -LiteralPath (Join-Path $ArchiveRoot $Components[$Key].Archive) -DestinationPath $temp -Force
    Copy-ComponentFiles $temp $info.target ([bool]$info.installed)
    $setup=Join-Path $info.target $Components[$Key].Setup
    if($Key -in @('mp3-bot-pro','yazici-pro') -and (Test-Path -LiteralPath $setup)) {
      $p=Start-Process -FilePath 'cmd.exe' -ArgumentList @('/d','/c',('"'+$setup+'" /silent')) -WorkingDirectory $info.target -WindowStyle Hidden -Wait -PassThru
      if($p.ExitCode -ne 0){ throw "$($info.name) hazırlığı çıkış kodu $($p.ExitCode) verdi." }
    }
    $started = Start-Component $Key $info.target
    $verb = $(if($info.installed){'onarildi'}else{'eklendi'})
    $message = $info.name+' güvenli şekilde '+$verb+' ve başlatıldı.'
    if($Key -eq 'mp3-bot-pro' -and $started -eq $false) {
      $message = $info.name+' güvenli şekilde '+$verb+'. Servis Session 0 yerine KafePin masaüstündeki MP3 Bot PRO sekmesinden kullanıcı oturumunda başlatılacak.'
    }
    return [pscustomobject]@{ok=$true; message=$message; installed=$true}
  } finally { if(Test-Path -LiteralPath $temp){ Remove-Item -LiteralPath $temp -Force -Recurse -ErrorAction SilentlyContinue } }
}

function Remove-Component([string]$Key) {
  $info=Get-ComponentInfo $Key
  if(-not $info.installed){ return [pscustomobject]@{ok=$true;message=($info.name+' zaten kurulu değil.');installed=$false} }
  if($Key -eq 'client-yonetim-pro') { Unregister-ScheduledTask -TaskName 'KafePin Client Yonetim PRO' -Confirm:$false -ErrorAction SilentlyContinue }
  if($Key -eq 'mp3-bot-pro') {
    $py=Join-Path $info.target '.venv\Scripts\python.exe'; $ctl=Join-Path $info.target 'service_control.py'
    if((Test-Path -LiteralPath $py) -and (Test-Path -LiteralPath $ctl)){ & $py $ctl stop 2>$null | Out-Null }
  }
  New-Item -ItemType Directory -Force -Path $RecoveryRoot | Out-Null
  $backup=Join-Path $RecoveryRoot ($Key+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
  Move-Item -LiteralPath $info.target -Destination $backup -Force
  return [pscustomobject]@{ok=$true;message=($info.name+' kaldırıldı; geri alınabilir klasöre taşındı.');installed=$false;recovery=$backup}
}

try {
  if($Action -eq 'status') {
    $items=@($Components.Keys | Sort-Object | ForEach-Object { Get-ComponentInfo $_ })
    [pscustomobject]@{ok=$true;components=$items;everyCafePresent=(Test-EveryCafePresent)} | ConvertTo-Json -Depth 5 -Compress
  } elseif($Action -in @('install','repair')) {
    Install-Or-Repair $Component | ConvertTo-Json -Compress
  } else {
    Remove-Component $Component | ConvertTo-Json -Compress
  }
} catch {
  [pscustomobject]@{ok=$false;error=$_.Exception.Message} | ConvertTo-Json -Compress
  exit 1
}
