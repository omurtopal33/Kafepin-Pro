# KafePin Pro v3.0.1 compatibility file.
# Guncellemeler artik server.js icinde dogrudan kurulur; gizli updater worker kullanilmaz.
param()
exit 0
