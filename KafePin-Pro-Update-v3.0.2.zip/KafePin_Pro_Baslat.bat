@echo off
echo Eski KafePin BAT baslatma sistemi devre disidir.
echo KafePin paneli ve Windows Sistem Yoneticisi kullanilir.
exit /b 0
