# KafePin Pro v3.0.2 compatibility file.
# Guncellemeler server.js icinde dogrudan kurulur; gizli updater worker yoktur.
param()
exit 0
