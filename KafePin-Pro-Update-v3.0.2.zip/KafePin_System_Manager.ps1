param([string]$RootPath = "C:\KafePin")

$ErrorActionPreference = 'SilentlyContinue'
$root = [IO.Path]::GetFullPath($RootPath)
$sys = Join-Path $env:ProgramData 'KafePinPro'
$lock = Join-Path $sys 'maintenance.lock'
$stopFile = Join-Path $sys 'manager.stop'
$manualStop = Join-Path $sys 'server.manual-stop'
$tokenFile = Join-Path $sys 'manager.token'
$managerLog = Join-Path $sys 'system-manager.log'
$statusFile = Join-Path $sys 'system-manager-status.json'
$logs = Join-Path $root 'logs'
$outLog = Join-Path $logs 'kafepin-system.log'
$errLog = Join-Path $logs 'kafepin-system-error.log'
$controlPrefix = 'http://127.0.0.1:2999/'

New-Item -ItemType Directory -Path $sys -Force | Out-Null
New-Item -ItemType Directory -Path $logs -Force | Out-Null
Remove-Item -LiteralPath $stopFile -Force -ErrorAction SilentlyContinue
# A reboot/logon always starts KafePin again; manual stop is session-only.
Remove-Item -LiteralPath $manualStop -Force -ErrorAction SilentlyContinue

if (-not (Test-Path -LiteralPath $tokenFile -PathType Leaf)) {
  [IO.File]::WriteAllText($tokenFile, [guid]::NewGuid().ToString('N'), (New-Object System.Text.UTF8Encoding($false)))
}
$managerToken = ([string](Get-Content -LiteralPath $tokenFile -Raw)).Trim()

function Log([string]$m) {
  try { Add-Content -LiteralPath $managerLog -Value ((Get-Date).ToString('s') + '  ' + $m) -Encoding UTF8 } catch {}
}

function WriteStatus([string]$state, [int]$processId = 0, [string]$message = '') {
  try {
    $o = [ordered]@{
      time = (Get-Date).ToString('o')
      state = $state
      pid = $processId
      root = $root
      message = $message
      manualStopped = (Test-Path -LiteralPath $manualStop)
      maintenance = (Test-Path -LiteralPath $lock)
      controlPort = 2999
    }
    [IO.File]::WriteAllText($statusFile, ($o | ConvertTo-Json -Depth 3), (New-Object System.Text.UTF8Encoding($false)))
  } catch {}
}

function FindNode {
  $candidates = @(
    (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'nodejs\node.exe')
  )
  foreach ($c in $candidates) {
    if ($c -and (Test-Path -LiteralPath $c -PathType Leaf)) { return $c }
  }
  try {
    $cmd = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) { return [string]$cmd.Source }
  } catch {}
  return $null
}

function KafePinPid {
  try {
    $serverFull = [IO.Path]::GetFullPath((Join-Path $root 'server.js'))
    $ps = Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue
    foreach ($p in $ps) {
      $cmd = [string]$p.CommandLine
      if (-not $cmd) { continue }
      if ($cmd.IndexOf($serverFull, [StringComparison]::OrdinalIgnoreCase) -ge 0) { return [int]$p.ProcessId }
      if ($cmd -match '(^|\s|["''])(server\.js)(["'']|\s|$)') {
        try {
          $conn = Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue |
            Where-Object { $_.OwningProcess -eq [int]$p.ProcessId } | Select-Object -First 1
          if ($conn) { return [int]$p.ProcessId }
        } catch {}
      }
    }
  } catch {}
  return 0
}

function ForeignPortPid {
  try {
    $conn = Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($conn) {
      $ownerPid = [int]$conn.OwningProcess
      if ($ownerPid -ne (KafePinPid)) { return $ownerPid }
    }
  } catch {}
  return 0
}

function StartKafePinNode {
  $existing = KafePinPid
  if ($existing -gt 0) { return $existing }
  $foreign = ForeignPortPid
  if ($foreign -gt 0) { throw ('Port 3000 baska surecte. PID=' + $foreign) }
  $node = FindNode
  if (-not $node) { throw 'Node.js bulunamadi' }
  $p = Start-Process -FilePath $node `
    -ArgumentList @((Join-Path $root 'server.js')) `
    -WorkingDirectory $root `
    -WindowStyle Hidden `
    -RedirectStandardOutput $outLog `
    -RedirectStandardError $errLog `
    -PassThru
  if (-not $p -or -not $p.Id) { throw 'KafePin Node baslatilamadi' }
  Log ('Node basladi PID=' + $p.Id)
  return [int]$p.Id
}

function StopKafePinNode {
  $pidNow = KafePinPid
  if ($pidNow -gt 0) {
    Stop-Process -Id $pidNow -Force -ErrorAction SilentlyContinue
    Log ('Node durduruldu PID=' + $pidNow)
  }
  return $pidNow
}

function IsAllowedOrigin([string]$origin) {
  if ([string]::IsNullOrWhiteSpace($origin)) { return $true }
  try {
    $u = [Uri]$origin
    return (($u.Host -eq '127.0.0.1' -or $u.Host -eq 'localhost' -or $u.Host -eq '::1') -and $u.Port -eq 3000)
  } catch { return $false }
}

function SendJson($ctx, [int]$statusCode, $obj) {
  try {
    $origin = [string]$ctx.Request.Headers['Origin']
    if ($origin -and (IsAllowedOrigin $origin)) {
      $ctx.Response.Headers['Access-Control-Allow-Origin'] = $origin
      $ctx.Response.Headers['Vary'] = 'Origin'
    }
    $ctx.Response.Headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
    $ctx.Response.Headers['Access-Control-Allow-Headers'] = 'Content-Type, X-KafePin-Manager-Token'
    $ctx.Response.Headers['Cache-Control'] = 'no-store'
    $ctx.Response.StatusCode = $statusCode
    $ctx.Response.ContentType = 'application/json; charset=utf-8'
    $json = $obj | ConvertTo-Json -Compress -Depth 5
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $ctx.Response.ContentLength64 = $bytes.Length
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
  } catch {}
  try { $ctx.Response.OutputStream.Close() } catch {}
  try { $ctx.Response.Close() } catch {}
}

function HandleControlRequest($ctx) {
  $req = $ctx.Request
  $origin = [string]$req.Headers['Origin']
  if (-not (IsAllowedOrigin $origin)) {
    SendJson $ctx 403 @{ ok=$false; error='Origin reddedildi' }
    return
  }
  if ($req.HttpMethod -eq 'OPTIONS') {
    SendJson $ctx 200 @{ ok=$true }
    return
  }
  $provided = [string]$req.Headers['X-KafePin-Manager-Token']
  if ([string]::IsNullOrWhiteSpace($provided) -or $provided -ne $managerToken) {
    SendJson $ctx 403 @{ ok=$false; error='Yetkisiz sistem yoneticisi istegi' }
    return
  }

  $route = $req.Url.AbsolutePath.ToLowerInvariant()
  try {
    if ($route -eq '/status') {
      $pidNow = KafePinPid
      SendJson $ctx 200 @{
        ok=$true
        running=($pidNow -gt 0)
        pid=$pidNow
        manualStopped=(Test-Path -LiteralPath $manualStop)
        maintenance=(Test-Path -LiteralPath $lock)
        root=$root
      }
      return
    }
    if ($route -eq '/start' -and $req.HttpMethod -eq 'POST') {
      Remove-Item -LiteralPath $manualStop -Force -ErrorAction SilentlyContinue
      $pidNow = StartKafePinNode
      WriteStatus 'running' $pidNow 'panel start'
      SendJson $ctx 200 @{ ok=$true; running=$true; pid=$pidNow; action='start' }
      return
    }
    if ($route -eq '/stop' -and $req.HttpMethod -eq 'POST') {
      New-Item -ItemType File -Path $manualStop -Force | Out-Null
      $oldPid = StopKafePinNode
      WriteStatus 'manual-stopped' 0 'panel stop'
      SendJson $ctx 200 @{ ok=$true; running=$false; oldPid=$oldPid; action='stop' }
      return
    }
    if ($route -eq '/restart' -and $req.HttpMethod -eq 'POST') {
      Remove-Item -LiteralPath $manualStop -Force -ErrorAction SilentlyContinue
      $oldPid = StopKafePinNode
      Start-Sleep -Milliseconds 500
      $newPid = StartKafePinNode
      WriteStatus 'running' $newPid 'panel restart'
      SendJson $ctx 200 @{ ok=$true; running=$true; oldPid=$oldPid; pid=$newPid; action='restart' }
      return
    }
    SendJson $ctx 404 @{ ok=$false; error='Komut bulunamadi' }
  } catch {
    Log ('Kontrol API hata: ' + $_.Exception.Message)
    SendJson $ctx 500 @{ ok=$false; error=$_.Exception.Message }
  }
}

$listener = $null
$pending = $null
try {
  $listener = New-Object System.Net.HttpListener
  $listener.Prefixes.Add($controlPrefix)
  $listener.Start()
  $pending = $listener.GetContextAsync()
  Log ('Kontrol API basladi: ' + $controlPrefix)
} catch {
  Log ('Kontrol API baslatilamadi: ' + $_.Exception.Message)
  $listener = $null
}

Log 'KafePin System Manager v3.0.1 basladi.'
WriteStatus 'starting' 0 'manager v3.0.1 started'

while ($true) {
  if (Test-Path -LiteralPath $stopFile) {
    WriteStatus 'stopped' 0 'manager.stop'
    Log 'manager.stop bulundu'
    break
  }

  if ($listener -and $pending -and $pending.IsCompleted) {
    try {
      $ctx = $pending.Result
      HandleControlRequest $ctx
    } catch {}
    try { $pending = $listener.GetContextAsync() } catch { $pending = $null }
  }

  if (Test-Path -LiteralPath $lock) {
    WriteStatus 'maintenance' 0 'maintenance lock'
    Start-Sleep -Milliseconds 300
    continue
  }

  if (Test-Path -LiteralPath $manualStop) {
    $pidNow = KafePinPid
    if ($pidNow -gt 0) { StopKafePinNode | Out-Null }
    WriteStatus 'manual-stopped' 0 'panel stop'
    Start-Sleep -Milliseconds 300
    continue
  }

  if (-not (Test-Path -LiteralPath (Join-Path $root 'server.js') -PathType Leaf)) {
    WriteStatus 'waiting' 0 'server.js bulunamadi'
    Start-Sleep -Milliseconds 600
    continue
  }

  $pidNow = KafePinPid
  if ($pidNow -le 0) {
    try { $pidNow = StartKafePinNode } catch {
      WriteStatus 'error' 0 $_.Exception.Message
      Log ('Node baslatma hata: ' + $_.Exception.Message)
    }
  }
  if ($pidNow -gt 0) { WriteStatus 'running' $pidNow 'KafePin Node calisiyor' }
  Start-Sleep -Milliseconds 350
}

try { if ($listener) { $listener.Stop(); $listener.Close() } } catch {}
