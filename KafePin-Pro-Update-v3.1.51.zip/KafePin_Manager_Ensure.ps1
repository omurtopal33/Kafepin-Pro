﻿param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$NodePath = ''
)

$ErrorActionPreference = 'Stop'
$TaskName = 'KafePin Pro Server Manager'
$RestoreTaskName = 'KafePin Pro Restore Worker'
$SystemRoot = Join-Path $env:ProgramData 'KafePinPro'
$ManagerSource = Join-Path $InstallRoot 'KafePin_System_Manager.ps1'
$ManagerLive = Join-Path $SystemRoot 'KafePin_System_Manager.ps1'
$RestoreSource = Join-Path $InstallRoot 'KafePin_Restore_Worker.ps1'
$RestoreLive = Join-Path $SystemRoot 'KafePin_Restore_Worker.ps1'
$ConfigFile = Join-Path $SystemRoot 'manager-config.json'
$TokenFile = Join-Path $SystemRoot 'manager.token'
$RestartRequestFile = Join-Path $SystemRoot 'server-restart-request.json'
$LogDir = Join-Path $SystemRoot 'logs'
$LogFile = Join-Path $LogDir 'manager-ensure.log'
$ControlPort = 2999
$ExpectedManagerVersion = '3.1.4'
New-Item -ItemType Directory -Force -Path $SystemRoot,$LogDir | Out-Null

function Log([string]$Message) {
  try { Add-Content -LiteralPath $LogFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' [ensure-3.1.4] ' + $Message) -Encoding UTF8 } catch {}
}
function Find-Node {
  if ($NodePath -and (Test-Path -LiteralPath $NodePath -PathType Leaf)) { return $NodePath }
  try {
    if (Test-Path -LiteralPath $ConfigFile) {
      $cfg = Get-Content -LiteralPath $ConfigFile -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($cfg.nodePath -and (Test-Path -LiteralPath ([string]$cfg.nodePath) -PathType Leaf)) { return [string]$cfg.nodePath }
    }
  } catch {}
  $candidates = @(
    (Join-Path $InstallRoot 'node\node.exe'),
    'C:\Program Files\nodejs\node.exe',
    'C:\Program Files (x86)\nodejs\node.exe'
  )
  foreach ($candidate in $candidates) { if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate } }
  try {
    $cmd = Get-Command node.exe -ErrorAction Stop
    if ($cmd.Source -and (Test-Path -LiteralPath $cmd.Source -PathType Leaf)) { return $cmd.Source }
  } catch {}
  throw 'Node.exe bulunamadi.'
}
function Get-ControlState {
  try {
    if (-not (Test-Path -LiteralPath $TokenFile)) { return $null }
    $token = (Get-Content -LiteralPath $TokenFile -Raw -ErrorAction Stop).Trim()
    if (-not $token) { return $null }
    $r = Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:' + $ControlPort + '/status?_=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 2 -Headers @{ 'X-KafePin-Manager-Token'=$token; 'Cache-Control'='no-cache' }
    if ($r.StatusCode -lt 200 -or $r.StatusCode -ge 300) { return $null }
    $j = $r.Content | ConvertFrom-Json
    if (-not [bool]$j.ok) { return $null }
    return $j
  } catch { return $null }
}
function Test-Control {
  return ($null -ne (Get-ControlState))
}
function Test-ControlExpectedVersion {
  $state = Get-ControlState
  return ($null -ne $state -and [string]$state.managerVersion -eq $ExpectedManagerVersion)
}
function Wait-Control([int]$Seconds) {
  for ($i=0; $i -lt $Seconds; $i++) {
    if (Test-ControlExpectedVersion) { return $true }
    Start-Sleep -Seconds 1
  }
  return $false
}
function Stop-ManagerProcesses {
  try { & schtasks.exe /End /TN $TaskName 2>$null | Out-Null } catch {}
  Start-Sleep -Milliseconds 400
  try {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue | Where-Object {
      $cmd=[string]$_.CommandLine
      $cmd -and $cmd.IndexOf('KafePin_System_Manager.ps1',[StringComparison]::OrdinalIgnoreCase) -ge 0
    } | ForEach-Object { try { Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue } catch {} }
  } catch {}
  Start-Sleep -Milliseconds 500
}
function Ensure-RestoreTask {
  if (-not (Test-Path -LiteralPath $RestoreSource -PathType Leaf)) { throw 'KafePin_Restore_Worker.ps1 bulunamadi.' }
  Copy-Item -LiteralPath $RestoreSource -Destination $RestoreLive -Force
  try { & schtasks.exe /End /TN $RestoreTaskName 2>$null | Out-Null } catch {}
  try { & schtasks.exe /Delete /TN $RestoreTaskName /F 2>$null | Out-Null } catch {}
  $powershellExe = Join-Path $PSHOME 'powershell.exe'
  $taskCommand = '"' + $powershellExe + '" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $RestoreLive + '"'
  $out = & schtasks.exe /Create /TN $RestoreTaskName /SC ONSTART /RU SYSTEM /RL HIGHEST /TR $taskCommand /F 2>&1
  if ($LASTEXITCODE -ne 0) { throw ('Restore Worker gorevi olusturulamadi: ' + ($out -join ' ')) }
  Log 'Restore Worker SYSTEM gorevi hazirlandi.'
}

function Register-Task([string]$Node) {
  if (-not (Test-Path -LiteralPath $ManagerSource -PathType Leaf)) { throw 'KafePin_System_Manager.ps1 bulunamadi.' }
  Copy-Item -LiteralPath $ManagerSource -Destination $ManagerLive -Force
  [ordered]@{ nodePath=$Node; root=$InstallRoot; port=3000; controlPort=$ControlPort; version=$ExpectedManagerVersion } | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $ConfigFile -Encoding UTF8
  if (-not (Test-Path -LiteralPath $TokenFile)) { [guid]::NewGuid().ToString('N') | Set-Content -LiteralPath $TokenFile -Encoding ASCII }
  try { & schtasks.exe /Delete /TN $TaskName /F 2>$null | Out-Null } catch {}
  $powershellExe = Join-Path $PSHOME 'powershell.exe'
  $taskCommand = '"' + $powershellExe + '" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $ManagerLive + '" -Loop'
  $out = & schtasks.exe /Create /TN $TaskName /SC ONSTART /RU SYSTEM /RL HIGHEST /TR $taskCommand /F 2>&1
  if ($LASTEXITCODE -ne 0) { throw ('Server Manager gorevi olusturulamadi: ' + ($out -join ' ')) }
  $out = & schtasks.exe /Run /TN $TaskName 2>&1
  if ($LASTEXITCODE -ne 0) { throw ('Server Manager gorevi baslatilamadi: ' + ($out -join ' ')) }
}

try {
  $node = Find-Node


  # v3.1.51 CANDIDATE1 - Yazici PRO gelir katmani gercek kurulum klasorune
  # dogrudan uygulanir. MP3 PRO, Teknik Servis PRO ve diger bilesenlere dokunulmaz.
  $YaziciPayload = Join-Path $InstallRoot 'v3151-yazici-payload'
  $YaziciRoot = Join-Path $InstallRoot 'KafePinYaziciPRO'
  $YaziciWeb = Join-Path $YaziciRoot 'web'
  $YaziciLog = Join-Path $LogDir 'v3151-yazici-apply.log'
  function YaziciLog([string]$Text) {
    try { Add-Content -LiteralPath $YaziciLog -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' [v3.1.51-candidate1] ' + $Text) -Encoding UTF8 } catch {}
  }
  function YaziciFileSha([string]$P) { return (Get-FileHash -Algorithm SHA256 -LiteralPath $P).Hash.ToLowerInvariant() }

  if (-not (Test-Path -LiteralPath $YaziciPayload -PathType Container)) { throw 'v3.1.51 Yazici payload klasoru bulunamadi.' }
  if (-not (Test-Path -LiteralPath $YaziciRoot -PathType Container)) { throw ('Yazici PRO kurulum klasoru bulunamadi: ' + $YaziciRoot) }
  New-Item -ItemType Directory -Force -Path $YaziciWeb | Out-Null

  $pairs = @(
    [pscustomobject]@{ Src='index.html'; Dst='web\index.html'; Sha='a43860299adece7a96a060949e24e6bf1cd249d0e91de976f01592c1159fbaa6' },
    [pscustomobject]@{ Src='KafePin_YaziciGelir_Service.js'; Dst='KafePin_YaziciGelir_Service.js'; Sha='af659baa26197b4ed6bbe7a2d9d85a5a931f3db2b804b45a1ddae52aa49db047' },
    [pscustomobject]@{ Src='START_YAZICI_PRO.cmd'; Dst='START_YAZICI_PRO.cmd'; Sha='d6f6ceba73b49921555b6406ff19e0a7e51e2b23d3c0bbe8b19c3309a645fb85' },
    [pscustomobject]@{ Src='yazici-pro-version.json'; Dst='yazici-pro-version.json'; Sha='cb3e3107eb275794617608743f6e2e6015b79b773cdcf357de606ae3ef6c0d65' }
  )
  foreach ($pair in $pairs) {
    $src = Join-Path $YaziciPayload ([string]$pair.Src)
    $dst = Join-Path $YaziciRoot ([string]$pair.Dst)
    if (-not (Test-Path -LiteralPath $src -PathType Leaf)) { throw ('Yazici payload dosyasi eksik: ' + [string]$pair.Src) }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
    Copy-Item -LiteralPath $src -Destination $dst -Force
    if ((YaziciFileSha $dst) -ne [string]$pair.Sha) { throw ('Yazici PRO SHA256 dogrulamasi basarisiz: ' + [string]$pair.Dst) }
    YaziciLog ('Kopya+SHA OK: ' + [string]$pair.Dst)
  }

  $indexPath = Join-Path $YaziciWeb 'index.html'
  $indexRaw = Get-Content -LiteralPath $indexPath -Raw -Encoding UTF8
  if ($indexRaw.IndexOf('v3151Verified',[StringComparison]::Ordinal) -lt 0) { throw 'Yazici PRO v3.1.51 arayuz marker dogrulamasi basarisiz.' }
  if ($indexRaw.IndexOf('WHATSAPP / HIZLI CIKTI',[StringComparison]::OrdinalIgnoreCase) -lt 0 -and $indexRaw.IndexOf('WHATSAPP / HIZLI ÇIKTI',[StringComparison]::OrdinalIgnoreCase) -lt 0) { throw 'Yazici PRO Hizli Cikti sekmesi bulunamadi.' }

  Set-Content -LiteralPath (Join-Path $YaziciRoot 'node-path.txt') -Value $node -Encoding ASCII
  try { & wevtutil.exe sl 'Microsoft-Windows-PrintService/Operational' /e:true 2>$null | Out-Null } catch {}

  $revenueService = Join-Path $YaziciRoot 'KafePin_YaziciGelir_Service.js'
  $syntax = Start-Process -FilePath $node -ArgumentList @('--check', $revenueService) -WorkingDirectory $YaziciRoot -WindowStyle Hidden -Wait -PassThru
  if ($syntax.ExitCode -ne 0) { throw ('Yazici Geliri Node syntax kontrolu basarisiz. exit=' + $syntax.ExitCode) }

  # Eski v3.1.50/3.1.51 gelir servisi aciksa ayni portta eski kod kalmasin.
  try {
    Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue | Where-Object {
      $cmd=[string]$_.CommandLine
      $cmd -and $cmd.IndexOf('KafePin_YaziciGelir_Service.js',[StringComparison]::OrdinalIgnoreCase) -ge 0
    } | ForEach-Object { try { Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue } catch {} }
  } catch {}
  Start-Process -FilePath $node -ArgumentList @($revenueService) -WorkingDirectory $YaziciRoot -WindowStyle Hidden | Out-Null

  [ordered]@{
    version='3.1.51'; build='candidate1'; appliedAt=(Get-Date).ToString('o');
    yaziciRoot=$YaziciRoot; revenuePort=17893
  } | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $SystemRoot 'v3151-yazici-applied.json') -Encoding UTF8
  YaziciLog 'BASARILI: v3.1.51 Yazici PRO payload gercek hedefe uygulandi.'
  if (-not (Test-Path -LiteralPath $ManagerSource -PathType Leaf)) { throw 'Manager kaynak dosyasi yok.' }
  Copy-Item -LiteralPath $ManagerSource -Destination $ManagerLive -Force
  [ordered]@{ nodePath=$node; root=$InstallRoot; port=3000; controlPort=$ControlPort; version=$ExpectedManagerVersion } | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $ConfigFile -Encoding UTF8
  if (-not (Test-Path -LiteralPath $TokenFile)) { [guid]::NewGuid().ToString('N') | Set-Content -LiteralPath $TokenFile -Encoding ASCII }
  Ensure-RestoreTask

  if (Test-ControlExpectedVersion) { Log 'Manager control zaten hazir ve surum dogru.'; exit 0 }

  if (Test-Control) {
    Log 'Manager control var fakat surum eski; yeni surum temizden kaydediliyor.'
    Stop-ManagerProcesses
    Remove-Item -LiteralPath $RestartRequestFile -Force -ErrorAction SilentlyContinue
    Register-Task $node
    if (-not (Wait-Control 15)) { throw 'Yeni Server Manager surumu 15 saniye icinde hazir olmadi.' }
    Log 'BASARILI: Manager yeni surume gecirildi.'
    exit 0
  }

  Log 'Manager control yok; mevcut gorev tetikleniyor.'
  try { & schtasks.exe /Run /TN $TaskName 2>$null | Out-Null } catch {}
  if (Wait-Control 6) { Log 'Manager mevcut gorev ile hazirlandi.'; exit 0 }

  Log 'Manager hala yok; gorev temizden kaydediliyor.'
  Stop-ManagerProcesses
  Remove-Item -LiteralPath $RestartRequestFile -Force -ErrorAction SilentlyContinue
  Register-Task $node
  if (-not (Wait-Control 15)) { throw 'Server Manager control portu 15 saniye icinde hazir olmadi.' }
  Log 'BASARILI: Manager gorevi yeniden kaydedildi ve control portu dogrulandi.'
  exit 0
} catch {
  Log ('HATA: ' + $_.Exception.Message)
  Write-Error $_.Exception.Message
  exit 21
}
