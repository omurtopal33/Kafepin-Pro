param([string]$InstallRoot='C:\KafePin')
$ErrorActionPreference='Stop'
$LogDir=Join-Path $env:ProgramData 'KafePinPro\logs'
$Log=Join-Path $LogDir 'v3150-yazici.log'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
function Log([string]$m){ try{ Add-Content -LiteralPath $Log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss')+' '+$m) -Encoding UTF8 }catch{} }
function Find-Python3([string]$YaziciRoot) {
  $candidates=@()
  if($YaziciRoot){
    $candidates += (Join-Path $YaziciRoot '.venv\Scripts\python.exe')
    $candidates += (Join-Path $YaziciRoot 'python\python.exe')
  }
  $candidates += (Join-Path $InstallRoot 'python\python.exe')
  if($env:LOCALAPPDATA){
    foreach($v in @('Python314','Python313','Python312','Python311','Python310')){$candidates += (Join-Path $env:LOCALAPPDATA ('Programs\Python\'+$v+'\python.exe'))}
  }
  foreach($v in @('Python314','Python313','Python312','Python311','Python310')){$candidates += ('C:\Program Files\'+$v+'\python.exe')}
  foreach($c in $candidates){
    if($c -and (Test-Path -LiteralPath $c -PathType Leaf)){
      try { & $c -c "import sys; assert sys.version_info >= (3,10)" 2>$null; if($LASTEXITCODE -eq 0){Log ('Python bulundu: '+$c);return $c} } catch {}
    }
  }
  try {
    $launcher=(Get-Command py.exe -ErrorAction Stop).Source
    $resolved=& $launcher -3 -c "import sys; print(sys.executable)" 2>$null
    if($LASTEXITCODE -eq 0 -and $resolved){$r=[string]($resolved|Select-Object -First 1);$r=$r.Trim();if(Test-Path -LiteralPath $r){Log ('Python py launcher ile bulundu: '+$r);return $r}}
  } catch {}
  try {$cmd=(Get-Command python.exe -ErrorAction Stop).Source;if($cmd){Log ('Python PATH ile bulundu: '+$cmd);return $cmd}}catch{}
  return $null
}
function Add-LazyPdfDependency([string]$YaziciRoot){
  try {
    $start=Join-Path $YaziciRoot 'START_YAZICI_PRO.cmd'
    if(-not(Test-Path -LiteralPath $start -PathType Leaf)){return}
    $txt=Get-Content -LiteralPath $start -Raw
    if($txt -match 'KAFEPIN_V3150_PYMUPDF_CHECK'){return}
    $launch='start "Yazici PRO" /min "%~dp0.venv\Scripts\pythonw.exe" "%~dp0web_service.py"'
    $dep=@'
rem KAFEPIN_V3150_PYMUPDF_CHECK
"%~dp0.venv\Scripts\python.exe" -c "import fitz" >nul 2>&1
if errorlevel 1 (
  "%~dp0.venv\Scripts\python.exe" -m pip install --disable-pip-version-check "PyMuPDF>=1.24,<2"
  if errorlevel 1 exit /b 1
)
'@
    if($txt.Contains($launch)){$txt=$txt.Replace($launch,$dep+"`r`n"+$launch)}else{$txt=$dep+"`r`n"+$txt}
    Set-Content -LiteralPath $start -Value $txt -Encoding ASCII
    Log 'START_YAZICI_PRO PyMuPDF tembel kurulum kontrolu eklendi.'
  } catch { Log ('START dependency kontrolu eklenemedi: '+$_.Exception.Message) }
}
$Marker=Join-Path $env:ProgramData 'KafePinPro\v3150-yazici-installed.json'
try { if(Test-Path $Marker){$m=Get-Content $Marker -Raw|ConvertFrom-Json;if([string]$m.version -eq '3.1.50' -and [string]$m.build -eq 'repair2'){Log 'repair2 marker mevcut; atlandi.';exit 0}} } catch{}
$tmp=$null;$base=$null;$target=$null;$targetBackup=$null;$component=$null
try {
  Log 'v3.1.50 TEST repair2 bootstrap basladi.'
  $tmp=Join-Path $env:TEMP ('KafePin-v3150-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $tmp|Out-Null
  $zip=Join-Path $tmp 'v3149.zip'
  Invoke-WebRequest -UseBasicParsing -Uri 'https://raw.githubusercontent.com/omurtopal33/Kafepin-Pro/main/KafePin-Pro-Update-v3.1.49.zip' -OutFile $zip -TimeoutSec 20
  $sha=(Get-FileHash -Algorithm SHA256 -LiteralPath $zip).Hash.ToLowerInvariant()
  if($sha -ne '9eb3468b4991476ae7850be0556315f05a4430ae3b94264cc53238b69fc2b34e'){throw ('v3.1.49 SHA256 uyusmuyor: '+$sha)}
  $base=Join-Path $tmp 'v3149';Expand-Archive -LiteralPath $zip -DestinationPath $base -Force
  $info=Get-Content (Join-Path $base 'update.json') -Raw -Encoding UTF8|ConvertFrom-Json
  if([string]$info.version -ne '3.1.49'){throw 'v3.1.49 paket tanimi gecersiz'}
  foreach($rel in @($info.files)){
    $r=[string]$rel
    if($r -in @('KafePin_Manager_Ensure.ps1','kafepin-pro-version.json','update.json')){continue}
    $src=Join-Path $base $r;if(-not(Test-Path -LiteralPath $src -PathType Leaf)){throw ('v3.1.49 eksik dosya: '+$r)}
    $dst=Join-Path $InstallRoot $r;$parent=Split-Path -Parent $dst;if($parent){New-Item -ItemType Directory -Force -Path $parent|Out-Null};Copy-Item -LiteralPath $src -Destination $dst -Force
  }
  Log 'v3.1.49 kumulatif taban dogrulandi/tazelendi.'

  $target=Join-Path $InstallRoot 'KafePinYaziciPRO'
  $py=Find-Python3 $target
  if(-not $py){throw 'Python 3 bulunamadi. Kurulu Yazici PRO .venv dahil bilinen tum yollar kontrol edildi.'}
  $patch=Join-Path $InstallRoot 'v3150-yazici\patch.py'
  $component=Join-Path $InstallRoot 'pro-components\yazici-pro.zip'
  if(-not(Test-Path -LiteralPath $patch -PathType Leaf)){throw 'v3.1.50 patch.py bulunamadi.'}
  if(-not(Test-Path -LiteralPath $component -PathType Leaf)){throw 'Yazici PRO component ZIP bulunamadi.'}
  $compDir=Join-Path $tmp 'yazici-component';Expand-Archive -LiteralPath $component -DestinationPath $compDir -Force
  & $py $patch --target $compDir
  if($LASTEXITCODE -ne 0){throw 'Yazici PRO component patch basarisiz.'}
  Remove-Item -LiteralPath $component -Force
  Compress-Archive -Path (Join-Path $compDir '*') -DestinationPath $component -CompressionLevel Optimal -Force
  Log 'Yazici PRO component ZIP v3.1.50 TEST yapildi.'

  $targetBackup=Join-Path $tmp 'installed-yazici-backup'
  if(Test-Path -LiteralPath $target -PathType Container){
    Copy-Item -LiteralPath $target -Destination $targetBackup -Recurse -Force
    try{Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" -ErrorAction SilentlyContinue|Where-Object{[string]$_.CommandLine -like ('*'+$target+'*web_service.py*')}|ForEach-Object{Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue}}catch{}
    & $py $patch --target $target
    if($LASTEXITCODE -ne 0){throw 'Kurulu Yazici PRO patch basarisiz.'}
    Add-LazyPdfDependency $target
    try{& wevtutil.exe sl 'Microsoft-Windows-PrintService/Operational' /e:true|Out-Null;Log 'PrintService Operational aktif.'}catch{Log ('PrintService log acilamadi: '+$_.Exception.Message)}
    $start=Join-Path $target 'START_YAZICI_PRO.cmd';if(Test-Path $start){Start-Process -FilePath $start -WorkingDirectory $target -WindowStyle Hidden}
    Log 'Kurulu Yazici PRO v3.1.50 TEST yukseltildi; mevcut .venv kullanildi.'
  } else { Log 'Yazici PRO kurulu degil; component ZIP v3.1.50 olarak hazirlandi.' }

  [ordered]@{version='3.1.50';channel='test';mode='cumulative-test-repair2';baseVersion='3.1.29';installedAt=(Get-Date).ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $InstallRoot 'kafepin-pro-version.json') -Encoding UTF8
  [ordered]@{version='3.1.50';build='repair2';channel='test';installedAt=(Get-Date).ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath $Marker -Encoding UTF8
  if($tmp){Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue}
  Log 'v3.1.50 TEST repair2 bootstrap BASARILI.'
  exit 0
} catch {
  try {
    if($targetBackup -and (Test-Path -LiteralPath $targetBackup -PathType Container) -and $target){if(Test-Path -LiteralPath $target){Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction SilentlyContinue};Copy-Item -LiteralPath $targetBackup -Destination $target -Recurse -Force;Log 'Yazici PRO onceki hali geri yuklendi.'}
    if($base -and $component){$stableComponent=Join-Path $base 'pro-components\yazici-pro.zip';if(Test-Path -LiteralPath $stableComponent -PathType Leaf){Copy-Item -LiteralPath $stableComponent -Destination $component -Force}}
  } catch { Log ('ROLLBACK HATA: '+$_.Exception.Message) }
  if($tmp){Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue}
  Log ('HATA: '+$_.Exception.Message);Write-Error $_.Exception.Message;exit 50
}
