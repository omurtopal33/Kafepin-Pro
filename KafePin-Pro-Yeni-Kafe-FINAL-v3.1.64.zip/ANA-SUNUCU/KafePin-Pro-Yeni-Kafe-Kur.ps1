﻿param(
  [string]$InstallRoot = 'C:\KafePin',
  [switch]$ValidateOnly
)
$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$BaseVersion='3.1.64'
$InstallerBuild='2026.08.22-FINAL-3164-OFFLINE'
$NodeVersion='24.19.0'
$NodeSha256='57f71ab3652e797d84acddc79c81cc9ff1c6ddb2a1974cdb83f00fee9bff4c73'
$TaskName='KafePin Pro Server Manager'
$RestoreTaskName='KafePin Pro Restore Worker'
$FirewallName='KafePin Pro Server 3000'
$SystemRoot=Join-Path $env:ProgramData 'KafePinPro'
$InstallLog=Join-Path $SystemRoot 'install.log'
try{New-Item -ItemType Directory -Force -Path $SystemRoot|Out-Null;Start-Transcript -Path $InstallLog -Append|Out-Null}catch{}
$RuntimeRoot=Join-Path $SystemRoot 'runtime'
$ManagerScript=Join-Path $SystemRoot 'KafePin_System_Manager.ps1'
$RestoreScript=Join-Path $SystemRoot 'KafePin_Restore_Worker.ps1'
$ManagerConfig=Join-Path $SystemRoot 'manager-config.json'
$ManagerToken=Join-Path $SystemRoot 'manager.token'
$Payload=Join-Path $PSScriptRoot 'server'
$PackageManifest=Join-Path $PSScriptRoot 'kurulum-manifest.json'

function Test-PackageIntegrity {
  if(-not(Test-Path $PackageManifest)){throw 'Kurulum butunluk manifesti yok: kurulum-manifest.json'}
  $m=Get-Content -LiteralPath $PackageManifest -Raw -Encoding UTF8|ConvertFrom-Json
  if([string]$m.version -ne $BaseVersion){throw 'Kurulum manifest surumu taban surumle uyusmuyor.'}
  foreach($f in @($m.files)){
    $rel=[string]$f.path
    if([string]::IsNullOrWhiteSpace($rel) -or $rel -match '(^|[\/])\.\.([\/]|$)' -or [IO.Path]::IsPathRooted($rel)){throw ('Gecersiz manifest yolu: '+$rel)}
    $full=Join-Path $PSScriptRoot ($rel -replace '/', [IO.Path]::DirectorySeparatorChar)
    if(-not(Test-Path -LiteralPath $full -PathType Leaf)){throw ('Kurulum dosyasi eksik: '+$rel)}
    $size=(Get-Item -LiteralPath $full).Length
    if([int64]$f.size -ne [int64]$size){throw ('Kurulum dosya boyutu uyusmuyor: '+$rel)}
    $got=(Get-FileHash -Algorithm SHA256 -LiteralPath $full).Hash.ToLowerInvariant()
    if($got -ne ([string]$f.sha256).ToLowerInvariant()){throw ('Kurulum SHA-256 uyusmuyor: '+$rel)}
  }
  Write-Host ('Kurulum paket butunlugu dogrulandi: '+@($m.files).Count+' dosya.') -ForegroundColor Green
}

function Is-Admin { return ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) }
if(-not(Is-Admin)){throw 'Bu kurulum Yonetici olarak calistirilmalidir.'}
if(-not [Environment]::Is64BitOperatingSystem){throw 'KafePin Pro yalniz Windows x64 icindir.'}
if(-not(Test-Path (Join-Path $Payload 'server.js'))){throw 'Kurulum payload/server dosyalari eksik.'}
Test-PackageIntegrity
if($ValidateOnly){Write-Host 'KafePin yeni-kafe paket kontrolü başarılı.' -ForegroundColor Green;exit 0}

function Ask([string]$Text,[string]$Default=''){
  $p=if($Default){"$Text [$Default]"}else{$Text};$v=Read-Host $p;if([string]::IsNullOrWhiteSpace($v)){return $Default};return $v.Trim()
}
function Ask-Yes([string]$Text,[bool]$Default=$true){
  $d=if($Default){'E'}else{'H'};while($true){$v=(Ask "$Text (E/H)" $d).ToUpperInvariant();if($v -in @('E','EVET','Y','YES')){return $true};if($v -in @('H','HAYIR','N','NO')){return $false}}
}
function Write-Step([string]$s){Write-Host ("`n== "+$s+' ==') -ForegroundColor Cyan}
function Compare-Version([string]$a,[string]$b){ try{return ([version]$a).CompareTo([version]$b)}catch{return 0} }
function Invoke-JsonPost([string]$Url,$Body){
  $json=$Body|ConvertTo-Json -Depth 12 -Compress
  return Invoke-RestMethod -Uri $Url -Method Post -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 90
}
function Wait-Health([string]$Base,[int]$Seconds=40){
  $until=(Get-Date).AddSeconds($Seconds);do{try{$h=Invoke-RestMethod -Uri ($Base+'/api/health') -TimeoutSec 3;if($h.ok -and $h.db){return $true}}catch{};Start-Sleep -Milliseconds 700}while((Get-Date)-lt$until);return $false
}
function Get-DefaultLanIp {
  try{
    $x=Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop | Where-Object {$_.IPAddress -notlike '169.254.*' -and $_.IPAddress -ne '127.0.0.1' -and $_.PrefixOrigin -ne 'WellKnown'} | Sort-Object InterfaceMetric | Select-Object -First 1
    if($x){return [string]$x.IPAddress}
  }catch{}
  return '192.168.1.100'
}

Write-Host 'KafePin Pro v3.1.64 FINAL / STABLE — tam kurulum' -ForegroundColor Green
Write-Host ('Kurucu build: '+$InstallerBuild) -ForegroundColor DarkCyan
Write-Host 'Ayni 3.x stabil kanal, EveryCafe guvenli ilk aktarim ve otomatik son surume gecis.'

Write-Step 'On kontrol'
if(Test-Path $InstallRoot){throw "Mevcut kurulum bulundu: $InstallRoot. Yeni-kafe kurucusu mevcut sistemi ezmez."}
$existingTask=Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if($existingTask){throw "Mevcut gorev bulundu: $TaskName"}
$existingRestoreTask=Get-ScheduledTask -TaskName $RestoreTaskName -ErrorAction SilentlyContinue
if($existingRestoreTask){throw "Mevcut gorev bulundu: $RestoreTaskName"}
$listener=Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue;if($listener){throw '3000 portu baska bir uygulama tarafindan kullaniliyor.'}

$masaCount=[int](Ask 'Toplam masa/bilgisayar sayisi' '23');$telegramEnabled=Ask-Yes 'Telegram sağlık ve gün sonu bildirimleri etkinleştirilsin mi?' $false
$telegramToken='';$telegramChatId=''
if($telegramEnabled){
  $telegramToken=Ask 'Telegram bot token' ''
  $telegramChatId=Ask 'Telegram chat ID' ''
  if([string]::IsNullOrWhiteSpace($telegramToken) -or [string]::IsNullOrWhiteSpace($telegramChatId)){throw 'Telegram etkinse bot token ve chat ID zorunludur.'}
}
if($masaCount -lt 1 -or $masaCount -gt 250){throw 'Masa sayisi 1-250 olmali.'}
$serverIp=Ask 'KafePin sunucu LAN IP adresi' (Get-DefaultLanIp)
if($serverIp -notmatch '^(\d{1,3}\.){3}\d{1,3}$'){throw 'Sunucu IP bicimi gecersiz.'}
$parts=$serverIp.Split('.');$prefix=($parts[0..2]-join '.')
$firstHost=[int](Ask 'Masa-1 IP son hanesi' '101');if(($firstHost+$masaCount-1)-gt 254){throw 'IP araligi 254u geciyor.'}
$vipDefault=if($masaCount -ge 3){(($masaCount-2)..$masaCount)-join ','}else{''}
$vipText=Ask 'VIP masa numaralari (virgulle, yoksa bos)' $vipDefault
$vip=@();if($vipText){$vip=@($vipText -split ','|ForEach-Object{[int]$_.Trim()}|Where-Object{$_ -ge 1 -and $_ -le $masaCount}|Select-Object -Unique)}

$ecCandidates=@('C:\Program Files (x86)\EveryCafeManager\ecmdata.ecm','C:\Program Files\EveryCafeManager\ecmdata.ecm','C:\EveryCafe\ecmdata.ecm')
$defaultEc=@($ecCandidates|Where-Object{Test-Path -LiteralPath $_}|Select-Object -First 1)[0]
if(-not$defaultEc){$defaultEc=$ecCandidates[0]}
$ecDetected=Test-Path -LiteralPath $defaultEc
$useEc=Ask-Yes 'Bu kafede EveryCafe kullaniliyor mu?' $ecDetected
$ecPath=''
if($useEc){
  $ecPath=Ask 'EveryCafe ecmdata.ecm yolu' $defaultEc
  if(-not(Test-Path $ecPath)){throw "EveryCafe DB bulunamadi: $ecPath"}
}
$backupDefault=if(Test-Path 'D:\'){'D:\KAFEPIN_YEDEK'}else{'C:\KAFEPIN_YEDEK'}
$backupRoot=Ask 'KafePin yedek klasoru' $backupDefault

Write-Step 'Program dosyalari'
New-Item -ItemType Directory -Force -Path $InstallRoot,$SystemRoot,$RuntimeRoot,$backupRoot|Out-Null
# Payload icerigini tek tek kopyala; mevcut sistem zaten yukarida reddedildi.
Get-ChildItem -LiteralPath $Payload -Force|ForEach-Object{Copy-Item -LiteralPath $_.FullName -Destination $InstallRoot -Recurse -Force}
Remove-Item -LiteralPath (Join-Path $InstallRoot 'database.db') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $InstallRoot 'database.db-wal') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $InstallRoot 'database.db-shm') -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path (Join-Path $InstallRoot 'logs'),(Join-Path $InstallRoot 'config')|Out-Null

$ips=[ordered]@{};$tokens=[ordered]@{}
for($i=1;$i -le $masaCount;$i++){$ips[[string]$i]="$prefix.$($firstHost+$i-1)";$tokens[[string]$i]='KP_'+$i+'_'+[guid]::NewGuid().ToString('N')}
[ordered]@{count=$masaCount;serverIp=$serverIp;ips=$ips;tokens=$tokens;vip=$vip}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $InstallRoot 'config\masalar.json') -Encoding UTF8
$disabledEc=Join-Path $SystemRoot 'everycafe-disabled.ecm'
$effectiveEcPath=if($useEc){$ecPath}else{$disabledEc}
$envLines=@(
  'KAFEPIN_MASA_SAYISI='+$masaCount,
  'KAFEPIN_BACKUP_ROOT='+$backupRoot,
  'EVERYCAFE_DB_PATH='+$effectiveEcPath,
  'TELEGRAM_ENABLED='+$(if($telegramEnabled){'1'}else{'0'}),
  'TELEGRAM_BOT_TOKEN='+$telegramToken,
  'TELEGRAM_CHAT_ID='+$telegramChatId
)
$envLines|Set-Content -LiteralPath (Join-Path $InstallRoot '.env') -Encoding UTF8

Write-Step 'GitHub son surum kontrolu'
try{
  $latest=Invoke-RestMethod -Uri ('https://raw.githubusercontent.com/omurtopal33/Kafepin-Pro/main/latest.json?cb='+[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()) -Headers @{'Cache-Control'='no-cache'} -TimeoutSec 20
  $latestVersion=[string]$latest.version
  if((Compare-Version $latestVersion $BaseVersion) -gt 0){
    Write-Host "Daha yeni stabil surum bulundu: v$latestVersion. Kurulum tabani otomatik guncelleniyor..." -ForegroundColor Yellow
    $tmp=Join-Path $env:TEMP ('KafePin-NewCafe-Update-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $tmp|Out-Null
    $zip=Join-Path $tmp 'update.zip';Invoke-WebRequest -UseBasicParsing -Uri ([string]$latest.downloadUrl) -OutFile $zip
    if($latest.sha256){$got=(Get-FileHash -Algorithm SHA256 -LiteralPath $zip).Hash.ToLowerInvariant();if($got -ne ([string]$latest.sha256).ToLowerInvariant()){throw 'Son surum SHA-256 dogrulamasi basarisiz.'}}
    $exp=Join-Path $tmp 'expanded';Expand-Archive -LiteralPath $zip -DestinationPath $exp -Force
    $info=Get-Content -LiteralPath (Join-Path $exp 'update.json') -Raw -Encoding UTF8|ConvertFrom-Json
    if([string]$info.version -ne $latestVersion){throw 'Update paket surumu manifest ile uyusmuyor.'}
    foreach($rel in @($info.files)){
      if([string]$rel -match '\.\.' -or [IO.Path]::IsPathRooted([string]$rel)){throw 'Gecersiz update yolu.'}
      $src=Join-Path $exp ([string]$rel);$dst=Join-Path $InstallRoot ([string]$rel);if(-not(Test-Path $src)){throw "Update dosyasi eksik: $rel"};New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst)|Out-Null;Copy-Item -LiteralPath $src -Destination $dst -Force
    }
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Kurulum tabani v$latestVersion oldu." -ForegroundColor Green
  }else{Write-Host "Kurulum tabani v$BaseVersion; GitHub stabil kanal daha yeni degil."}
}catch{Write-Warning ('GitHub son surum kontrolu tamamlanamadi; v'+$BaseVersion+' tabaniyla devam ediliyor. Sonra panelden tekrar kontrol edilebilir. '+$_.Exception.Message)}

Write-Step 'İsteğe bağlı PRO bileşenleri'
$componentInstaller=Join-Path $InstallRoot 'KafePin_Pro_Bilesen_Kurulum.ps1'
if(Test-Path -LiteralPath $componentInstaller){
  try{
    if($useEc){
      & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $componentInstaller -InstallRoot $InstallRoot -ProRoot 'C:\KafePinPro' -InitialSetup -EveryCafeEnabled
    }else{
      & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $componentInstaller -InstallRoot $InstallRoot -ProRoot 'C:\KafePinPro' -InitialSetup
    }
    if($LASTEXITCODE -ne 0){Write-Warning ('PRO bileşen kurucusu çıkış kodu: '+$LASTEXITCODE)}
  }catch{Write-Warning ('PRO bileşen seçimi tamamlanamadı; çekirdek kurulum devam ediyor. '+$_.Exception.Message)}
}

Write-Step 'Node.js x64 runtime'
$nodeDir=Join-Path $RuntimeRoot ('node-v'+$NodeVersion+'-win-x64');$nodeExe=Join-Path $nodeDir 'node.exe'
if(-not(Test-Path $nodeExe)){
  $tmp=Join-Path $env:TEMP ('KafePin-Node-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $tmp|Out-Null
  $nodeZip=Join-Path $tmp 'node.zip';$url='https://nodejs.org/dist/v'+$NodeVersion+'/node-v'+$NodeVersion+'-win-x64.zip'
  Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $nodeZip
  $hash=(Get-FileHash -Algorithm SHA256 -LiteralPath $nodeZip).Hash.ToLowerInvariant();if($hash -ne $NodeSha256){throw "Node SHA-256 uyusmuyor: $hash"}
  Expand-Archive -LiteralPath $nodeZip -DestinationPath $RuntimeRoot -Force;Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
if(-not(Test-Path $nodeExe)){throw 'Node runtime kurulumu dogrulanamadi.'}

Write-Step 'Windows Sistem Yoneticisi'
Copy-Item -LiteralPath (Join-Path $InstallRoot 'KafePin_System_Manager.ps1') -Destination $ManagerScript -Force
Copy-Item -LiteralPath (Join-Path $InstallRoot 'KafePin_Restore_Worker.ps1') -Destination $RestoreScript -Force
$installedVersion=$BaseVersion
try{
  $installedVersionJson=Get-Content -LiteralPath (Join-Path $InstallRoot 'kafepin-pro-version.json') -Raw -Encoding UTF8|ConvertFrom-Json
  if($installedVersionJson.version){$installedVersion=[string]$installedVersionJson.version}
}catch{}
[ordered]@{root=$InstallRoot;nodePath=$nodeExe;port=3000;controlPort=2999;version=$installedVersion}|ConvertTo-Json|Set-Content -LiteralPath $ManagerConfig -Encoding UTF8
if(-not(Test-Path $ManagerToken)){[guid]::NewGuid().ToString('N')|Set-Content -LiteralPath $ManagerToken -Encoding ASCII}
Remove-Item (Join-Path $SystemRoot 'server.manual-stop') -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $SystemRoot 'maintenance.lock') -Force -ErrorAction SilentlyContinue
# Windows 11 yerlesik ScheduledTasks/NetSecurity cmdlet'lerini kullan.
# Ilk kurulumda gorev/firewall kurali bulunmamasi normaldir; hata sayilmaz.
$oldTask=Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if($oldTask){ Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction Stop }
$taskArg='-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+$ManagerScript+'" -Loop'
$taskAction=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $taskArg
$taskTrigger=New-ScheduledTaskTrigger -AtStartup
$taskPrincipal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName $TaskName -Action $taskAction -Trigger $taskTrigger -Principal $taskPrincipal -Force | Out-Null
$oldRestoreTask=Get-ScheduledTask -TaskName $RestoreTaskName -ErrorAction SilentlyContinue
if($oldRestoreTask){ Unregister-ScheduledTask -TaskName $RestoreTaskName -Confirm:$false -ErrorAction Stop }
$restoreArg='-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+$RestoreScript+'"'
$restoreAction=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $restoreArg
$restoreTrigger=New-ScheduledTaskTrigger -AtStartup
Register-ScheduledTask -TaskName $RestoreTaskName -Action $restoreAction -Trigger $restoreTrigger -Principal $taskPrincipal -Force | Out-Null
Remove-NetFirewallRule -DisplayName $FirewallName -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName $FirewallName -Direction Inbound -Action Allow -Protocol TCP -LocalPort 3000 -Profile Private -ErrorAction Stop | Out-Null
Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop
$base='http://127.0.0.1:3000';if(-not(Wait-Health $base 45)){throw 'KafePin sunucusu 45 saniye icinde saglik kontrolu vermedi.'}
Write-Host 'Sunucu hazir.' -ForegroundColor Green

if($useEc){
  Write-Step 'EveryCafe ilk gecis - ON KONTROL'
  $opt=[ordered]@{includeTables=$true;includeDirect=$true;includeMembers=$true}
  $pre=Invoke-JsonPost ($base+'/admin/everycafe/history/precheck') $opt
  Write-Host ('Kaynak kayit : '+$pre.sourceRecords)
  Write-Host ('EveryCafe toplam: '+('{0:N2}' -f [double]$pre.sourceTotal)+' TL')
  Write-Host ('Yeni kayit    : '+$pre.newRecords+' / '+('{0:N2}' -f [double]$pre.newTotal)+' TL')
  Write-Host ('Ucretsiz/test : '+$pre.ignoredFreeRecords+' (tamamen haric)')
  Write-Host ('Silme audit   : '+$pre.deletedAuditEvents+' (sadece bilgi)')
  Write-Host ('Cift kayit riski: '+$pre.doubleRecordRisk)
  if(-not $pre.safe -or [int]$pre.doubleRecordRisk -ne 0 -or [int]$pre.conflictRecords -ne 0){throw 'EveryCafe on kontrol guvenli degil. Aktarim yapilmadi; Geçmis Aktarim ekranindan inceleyin.'}
  $historyOkay=$true
  if([int]$pre.newRecords -gt 0){
    if(Ask-Yes ("Bu "+$pre.newRecords+" kayit / "+('{0:N2}' -f [double]$pre.newTotal)+" TL KafePin'e aktarilsin mi? Once tam yedek alinacak.") $true){
      $imp=Invoke-JsonPost ($base+'/admin/everycafe/history/import') ([ordered]@{token=$pre.token;options=$pre.options})
      if(-not$imp.ok -or [int]$imp.remainingNew -ne 0){throw 'EveryCafe gecmis aktarimi son dogrulamayi gecemedi.'}
      $verify=Invoke-JsonPost ($base+'/admin/everycafe/history/precheck') $opt
      if([int]$verify.newRecords -ne 0 -or [int]$verify.doubleRecordRisk -ne 0){throw 'EveryCafe ikinci on kontrolde yeni/tekrar kayit kaldi.'}
      Write-Host 'EveryCafe gecmis aktarimi tamam: ikinci kontrolde YENI 0.' -ForegroundColor Green
    }else{$historyOkay=$false;Write-Warning 'Gecmis aktarim kullanici tarafindan ertelendi. Canli EveryCafe aktarimi baslatilmayacak.'}
  }
  Write-Step 'EveryCafe urun/kategori ilk senkron'
  $cat=Invoke-JsonPost ($base+'/admin/everycafe/catalog-sync-now') @{}
  if(-not$cat.ok){throw 'EveryCafe katalog senkronu basarisiz.'}
  Write-Host ("Katalog: "+$cat.sourceCategories+" kategori / "+$cat.sourceProducts+" urun") -ForegroundColor Green
  if($historyOkay){$live=Invoke-JsonPost ($base+'/admin/everycafe/start-test') @{};if(-not$live.ok){throw 'EveryCafe canli aktarim baslatilamadi.'};Write-Host 'EveryCafe canli entegrasyon aktif: yalniz bu andan sonraki kapanislar.' -ForegroundColor Green}
}

Write-Step 'KafePin Pro masaustu uygulamasi'
try{& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $InstallRoot 'KafePin_Desktop_App_Setup.ps1') -InstallRoot $InstallRoot -Launch;if($LASTEXITCODE -ne 0){throw 'desktop setup hata'}}catch{Write-Warning ('Masaustu uygulamasi otomatik kurulamadı. Sunucu calisiyor; panel: '+$base+'/kafepin-pro-yonetim.html. Hata: '+$_.Exception.Message)}

Write-Step 'Kurulum tamamlandi'
Write-Host ('KafePin Pro: '+$base+'/kafepin-pro-yonetim.html') -ForegroundColor Green
Write-Host ('LAN adresi : http://'+$serverIp+':3000')
Write-Host ('Masa sayisi: '+$masaCount+' | IP araligi: '+$prefix+'.'+$firstHost+' - '+$prefix+'.'+($firstHost+$masaCount-1))
if($useEc){Write-Host 'EveryCafe: AKTIF / guvenli ilk gecis motoru kullanildi.'}else{Write-Host 'EveryCafe: KULLANILMIYOR.'}
Write-Host 'Client PC kurucusu: Diskless-Client-Paketi\KafePin-Client-Kur.ps1'
