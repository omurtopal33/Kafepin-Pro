$ErrorActionPreference='Continue'
Write-Host 'KafePin Pro Yeni Kafe - On Kontrol' -ForegroundColor Cyan
$manifest=Join-Path $PSScriptRoot 'kurulum-manifest.json'
try{
  if(-not(Test-Path $manifest)){throw 'kurulum-manifest.json yok'}
  $m=Get-Content -LiteralPath $manifest -Raw -Encoding UTF8|ConvertFrom-Json;$bad=@()
  foreach($f in @($m.files)){$full=Join-Path $PSScriptRoot (([string]$f.path)-replace '/', [IO.Path]::DirectorySeparatorChar);if(-not(Test-Path -LiteralPath $full -PathType Leaf)){$bad+=([string]$f.path);continue};$got=(Get-FileHash -Algorithm SHA256 -LiteralPath $full).Hash.ToLowerInvariant();if($got -ne ([string]$f.sha256).ToLowerInvariant()){$bad+=([string]$f.path)}}
  if($bad.Count){Write-Host ('Paket butunlugu HATALI: '+($bad -join ', ')) -ForegroundColor Red}else{Write-Host ('Paket butunlugu: OK ('+@($m.files).Count+' dosya)') -ForegroundColor Green}
}catch{Write-Warning ('Paket butunlugu kontrol edilemedi: '+$_.Exception.Message)}
$admin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
Write-Host ('Yonetici: '+$admin)
Write-Host ('Windows x64: '+[Environment]::Is64BitOperatingSystem)
Write-Host ('C:\KafePin mevcut: '+(Test-Path 'C:\KafePin'))
$ecCandidates=@('C:\Program Files (x86)\EveryCafeManager\ecmdata.ecm','C:\Program Files\EveryCafeManager\ecmdata.ecm','C:\EveryCafe\ecmdata.ecm');$ec=@($ecCandidates|Where-Object{Test-Path -LiteralPath $_}|Select-Object -First 1)[0];if($ec){Write-Host ('EveryCafe DB: TRUE • '+$ec) -ForegroundColor Green}else{Write-Host ('EveryCafe DB otomatik bulunamadi. Kurulumda yol elle secilebilir.') -ForegroundColor Yellow}
try{$p=Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction Stop;Write-Host ('Port 3000 BOS DEGIL • PID '+$p.OwningProcess) -ForegroundColor Red}catch{Write-Host 'Port 3000 bos.' -ForegroundColor Green}
try{$x=Invoke-RestMethod 'https://raw.githubusercontent.com/omurtopal33/Kafepin-Pro/main/latest.json' -TimeoutSec 10;Write-Host ('GitHub stabil: v'+$x.version) -ForegroundColor Green}catch{Write-Warning 'GitHub latest.json okunamadi.'}
try{$n=Invoke-WebRequest -UseBasicParsing -Method Head 'https://nodejs.org/dist/v24.19.0/node-v24.19.0-win-x64.zip' -TimeoutSec 10;Write-Host 'Node.js indirme erisimi: OK' -ForegroundColor Green}catch{Write-Warning 'Node.js indirme adresine erisilemiyor.'}
