﻿$ErrorActionPreference='Stop'
if(-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Yonetici olarak calistirin.'}
$ans=(Read-Host 'KafePin Pro yeni-kafe kurulumu tamamen kaldirilsin mi? database.db DAHIL silinir. SIL yazin').Trim()
if($ans -cne 'SIL'){Write-Host 'Iptal.';exit}
$t=Get-ScheduledTask -TaskName 'KafePin Pro Server Manager' -ErrorAction SilentlyContinue;if($t){Stop-ScheduledTask -TaskName 'KafePin Pro Server Manager' -ErrorAction SilentlyContinue;Unregister-ScheduledTask -TaskName 'KafePin Pro Server Manager' -Confirm:$false -ErrorAction SilentlyContinue}
$rw=Get-ScheduledTask -TaskName 'KafePin Pro Restore Worker' -ErrorAction SilentlyContinue;if($rw){Stop-ScheduledTask -TaskName 'KafePin Pro Restore Worker' -ErrorAction SilentlyContinue;Unregister-ScheduledTask -TaskName 'KafePin Pro Restore Worker' -Confirm:$false -ErrorAction SilentlyContinue}
Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue|Where-Object{$_.CommandLine -like '*C:\KafePin\server.js*'}|ForEach-Object{Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue}
netsh advfirewall firewall delete rule name='KafePin Pro Server 3000'|Out-Null
Remove-Item 'C:\KafePin' -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $env:ProgramData 'KafePinPro') -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'KafePin Pro kaldirildi. Harici yedek klasoru guvenlik icin silinmedi.' -ForegroundColor Green
