# KafePin Pro 3.x direct updater compatibility marker.
# v3.0.14+ updates are extracted/verified/copied by server.js itself.
param([string]$LocalZipPath='', [string]$ExpectedVersion='', [switch]$SkipBackup)
Write-Output 'KAFEPIN_DIRECT_UPDATER_SERVER_MANAGED'
exit 0
