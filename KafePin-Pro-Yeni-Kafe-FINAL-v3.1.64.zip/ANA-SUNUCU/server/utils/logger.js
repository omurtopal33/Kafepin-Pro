'use strict';
function logErr(where,err){if(err)console.error(`[${where}]`,err);}
function logInfo(where,data){try{console.log(`[${where}]`,typeof data==='string'?data:JSON.stringify(data));}catch(_e){console.log(`[${where}]`,data);}}
module.exports={logErr,logInfo};
