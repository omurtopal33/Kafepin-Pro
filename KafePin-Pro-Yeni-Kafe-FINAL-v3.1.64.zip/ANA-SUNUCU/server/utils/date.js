'use strict';
module.exports=function createDateUtils(DAY_SHIFT_MS){
  const shift=Number(DAY_SHIFT_MS)||0;
  function dayKey(ts){return new Date((Number(ts)||0)-shift).toDateString();}
  function dayStartTs(ts){const d=new Date((Number(ts)||0)-shift);return new Date(d.getFullYear(),d.getMonth(),d.getDate()).getTime()+shift;}
  return {dayKey,dayStartTs};
};
