﻿param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$Reason = 'automatic',
  [switch]$WaitForDownFirst,
  [switch]$LaunchDesktop
)

$ErrorActionPreference = 'SilentlyContinue'
$SystemRoot = Join-Path $env:ProgramData 'KafePinPro'
$LogDir = Join-Path $SystemRoot 'logs'
$LogFile = Join-Path $LogDir 'recovery.log'
$DesktopExe = Join-Path $InstallRoot 'desktop-app\KafePin Pro.exe'
$EnsureScript = Join-Path $InstallRoot 'KafePin_Manager_Ensure.ps1'
New-Item -ItemType Directory -Force -Path $SystemRoot,$LogDir | Out-Null

function Log([string]$Message) { try { Add-Content -LiteralPath $LogFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' [recovery-3.1.29] ' + $Message) -Encoding UTF8 } catch {} }
function Health {
  try {
    $r=Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:3000/api/health?_recovery=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 2 -Headers @{'Cache-Control'='no-cache'}
    return ($r.StatusCode -ge 200 -and $r.StatusCode -lt 300)
  } catch { return $false }
}
function Wait-Health([int]$Seconds) { for($i=0;$i -lt $Seconds;$i++){ if(Health){return $true}; Start-Sleep -Seconds 1 }; return $false }
function Start-Desktop {
  if(-not $LaunchDesktop){return}
  try { if((Get-Process -Name 'KafePin Pro' -ErrorAction SilentlyContinue).Count -gt 0){return} } catch {}
  if(Test-Path -LiteralPath $DesktopExe){ try { Start-Process -FilePath $DesktopExe -WorkingDirectory (Split-Path -Parent $DesktopExe)|Out-Null } catch {} }
}

Log ('Kurtarma istegi • ' + $Reason)
if($WaitForDownFirst){ for($i=0;$i -lt 20;$i++){ if(-not(Health)){break}; Start-Sleep -Seconds 1 } }
if(Health){ Log 'Sunucu zaten saglikli.'; Start-Desktop; exit 0 }

# STABLE: Recovery Node baslatmaz ve art arda schtasks tetiklemez.
# Tek gorevi Manager Ensure ile kalici Server Manager'i dogrulamak.
if(Test-Path -LiteralPath $EnsureScript){
  try {
    $p=Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$EnsureScript,'-InstallRoot',$InstallRoot) -Wait -PassThru -WindowStyle Hidden
    Log ('Manager Ensure cikis=' + $p.ExitCode)
  } catch { Log ('Manager Ensure baslatilamadi: ' + $_.Exception.Message) }
}else{
  try { & schtasks.exe /Run /TN 'KafePin Pro Server Manager' 2>$null | Out-Null; Log 'Server Manager gorevi bir kez tetiklendi.' } catch {}
}

if(Wait-Health 60){ Log 'BASARILI: Server Manager ile sunucu acildi.'; Start-Desktop; exit 0 }
Log 'BASARISIZ: Server Manager sunucuyu acamadi.'
exit 1
