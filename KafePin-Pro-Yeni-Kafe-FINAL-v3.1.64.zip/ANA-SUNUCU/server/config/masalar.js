'use strict';
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const cfgPath=path.join(__dirname,'masalar.json');
let cfg={};try{cfg=JSON.parse(fs.readFileSync(cfgPath,'utf8'));}catch(_e){}
const count=Math.max(1,Math.min(250,Number(process.env.KAFEPIN_MASA_SAYISI||cfg.count||23)||23));
const MASA_IPS={};const MASA_TOKENS={};
for(let i=1;i<=count;i++){
  MASA_IPS[i]=String((cfg.ips&&cfg.ips[i])||(cfg.ips&&cfg.ips[String(i)])||`192.168.1.${100+i}`);
  MASA_TOKENS[i]=String((cfg.tokens&&cfg.tokens[i])||(cfg.tokens&&cfg.tokens[String(i)])||`KP_${i}_${crypto.createHash('sha256').update('KafePin-NewCafe-'+i).digest('hex').slice(0,24)}`);
}
const VIP_MASALAR=(Array.isArray(cfg.vip)?cfg.vip:[]).map(Number).filter(n=>n>=1&&n<=count);
module.exports={MASA_TOKENS,MASA_IPS,VIP_MASALAR,MASA_SAYISI:count};
