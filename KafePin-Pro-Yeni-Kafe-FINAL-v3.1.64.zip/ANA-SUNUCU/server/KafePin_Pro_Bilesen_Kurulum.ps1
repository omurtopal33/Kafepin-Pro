﻿param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$ProRoot = 'C:\KafePinPro',
  [switch]$InitialSetup,
  [switch]$EveryCafeEnabled,
  [switch]$ForceInitialSetup
)

$ErrorActionPreference = 'Stop'
try{$utf8=New-Object System.Text.UTF8Encoding($false);[Console]::OutputEncoding=$utf8;$OutputEncoding=$utf8}catch{}
$PayloadRoot = Join-Path $InstallRoot 'pro-components'
$StatePath = Join-Path $InstallRoot 'config\pro-components.json'
$FreshInstall = -not (Test-Path -LiteralPath (Join-Path $InstallRoot 'database.db'))

# Çekirdek C:\KafePin altında kalır. İsteğe bağlı PRO modülleri kendi ortak
# köklerinde çalışır ve çekirdeğin dosyalarına/DB'sine erişmez.
$ComponentTargets = [ordered]@{
  mp3       = Join-Path $ProRoot 'MP3BotPRO'
  printer   = Join-Path $ProRoot 'YaziciPRO'
  technical = Join-Path $ProRoot 'TeknikServisPRO'
  client    = Join-Path $ProRoot 'ClientYonetimPRO'
}

function Write-ComponentLog([string]$Text) {
  $log = Join-Path $InstallRoot 'logs\pro-components-install.log'
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $log) | Out-Null
  Add-Content -LiteralPath $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Text) -Encoding UTF8
}

function Ask-Component([string]$Title, [string]$Text) {
  Write-Host ''
  Write-Host ('=== ' + $Title + ' ===') -ForegroundColor Cyan
  Write-Host $Text -ForegroundColor White
  while ($true) {
    $answer = (Read-Host 'Kurulsun mu? (E/H) [H]').Trim().ToUpperInvariant()
    if ([string]::IsNullOrWhiteSpace($answer) -or $answer -in @('H','HAYIR','N','NO')) { return $false }
    if ($answer -in @('E','EVET','Y','YES')) { return $true }
    Write-Host 'Lütfen E veya H girin.' -ForegroundColor Yellow
  }
}

function Copy-Component([string]$SourceName, [string]$TargetPath) {
  $source = Join-Path $PayloadRoot ($SourceName + '.zip')
  if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
    throw "Bileşen paketi bulunamadı: $SourceName"
  }
  $temp = Join-Path $env:TEMP ('KafePin-Pro-Component-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $temp | Out-Null
  try {
    Expand-Archive -LiteralPath $source -DestinationPath $temp -Force
    if (-not (Get-ChildItem -LiteralPath $temp -Force | Select-Object -First 1)) {
      throw "Bileşen paketi boş: $SourceName"
    }
    New-Item -ItemType Directory -Force -Path $TargetPath | Out-Null
    Get-ChildItem -LiteralPath $temp -Force | ForEach-Object {
      Copy-Item -LiteralPath $_.FullName -Destination $TargetPath -Recurse -Force
    }
  } finally {
    Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
  }
}

function Invoke-ComponentSetup([string]$ComponentName, [string]$FilePath, [string]$Arguments, [string]$WorkingDirectory, [int]$TimeoutSeconds = 600) {
  $safeName = ($ComponentName -replace '[^a-zA-Z0-9]+','-').Trim('-').ToLowerInvariant()
  $logDir = Join-Path $InstallRoot 'logs'
  New-Item -ItemType Directory -Force -Path $logDir | Out-Null
  $outLog = Join-Path $logDir ('pro-'+$safeName+'-setup.out.log')
  $errLog = Join-Path $logDir ('pro-'+$safeName+'-setup.err.log')
  Remove-Item -LiteralPath $outLog,$errLog -Force -ErrorAction SilentlyContinue
  $p = Start-Process -FilePath $FilePath -ArgumentList $Arguments -WorkingDirectory $WorkingDirectory -WindowStyle Hidden -RedirectStandardOutput $outLog -RedirectStandardError $errLog -PassThru
  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  $nextNotice = Get-Date
  while (-not $p.HasExited) {
    if ((Get-Date) -ge $deadline) {
      try { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue } catch {}
      throw ($ComponentName+' kurulumu '+$TimeoutSeconds+' saniye içinde tamamlanmadı. Günlük: '+$outLog)
    }
    if ((Get-Date) -ge $nextNotice) {
      $remaining = [math]::Max(0,[int](($deadline-(Get-Date)).TotalSeconds))
      Write-Host ('… '+$ComponentName+' hazırlanıyor; kalan en fazla '+$remaining+' sn. (günlük: '+$outLog+')') -ForegroundColor DarkCyan
      $nextNotice = (Get-Date).AddSeconds(5)
    }
    Start-Sleep -Milliseconds 500
    $p.Refresh()
  }
  try { $p.WaitForExit(); $exitCode = $p.ExitCode } catch { $exitCode = $null }
  # Bazı Windows/cmd.exe sürümleri çıkış kodunu Process nesnesine boş
  # döndürüyor; bağımlılıklar zaten başarıyla kurulduysa bunu sahte hata
  # sayma. Gerçek sıfır-dışı kodlar yine günlükle birlikte durdurulur.
  if ($null -ne $exitCode -and $exitCode -ne 0) {
    $detail = @()
    foreach($logFile in @($errLog,$outLog)) { if(Test-Path -LiteralPath $logFile){ $detail += @(Get-Content -LiteralPath $logFile -Tail 8 -ErrorAction SilentlyContinue) } }
    throw ($ComponentName+' kurulum çıkış kodu: '+$exitCode+$(if($detail.Count){' — '+(($detail -join ' ') -replace '\s+',' ').Trim()}else{''}))
  }
  Write-Host ('✓ '+$ComponentName+' bağımlılık kurulumu tamamlandı.') -ForegroundColor Green
}

function Prepare-Mp3Setup([string]$Root) {
  $setup = Join-Path $Root 'KURULUM.cmd'
  if (-not (Test-Path -LiteralPath $setup)) { throw 'MP3 Bot PRO KURULUM.cmd bulunamadı.' }
  $text = Get-Content -LiteralPath $setup -Raw
  $text = $text.Replace('--disable-pip-version-check --upgrade pip','--disable-pip-version-check --timeout 30 --retries 2 --upgrade pip')
  $text = $text.Replace('--disable-pip-version-check -r requirements.txt','--disable-pip-version-check --timeout 30 --retries 2 -r requirements.txt')
  Set-Content -LiteralPath $setup -Value $text -Encoding ASCII
}

function Start-Mp3Service([string]$Root) {
  $launcher = Join-Path $Root 'START_WEB.ps1'
  if (-not (Test-Path -LiteralPath $launcher)) { throw 'MP3 Bot PRO servis başlatıcısı bulunamadı.' }
  Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$launcher) -WorkingDirectory $Root -WindowStyle Hidden | Out-Null
}

function Start-PrinterService([string]$Root) {
  $serviceHost = Join-Path $Root 'KafePin_YaziciPRO_ServiceHost.ps1'
  if (-not (Test-Path -LiteralPath $serviceHost)) { throw 'Yazıcı PRO servis başlatıcısı bulunamadı.' }
  Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$serviceHost,'-InstallRoot',$Root) -WorkingDirectory $Root -WindowStyle Hidden | Out-Null
}

function Start-TechnicalService([string]$Root) {
  $py = Ensure-Python3
  $args = if ([IO.Path]::GetFileName($py.Source) -ieq 'py.exe') { @('-3', '-B', 'web_service.py') } else { @('-B', 'web_service.py') }
  Start-Process -FilePath $py.Source -ArgumentList $args -WorkingDirectory $Root -WindowStyle Hidden | Out-Null
}

function Start-ClientManagementService([string]$Root) {
  $py = Ensure-Python3
  $service = Join-Path $Root 'web_service.py'
  if (-not (Test-Path -LiteralPath $service)) { throw 'Client Yönetim PRO web servisi bulunamadı.' }
  $taskName = 'KafePin Client Yonetim PRO'
  $runArgs = if ([IO.Path]::GetFileName($py.Source) -ieq 'py.exe') { '-3 -B "' + $service + '"' } else { '-B "' + $service + '"' }
  $action = New-ScheduledTaskAction -Execute $py.Source -Argument $runArgs -WorkingDirectory $Root
  $userId = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
  $trigger = New-ScheduledTaskTrigger -AtLogOn -User $userId
  $principal = New-ScheduledTaskPrincipal -UserId $userId -LogonType Interactive -RunLevel Highest
  $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
  Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'KafePin Client PRO - EveryCafe UI köprüsü; DB salt okunur.' -Force | Out-Null
  Start-ScheduledTask -TaskName $taskName
}

if (-not $InitialSetup -or ((-not $FreshInstall) -and (-not $ForceInitialSetup)) -or ((Test-Path -LiteralPath $StatePath) -and (-not $ForceInitialSetup))) {
  exit 0
}
if (-not (Test-Path -LiteralPath (Join-Path $PayloadRoot 'mp3-bot-pro.zip') -PathType Leaf)) {
  Write-ComponentLog 'Bileşen seçimi atlandı: paket klasörü yok.'
  exit 0
}

$choices = [ordered]@{
  mp3 = Ask-Component 'KafePin MP3 Bot PRO' 'MP3 Bot PRO kurulsun mu?`n`nYouTube arama/indirme, Dinleme Modu, Winamp Modu ve Favori Listem bağımsız olarak kurulacaktır.'
  printer = Ask-Component 'KafePin Yazıcı PRO' 'Yazıcı PRO kurulsun mu?`n`nTarayıcı, kimlik fotokopisi, PDF/dosya dönüştürme ve Windows yazıcı seçimi kurulacaktır.'
  technical = Ask-Component 'KafePin Teknik Servis PRO' 'Teknik Servis PRO kurulsun mu?`n`nServis kaydı, A4 servis fişi ve Nakit/Kart tahsilat kaydı bağımsız olarak kurulacaktır.'
  client = $(if ($EveryCafeEnabled) { Ask-Component 'KafePin Client Yönetim PRO' 'Client Yönetim PRO kurulsun mu?`n`nCanlı masa durumunu salt okunur gösterir; uyandırma, yeniden başlatma, süreli/süresiz/ücretsiz oturum açma, açık oturuma süre ekleme ve onaylı çalışan uygulamaları sonlandırma araçlarını sağlar. Bilgisayar/hesap/masa kapatma ve tahsilat yapmaz.' } else { $false })
}


function Ensure-Python3 {
  $py = Get-Command py.exe -ErrorAction SilentlyContinue
  if ($py) { return $py }
  foreach($candidate in @((Join-Path $env:ProgramFiles 'Python313\python.exe'),(Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'))){
    if(Test-Path -LiteralPath $candidate){return [pscustomobject]@{ Source = $candidate; IsPythonExe = $true }}
  }
  $url='https://www.python.org/ftp/python/3.13.15/python-3.13.15-amd64.exe'
  $expected='edec09c4853aeae9ac36efb8c9f95b6b8e2fee65eee56d9767a8b7c69c574403'
  $temp=Join-Path $env:TEMP ('KafePin-Python-'+[guid]::NewGuid().ToString('N')+'.exe')
  try{
    Write-ComponentLog 'Python 3 bulunamadı; resmi Python kurucusu indiriliyor.'
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $temp
    if((Get-FileHash -Algorithm SHA256 -LiteralPath $temp).Hash.ToLowerInvariant() -ne $expected){throw 'Python indirilen dosya SHA-256 doğrulamasını geçemedi.'}
    $process=Start-Process -FilePath $temp -ArgumentList @('/quiet','InstallAllUsers=1','PrependPath=1','Include_test=0') -Wait -PassThru
    if($process.ExitCode -ne 0){throw ('Python 3 kurulum çıkış kodu: '+$process.ExitCode)}
  }finally{Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue}
  $py = Get-Command py.exe -ErrorAction SilentlyContinue
  if (-not $py) {
    foreach($candidate in @((Join-Path $env:ProgramFiles 'Python313\python.exe'),(Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'))){
      if (Test-Path -LiteralPath $candidate) { return [pscustomobject]@{ Source = $candidate; IsPythonExe = $true } }
    }
    throw 'Python 3 kurulumu tamamlandı ancak py.exe/python.exe bulunamadı.'
  }
  return $py
}

$result = [ordered]@{ version = '3.1.64'; installedAt = (Get-Date).ToString('o'); choices = $choices; results = [ordered]@{} }

$selectedComponents=@('mp3','printer','technical','client')|Where-Object{$choices[$_]}
$selectedIndex=0
foreach ($name in @('mp3', 'printer', 'technical', 'client')) {
  if (-not $choices[$name]) { $result.results[$name] = 'skipped'; continue }
  $selectedIndex++
  $componentLabel=@{mp3='MP3 Bot PRO';printer='Yazıcı PRO';technical='Teknik Servis PRO';client='Client Yönetim PRO'}[$name]
  $percent=[math]::Floor((($selectedIndex-1)*100)/[math]::Max(1,$selectedComponents.Count))
  Write-Progress -Activity 'PRO servisleri kuruluyor' -Status ($componentLabel+' kuruluyor ('+$selectedIndex+'/'+$selectedComponents.Count+')') -PercentComplete $percent
  Write-Host ('['+$selectedIndex+'/'+$selectedComponents.Count+'] '+$componentLabel+' kuruluyor...') -ForegroundColor Cyan
  try {
    if ($name -eq 'mp3') {
      $target = $ComponentTargets.mp3
      Copy-Component 'mp3-bot-pro' $target
      Prepare-Mp3Setup $target
      Invoke-ComponentSetup 'MP3 Bot PRO' 'cmd.exe' '/d /c KURULUM.cmd /silent' $target 600
      Start-Mp3Service $target
    } elseif ($name -eq 'printer') {
      $target = $ComponentTargets.printer
      Copy-Component 'yazici-pro' $target
      Invoke-ComponentSetup 'Yazıcı PRO' 'cmd.exe' '/d /c KURULUM.cmd /silent' $target 600
      Start-PrinterService $target
    } else {
      $null = Ensure-Python3
      if ($name -eq 'client') {
        $target = $ComponentTargets.client
        Copy-Component 'client-yonetim-pro' $target
        Start-ClientManagementService $target
      } else {
      $target = $ComponentTargets.technical
      Copy-Component 'teknik-servis-pro' $target
      Start-TechnicalService $target
      }
    }
    $result.results[$name] = 'installed'
    Write-ComponentLog "$name kuruldu: $target"
  } catch {
    $result.results[$name] = 'failed: ' + $_.Exception.Message
    Write-Host ('✗ '+$componentLabel+' kurulamadı: '+$_.Exception.Message) -ForegroundColor Red
    Write-ComponentLog "$name kurulamadı: $($_.Exception.Message)"
  }
}

Write-Progress -Activity 'PRO servisleri kuruluyor' -Completed
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $StatePath) | Out-Null
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $StatePath -Encoding UTF8
$failed = @($result.results.Values | Where-Object { $_ -like 'failed:*' })
Write-Host ''
if ($failed.Count -gt 0) {
  Write-Host 'Seçilen bazı PRO bileşenleri kurulamadı.' -ForegroundColor Yellow
  Write-Host 'Ayrıntı: C:\KafePin\logs\pro-components-install.log' -ForegroundColor Yellow
} else {
  Write-Host 'PRO bileşen seçimleri tamamlandı. Seçilen paneller KafePin masaüstü uygulamasında hazırdır.' -ForegroundColor Green
}
