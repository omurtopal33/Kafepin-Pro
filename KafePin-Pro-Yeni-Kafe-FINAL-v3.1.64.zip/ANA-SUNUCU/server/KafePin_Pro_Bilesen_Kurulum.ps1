﻿param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$ProRoot = 'C:\KafePinPro',
  [switch]$InitialSetup,
  [switch]$EveryCafeEnabled
)

$ErrorActionPreference = 'Stop'
$PayloadRoot = Join-Path $InstallRoot 'pro-components'
$StatePath = Join-Path $InstallRoot 'config\pro-components.json'
$FreshInstall = -not (Test-Path -LiteralPath (Join-Path $InstallRoot 'database.db'))

# Çekirdek C:\KafePin altında kalır. İsteğe bağlı PRO modülleri kendi ortak
# köklerinde çalışır ve çekirdeğin dosyalarına/DB'sine erişmez.
$ComponentTargets = [ordered]@{
  mp3       = Join-Path $ProRoot 'MP3BotPRO'
  printer   = Join-Path $ProRoot 'YaziciPRO'
  technical = Join-Path $ProRoot 'TeknikServisPRO'
  client    = Join-Path $ProRoot 'ClientYonetimPRO'
}

function Write-ComponentLog([string]$Text) {
  $log = Join-Path $InstallRoot 'logs\pro-components-install.log'
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $log) | Out-Null
  Add-Content -LiteralPath $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Text) -Encoding UTF8
}

function Ask-Component([string]$Title, [string]$Text) {
  Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
  $answer = [System.Windows.Forms.MessageBox]::Show(
    $Text,
    $Title,
    [System.Windows.Forms.MessageBoxButtons]::YesNo,
    [System.Windows.Forms.MessageBoxIcon]::Question,
    [System.Windows.Forms.MessageBoxDefaultButton]::Button2
  )
  return $answer -eq [System.Windows.Forms.DialogResult]::Yes
}

function Copy-Component([string]$SourceName, [string]$TargetPath) {
  $source = Join-Path $PayloadRoot ($SourceName + '.zip')
  if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
    throw "Bileşen paketi bulunamadı: $SourceName"
  }
  $temp = Join-Path $env:TEMP ('KafePin-Pro-Component-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $temp | Out-Null
  try {
    Expand-Archive -LiteralPath $source -DestinationPath $temp -Force
    if (-not (Get-ChildItem -LiteralPath $temp -Force | Select-Object -First 1)) {
      throw "Bileşen paketi boş: $SourceName"
    }
    New-Item -ItemType Directory -Force -Path $TargetPath | Out-Null
    Get-ChildItem -LiteralPath $temp -Force | ForEach-Object {
      Copy-Item -LiteralPath $_.FullName -Destination $TargetPath -Recurse -Force
    }
  } finally {
    Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
  }
}

function Invoke-SilentCmd([string]$FilePath, [string]$Arguments, [string]$WorkingDirectory) {
  $p = Start-Process -FilePath $FilePath -ArgumentList $Arguments -WorkingDirectory $WorkingDirectory -WindowStyle Hidden -Wait -PassThru
  if ($p.ExitCode -ne 0) { throw "Kurulum çıkış kodu: $($p.ExitCode)" }
}

function Start-Mp3Service([string]$Root) {
  $launcher = Join-Path $Root 'START_WEB.ps1'
  Invoke-SilentCmd 'powershell.exe' ('-NoProfile -ExecutionPolicy Bypass -File "' + $launcher + '"') $Root
}

function Start-PrinterService([string]$Root) {
  $host = Join-Path $Root 'KafePin_YaziciPRO_ServiceHost.ps1'
  if (-not (Test-Path -LiteralPath $host)) { throw 'Yazıcı PRO servis başlatıcısı bulunamadı.' }
  Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$host,'-InstallRoot',$Root) -WorkingDirectory $Root -WindowStyle Hidden | Out-Null
}

function Start-TechnicalService([string]$Root) {
  $py = Ensure-Python3
  $args = if ([IO.Path]::GetFileName($py.Source) -ieq 'py.exe') { @('-3', '-B', 'web_service.py') } else { @('-B', 'web_service.py') }
  Start-Process -FilePath $py.Source -ArgumentList $args -WorkingDirectory $Root -WindowStyle Hidden | Out-Null
}

function Start-ClientManagementService([string]$Root) {
  $py = Ensure-Python3
  $service = Join-Path $Root 'web_service.py'
  if (-not (Test-Path -LiteralPath $service)) { throw 'Client Yönetim PRO web servisi bulunamadı.' }
  $taskName = 'KafePin Client Yonetim PRO'
  $runArgs = if ([IO.Path]::GetFileName($py.Source) -ieq 'py.exe') { '-3 -B "' + $service + '"' } else { '-B "' + $service + '"' }
  $action = New-ScheduledTaskAction -Execute $py.Source -Argument $runArgs -WorkingDirectory $Root
  $userId = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
  $trigger = New-ScheduledTaskTrigger -AtLogOn -User $userId
  $principal = New-ScheduledTaskPrincipal -UserId $userId -LogonType Interactive -RunLevel Highest
  $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
  Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'KafePin Client PRO - EveryCafe UI köprüsü; DB salt okunur.' -Force | Out-Null
  Start-ScheduledTask -TaskName $taskName
}

if (-not $InitialSetup -or -not $FreshInstall -or (Test-Path -LiteralPath $StatePath)) {
  exit 0
}
if (-not (Test-Path -LiteralPath (Join-Path $PayloadRoot 'mp3-bot-pro.zip') -PathType Leaf)) {
  Write-ComponentLog 'Bileşen seçimi atlandı: paket klasörü yok.'
  exit 0
}

$choices = [ordered]@{
  mp3 = Ask-Component 'KafePin MP3 Bot PRO' 'MP3 Bot PRO kurulsun mu?`n`nYouTube arama/indirme, Dinleme Modu, Winamp Modu ve Favori Listem bağımsız olarak kurulacaktır.'
  printer = Ask-Component 'KafePin Yazıcı PRO' 'Yazıcı PRO kurulsun mu?`n`nTarayıcı, kimlik fotokopisi, PDF/dosya dönüştürme ve Windows yazıcı seçimi kurulacaktır.'
  technical = Ask-Component 'KafePin Teknik Servis PRO' 'Teknik Servis PRO kurulsun mu?`n`nServis kaydı, A4 servis fişi ve Nakit/Kart tahsilat kaydı bağımsız olarak kurulacaktır.'
  client = $(if ($EveryCafeEnabled) { Ask-Component 'KafePin Client Yönetim PRO' 'Client Yönetim PRO kurulsun mu?`n`nCanlı masa durumunu salt okunur gösterir; uyandırma, yeniden başlatma, süreli/süresiz/ücretsiz oturum açma, açık oturuma süre ekleme ve onaylı çalışan uygulamaları sonlandırma araçlarını sağlar. Bilgisayar/hesap/masa kapatma ve tahsilat yapmaz.' } else { $false })
}


function Ensure-Python3 {
  $py = Get-Command py.exe -ErrorAction SilentlyContinue
  if ($py) { return $py }
  $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
  if (-not $winget) { throw 'Python 3 gerekli ancak Windows Paket Yöneticisi (winget) bulunamadı.' }
  Write-ComponentLog 'Python 3 bulunamadı; winget ile kuruluyor.'
  $process = Start-Process -FilePath $winget.Source -ArgumentList @('install','--id','Python.Python.3.13','--exact','--silent','--accept-package-agreements','--accept-source-agreements') -Wait -PassThru
  if ($process.ExitCode -ne 0) { throw ('Python 3 kurulumu başarısız. Çıkış kodu: ' + $process.ExitCode) }
  $py = Get-Command py.exe -ErrorAction SilentlyContinue
  if (-not $py) {
    $candidate = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'
    if (Test-Path -LiteralPath $candidate) { return [pscustomobject]@{ Source = $candidate; IsPythonExe = $true } }
    throw 'Python 3 kurulumu tamamlandı ancak py.exe/python.exe bulunamadı.'
  }
  return $py
}

$result = [ordered]@{ version = '3.1.64'; installedAt = (Get-Date).ToString('o'); choices = $choices; results = [ordered]@{} }

foreach ($name in @('mp3', 'printer', 'technical', 'client')) {
  if (-not $choices[$name]) { $result.results[$name] = 'skipped'; continue }
  try {
    if ($name -eq 'mp3') {
      $target = $ComponentTargets.mp3
      Copy-Component 'mp3-bot-pro' $target
      Invoke-SilentCmd 'cmd.exe' '/c KURULUM.cmd /silent' $target
      Start-Mp3Service $target
    } elseif ($name -eq 'printer') {
      $target = $ComponentTargets.printer
      Copy-Component 'yazici-pro' $target
      Invoke-SilentCmd 'cmd.exe' '/c KURULUM.cmd /silent' $target
      Start-PrinterService $target
    } else {
      $null = Ensure-Python3
      if ($name -eq 'client') {
        $target = $ComponentTargets.client
        Copy-Component 'client-yonetim-pro' $target
        Start-ClientManagementService $target
      } else {
      $target = $ComponentTargets.technical
      Copy-Component 'teknik-servis-pro' $target
      Start-TechnicalService $target
      }
    }
    $result.results[$name] = 'installed'
    Write-ComponentLog "$name kuruldu: $target"
  } catch {
    $result.results[$name] = 'failed: ' + $_.Exception.Message
    Write-ComponentLog "$name kurulamadı: $($_.Exception.Message)"
  }
}

New-Item -ItemType Directory -Force -Path (Split-Path -Parent $StatePath) | Out-Null
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $StatePath -Encoding UTF8
$failed = @($result.results.Values | Where-Object { $_ -like 'failed:*' })
if ($failed.Count -gt 0) {
  Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
  [System.Windows.Forms.MessageBox]::Show('Seçilen bazı PRO bileşenleri kurulamadı. Ayrıntı: C:\KafePin\logs\pro-components-install.log', 'KafePin PRO Bileşenleri', 'OK', 'Warning') | Out-Null
} else {
  Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
  [System.Windows.Forms.MessageBox]::Show('PRO bileşen seçimleri tamamlandı. Seçilen paneller KafePin masaüstü uygulamasında hazırdır.', 'KafePin PRO Bileşenleri', 'OK', 'Information') | Out-Null
}
