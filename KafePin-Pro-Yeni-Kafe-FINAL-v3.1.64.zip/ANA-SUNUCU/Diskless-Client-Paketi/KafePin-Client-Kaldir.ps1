$ErrorActionPreference='SilentlyContinue'
if(-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Yonetici olarak calistirin.'}
$t=Get-ScheduledTask -TaskName 'KafePin Client Ping' -ErrorAction SilentlyContinue;if($t){Stop-ScheduledTask -TaskName 'KafePin Client Ping' -ErrorAction SilentlyContinue;Unregister-ScheduledTask -TaskName 'KafePin Client Ping' -Confirm:$false -ErrorAction SilentlyContinue}
Get-Process KafePinClient -ErrorAction SilentlyContinue|Stop-Process -Force
Remove-Item (Join-Path $env:ProgramData 'KafePinClient') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'KafePin Sans Carki.lnk') -Force -ErrorAction SilentlyContinue
Write-Host 'KafePin Client kaldirildi.'
