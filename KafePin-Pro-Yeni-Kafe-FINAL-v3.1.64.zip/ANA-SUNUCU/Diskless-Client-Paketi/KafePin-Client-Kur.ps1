﻿param([string]$ServerUrl='')
$ErrorActionPreference='Stop'
function Set-ClientProgress([int]$Percent,[string]$Text){ Write-Output ('KAFEPIN_CLIENT_PROGRESS|'+$Percent+'|'+$Text) }
Set-ClientProgress 5 'Kurulum hazırlanıyor'

function Is-Admin {
  return ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
if(-not (Is-Admin)){ throw 'Yonetici olarak calistirin.' }
Set-ClientProgress 10 'Yönetici izni doğrulandı'

if(-not $ServerUrl){ $ServerUrl=Read-Host 'KafePin ana sunucu adresi (ornek: http://192.168.1.100:3000)' }
$ServerUrl=$ServerUrl.Trim().TrimEnd('/')
if($ServerUrl -notmatch '^http://[^/]+:\d+$'){ throw 'Sunucu adresi gecersiz.' }
Set-ClientProgress 20 'Ana sunucu kontrol ediliyor'

try{
  $h=Invoke-RestMethod -Uri ($ServerUrl+'/api/health') -TimeoutSec 6
  if(-not $h.ok){ throw 'health false' }
}catch{ throw ('Ana sunucuya ulasilamadi: '+$_.Exception.Message) }

# Client rolu sunucudan okunur. Ping her durumda kurulur; cark kisayolu
# yalniz sunucuda cark aciksa olusturulur.
try{
  $clientCfg=Invoke-RestMethod -Uri ($ServerUrl+'/api/client-config') -TimeoutSec 6
}catch{ throw ('Client masa ayari okunamadi: '+$_.Exception.Message) }
if(-not $clientCfg.ok){ throw ('Bu client ana sunucuda masa olarak tanimli degil: '+[string]$clientCfg.error) }
$masa=[int]$clientCfg.masa
$spinEnabled=[bool]$clientCfg.spinEnabled
Set-ClientProgress 35 ('MASA-'+$masa+' bulundu • sunucu ayarı okundu')

$src=Join-Path $PSScriptRoot 'KafePinClient.cs'
if(-not(Test-Path $src)){ throw 'KafePinClient.cs eksik.' }

$root=Join-Path $env:ProgramData 'KafePinClient'
New-Item -ItemType Directory -Force -Path $root | Out-Null
$exe=Join-Path $root 'KafePinClient.exe'
$cfg=Join-Path $root 'config.json'
@{
  serverUrl=$ServerUrl
  masa=$masa
  spinEnabled=$spinEnabled
}|ConvertTo-Json | Set-Content -LiteralPath $cfg -Encoding UTF8

$csc=@(
  (Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'),
  (Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe')
)|Where-Object{Test-Path $_}|Select-Object -First 1
if(-not$csc){ throw '.NET Framework csc.exe bulunamadi.' }

& $csc /nologo /target:winexe /platform:anycpu /optimize+ ('/out:'+$exe) /reference:System.dll /reference:System.Core.dll /reference:System.Web.Extensions.dll $src
if($LASTEXITCODE -ne 0 -or -not(Test-Path $exe)){ throw 'Client ping uygulamasi derlenemedi.' }
Set-ClientProgress 60 'Ping uygulaması hazır'

# PING SISTEMI: her clientta her durumda kurulur.
$task='KafePin Client Ping'
$oldTask=Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
if($oldTask){ Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction Stop }
$taskAction=New-ScheduledTaskAction -Execute $exe
$taskTrigger=New-ScheduledTaskTrigger -AtStartup
$taskPrincipal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName $task -Action $taskAction -Trigger $taskTrigger -Principal $taskPrincipal -Force | Out-Null
Start-ScheduledTask -TaskName $task -ErrorAction Stop
Set-ClientProgress 82 'Ping sistemi kuruldu ve başlatıldı'

# CARK KISAYOLU: secim clientta tekrar sorulmaz; ana sunucu ayari neyse o uygulanir.
$pub=[Environment]::GetFolderPath('CommonDesktopDirectory')
if(-not$pub){ $pub=Join-Path $env:PUBLIC 'Desktop' }
$shortcutNames=@('KafePin Sans Carki.lnk','KafePin Şans Çarkı.lnk')
foreach($n in $shortcutNames){ Remove-Item -LiteralPath (Join-Path $pub $n) -Force -ErrorAction SilentlyContinue }

Set-ClientProgress 90 'Çark politikası uygulanıyor'
if($spinEnabled){
  $w=New-Object -ComObject WScript.Shell
  $lnk=$w.CreateShortcut((Join-Path $pub 'KafePin Şans Çarkı.lnk'))
  $lnk.TargetPath=(Join-Path $env:WINDIR 'explorer.exe')
  $lnk.Arguments=($ServerUrl+'/wheel.html')
  $lnk.Description='KafePin Şans Çarkı'
  $lnk.Save()
}

Set-ClientProgress 100 'Client kurulumu tamamlandı'
Write-Host ('KafePin Client kuruldu. MASA-'+$masa+' | Ping: AKTIF | Cark: '+$(if($spinEnabled){'AKTIF - masaustu kisayolu hazir'}else{'KAPALI - kisayol kurulmaz'})) -ForegroundColor Green
