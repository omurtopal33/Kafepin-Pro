using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

class KafePinClient {
    static string ConfigDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "KafePinClient");
    static string ConfigFile = Path.Combine(ConfigDir, "config.json");
    static string LogFile = Path.Combine(ConfigDir, "client.log");
    static JavaScriptSerializer Json = new JavaScriptSerializer();
    static void Log(string s){ try { Directory.CreateDirectory(ConfigDir); File.AppendAllText(LogFile, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+" "+s+Environment.NewLine, Encoding.UTF8); } catch{} }
    static Dictionary<string,object> GetJson(string url){
        var req=(HttpWebRequest)WebRequest.Create(url); req.Method="GET"; req.Timeout=6000; req.ReadWriteTimeout=6000; req.CachePolicy=new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);
        using(var res=(HttpWebResponse)req.GetResponse()) using(var sr=new StreamReader(res.GetResponseStream())) return Json.Deserialize<Dictionary<string,object>>(sr.ReadToEnd());
    }
    static Dictionary<string,object> PostJson(string url, object body){
        byte[] b=Encoding.UTF8.GetBytes(Json.Serialize(body)); var req=(HttpWebRequest)WebRequest.Create(url); req.Method="POST"; req.ContentType="application/json"; req.Timeout=6000; req.ReadWriteTimeout=6000; req.ContentLength=b.Length;
        using(var st=req.GetRequestStream()) st.Write(b,0,b.Length);
        using(var res=(HttpWebResponse)req.GetResponse()) using(var sr=new StreamReader(res.GetResponseStream())) return Json.Deserialize<Dictionary<string,object>>(sr.ReadToEnd());
    }
    static string ReadBase(){
        Directory.CreateDirectory(ConfigDir); var raw=File.ReadAllText(ConfigFile,Encoding.UTF8); var d=Json.Deserialize<Dictionary<string,object>>(raw); string v=Convert.ToString(d["serverUrl"]); return v.TrimEnd('/');
    }
    static bool Ok(Dictionary<string,object> d){ return d!=null && d.ContainsKey("ok") && Convert.ToBoolean(d["ok"]); }
    static void Main(){
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        string baseUrl=""; try{baseUrl=ReadBase();}catch(Exception e){Log("config error "+e.Message);return;}
        int lastMasa=0; Log("client started "+baseUrl);
        while(true){
            try{
                var c=GetJson(baseUrl+"/api/client-config");
                if(!Ok(c)) throw new Exception(c!=null&&c.ContainsKey("error")?Convert.ToString(c["error"]):"client-config failed");
                int masa=Convert.ToInt32(c["masa"]); string token=Convert.ToString(c["token"]);
                var p=PostJson(baseUrl+"/api/ping", new { masa=masa, token=token });
                if(!Ok(p)) throw new Exception(p!=null&&p.ContainsKey("error")?Convert.ToString(p["error"]):"ping failed");
                if(masa!=lastMasa){Log("connected masa="+masa);lastMasa=masa;}
            }catch(Exception e){ Log("ping error "+e.Message); }
            Thread.Sleep(10000);
        }
    }
}
