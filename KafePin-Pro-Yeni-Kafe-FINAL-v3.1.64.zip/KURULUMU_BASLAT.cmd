@echo off
chcp 65001 >nul
title KafePin Pro v3.1.64 FINAL Yeni Kafe Kurulumu
"%~dp0KafePin-Pro-Ana-Sunucu-Kurulum-v3.1.64.exe"
set RC=%ERRORLEVEL%
if not "%RC%"=="0" pause
exit /b %RC%
