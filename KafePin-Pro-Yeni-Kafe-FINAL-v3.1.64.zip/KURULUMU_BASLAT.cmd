@echo off
chcp 65001 >nul
title KafePin Pro v3.1.64 FINAL Yeni Kafe Kurulumu
net session >nul 2>&1
if not "%errorlevel%"=="0" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath 'cmd.exe' -ArgumentList '/c ""%~f0""' -Verb RunAs"
  exit /b
)
set EXTRA=
if /I "%KAFEPIN_VALIDATE_ONLY%"=="1" set EXTRA=-ValidateOnly
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0ANA-SUNUCU\KafePin-Pro-Yeni-Kafe-Kur-GUI.ps1" %EXTRA%
set RC=%ERRORLEVEL%
if not "%RC%"=="0" echo Kurulum hata kodu: %RC%
pause
exit /b %RC%
