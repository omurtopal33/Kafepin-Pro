@echo off
chcp 65001 >nul
title KafePin PRO Servisleri Onarimi
net session >nul 2>&1
if not "%errorlevel%"=="0" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath 'cmd.exe' -ArgumentList '/c ""%~f0""' -Verb RunAs"
  exit /b
)
if not exist "C:\KafePin\KafePin_Pro_Bilesen_Kurulum.ps1" (
  echo KafePin ana kurulumu bulunamadi: C:\KafePin
  pause
  exit /b 1
)
set EC=
findstr /B /C:"EVERYCAFE_DB_PATH=" "C:\KafePin\.env" >nul 2>&1 && set EC=-EveryCafeEnabled
echo.
echo KafePin PRO servisleri onarimi basliyor...
copy /Y "%~dp0ANA-SUNUCU\server\KafePin_Pro_Bilesen_Kurulum.ps1" "C:\KafePin\KafePin_Pro_Bilesen_Kurulum.ps1" >nul
if errorlevel 1 ( echo Guncel PRO kurucu kopyalanamadi. & pause & exit /b 1 )
xcopy /E /I /Y /Q "%~dp0ANA-SUNUCU\server\pro-components" "C:\KafePin\pro-components" >nul
if errorlevel 2 ( echo Guncel PRO paketleri kopyalanamadi. & pause & exit /b 1 )
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "C:\KafePin\KafePin_Pro_Bilesen_Kurulum.ps1" -InstallRoot "C:\KafePin" -ProRoot "C:\KafePinPro" -InitialSetup -ForceInitialSetup %EC%
set RC=%ERRORLEVEL%
if not "%RC%"=="0" echo PRO onarim hata kodu: %RC%
pause
exit /b %RC%
