param(
  [string]$ManifestUrl = "",
  [string]$ExpectedVersion = "",
  [string]$LocalZipPath = "",
  [string]$RootPath = "",
  [switch]$SkipBackup
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = if ($RootPath) { [IO.Path]::GetFullPath($RootPath) } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$work = Join-Path $env:TEMP ('KafePinProUpdate_' + [guid]::NewGuid().ToString('N'))
$zip = Join-Path $work 'update.zip'
$expanded = Join-Path $work 'expanded'
$updateLog = Join-Path $root 'logs\kafepin-update.log'
$resultFile = Join-Path $root 'logs\kafepin-pro-update-result.json'
$stateFile = Join-Path $root 'logs\kafepin-pro-update-state.json'

function Write-UpdateLog([string]$message) {
  New-Item -ItemType Directory -Path (Split-Path -Parent $updateLog) -Force | Out-Null
  ((Get-Date).ToString('s') + '  ' + $message) | Add-Content -LiteralPath $updateLog
}
function Write-UpdateResult([bool]$ok, [string]$version, [string]$errorMessage) {
  $payload = @{ ok=$ok; version=$version; error=$errorMessage; time=(Get-Date).ToString('o') } | ConvertTo-Json
  New-Item -ItemType Directory -Path (Split-Path -Parent $resultFile) -Force | Out-Null
  [IO.File]::WriteAllText($resultFile, $payload, (New-Object System.Text.UTF8Encoding($false)))
}
function Write-UpdateState([string]$stage, [string]$message, [bool]$running = $true) {
  $payload = @{ ok=$true; running=$running; stage=$stage; message=$message; time=[DateTimeOffset]::Now.ToUnixTimeMilliseconds() } | ConvertTo-Json
  New-Item -ItemType Directory -Path (Split-Path -Parent $stateFile) -Force | Out-Null
  [IO.File]::WriteAllText($stateFile, $payload, (New-Object System.Text.UTF8Encoding($false)))
}
function Stop-KafePinServer {
  Write-UpdateState 'stop' 'Sunucu durduruluyor.'
  Write-UpdateLog 'Sunucu durduruluyor.'
  try {
    Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:3000/admin/pro/stop' -ContentType 'application/json' -TimeoutSec 5 | Out-Null
  } catch {
    Write-UpdateLog ('HTTP durdurma yaniti alinamadi: ' + $_.Exception.Message)
  }
  Start-Sleep -Milliseconds 1200
  try {
    $listener = Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listener -and $listener.OwningProcess) {
      Stop-Process -Id $listener.OwningProcess -Force -ErrorAction SilentlyContinue
      Write-UpdateLog ('Port 3000 sureci kapatildi. PID=' + $listener.OwningProcess)
    }
  } catch {}
  Start-Sleep -Milliseconds 800
}

try {
  # Onceki bir guncelleyici Expand-Archive asamasinda takildiysa ayni anda iki kurucu calismasin.
  try {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue |
      Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -and $_.CommandLine -like '*KafePin_Pro_OtoGuncelle.ps1*' } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  } catch {}
  Write-UpdateLog ('Guncelleme baslatildi. Root=' + $root)
  Write-UpdateState 'prepare' 'Kurucu hazirlaniyor.'
  if (-not (Test-Path -LiteralPath $root -PathType Container)) { throw 'KafePin klasoru bulunamadi: ' + $root }
  New-Item -ItemType Directory -Path $work -Force | Out-Null

  if ($LocalZipPath) {
    Write-UpdateState 'prepare_copy' 'Yerel ZIP gecici alana kopyalaniyor.'
    Write-UpdateLog ('Yerel paket: ' + $LocalZipPath)
    if (-not (Test-Path -LiteralPath $LocalZipPath -PathType Leaf) -or $LocalZipPath -notmatch '\.zip$') { throw 'Secilen guncelleme paketi bulunamadi.' }
    Copy-Item -LiteralPath $LocalZipPath -Destination $zip -Force
  } else {
    Write-UpdateState 'download' 'Guncelleme paketi indiriliyor.'
    if (-not $ManifestUrl -or -not $ExpectedVersion) { throw 'Guncelleme bilgisi eksik.' }
    $manifestUrlFresh = $ManifestUrl + ($(if ($ManifestUrl.Contains('?')) {'&'} else {'?' })) + 'kafepin_cb=' + [DateTimeOffset]::Now.ToUnixTimeMilliseconds()
    try {
      $manifest = Invoke-RestMethod -Uri $manifestUrlFresh -Headers @{ 'Cache-Control'='no-cache, no-store, max-age=0'; 'Pragma'='no-cache' } -UseBasicParsing -TimeoutSec 20
    } catch {
      $manifest = (& curl.exe -fsSL --retry 2 -H 'Cache-Control: no-cache' $manifestUrlFresh | ConvertFrom-Json)
      if ($LASTEXITCODE -ne 0 -or -not $manifest) { throw 'Manifest indirilemedi.' }
    }
    if ([string]$manifest.version -ne $ExpectedVersion) { throw 'Surum bilgisi degisti; guncelleme iptal edildi.' }
    if (-not $manifest.downloadUrl -or $manifest.downloadUrl -notmatch '^https://') { throw 'Guncelleme indirme adresi gecersiz.' }
    try {
      Invoke-WebRequest -Uri ([string]$manifest.downloadUrl + '?kafepin_cb=' + [DateTimeOffset]::Now.ToUnixTimeMilliseconds()) -Headers @{ 'Cache-Control'='no-cache, no-store, max-age=0' } -OutFile $zip -UseBasicParsing -TimeoutSec 60
    } catch {
      & curl.exe -fL --retry 2 --retry-delay 1 -H 'Cache-Control: no-cache' -o $zip $manifest.downloadUrl
      if ($LASTEXITCODE -ne 0) { throw 'Paket indirilemedi.' }
    }
    if ($manifest.sha256) {
      $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
      if ($hash -ne ([string]$manifest.sha256).ToLowerInvariant()) { throw 'Indirilen paket dogrulanamadi.' }
    }
  }

  Write-UpdateState 'prepare_extract' 'ZIP aciliyor.'
  Write-UpdateLog 'ZIP aciliyor (.NET ZipFile).'
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  New-Item -ItemType Directory -Path $expanded -Force | Out-Null
  [IO.Compression.ZipFile]::ExtractToDirectory($zip, $expanded)

  Write-UpdateState 'prepare_read' 'Paket bilgisi okunuyor.'
  $updateInfoPath = Join-Path $expanded 'update.json'
  if (-not (Test-Path -LiteralPath $updateInfoPath -PathType Leaf)) { throw 'Paket tanim dosyasi bulunamadi.' }
  $update = Get-Content -LiteralPath $updateInfoPath -Raw | ConvertFrom-Json
  $targetVersion = [string]$update.version
  if (-not $targetVersion -or -not $update.files) { throw 'Paket surumu gecersiz.' }
  if ($ExpectedVersion -and $targetVersion -ne $ExpectedVersion) { throw 'Paket surumu beklenen surumle uyusmuyor.' }

  if (-not $SkipBackup) {
    Write-UpdateState 'backup' 'Emniyet yedegi aliniyor.'
    Write-UpdateLog 'Emniyet yedegi isteniyor.'
    try {
      $backupResponse = Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:3000/admin/backup/full' -ContentType 'application/json' -TimeoutSec 240
      if (-not $backupResponse.ok) { throw 'Sunucu yedekleme islemi basarisiz.' }
      Write-UpdateLog ('Emniyet yedegi tamamlandi: ' + [string]$backupResponse.fileName)
    } catch {
      $backupBat = Join-Path $root 'KafePin_Pro_Yedek_Al.bat'
      if (Test-Path -LiteralPath $backupBat) {
        & $backupBat /AUTO
        if ($LASTEXITCODE -ne 0) { throw 'Emniyet yedegi alinamadi.' }
      } else {
        throw ('Emniyet yedegi alinamadi: ' + $_.Exception.Message)
      }
    }
  } else {
    Write-UpdateLog 'Emniyet yedegi sunucu tarafinda onceden alindi.'
  }

  Stop-KafePinServer

  Write-UpdateState 'copy' ('Dosyalar kuruluyor: v' + $targetVersion)
  foreach ($relative in $update.files) {
    $safe = [string]$relative
    if ([string]::IsNullOrWhiteSpace($safe) -or $safe -match '(^|[\\/])\.\.([\\/]|$)' -or [IO.Path]::IsPathRooted($safe)) { throw 'Paket dosya yolu gecersiz.' }
    $source = Join-Path $expanded $safe
    $target = Join-Path $root $safe
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Paket dosyasi eksik: $safe" }
    New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
    Copy-Item -LiteralPath $source -Destination $target -Force
    Write-UpdateLog ('Kuruldu: ' + $safe)
  }

  $versionJson = @{ version=$targetVersion; channel='stable'; installedAt=(Get-Date).ToString('o') } | ConvertTo-Json
  [IO.File]::WriteAllText((Join-Path $root 'kafepin-pro-version.json'), $versionJson, (New-Object System.Text.UTF8Encoding($false)))
  Write-UpdateResult $true $targetVersion ''
  Write-UpdateState 'success' ('Guncelleme tamamlandi: v' + $targetVersion) $false
  Write-UpdateLog ('Dosyalar kuruldu: v' + $targetVersion)
  Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue

  $startBat = Join-Path $root 'KafePin_Pro_Baslat.bat'
  if (-not (Test-Path -LiteralPath $startBat -PathType Leaf)) { throw 'KafePin baslatma dosyasi bulunamadi.' }
  Start-Process -FilePath 'cmd.exe' -ArgumentList ('/d /c ""' + $startBat + '""') -WindowStyle Hidden
  Start-Sleep -Seconds 4
  Write-UpdateLog 'Sunucu yeniden baslatildi.'
  $appLauncher = Join-Path $root 'KafePin_Pro_Uygulama.vbs'
  if (Test-Path -LiteralPath $appLauncher -PathType Leaf) {
    Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + $appLauncher + '"') -WindowStyle Hidden
  }
  Write-UpdateLog 'Guncelleme basariyla tamamlandi.'
} catch {
  $msg = $_.Exception.Message
  try {
    New-Item -ItemType Directory -Path (Split-Path -Parent $updateLog) -Force | Out-Null
    ((Get-Date).ToString('s') + '  HATA: ' + $msg) | Add-Content -LiteralPath (Join-Path $root 'logs\kafepin-update-error.log')
  } catch {}
  try { Write-UpdateResult $false '' $msg } catch {}
  try { Write-UpdateState 'error' $msg $false } catch {}
  try {
    $startBat = Join-Path $root 'KafePin_Pro_Baslat.bat'
    if (Test-Path -LiteralPath $startBat -PathType Leaf) { Start-Process -FilePath 'cmd.exe' -ArgumentList ('/d /c ""' + $startBat + '""') -WindowStyle Hidden }
  } catch {}
  exit 1
}
