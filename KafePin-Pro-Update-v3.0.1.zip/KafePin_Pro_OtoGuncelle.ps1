# KafePin Pro v3.0.1 PANEL MODE updater - BAT/VBS restart yok
param(
  [string]$ManifestUrl = "",
  [string]$ExpectedVersion = "",
  [string]$LocalZipPath = "",
  [string]$RootPath = "",
  [switch]$SkipBackup,
  [switch]$Bootstrapped,
  [switch]$SelfDelete
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = if ($RootPath) { [IO.Path]::GetFullPath($RootPath) } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$systemRoot = Join-Path $env:ProgramData 'KafePinPro'
$maintenanceLock = Join-Path $systemRoot 'maintenance.lock'
$systemTaskName = 'KafePin Pro Server Manager'
New-Item -ItemType Directory -Path $systemRoot -Force | Out-Null
$work = Join-Path $env:TEMP ('KafePinProUpdate_' + [guid]::NewGuid().ToString('N'))
$zip = Join-Path $work 'update.zip'
$expanded = Join-Path $work 'expanded'
$updateLog = Join-Path $root 'logs\kafepin-update.log'
$resultFile = Join-Path $root 'logs\kafepin-pro-update-result.json'
$stateFile = Join-Path $root 'logs\kafepin-pro-update-state.json'

# IMPORTANT: The updater must never update itself while running from C:\KafePin.
# The server can launch this root script directly; it immediately copies itself to
# TEMP and relaunches there, then exits. The TEMP copy can safely replace every
# KafePin file, including KafePin_Pro_OtoGuncelle.ps1 itself.
if (-not $Bootstrapped) {
  try {
    $bootstrapDir = Join-Path $env:TEMP ('KafePinBootstrap_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $bootstrapDir -Force | Out-Null
    $bootstrapScript = Join-Path $bootstrapDir 'KafePin_Pro_Bootstrap.ps1'
    Copy-Item -LiteralPath $MyInvocation.MyCommand.Path -Destination $bootstrapScript -Force

    function Q([string]$v) { '"' + ($v -replace '"','\"') + '"' }
    $argParts = @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Q $bootstrapScript),'-RootPath',(Q $root),'-Bootstrapped','-SelfDelete')
    if ($ManifestUrl) { $argParts += @('-ManifestUrl',(Q $ManifestUrl)) }
    if ($ExpectedVersion) { $argParts += @('-ExpectedVersion',(Q $ExpectedVersion)) }
    if ($LocalZipPath) { $argParts += @('-LocalZipPath',(Q $LocalZipPath)) }
    if ($SkipBackup) { $argParts += '-SkipBackup' }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'powershell.exe'
    $psi.Arguments = ($argParts -join ' ')
    $psi.UseShellExecute = $true
    $psi.CreateNoWindow = $true
    $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
    [System.Diagnostics.Process]::Start($psi) | Out-Null
    exit 0
  } catch {
    throw ('Guncelleyici gecici alana tasinamadi: ' + $_.Exception.Message)
  }
}

function Write-UpdateLog([string]$message) {
  New-Item -ItemType Directory -Path (Split-Path -Parent $updateLog) -Force | Out-Null
  ((Get-Date).ToString('s') + '  ' + $message) | Add-Content -LiteralPath $updateLog
}
function Write-UpdateResult([bool]$ok, [string]$version, [string]$errorMessage) {
  $payload = @{ ok=$ok; version=$version; error=$errorMessage; time=(Get-Date).ToString('o') } | ConvertTo-Json
  New-Item -ItemType Directory -Path (Split-Path -Parent $resultFile) -Force | Out-Null
  [IO.File]::WriteAllText($resultFile, $payload, (New-Object System.Text.UTF8Encoding($false)))
}
function Write-UpdateState([string]$stage, [string]$message, [bool]$running = $true) {
  $payload = @{ ok=$true; running=$running; stage=$stage; message=$message; time=[DateTimeOffset]::Now.ToUnixTimeMilliseconds() } | ConvertTo-Json
  New-Item -ItemType Directory -Path (Split-Path -Parent $stateFile) -Force | Out-Null
  [IO.File]::WriteAllText($stateFile, $payload, (New-Object System.Text.UTF8Encoding($false)))
}
function Close-KafePinDesktop {
  Write-UpdateState 'close_app' 'KafePin Pro penceresi kapatiliyor.'
  Write-UpdateLog 'KafePin Pro penceresine guvenli WM_CLOSE gonderiliyor. EveryCafe ve tarayici surecleri korunur.'

  try {
    if (-not ('KafePin.SafeWindowCloser' -as [type])) {
      Add-Type -TypeDefinition @"
using System;
using System.Text;
using System.Runtime.InteropServices;

namespace KafePin {
  public static class SafeWindowCloser {
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll", CharSet=CharSet.Unicode)]
    static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    [DllImport("user32.dll")]
    static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    static extern bool PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

    const uint WM_CLOSE = 0x0010;

    public static int CloseKafePinWindows() {
      int count = 0;
      EnumWindows(delegate(IntPtr hWnd, IntPtr lParam) {
        if (!IsWindowVisible(hWnd)) return true;

        var sb = new StringBuilder(1024);
        GetWindowText(hWnd, sb, sb.Capacity);
        string title = sb.ToString();
        if (String.IsNullOrWhiteSpace(title)) return true;

        bool isKafePin = title.IndexOf("KafePin Pro", StringComparison.OrdinalIgnoreCase) >= 0;
        bool isEveryCafe = title.IndexOf("EveryCafe", StringComparison.OrdinalIgnoreCase) >= 0;

        if (isKafePin && !isEveryCafe) {
          PostMessage(hWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
          count++;
        }
        return true;
      }, IntPtr.Zero);
      return count;
    }
  }
}
"@
    }

    $closed = [KafePin.SafeWindowCloser]::CloseKafePinWindows()
    Write-UpdateLog ('Guvenli kapatma mesaji gonderilen KafePin pencere sayisi=' + $closed)
  } catch {
    Write-UpdateLog ('KafePin pencere kapatma uyarisi: ' + $_.Exception.Message)
  }

  # Browser/EveryCafe processes are NEVER force-killed here.
  Start-Sleep -Milliseconds 900
}

function Get-KafePinServerPid {
  try {
    $r = Invoke-RestMethod -Uri 'http://127.0.0.1:3000/admin/pro/runtime' -TimeoutSec 3
    if ($r.ok -and $r.pid) { return [int]$r.pid }
  } catch {}
  return 0
}

function Start-KafePinSystemManager {
  try {
    Start-ScheduledTask -TaskName $systemTaskName -ErrorAction SilentlyContinue
  } catch {
    try { schtasks.exe /Run /TN $systemTaskName | Out-Null } catch {}
  }
}

function Stop-KafePinServer {
  Write-UpdateState 'stop' 'KafePin Pro kapatiliyor; sunucu durduruluyor.'
  Write-UpdateLog 'Sunucu durduruluyor. EveryCafe korunuyor.'
  Close-KafePinDesktop

  $expectedPid = Get-KafePinServerPid
  if ($expectedPid -gt 0) {
    Write-UpdateLog ('Dogrulanan KafePin server PID=' + $expectedPid)
  }

  try {
    Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:3000/admin/pro/stop' -ContentType 'application/json' -TimeoutSec 5 | Out-Null
  } catch {
    Write-UpdateLog ('HTTP durdurma yaniti alinamadi: ' + $_.Exception.Message)
  }

  $deadline = (Get-Date).AddSeconds(15)
  $listener = $null
  do {
    Start-Sleep -Milliseconds 350
    $listener = $null
    try {
      $listener = Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    } catch {}
    if (-not $listener) { break }
  } while ((Get-Date) -lt $deadline)

  if ($listener -and $listener.OwningProcess) {
    $listenerPid = [int]$listener.OwningProcess

    # Only force-stop a PID that the KafePin server itself reported.
    if ($expectedPid -gt 0 -and $listenerPid -eq $expectedPid) {
      try {
        Stop-Process -Id $listenerPid -Force -ErrorAction Stop
        Write-UpdateLog ('Dogrulanmis KafePin Node sunucusu zorla kapatildi. PID=' + $listenerPid)
      } catch {
        throw ('KafePin sunucusu kapatilamadi. PID=' + $listenerPid)
      }
    } else {
      throw ('Port 3000 hala acik fakat surecin KafePin oldugu dogrulanamadi. Guvenlik icin baska program kapatilmadi. PID=' + $listenerPid)
    }
  }

  Start-Sleep -Milliseconds 700
}

try {
  # Only remove stale TEMP bootstrap updater instances; never kill this process.
  try {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue |
      Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -and $_.CommandLine -like '*KafePin_Pro_Bootstrap.ps1*' } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  } catch {}
  Write-UpdateLog ('Guncelleme baslatildi. Root=' + $root)
  Write-UpdateState 'prepare' 'Kurucu hazirlaniyor.'
  if (-not (Test-Path -LiteralPath $root -PathType Container)) { throw 'KafePin klasoru bulunamadi: ' + $root }
  New-Item -ItemType Directory -Path $work -Force | Out-Null

  if ($LocalZipPath) {
    Write-UpdateState 'prepare_copy' 'Yerel ZIP gecici alana kopyalaniyor.'
    Write-UpdateLog ('Yerel paket: ' + $LocalZipPath)
    if (-not (Test-Path -LiteralPath $LocalZipPath -PathType Leaf) -or $LocalZipPath -notmatch '\.zip$') { throw 'Secilen guncelleme paketi bulunamadi.' }
    Copy-Item -LiteralPath $LocalZipPath -Destination $zip -Force
  } else {
    Write-UpdateState 'download' 'Guncelleme paketi indiriliyor.'
    if (-not $ManifestUrl -or -not $ExpectedVersion) { throw 'Guncelleme bilgisi eksik.' }
    $manifestUrlFresh = $ManifestUrl + ($(if ($ManifestUrl.Contains('?')) {'&'} else {'?' })) + 'kafepin_cb=' + [DateTimeOffset]::Now.ToUnixTimeMilliseconds()
    try {
      $manifest = Invoke-RestMethod -Uri $manifestUrlFresh -Headers @{ 'Cache-Control'='no-cache, no-store, max-age=0'; 'Pragma'='no-cache' } -UseBasicParsing -TimeoutSec 20
    } catch {
      $manifest = (& curl.exe -fsSL --retry 2 -H 'Cache-Control: no-cache' $manifestUrlFresh | ConvertFrom-Json)
      if ($LASTEXITCODE -ne 0 -or -not $manifest) { throw 'Manifest indirilemedi.' }
    }
    if ([string]$manifest.version -ne $ExpectedVersion) { throw 'Surum bilgisi degisti; guncelleme iptal edildi.' }
    if (-not $manifest.downloadUrl -or $manifest.downloadUrl -notmatch '^https://') { throw 'Guncelleme indirme adresi gecersiz.' }
    try {
      Invoke-WebRequest -Uri ([string]$manifest.downloadUrl + '?kafepin_cb=' + [DateTimeOffset]::Now.ToUnixTimeMilliseconds()) -Headers @{ 'Cache-Control'='no-cache, no-store, max-age=0' } -OutFile $zip -UseBasicParsing -TimeoutSec 60
    } catch {
      & curl.exe -fL --retry 2 --retry-delay 1 -H 'Cache-Control: no-cache' -o $zip $manifest.downloadUrl
      if ($LASTEXITCODE -ne 0) { throw 'Paket indirilemedi.' }
    }
    if ($manifest.sha256) {
      $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
      if ($hash -ne ([string]$manifest.sha256).ToLowerInvariant()) { throw 'Indirilen paket dogrulanamadi.' }
    }
  }

  Write-UpdateState 'prepare_extract' 'ZIP aciliyor.'
  Write-UpdateLog 'ZIP aciliyor (.NET ZipFile).'
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  New-Item -ItemType Directory -Path $expanded -Force | Out-Null
  [IO.Compression.ZipFile]::ExtractToDirectory($zip, $expanded)

  Write-UpdateState 'prepare_read' 'Paket bilgisi okunuyor.'
  $updateInfoPath = Join-Path $expanded 'update.json'
  if (-not (Test-Path -LiteralPath $updateInfoPath -PathType Leaf)) { throw 'Paket tanim dosyasi bulunamadi.' }
  $update = Get-Content -LiteralPath $updateInfoPath -Raw | ConvertFrom-Json
  $targetVersion = [string]$update.version
  if (-not $targetVersion -or -not $update.files) { throw 'Paket surumu gecersiz.' }
  if ($ExpectedVersion -and $targetVersion -ne $ExpectedVersion) { throw 'Paket surumu beklenen surumle uyusmuyor.' }

  if (-not $SkipBackup) {
    Write-UpdateState 'backup' 'Emniyet yedegi aliniyor.'
    Write-UpdateLog 'Emniyet yedegi isteniyor.'
    try {
      $backupResponse = Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:3000/admin/backup/full' -ContentType 'application/json' -TimeoutSec 240
      if (-not $backupResponse.ok) { throw 'Sunucu yedekleme islemi basarisiz.' }
      Write-UpdateLog ('Emniyet yedegi tamamlandi: ' + [string]$backupResponse.fileName)
    } catch {
      throw ('Emniyet yedegi alinamadi: ' + $_.Exception.Message)
    }
  } else {
    Write-UpdateLog 'Emniyet yedegi sunucu tarafinda onceden alindi.'
  }

  New-Item -ItemType File -Path $maintenanceLock -Force | Out-Null
  Write-UpdateLog 'Windows Sistem Yoneticisi bakim kilidine alindi.'
  Stop-KafePinServer

  Write-UpdateState 'copy' ('Dosyalar kuruluyor: v' + $targetVersion)
  foreach ($relative in $update.files) {
    $safe = [string]$relative
    if ([string]::IsNullOrWhiteSpace($safe) -or $safe -match '(^|[\\/])\.\.([\\/]|$)' -or [IO.Path]::IsPathRooted($safe)) { throw 'Paket dosya yolu gecersiz.' }
    $source = Join-Path $expanded $safe
    $target = Join-Path $root $safe
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Paket dosyasi eksik: $safe" }
    New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
    $copied = $false
    for ($attempt = 1; $attempt -le 12; $attempt++) {
      try {
        Copy-Item -LiteralPath $source -Destination $target -Force -ErrorAction Stop
        $copied = $true
        break
      } catch {
        if ($attempt -ge 12) { throw }
        Start-Sleep -Milliseconds 500
      }
    }
    if (-not $copied) { throw "Dosya kopyalanamadi: $safe" }
    Write-UpdateLog ('Kuruldu: ' + $safe)
  }

  # Paket icindeki updater kalici dosya olarak kalir; calisan eski motor onu geri ezmez.
  # Windows Sistem Yoneticisi de paketle birlikte guncellenir.
  $managerSource = Join-Path $root 'KafePin_System_Manager.ps1'
  $managerTarget = Join-Path $systemRoot 'KafePin_System_Manager.ps1'
  if (Test-Path -LiteralPath $managerSource -PathType Leaf) {
    try { Stop-ScheduledTask -TaskName $systemTaskName -ErrorAction SilentlyContinue } catch {}
    Start-Sleep -Milliseconds 500
    Copy-Item -LiteralPath $managerSource -Destination $managerTarget -Force
    Write-UpdateLog 'Windows Sistem Yoneticisi dosyasi yenilendi.'
    Start-KafePinSystemManager
    Start-Sleep -Milliseconds 500
  }
  Remove-Item -LiteralPath (Join-Path $systemRoot 'server.manual-stop') -Force -ErrorAction SilentlyContinue

  $versionJson = @{ version=$targetVersion; channel='stable'; installedAt=(Get-Date).ToString('o') } | ConvertTo-Json
  [IO.File]::WriteAllText((Join-Path $root 'kafepin-pro-version.json'), $versionJson, (New-Object System.Text.UTF8Encoding($false)))
  Write-UpdateResult $true $targetVersion ''
  Write-UpdateState 'success' ('Guncelleme tamamlandi: v' + $targetVersion) $false
  Write-UpdateLog ('Dosyalar kuruldu: v' + $targetVersion)
  Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue

  Remove-Item -LiteralPath $maintenanceLock -Force -ErrorAction SilentlyContinue
  Write-UpdateLog 'Bakim kilidi kaldirildi; Windows Sistem Yoneticisi sunucuyu acacak.'
  Start-KafePinSystemManager
  $healthy = $false
  $healthDeadline = (Get-Date).AddSeconds(60)
  do {
    Start-Sleep -Milliseconds 700
    try {
      $h = Invoke-RestMethod -Uri 'http://127.0.0.1:3000/api/health' -TimeoutSec 2
      if ($h.ok) { $healthy = $true; break }
    } catch {}
  } while ((Get-Date) -lt $healthDeadline)
  if (-not $healthy) { throw 'Guncelleme kuruldu ancak Windows Sistem Yoneticisi KafePin sunucusunu acamadi.' }
  Write-UpdateLog 'Sunucu Windows Sistem Yoneticisi tarafindan yeniden acildi ve saglik kontrolu basarili.'

  $edge = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
  ) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1
  if ($edge) {
    Start-Process -FilePath $edge -ArgumentList '--app=http://127.0.0.1:3000/kafepin-pro-yonetim.html'
  } else {
    Start-Process 'http://127.0.0.1:3000/kafepin-pro-yonetim.html'
  }
  Write-UpdateLog 'Guncelleme basariyla tamamlandi.'
  if ($SelfDelete) {
    try {
      $self = $MyInvocation.MyCommand.Path
      $selfDir = Split-Path -Parent $self
      Start-Process -FilePath 'cmd.exe' -ArgumentList ('/d /c timeout /t 2 /nobreak >nul & del /f /q "' + $self + '" >nul 2>&1 & rmdir /q "' + $selfDir + '" >nul 2>&1') -WindowStyle Hidden
    } catch {}
  }
} catch {
  $msg = $_.Exception.Message
  try {
    New-Item -ItemType Directory -Path (Split-Path -Parent $updateLog) -Force | Out-Null
    ((Get-Date).ToString('s') + '  HATA: ' + $msg) | Add-Content -LiteralPath (Join-Path $root 'logs\kafepin-update-error.log')
  } catch {}
  try { Write-UpdateResult $false '' $msg } catch {}
  try { Write-UpdateState 'error' $msg $false } catch {}
  try {
    Remove-Item -LiteralPath $maintenanceLock -Force -ErrorAction SilentlyContinue
    Start-KafePinSystemManager
  } catch {}
  exit 1
}
