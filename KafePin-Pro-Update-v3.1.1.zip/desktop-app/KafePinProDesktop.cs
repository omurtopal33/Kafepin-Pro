using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace KafePinProDesktop
{
    internal static class NativeMethods
    {
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        internal static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll")]
        internal static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")]
        internal static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
    }

    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            bool createdNew;
            using (Mutex mutex = new Mutex(true, "Local\\KafePinProDesktopApp", out createdNew))
            {
                if (!createdNew)
                {
                    IntPtr hwnd = NativeMethods.FindWindow(null, "KafePin Pro");
                    if (hwnd != IntPtr.Zero)
                    {
                        NativeMethods.ShowWindowAsync(hwnd, 9);
                        NativeMethods.SetForegroundWindow(hwnd);
                    }
                    return;
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MainForm());
            }
        }
    }

    internal sealed class MainForm : Form
    {
        private const string HomeUrl = "http://127.0.0.1:3000/kafepin-pro-yonetim.html";
        private const string AdminUrl = "http://127.0.0.1:3000/admin.html";
        private const string MonitorUrl = "http://127.0.0.1:3000/monitor.html";
        private const string EveryCafeSyncUrl = "http://127.0.0.1:3000/everycafe-sync.html";
        private const string EveryCafeHistoryUrl = "http://127.0.0.1:3000/everycafe-history.html";
        private const string EveryCafeIntegrationUrl = "http://127.0.0.1:3000/everycafe-integration.html";

        private readonly WebView2 browser;
        private readonly Panel contentPanel;
        private readonly Panel splash;
        private readonly Label splashTitle;
        private readonly Label splashText;
        private readonly Button retryButton;
        private readonly Button managementButton;
        private readonly Button adminButton;
        private readonly Button monitorButton;
        private readonly Button everyCafeSyncButton;
        private readonly Button everyCafeHistoryButton;
        private readonly Button everyCafeIntegrationButton;
        private readonly Button refreshButton;
        private readonly System.Windows.Forms.Timer serverWatchTimer;
        private bool initializing;
        private bool hasLoadedOnce;
        private bool serverWatchBusy;
        private bool serverWasUnavailable;
        private DateTime? serverUnavailableSince;
        private bool automaticRecoveryAttempted;
        private bool automaticRecoveryBusy;
        private string lastServerVersion = string.Empty;
        private string targetUrl = HomeUrl;
        private readonly string maintenanceLockPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "KafePinPro", "maintenance.lock");

        internal MainForm()
        {
            Text = "KafePin Pro";
            StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;
            MinimumSize = new Size(960, 650);
            BackColor = Color.FromArgb(9, 13, 20);
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

            Panel topBar = new Panel();
            topBar.Dock = DockStyle.Top;
            topBar.Height = 56;
            topBar.BackColor = Color.FromArgb(12, 23, 34);
            topBar.Padding = new Padding(12, 8, 12, 8);

            Label brand = new Label();
            brand.Text = "KafePin Pro";
            brand.ForeColor = Color.FromArgb(105, 236, 183);
            brand.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            brand.AutoSize = false;
            brand.TextAlign = ContentAlignment.MiddleLeft;
            brand.SetBounds(12, 8, 150, 40);
            topBar.Controls.Add(brand);

            managementButton = MakeNavButton("Yönetim", 160, 12, 100);
            adminButton = MakeNavButton("Admin", 268, 12, 70);
            monitorButton = MakeNavButton("Monitör", 346, 12, 76);
            everyCafeSyncButton = MakeNavButton("EveryCafe Senkron", 430, 12, 124);
            everyCafeHistoryButton = MakeNavButton("Geçmiş Aktarım", 562, 12, 120);
            everyCafeIntegrationButton = MakeNavButton("Entegrasyon Günlüğü", 690, 12, 136);
            refreshButton = MakeNavButton("Yenile", 834, 12, 70);

            managementButton.Click += delegate { NavigateLocal(HomeUrl); };
            adminButton.Click += delegate { NavigateLocal(AdminUrl); };
            monitorButton.Click += delegate { NavigateLocal(MonitorUrl); };
            everyCafeSyncButton.Click += delegate { NavigateLocal(EveryCafeSyncUrl); };
            everyCafeHistoryButton.Click += delegate { NavigateLocal(EveryCafeHistoryUrl); };
            everyCafeIntegrationButton.Click += delegate { NavigateLocal(EveryCafeIntegrationUrl); };
            refreshButton.Click += delegate
            {
                try { NavigateLocal(targetUrl); }
                catch { }
            };

            topBar.Controls.Add(managementButton);
            topBar.Controls.Add(adminButton);
            topBar.Controls.Add(monitorButton);
            topBar.Controls.Add(everyCafeSyncButton);
            topBar.Controls.Add(everyCafeHistoryButton);
            topBar.Controls.Add(everyCafeIntegrationButton);
            topBar.Controls.Add(refreshButton);

            Label hint = new Label();
            hint.Text = "Masaüstü uygulaması";
            hint.ForeColor = Color.FromArgb(130, 155, 176);
            hint.Font = new Font("Segoe UI", 9F, FontStyle.Regular);
            hint.AutoSize = false;
            hint.TextAlign = ContentAlignment.MiddleRight;
            hint.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            hint.SetBounds(Math.Max(912, ClientSize.Width - 138), 8, 128, 40);
            topBar.Controls.Add(hint);
            topBar.Resize += delegate { hint.Visible = topBar.ClientSize.Width >= 1080; hint.Left = Math.Max(912, topBar.ClientSize.Width - 138); };

            contentPanel = new Panel();
            contentPanel.Dock = DockStyle.Fill;
            contentPanel.BackColor = Color.FromArgb(9, 13, 20);

            browser = new WebView2();
            browser.Dock = DockStyle.Fill;
            browser.Visible = false;
            contentPanel.Controls.Add(browser);

            splash = new Panel();
            splash.Dock = DockStyle.Fill;
            splash.BackColor = Color.FromArgb(9, 13, 20);
            contentPanel.Controls.Add(splash);
            splash.BringToFront();

            splashTitle = new Label();
            splashTitle.AutoSize = false;
            splashTitle.TextAlign = ContentAlignment.MiddleCenter;
            splashTitle.ForeColor = Color.FromArgb(98, 240, 179);
            splashTitle.Font = new Font("Segoe UI", 28F, FontStyle.Bold);
            splashTitle.Text = "KafePin Pro";
            splashTitle.Height = 60;
            splash.Controls.Add(splashTitle);

            splashText = new Label();
            splashText.AutoSize = false;
            splashText.TextAlign = ContentAlignment.MiddleCenter;
            splashText.ForeColor = Color.FromArgb(190, 214, 232);
            splashText.Font = new Font("Segoe UI", 12F, FontStyle.Regular);
            splashText.Text = "Yönetim Merkezi başlatılıyor...";
            splashText.Height = 36;
            splash.Controls.Add(splashText);

            retryButton = new Button();
            retryButton.Text = "Yeniden Dene";
            retryButton.Width = 150;
            retryButton.Height = 38;
            retryButton.Visible = false;
            retryButton.FlatStyle = FlatStyle.Flat;
            retryButton.ForeColor = Color.White;
            retryButton.BackColor = Color.FromArgb(22, 69, 47);
            retryButton.FlatAppearance.BorderColor = Color.FromArgb(39, 138, 91);
            retryButton.Click += RetryButton_Click;
            splash.Controls.Add(retryButton);

            Controls.Add(contentPanel);
            Controls.Add(topBar);

            serverWatchTimer = new System.Windows.Forms.Timer();
            serverWatchTimer.Interval = 1500;
            serverWatchTimer.Tick += ServerWatchTimer_Tick;

            contentPanel.Resize += delegate { LayoutSplash(); };
            Shown += delegate { BeginInitialize(); serverWatchTimer.Start(); };
            FormClosing += delegate { try { serverWatchTimer.Stop(); } catch { } try { browser.Dispose(); } catch { } };
            LayoutSplash();
            UpdateNavButtons(HomeUrl);
        }

        private Button MakeNavButton(string text, int left, int top, int width)
        {
            Button b = new Button();
            b.Text = text;
            b.SetBounds(left, top, width, 34);
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 1;
            b.FlatAppearance.BorderColor = Color.FromArgb(55, 82, 103);
            b.BackColor = Color.FromArgb(24, 42, 58);
            b.ForeColor = Color.FromArgb(228, 239, 248);
            b.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            b.Cursor = Cursors.Hand;
            return b;
        }

        private void SetActive(Button button, bool active)
        {
            button.BackColor = active ? Color.FromArgb(29, 111, 78) : Color.FromArgb(24, 42, 58);
            button.FlatAppearance.BorderColor = active ? Color.FromArgb(70, 200, 143) : Color.FromArgb(55, 82, 103);
            button.ForeColor = active ? Color.White : Color.FromArgb(228, 239, 248);
        }

        private void UpdateNavButtons(string url)
        {
            string value = (url ?? "").ToLowerInvariant();
            SetActive(managementButton, value.Contains("kafepin-pro-yonetim"));
            SetActive(adminButton, value.EndsWith("/admin.html") || value.Contains("/admin.html?"));
            SetActive(monitorButton, value.EndsWith("/monitor.html") || value.Contains("/monitor.html?"));
            SetActive(everyCafeSyncButton, value.EndsWith("/everycafe-sync.html") || value.Contains("/everycafe-sync.html?"));
            SetActive(everyCafeHistoryButton, value.EndsWith("/everycafe-history.html") || value.Contains("/everycafe-history.html?"));
            SetActive(everyCafeIntegrationButton, value.EndsWith("/everycafe-integration.html") || value.Contains("/everycafe-integration.html?"));
        }

        private string WithCacheBust(string url)
        {
            string clean = string.IsNullOrWhiteSpace(url) ? HomeUrl : url;
            int hashIndex = clean.IndexOf('#');
            string hash = hashIndex >= 0 ? clean.Substring(hashIndex) : string.Empty;
            if (hashIndex >= 0) clean = clean.Substring(0, hashIndex);
            string sep = clean.Contains("?") ? "&" : "?";
            return clean + sep + "_kp=" + DateTime.UtcNow.Ticks.ToString() + hash;
        }

        private void NavigateLocal(string url)
        {
            targetUrl = url;
            UpdateNavButtons(url);
            string freshUrl = WithCacheBust(url);
            try
            {
                if (browser.CoreWebView2 != null)
                {
                    browser.CoreWebView2.Navigate(freshUrl);
                    return;
                }
            }
            catch { }
            BeginInitialize();
        }

        private void LayoutSplash()
        {
            int w = contentPanel.ClientSize.Width;
            int h = contentPanel.ClientSize.Height;
            splashTitle.SetBounds(0, Math.Max(120, h / 2 - 100), w, 60);
            splashText.SetBounds(0, Math.Max(180, h / 2 - 35), w, 36);
            retryButton.Left = Math.Max(10, w / 2 - retryButton.Width / 2);
            retryButton.Top = Math.Max(230, h / 2 + 25);
        }

        private async void BeginInitialize()
        {
            if (initializing) return;
            initializing = true;
            retryButton.Visible = false;
            splash.Visible = true;
            splash.BringToFront();
            splashText.Text = IsMaintenanceActive() ? "KafePin bakım / geri yükleme işlemini tamamlıyor..." : "KafePin sunucusu hazırlanıyor...";

            try
            {
                if (browser.CoreWebView2 == null)
                {
                    string userData = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                        "KafePinPro", "WebView2");
                    Directory.CreateDirectory(userData);

                    CoreWebView2Environment.SetLoaderDllFolderPath(AppDomain.CurrentDomain.BaseDirectory);
                    CoreWebView2Environment env = await CoreWebView2Environment.CreateAsync(null, userData);
                    await browser.EnsureCoreWebView2Async(env);

                    browser.CoreWebView2.Settings.AreDevToolsEnabled = false;
                    browser.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
                    browser.CoreWebView2.Settings.IsStatusBarEnabled = false;
                    browser.CoreWebView2.Settings.IsZoomControlEnabled = false;

                    browser.CoreWebView2.NewWindowRequested += CoreWebView2_NewWindowRequested;
                    browser.CoreWebView2.NavigationStarting += CoreWebView2_NavigationStarting;
                    browser.CoreWebView2.ProcessFailed += delegate
                    {
                        BeginInvoke((MethodInvoker)delegate
                        {
                            browser.Visible = false;
                            splash.Visible = true;
                            splash.BringToFront();
                            splashText.Text = "Görüntü motoru yeniden başlatılıyor...";
                            retryButton.Visible = true;
                        });
                    };
                    browser.NavigationCompleted += Browser_NavigationCompleted;
                }

                if (IsMaintenanceActive()) KickServerManager();
                bool ready = await WaitForServerAsync(IsMaintenanceActive() ? 120 : 45);
                if (!ready)
                {
                    splashText.Text = IsMaintenanceActive() ? "Bakım / geri yükleme beklenenden uzun sürdü. İşlem kilidi devam ediyor." : "KafePin sunucusuna ulaşılamadı. Windows Sistem Yöneticisini kontrol et.";
                    retryButton.Visible = true;
                    initializing = false;
                    return;
                }

                browser.Source = new Uri(WithCacheBust(targetUrl));
            }
            catch (Exception ex)
            {
                splashText.Text = "KafePin Pro açılamadı: " + ex.Message;
                retryButton.Visible = true;
                initializing = false;
            }
        }

        private bool IsMaintenanceActive()
        {
            try
            {
                if (!File.Exists(maintenanceLockPath)) return false;
                DateTime modified = File.GetLastWriteTimeUtc(maintenanceLockPath);
                // Manager 180 sn'de stale lock'u temizler. Desktop 210 sn'den eski
                // kilidi aktif saymaz; böylece Manager yoksa bile onarım düğmesi görünür.
                if ((DateTime.UtcNow - modified).TotalSeconds > 210) return false;
                return true;
            }
            catch { return false; }
        }

        private async void RetryButton_Click(object sender, EventArgs e)
        {
            retryButton.Visible = false;
            retryButton.Text = "Yeniden Dene";
            splashText.Text = "KafePin sunucusu yeniden başlatılıyor...";
            bool recovered = await TryRecoverServerAsync();
            if (recovered)
            {
                serverWasUnavailable = false;
                serverUnavailableSince = null;
                automaticRecoveryAttempted = false;
                targetUrl = HomeUrl;
                NavigateLocal(HomeUrl);
                return;
            }

            splashText.Text = "Sunucu başlatılamadı. 'Sunucuyu Onar' ile tekrar deneyebilirsin.";
            retryButton.Text = "Sunucuyu Onar";
            retryButton.Visible = true;
        }

        private string GetKafePinRoot()
        {
            try
            {
                DirectoryInfo appDir = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
                if (appDir.Parent != null) return appDir.Parent.FullName;
            }
            catch { }
            return @"C:\KafePin";
        }

        private void KickServerManager()
        {
            try
            {
                ProcessStartInfo task = new ProcessStartInfo();
                task.FileName = "schtasks.exe";
                task.Arguments = "/Run /TN \"KafePin Pro Server Manager\"";
                task.UseShellExecute = false;
                task.CreateNoWindow = true;
                task.WindowStyle = ProcessWindowStyle.Hidden;
                Process.Start(task);
            }
            catch { }
        }

        private async Task<bool> TryRecoverServerAsync()
        {
            if (automaticRecoveryBusy) return false;
            automaticRecoveryBusy = true;
            try
            {
                // v1.1.2: Masaustu Node baslatmaz. Once mevcut Server Manager gorevini
                // tetikler. Sunucu gelmezse kullanicinin tikladigi Onar dugmesinde
                // Manager Ensure araci gorevi/config/control-portu yeniden dogrular.
                KickServerManager();
                if (await WaitForServerAsync(12)) return true;

                string ensureScript = Path.Combine(GetKafePinRoot(), "KafePin_Manager_Ensure.ps1");
                if (File.Exists(ensureScript))
                {
                    try
                    {
                        ProcessStartInfo repair = new ProcessStartInfo();
                        repair.FileName = "powershell.exe";
                        repair.Arguments = "-NoProfile -ExecutionPolicy Bypass -File "" + ensureScript + "" -InstallRoot "" + GetKafePinRoot() + """;
                        repair.UseShellExecute = true;
                        repair.Verb = "runas";
                        repair.WindowStyle = ProcessWindowStyle.Hidden;
                        Process proc = Process.Start(repair);
                        if (proc != null)
                        {
                            await Task.Run(delegate { try { proc.WaitForExit(30000); } catch { } });
                        }
                    }
                    catch { }
                }

                KickServerManager();
                return await WaitForServerAsync(25);
            }
            finally
            {
                automaticRecoveryBusy = false;
            }
        }

        private async void ServerWatchTimer_Tick(object sender, EventArgs e)
        {
            if (!hasLoadedOnce || serverWatchBusy) return;
            serverWatchBusy = true;
            try
            {
                string version = await GetServerVersionOnceAsync();
                if (version == null)
                {
                    if (!serverWasUnavailable)
                    {
                        serverUnavailableSince = DateTime.UtcNow;
                        automaticRecoveryAttempted = false;
                    }

                    serverWasUnavailable = true;
                    browser.Visible = false;
                    splash.Visible = true;
                    splash.BringToFront();

                    TimeSpan unavailableFor = serverUnavailableSince.HasValue
                        ? DateTime.UtcNow - serverUnavailableSince.Value
                        : TimeSpan.Zero;

                    // v1.1.2: Masaustu artik sunucuyu OTOMATIK baslatmaz.
                    // Sunucunun tek sahibi Windows Server Manager'dir. Restore/update
                    // sirasinda maintenance.lock varken yalniz bekler; boylece
                    // masaustu + restore motoru + manager arasinda yaris olusmaz.
                    if (IsMaintenanceActive())
                    {
                        splashText.Text = "KafePin yedekten geri yükleniyor / bakım yapılıyor... Yönetim paneli otomatik geri açılacak.";
                        retryButton.Visible = false;
                        if (!automaticRecoveryAttempted && unavailableFor.TotalSeconds >= 4)
                        {
                            automaticRecoveryAttempted = true;
                            KickServerManager();
                        }
                        if (unavailableFor.TotalSeconds >= 120)
                        {
                            splashText.Text = "Geri yükleme beklenenden uzun sürdü. Server Manager yeniden tetiklendi.";
                            retryButton.Text = "Server Manager'ı Onar";
                            retryButton.Visible = true;
                        }
                        return;
                    }

                    splashText.Text = "KafePin sunucusu yeniden başlatılıyor... Yönetim paneli otomatik geri açılacak.";

                    if (unavailableFor.TotalSeconds >= 30)
                    {
                        splashText.Text = "Sunucu henüz açılamadı. Otomatik ikinci başlatma yapılmadı; istersen aşağıdaki düğmeyle onarabilirsin.";
                        retryButton.Text = "Sunucuyu Onar";
                        retryButton.Visible = true;
                    }
                    else
                    {
                        retryButton.Visible = false;
                    }
                    return;
                }

                bool versionChanged = !string.IsNullOrWhiteSpace(lastServerVersion) &&
                    !string.IsNullOrWhiteSpace(version) &&
                    !string.Equals(lastServerVersion, version, StringComparison.OrdinalIgnoreCase);

                if (string.IsNullOrWhiteSpace(lastServerVersion) && !string.IsNullOrWhiteSpace(version))
                    lastServerVersion = version;

                if (serverWasUnavailable || versionChanged)
                {
                    serverWasUnavailable = false;
                    serverUnavailableSince = null;
                    automaticRecoveryAttempted = false;
                    if (!string.IsNullOrWhiteSpace(version)) lastServerVersion = version;
                    targetUrl = HomeUrl;
                    browser.Visible = false;
                    splash.Visible = true;
                    splash.BringToFront();
                    splashText.Text = "Sunucu hazır. Yönetim paneli açılıyor...";
                    retryButton.Visible = false;
                    try
                    {
                        WindowState = FormWindowState.Maximized;
                        Show();
                        BringToFront();
                        Activate();
                    }
                    catch { }
                    NavigateLocal(HomeUrl);
                }
            }
            catch { }
            finally { serverWatchBusy = false; }
        }

        private async Task<string> GetServerVersionOnceAsync()
        {
            return await Task.Run(delegate
            {
                try
                {
                    HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:3000/api/health?_desktop=" + DateTime.UtcNow.Ticks.ToString());
                    req.Method = "GET";
                    req.Timeout = 900;
                    req.ReadWriteTimeout = 900;
                    req.CachePolicy = new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);
                    using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                    {
                        if ((int)resp.StatusCode < 200 || (int)resp.StatusCode >= 300) return null;
                        return resp.Headers["X-KafePin-Version"] ?? string.Empty;
                    }
                }
                catch { return null; }
            });
        }

        private async Task<bool> WaitForServerAsync(int maxSeconds)
        {
            int attempts = Math.Max(1, maxSeconds * 2);
            for (int i = 0; i < attempts; i++)
            {
                bool ok = await Task.Run(delegate
                {
                    try
                    {
                        HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:3000/api/health");
                        req.Method = "GET";
                        req.Timeout = 1000;
                        req.ReadWriteTimeout = 1000;
                        using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                        {
                            return (int)resp.StatusCode >= 200 && (int)resp.StatusCode < 300;
                        }
                    }
                    catch { return false; }
                });
                if (ok) return true;
                await Task.Delay(500);
            }
            return false;
        }

        private void Browser_NavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            if (e.IsSuccess)
            {
                browser.Visible = true;
                splash.Visible = false;
                try { UpdateNavButtons(browser.Source != null ? browser.Source.ToString() : targetUrl); } catch { }
                hasLoadedOnce = true;
                initializing = false;
            }
            else
            {
                browser.Visible = false;
                splash.Visible = true;
                splash.BringToFront();
                splashText.Text = "KafePin ekranı yüklenemedi. Tekrar denenebilir.";
                retryButton.Visible = true;
                initializing = false;
            }
        }

        private void CoreWebView2_NavigationStarting(object sender, CoreWebView2NavigationStartingEventArgs e)
        {
            if (IsLocalKafePinUrl(e.Uri))
            {
                targetUrl = e.Uri;
                UpdateNavButtons(e.Uri);
                return;
            }
            e.Cancel = true;
            OpenExternal(e.Uri);
        }

        private void CoreWebView2_NewWindowRequested(object sender, CoreWebView2NewWindowRequestedEventArgs e)
        {
            e.Handled = true;
            if (IsLocalKafePinUrl(e.Uri))
            {
                targetUrl = e.Uri;
                browser.CoreWebView2.Navigate(e.Uri);
                return;
            }
            OpenExternal(e.Uri);
        }

        private static bool IsLocalKafePinUrl(string value)
        {
            Uri uri;
            if (!Uri.TryCreate(value, UriKind.Absolute, out uri)) return false;
            if (uri.Scheme == "about") return true;
            if (uri.Scheme != "http" && uri.Scheme != "https") return false;
            return string.Equals(uri.Host, "127.0.0.1", StringComparison.OrdinalIgnoreCase)
                || string.Equals(uri.Host, "localhost", StringComparison.OrdinalIgnoreCase);
        }

        private static void OpenExternal(string url)
        {
            try { Process.Start(url); } catch { }
        }
    }
}
