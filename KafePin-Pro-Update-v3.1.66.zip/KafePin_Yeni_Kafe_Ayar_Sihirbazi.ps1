param(
  [string]$InstallRoot = 'C:\KafePin'
)

$ErrorActionPreference = 'Stop'
$envFile = Join-Path $InstallRoot '.env'
$setupFile = Join-Path $InstallRoot 'config\yeni-kafe-kurulum.json'

function Ask-YesNo([string]$Title, [string]$Text) {
  Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
  $answer = [System.Windows.Forms.MessageBox]::Show(
    $Text, $Title,
    [System.Windows.Forms.MessageBoxButtons]::YesNo,
    [System.Windows.Forms.MessageBoxIcon]::Question,
    [System.Windows.Forms.MessageBoxDefaultButton]::Button2
  )
  return $answer -eq [System.Windows.Forms.DialogResult]::Yes
}

function Ask-Text([string]$Title, [string]$Prompt, [string]$DefaultValue = '') {
  Add-Type -AssemblyName Microsoft.VisualBasic -ErrorAction Stop
  return [Microsoft.VisualBasic.Interaction]::InputBox($Prompt, $Title, $DefaultValue)
}

function Set-EnvValue([hashtable]$Values, [string]$Name, [string]$Value) {
  $Values[$Name] = [string]$Value
}

try {
  if (Test-Path -LiteralPath $setupFile) { exit 0 }

  $everyCafeDefault = 'C:\Program Files (x86)\EveryCafeManager\ecmdata.ecm'
  $backupDefault = 'D:\KAFEPIN_YEDEK'
  $usesEveryCafe = Ask-YesNo 'KafePin Pro — Yeni Kafe Kurulumu' 'Bu kafede EveryCafe kullanılıyor mu?`n`nEvet seçilirse yalnız salt-okunur bağlantı yolu sorulur; KafePin EveryCafe veritabanına yazmaz.'
  $everyCafePath = ''
  if ($usesEveryCafe) {
    do {
      $everyCafePath = Ask-Text 'EveryCafe Bağlantısı' 'EveryCafe ecmdata.ecm dosyasının tam yolunu girin.' $everyCafeDefault
      if ([string]::IsNullOrWhiteSpace($everyCafePath)) { throw 'EveryCafe bağlantı yolu boş bırakılamaz.' }
      if (-not (Test-Path -LiteralPath $everyCafePath -PathType Leaf)) {
        $continue = Ask-YesNo 'EveryCafe Dosyası Bulunamadı' "Dosya bulunamadı:`n$everyCafePath`n`nYolu yeniden girmek için Evet, EveryCafe ayarını sonra yapmak için Hayır seçin."
        if (-not $continue) { $everyCafePath = ''; $usesEveryCafe = $false; break }
      }
    } while (-not (Test-Path -LiteralPath $everyCafePath -PathType Leaf))
  }

  $masaText = Ask-Text 'Masa Sayısı' 'Kafedeki toplam müşteri masa/bilgisayar sayısını girin.' '23'
  $masaSayisi = 0
  if (-not [int]::TryParse($masaText, [ref]$masaSayisi) -or $masaSayisi -lt 1 -or $masaSayisi -gt 250) {
    throw 'Masa sayısı 1 ile 250 arasında bir tam sayı olmalıdır.'
  }

  $backupRoot = Ask-Text 'Yedek Klasörü' 'Otomatik KafePin yedeklerinin yazılacağı klasörü girin.' $backupDefault
  if ([string]::IsNullOrWhiteSpace($backupRoot)) { throw 'Yedek klasörü boş bırakılamaz.' }

  $telegramEnabled = Ask-YesNo 'Telegram Bildirimleri' 'Telegram sağlık ve gün sonu bildirimleri bu kafede etkinleştirilsin mi?'
  $telegramToken = ''
  $telegramChatId = ''
  if ($telegramEnabled) {
    $telegramToken = Ask-Text 'Telegram Bot Token' 'Telegram bot token değerini girin.'
    $telegramChatId = Ask-Text 'Telegram Chat ID' 'Bildirim gönderilecek Telegram chat ID değerini girin.'
    if ([string]::IsNullOrWhiteSpace($telegramToken) -or [string]::IsNullOrWhiteSpace($telegramChatId)) {
      throw 'Telegram etkinleştirildiği için bot token ve chat ID zorunludur.'
    }
  }

  $envValues = @{}
  if (Test-Path -LiteralPath $envFile) {
    Get-Content -LiteralPath $envFile -ErrorAction Stop | ForEach-Object {
      if ($_ -match '^\s*([^#=\s]+)=(.*)$') { $envValues[$matches[1]] = $matches[2] }
    }
  }
  Set-EnvValue $envValues 'KAFEPIN_MASA_SAYISI' $masaSayisi
  Set-EnvValue $envValues 'KAFEPIN_BACKUP_ROOT' $backupRoot
  if ($usesEveryCafe) { Set-EnvValue $envValues 'EVERYCAFE_DB_PATH' $everyCafePath }
  Set-EnvValue $envValues 'TELEGRAM_ENABLED' $(if ($telegramEnabled) { '1' } else { '0' })
  if ($telegramEnabled) {
    Set-EnvValue $envValues 'TELEGRAM_BOT_TOKEN' $telegramToken
    Set-EnvValue $envValues 'TELEGRAM_CHAT_ID' $telegramChatId
  } else {
    $envValues.Remove('TELEGRAM_BOT_TOKEN')
    $envValues.Remove('TELEGRAM_CHAT_ID')
  }
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $envFile),(Split-Path -Parent $setupFile) | Out-Null
  (($envValues.Keys | Sort-Object | ForEach-Object { $_ + '=' + $envValues[$_] }) -join [Environment]::NewLine) + [Environment]::NewLine |
    Set-Content -LiteralPath $envFile -Encoding UTF8

  [ordered]@{
    version = '3.1.60'
    completedAt = (Get-Date).ToString('o')
    everyCafe = [ordered]@{ enabled = $usesEveryCafe; path = $everyCafePath; readOnly = $true }
    masaSayisi = $masaSayisi
    backupRoot = $backupRoot
    telegramEnabled = $telegramEnabled
  } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $setupFile -Encoding UTF8
  [System.Windows.Forms.MessageBox]::Show('Temel yeni kafe ayarları kaydedildi. Şimdi isteğe bağlı PRO hizmetleri ayrı ayrı sorulacak.', 'KafePin Pro', 'OK', 'Information') | Out-Null
  exit 0
} catch {
  Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
  [System.Windows.Forms.MessageBox]::Show('Yeni kafe temel ayarları tamamlanamadı: ' + $_.Exception.Message, 'KafePin Pro', 'OK', 'Error') | Out-Null
  exit 1
}
