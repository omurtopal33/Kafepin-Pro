﻿param(
  [string]$BridgeDir = 'C:\ProgramData\KafePinPro\DesktopBridge'
)

$ErrorActionPreference = 'Stop'
$requestFile = Join-Path $BridgeDir 'request.json'
$resultFile = Join-Path $BridgeDir 'result.json'

function Write-Result([string]$RequestId, [bool]$Ok, [bool]$Foreground, [long]$Hwnd, [string]$ErrorText, [string]$SelectedPath = '', [bool]$Cancelled = $false, [string]$ActionName = '', [long]$ProcessId = 0, [long]$ProcessStartUnixMs = 0, [string]$ExeSha256 = '') {
  try {
    New-Item -ItemType Directory -Force -Path $BridgeDir | Out-Null
    $payload = [ordered]@{
      requestId = $RequestId
      action = $ActionName
      ok = $Ok
      foreground = $Foreground
      hwnd = $Hwnd
      selectedPath = $SelectedPath
      cancelled = $Cancelled
      sessionId = [System.Diagnostics.Process]::GetCurrentProcess().SessionId
      processId = $ProcessId
      processStartUnixMs = $ProcessStartUnixMs
      exeSha256 = $ExeSha256
      error = $ErrorText
      completedAt = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    }
    $tmp = $resultFile + '.tmp'
    $payload | ConvertTo-Json -Compress | Set-Content -LiteralPath $tmp -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination $resultFile -Force
  } catch {}
}

$requestId = ''
try {
  $desktopSessionId = [System.Diagnostics.Process]::GetCurrentProcess().SessionId
  if ([int]$desktopSessionId -le 0) { throw 'Masaüstü yardımcısı interaktif kullanıcı oturumunda çalışmıyor.' }
  if (-not (Test-Path -LiteralPath $requestFile -PathType Leaf)) { throw 'Masaüstü isteği bulunamadı.' }
  $request = Get-Content -LiteralPath $requestFile -Raw -Encoding UTF8 | ConvertFrom-Json
  $requestId = [string]$request.requestId
  $actionName = [string]$request.action
  if (-not $actionName) { $actionName = 'open-folder' }
  if (-not $requestId) { throw 'İstek kimliği boş.' }

  if ($actionName -eq 'select-update-zip') {
    Add-Type -AssemblyName System.Windows.Forms

    # Bu script aktif kullanıcının interaktif oturumunda çalıştığı için HKCU,
    # gerçekten oturum açmış kullanıcının profilidir. Known Folder GUID ile
    # Windows'un taşınmış/özelleştirilmiş İndirilenler klasörü de doğru bulunur.
    $downloads = ''
    try {
      $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders'
      $value = (Get-ItemProperty -LiteralPath $key -Name '{374DE290-123F-4565-9164-39C4925E467B}' -ErrorAction Stop).'{374DE290-123F-4565-9164-39C4925E467B}'
      if ($value) { $downloads = [Environment]::ExpandEnvironmentVariables([string]$value) }
    } catch {}
    if (-not $downloads -or -not (Test-Path -LiteralPath $downloads -PathType Container)) {
      $downloads = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Downloads'
    }
    if (-not (Test-Path -LiteralPath $downloads -PathType Container)) {
      $downloads = [Environment]::GetFolderPath('UserProfile')
    }

    $owner = New-Object System.Windows.Forms.Form
    $owner.Text = 'KafePin Pro'
    $owner.ShowInTaskbar = $false
    $owner.TopMost = $true
    $owner.Width = 1
    $owner.Height = 1
    $owner.StartPosition = 'CenterScreen'
    $owner.Opacity = 0.01
    $owner.Show()
    $owner.Activate()
    [System.Windows.Forms.Application]::DoEvents()

    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = 'KafePin Pro güncelleme paketi seçin'
    $dialog.Filter = 'KafePin güncelleme paketi (*.zip)|*.zip'
    $dialog.Multiselect = $false
    $dialog.CheckFileExists = $true
    $dialog.CheckPathExists = $true
    $dialog.RestoreDirectory = $true
    $dialog.InitialDirectory = $downloads
    try { $dialog.AutoUpgradeEnabled = $true } catch {}

    $choice = $dialog.ShowDialog($owner)
    $owner.Close()
    $owner.Dispose()
    if ($choice -eq [System.Windows.Forms.DialogResult]::OK) {
      $selected = [System.IO.Path]::GetFullPath([string]$dialog.FileName)
      if (-not $selected.EndsWith('.zip', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Seçilen dosya ZIP değil.' }
      if (-not (Test-Path -LiteralPath $selected -PathType Leaf)) { throw 'Seçilen ZIP dosyası bulunamadı.' }
      Write-Result $requestId $true $true 0 '' $selected $false $actionName
      exit 0
    }
    Write-Result $requestId $true $true 0 '' '' $true $actionName
    exit 0
  }

  if ($actionName -eq 'select-folder') {
    Add-Type -AssemblyName System.Windows.Forms
    $title = [string]$request.title
    if (-not $title) { $title = 'Klasör seç' }
    $initialPath = [string]$request.initialPath
    if (-not $initialPath -or -not (Test-Path -LiteralPath $initialPath -PathType Container)) {
      $initialPath = [Environment]::GetFolderPath('MyMusic')
    }
    if (-not $initialPath -or -not (Test-Path -LiteralPath $initialPath -PathType Container)) {
      $initialPath = [Environment]::GetFolderPath('UserProfile')
    }

    $owner = New-Object System.Windows.Forms.Form
    $owner.Text = 'KafePin Pro'
    $owner.ShowInTaskbar = $false
    $owner.TopMost = $true
    $owner.Width = 1
    $owner.Height = 1
    $owner.StartPosition = 'CenterScreen'
    $owner.Opacity = 0.01
    $owner.Show()
    $owner.Activate()
    [System.Windows.Forms.Application]::DoEvents()

    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = $title
    $dialog.ShowNewFolderButton = $true
    if ($initialPath) { $dialog.SelectedPath = $initialPath }
    $choice = $dialog.ShowDialog($owner)
    $owner.Close()
    $owner.Dispose()
    if ($choice -eq [System.Windows.Forms.DialogResult]::OK) {
      $selected = [System.IO.Path]::GetFullPath([string]$dialog.SelectedPath)
      if (-not (Test-Path -LiteralPath $selected -PathType Container)) { throw 'Seçilen klasör bulunamadı.' }
      Write-Result $requestId $true $true 0 '' $selected $false $actionName
      exit 0
    }
    Write-Result $requestId $true $true 0 '' '' $true $actionName
    exit 0
  }


  if ($actionName -eq 'convert-doc-to-docx') {
    $sourcePath = [string]$request.sourcePath
    $destPath = [string]$request.destPath
    if ([string]::IsNullOrWhiteSpace($sourcePath) -or [string]::IsNullOrWhiteSpace($destPath)) { throw 'Word dönüşüm yolu boş.' }
    $sourcePath = [System.IO.Path]::GetFullPath($sourcePath)
    $destPath = [System.IO.Path]::GetFullPath($destPath)
    $bridgeFull = [System.IO.Path]::GetFullPath($BridgeDir).TrimEnd('\\') + '\\'
    if (-not $sourcePath.StartsWith($bridgeFull,[System.StringComparison]::OrdinalIgnoreCase)) { throw 'DOC kaynağı DesktopBridge dışında olamaz.' }
    if (-not $destPath.StartsWith($bridgeFull,[System.StringComparison]::OrdinalIgnoreCase)) { throw 'DOCX hedefi DesktopBridge dışında olamaz.' }
    if (-not $sourcePath.EndsWith('.doc',[System.StringComparison]::OrdinalIgnoreCase)) { throw 'Kaynak eski Word .doc dosyası değil.' }
    if (-not $destPath.EndsWith('.docx',[System.StringComparison]::OrdinalIgnoreCase)) { throw 'Hedef .docx olmalı.' }
    if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) { throw 'Dönüştürülecek .doc bulunamadı.' }
    New-Item -ItemType Directory -Force -Path ([System.IO.Path]::GetDirectoryName($destPath)) | Out-Null
    Remove-Item -LiteralPath $destPath -Force -ErrorAction SilentlyContinue

    # Office COM, Session 0/SYSTEM yerine bu TASK_LOGON_INTERACTIVE_TOKEN oturumunda çalışır.
    # VBScript Office'in COM optional-parametre bağlayıcısında PowerShell'deki bool/null
    # overload sorunlarını yaşamaz. CScript penceresiz başlatılır.
    $vbsPath = Join-Path ([System.IO.Path]::GetDirectoryName($destPath)) ('word-convert-' + $requestId + '.vbs')
    $vbs = @'
On Error Resume Next
Dim word, doc, src, dst
src = WScript.Arguments(0)
dst = WScript.Arguments(1)
Err.Clear
Set word = CreateObject("Word.Application")
If Err.Number <> 0 Then WScript.Echo "WORD_CREATE:" & Err.Description : WScript.Quit 11
word.Visible = False
word.DisplayAlerts = 0
Err.Clear
Set doc = word.Documents.Open(src, False, True, False)
If Err.Number <> 0 Or (doc Is Nothing) Then
  WScript.Echo "WORD_OPEN:" & Err.Description
  word.Quit
  WScript.Quit 12
End If
Err.Clear
doc.SaveAs2 dst, 16
If Err.Number <> 0 Then
  Err.Clear
  doc.SaveAs dst, 16
End If
If Err.Number <> 0 Then
  WScript.Echo "WORD_SAVE:" & Err.Description
  doc.Close False
  word.Quit
  WScript.Quit 13
End If
doc.Close False
word.Quit
WScript.Quit 0
'@
    [System.IO.File]::WriteAllText($vbsPath,$vbs,[System.Text.Encoding]::UTF8)
    try {
      $cscript = Join-Path $env:SystemRoot 'System32\cscript.exe'
      $psi = New-Object System.Diagnostics.ProcessStartInfo
      $psi.FileName = $cscript
      $psi.Arguments = '//B //Nologo "' + $vbsPath.Replace('"','""') + '" "' + $sourcePath.Replace('"','""') + '" "' + $destPath.Replace('"','""') + '"'
      $psi.UseShellExecute = $false
      $psi.CreateNoWindow = $true
      $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
      $psi.RedirectStandardOutput = $true
      $psi.RedirectStandardError = $true
      $proc = [System.Diagnostics.Process]::Start($psi)
      if (-not $proc) { throw 'Word dönüştürücü başlatılamadı.' }
      if (-not $proc.WaitForExit(50000)) { try { $proc.Kill() } catch {}; throw 'Word dönüşümü zaman aşımı.' }
      $out = (($proc.StandardOutput.ReadToEnd() + ' ' + $proc.StandardError.ReadToEnd()).Trim())
      if ([int]$proc.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $destPath -PathType Leaf)) {
        if (-not $out) { $out = 'Word dönüşüm çıkış kodu: ' + [int]$proc.ExitCode }
        throw $out
      }
      $size = (Get-Item -LiteralPath $destPath -ErrorAction Stop).Length
      if ([long]$size -lt 100) { throw 'Word boş/geçersiz DOCX üretti.' }
      Write-Result $requestId $true $true 0 '' $destPath $false $actionName
      exit 0
    } finally {
      Remove-Item -LiteralPath $vbsPath -Force -ErrorAction SilentlyContinue
    }
  }

  if ($actionName -eq 'delete-file') {
    $target = [string]$request.path
    if ([string]::IsNullOrWhiteSpace($target)) { throw 'Silinecek dosya yolu boş.' }
    $target = [System.IO.Path]::GetFullPath($target)
    $ext = ([System.IO.Path]::GetExtension($target)).ToLowerInvariant()
    $allowed = @('.mp3','.wav','.flac','.m4a','.aac','.ogg','.wma','.opus')
    if ($allowed -notcontains $ext) { throw ('Bu dosya türü silinemez: ' + $ext) }
    $blocked = @(
      [Environment]::GetFolderPath('Windows'),
      [Environment]::GetFolderPath('ProgramFiles'),
      [Environment]::GetFolderPath('ProgramFilesX86'),
      [Environment]::GetFolderPath('CommonApplicationData')
    ) | Where-Object { $_ }
    foreach ($base in $blocked) {
      $fullBase = [System.IO.Path]::GetFullPath([string]$base).TrimEnd('\\') + '\\'
      if ($target.StartsWith($fullBase, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw 'Korunan sistem konumundaki dosya silinemez.'
      }
    }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) {
      Write-Result $requestId $true $true 0 '' $target $false $actionName
      exit 0
    }
    try { [System.IO.File]::SetAttributes($target, [System.IO.FileAttributes]::Normal) } catch {}
    # Explorer/CMD Delete ile ayni kullanici oturumunda, tamamen gizli tek-dosya silme.
    # /F salt-okunur dosyayi zorlar, /Q soru sormaz. Shell yorumu olmamasi icin
    # tam dosya yolu quoted arguman olarak cmd.exe'ye verilir.
    $cmdExe = Join-Path $env:SystemRoot 'System32\cmd.exe'
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $cmdExe
    $psi.Arguments = '/d /s /c del /f /q "' + $target.Replace('"','""') + '"'
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $proc = [System.Diagnostics.Process]::Start($psi)
    if (-not $proc.WaitForExit(8000)) { try { $proc.Kill() } catch {}; throw 'Windows silme komutu zaman aşımına uğradı.' }
    if (Test-Path -LiteralPath $target -PathType Leaf) {
      $detail = (($proc.StandardError.ReadToEnd() + ' ' + $proc.StandardOutput.ReadToEnd()).Trim())
      if (-not $detail) { $detail = 'Windows kullanıcı oturumu dosyayı silemedi.' }
      throw $detail
    }
    Write-Result $requestId $true $true 0 '' $target $false $actionName
    exit 0
  }

  if ($actionName -eq 'restart-mp3-only') {
    $mp3Root = 'C:\KafePinPro\MP3BotPRO'
    $pythonw = Join-Path $mp3Root '.venv\Scripts\pythonw.exe'
    $ctl = Join-Path $mp3Root 'service_control.py'
    $metaFile = Join-Path $mp3Root 'mp3-web-version.json'
    if (-not (Test-Path -LiteralPath $pythonw -PathType Leaf)) { throw 'MP3 pythonw.exe bulunamadı.' }
    if (-not (Test-Path -LiteralPath $ctl -PathType Leaf)) { throw 'MP3 service_control.py bulunamadı.' }
    if (-not (Test-Path -LiteralPath $metaFile -PathType Leaf)) { throw 'MP3 sürüm bilgisi bulunamadı.' }
    $expectedVersion = [string]((Get-Content -LiteralPath $metaFile -Raw -Encoding UTF8 | ConvertFrom-Json).version)
    if ([string]::IsNullOrWhiteSpace($expectedVersion)) { throw 'MP3 beklenen sürüm boş.' }

    # Bu action TASK_LOGON_INTERACTIVE_TOKEN ile gerçek masaüstü kullanıcısında çalışır.
    # Böylece otomatik update sonrası MP3, kullanıcının manuel PRO Servisleri başlatmasıyla
    # aynı Windows kullanıcı profili / LOCALAPPDATA / erişim bağlamında ayağa kalkar.
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $pythonw
    $psi.WorkingDirectory = $mp3Root
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
    $psi.Arguments = '"' + $ctl + '" start --wait --timeout 25 --expected-version "' + $expectedVersion + '" --expected-root "' + $mp3Root + '"'
    $proc = [System.Diagnostics.Process]::Start($psi)
    if (-not $proc) { throw 'MP3 servis kontrolcüsü başlatılamadı.' }
    if (-not $proc.WaitForExit(35000)) {
      try { $proc.Kill() } catch {}
      throw 'MP3 servis başlatma zaman aşımı.'
    }
    if ([int]$proc.ExitCode -ne 0) { throw ('MP3 servis başlatma çıkış kodu: ' + [int]$proc.ExitCode) }

    $deadline = (Get-Date).AddSeconds(12)
    $ready = $false
    do {
      try {
        $r = Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:17890/api/health?_kp=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 1 -Headers @{ 'Cache-Control'='no-cache' }
        if ([int]$r.StatusCode -ge 200 -and [int]$r.StatusCode -lt 300) {
          $j = $r.Content | ConvertFrom-Json
          if ([string]$j.version -eq $expectedVersion) { $ready = $true; break }
        }
      } catch {}
      Start-Sleep -Milliseconds 250
    } while ((Get-Date) -lt $deadline)
    if (-not $ready) { throw ('MP3 health-check geçmedi: ' + $expectedVersion) }
    Write-Result $requestId $true $true 0 '' $expectedVersion $false $actionName
    exit 0
  }

  if ($actionName -eq 'refresh-pro-services') {
    $proRoot = 'C:\KafePinPro'
    $mp3Root = Join-Path $proRoot 'MP3BotPRO'
    $printerRoot = Join-Path $proRoot 'YaziciPRO'
    $serviceRoot = Join-Path $proRoot 'TeknikServisPRO'
    $clientRoot = Join-Path $proRoot 'ClientYonetimPRO' # retired v4.0.6
    $cvRoot = Join-Path $proRoot 'CVOlusturPRO'
    $legacyMp3Roots = @((Join-Path $proRoot 'MP3Bot'),'C:\KafePinMp3BotPRO')
    $roots = @($mp3Root,$printerRoot,$serviceRoot,$clientRoot,$cvRoot) + $legacyMp3Roots

    # Her başlangıçta eski PRO proseslerini kapat; yeni sürüm dosyalarıyla temiz başla.
    try {
      $self = $PID
      Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        $name = ([string]$_.Name).ToLowerInvariant()
        $cmd = ([string]$_.CommandLine).ToLowerInvariant()
        $kindOk = ($name -eq 'python.exe' -or $name -eq 'pythonw.exe' -or $name -eq 'node.exe')
        $hit = $false
        foreach ($rootPath in $roots) { if ($cmd.Contains(([string]$rootPath).ToLowerInvariant())) { $hit = $true; break } }
        $kindOk -and $hit -and ([int]$_.ProcessId -ne [int]$self)
      } | ForEach-Object { try { Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue } catch {} }
    } catch {}
    # v3.1.79: Eski MP3 surumu farkli bir kokten (ornegin C:\KafePinMp3BotPRO)
    # calisiyorsa komut-satiri kok taramasi tek basina yetmeyebilir. 17890 LISTENING
    # PID'sini dogrudan bul ve KafePin web_service.py oldugunu dogrulayip kapat.
    try {
      $netstatLines = @(& netstat -ano -p tcp 2>$null)
      foreach ($line in $netstatLines) {
        $parts = @(([string]$line).Trim() -split '\s+')
        if ($parts.Count -lt 5 -or $parts[0].ToUpperInvariant() -ne 'TCP' -or $parts[3].ToUpperInvariant() -ne 'LISTENING') { continue }
        if (-not $parts[1].EndsWith(':17890')) { continue }
        $listenerPid = 0
        if (-not [int]::TryParse($parts[4], [ref]$listenerPid) -or $listenerPid -le 0 -or $listenerPid -eq $PID) { continue }
        try {
          $procRow = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $listenerPid) -ErrorAction SilentlyContinue
          $cmd = ([string]$procRow.CommandLine).Replace('/','\').ToLowerInvariant()
          $procName = ([string]$procRow.Name).ToLowerInvariant()
          # 17890 MP3 PRO icin ayrilmis port. Legacy pythonw.exe -B web_service.py prosesinde
          # kurulum yolu CommandLine icinde bulunmaz; port sahibi Python ise dogrudan devral.
          $pythonOwner = $procName -in @('python.exe','pythonw.exe','py.exe','python3.exe')
          $provedByCommand = $cmd.Contains('web_service.py') -and ($cmd.Contains('kafepinmp3botpro') -or $cmd.Contains('kafepinpro\mp3botpro') -or $cmd.Contains('\mp3botpro\'))
          if ($pythonOwner -or $provedByCommand) {
            Stop-Process -Id $listenerPid -Force -ErrorAction SilentlyContinue
            try { & taskkill.exe /PID $listenerPid /T /F 2>$null | Out-Null } catch {}
          }
        } catch {}
      }
    } catch {}
    # MP3 yeniden baslamadan once 17890 gercekten bosaldi mi kontrol et. Cross-session
    # taskkill bazen birkac yuz ms gec tamamlanir.
    $portFreeDeadline = (Get-Date).AddSeconds(5)
    do {
      $ownerStillThere = $false
      try {
        foreach ($line in @(& netstat -ano -p tcp 2>$null)) {
          $parts = @(([string]$line).Trim() -split '\s+')
          if ($parts.Count -ge 5 -and $parts[0].ToUpperInvariant() -eq 'TCP' -and $parts[3].ToUpperInvariant() -eq 'LISTENING' -and $parts[1].EndsWith(':17890')) { $ownerStillThere = $true; break }
        }
      } catch {}
      if (-not $ownerStillThere) { break }
      Start-Sleep -Milliseconds 120
    } while ((Get-Date) -lt $portFreeDeadline)

    # Servisleri tek tek beklemek yerine tamamını önce başlat. Sağlık kontrolü ortak
    # deadline ile paralel ilerler; normal kafede birkaç saniyede kullanıma hazır olur.
    $expected = [ordered]@{}
    $launchErrors = New-Object System.Collections.Generic.List[string]

    $mp3ExpectedVersion = ''
    if (Test-Path -LiteralPath $mp3Root -PathType Container) {
      $launcher = Join-Path $mp3Root 'START_WEB.ps1'
      $metaFile = Join-Path $mp3Root 'mp3-web-version.json'
      try { if (Test-Path -LiteralPath $metaFile) { $mp3ExpectedVersion = [string]((Get-Content -LiteralPath $metaFile -Raw | ConvertFrom-Json).version) } } catch {}
      if (Test-Path -LiteralPath $launcher -PathType Leaf) {
        try {
          # START_WEB exact expected version'i zorunlu kılar; 17890'da eski KafePin MP3
          # prosesi varsa port sahibini kapatıp bu payload'i başlatır.
          Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',$launcher,'-WaitReady','-TimeoutSeconds','25') -WorkingDirectory $mp3Root -WindowStyle Hidden | Out-Null
          $expected['MP3 Bot PRO'] = @('http://127.0.0.1:17890/api/health')
        } catch { [void]$launchErrors.Add('MP3 Bot PRO: baslatilamadi') }
      } else { [void]$launchErrors.Add('MP3 Bot PRO: launcher yok') }
    }

    if (Test-Path -LiteralPath $printerRoot -PathType Container) {
      $printerHost = Join-Path $printerRoot 'KafePin_YaziciPRO_ServiceHost.ps1'
      if (Test-Path -LiteralPath $printerHost -PathType Leaf) {
        try {
          Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',$printerHost,'-InstallRoot',$printerRoot) -WorkingDirectory $printerRoot -WindowStyle Hidden | Out-Null
          $expected['Yazici PRO'] = @('http://127.0.0.1:17891/api/health','http://127.0.0.1:17893/health')
        } catch { [void]$launchErrors.Add('Yazici PRO: baslatilamadi') }
      } else { [void]$launchErrors.Add('Yazici PRO: launcher yok') }
    }

    foreach ($item in @(
      @{ Name='Teknik Servis PRO'; Root=$serviceRoot; Port=17892 },
      @{ Name='CV Olustur PRO'; Root=$cvRoot; Port=17895 }
    )) {
      if (-not (Test-Path -LiteralPath $item.Root -PathType Container)) { continue }
      $serviceFile = Join-Path $item.Root 'web_service.py'
      if (-not (Test-Path -LiteralPath $serviceFile -PathType Leaf)) { [void]$launchErrors.Add($item.Name + ': servis dosyasi yok'); continue }
      try {
        $pythonw = Join-Path $item.Root '.venv\Scripts\pythonw.exe'
        if (Test-Path -LiteralPath $pythonw -PathType Leaf) {
          Start-Process -FilePath $pythonw -ArgumentList @('-B',$serviceFile) -WorkingDirectory $item.Root -WindowStyle Hidden | Out-Null
        } else {
          Start-Process -FilePath 'py.exe' -ArgumentList @('-3','-B',$serviceFile) -WorkingDirectory $item.Root -WindowStyle Hidden | Out-Null
        }
        $expected[$item.Name] = @(('http://127.0.0.1:' + $item.Port + '/api/health'))
      } catch { [void]$launchErrors.Add($item.Name + ': baslatilamadi') }
    }

    $pending = @{}
    foreach ($name in $expected.Keys) { $pending[$name] = @($expected[$name]) }
    $deadline = (Get-Date).AddSeconds(38)
    do {
      foreach ($name in @($pending.Keys)) {
        $allOk = $true
        foreach ($uri in @($pending[$name])) {
          try {
            $sep = if ($uri.Contains('?')) { '&' } else { '?' }
            $r = Invoke-WebRequest -UseBasicParsing -Uri ($uri + $sep + '_kp=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 1 -Headers @{ 'Cache-Control'='no-cache' }
            if ([int]$r.StatusCode -lt 200 -or [int]$r.StatusCode -ge 300) { $allOk = $false; break }
            if ($name -eq 'MP3 Bot PRO' -and -not [string]::IsNullOrWhiteSpace($mp3ExpectedVersion)) {
              try {
                $healthJson = $r.Content | ConvertFrom-Json
                if ([string]$healthJson.version -ne $mp3ExpectedVersion) { $allOk = $false; break }
              } catch { $allOk = $false; break }
            }
          } catch { $allOk = $false; break }
        }
        if ($allOk) { $pending.Remove($name) }
      }
      if ($pending.Count -eq 0) { break }
      Start-Sleep -Milliseconds 250
    } while ((Get-Date) -lt $deadline)

    # MP3 exact runtime bilgisini kalici tani kaydina yaz. Sonraki bir sorunda hangi
    # kok/surum/PID gercekten 17890'i tutuyor tek dosyadan gorulur.
    try {
      $actualMp3Version = ''
      try {
        $hr = Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:17890/api/health?_kp=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 2 -Headers @{ 'Cache-Control'='no-cache' }
        $hj = $hr.Content | ConvertFrom-Json
        $actualMp3Version = [string]$hj.version
      } catch {}
      $mp3Pid = 0
      try {
        foreach ($line in @(& netstat -ano -p tcp 2>$null)) {
          $parts = @(([string]$line).Trim() -split '\s+')
          if ($parts.Count -ge 5 -and $parts[0].ToUpperInvariant() -eq 'TCP' -and $parts[3].ToUpperInvariant() -eq 'LISTENING' -and $parts[1].EndsWith(':17890')) { [void][int]::TryParse($parts[4],[ref]$mp3Pid); break }
        }
      } catch {}
      $runtime = [ordered]@{ root=$mp3Root; expected=$mp3ExpectedVersion; actual=$actualMp3Version; pid=$mp3Pid; desktopSession=[int][System.Diagnostics.Process]::GetCurrentProcess().SessionId; checkedAt=(Get-Date).ToString('o') }
      New-Item -ItemType Directory -Force -Path (Join-Path $env:ProgramData 'KafePinPro') | Out-Null
      $runtime | ConvertTo-Json -Compress | Set-Content -LiteralPath (Join-Path $env:ProgramData 'KafePinPro\mp3-runtime.json') -Encoding UTF8
    } catch {}

    $report = New-Object System.Collections.Generic.List[string]
    foreach ($name in $expected.Keys) {
      if ($pending.ContainsKey($name)) { [void]$report.Add($name + ': baslatilamadi') }
      else { [void]$report.Add($name + ': hazir') }
    }
    foreach ($row in $launchErrors) { [void]$report.Add($row) }
    if (-not (Test-Path -LiteralPath $mp3Root -PathType Container)) { [void]$report.Add('MP3 Bot PRO: kurulu degil') }
    if (-not (Test-Path -LiteralPath $printerRoot -PathType Container)) { [void]$report.Add('Yazici PRO: kurulu degil') }
    if (-not (Test-Path -LiteralPath $serviceRoot -PathType Container)) { [void]$report.Add('Teknik Servis PRO: kurulu degil') }
    if (-not (Test-Path -LiteralPath $cvRoot -PathType Container)) { [void]$report.Add('CV Olustur PRO: kurulu degil') }

    $failed = @($report | Where-Object { $_ -match 'baslatilamadi|launcher yok|servis dosyasi yok' })
    if ($failed.Count -gt 0) {
      Write-Result $requestId $false $true 0 ($report -join ' | ') '' $false $actionName
      exit 4
    }
    Write-Result $requestId $true $true 0 '' ($report -join ' | ') $false $actionName
    exit 0
  }

  if ($actionName -eq 'launch-kafepin') {
    $appPath = [string]$request.appPath
    if (-not $appPath) { throw 'KafePin masaüstü uygulama yolu boş.' }
    $appPath = [System.IO.Path]::GetFullPath($appPath)
    if (-not (Test-Path -LiteralPath $appPath -PathType Leaf)) { throw ('KafePin masaüstü uygulaması bulunamadı: ' + $appPath) }

    # Get-Process tum Windows oturumlarini gorebilir. Onceki surum burada Session 0'da
    # yanlislikla acilmis bir KafePin Pro.exe gorunce "zaten acik" sanip kullanici
    # masaustunde yeni proses baslatmiyordu. Yalniz BU bridge'in gercek interaktif
    # session'inda calisan proses basarili kabul edilir.
    $currentSessionId = [int][System.Diagnostics.Process]::GetCurrentProcess().SessionId
    if ($currentSessionId -le 0) { throw 'KafePin masaüstü açma görevi interaktif kullanıcı oturumunda değil.' }

    function Get-KafePinProcessPath($Proc) {
      try { return [System.IO.Path]::GetFullPath([string]$Proc.MainModule.FileName) } catch { return '' }
    }

    $expectedExeSha256 = ''
    try { $expectedExeSha256 = ([string]$request.expectedExeSha256).Trim().ToLowerInvariant() } catch {}
    $notBeforeUnixMs = [Int64]0
    try { $notBeforeUnixMs = [Int64]$request.notBeforeUnixMs } catch {}
    $actualExeSha256 = (Get-FileHash -LiteralPath $appPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($expectedExeSha256 -and $actualExeSha256 -ne $expectedExeSha256) { throw ('KafePin EXE SHA dogrulanamadi. Beklenen=' + $expectedExeSha256 + ' Gercek=' + $actualExeSha256) }

    function Test-CurrentDesktopProcess($Proc) {
      try {
        if ([int]$Proc.SessionId -ne $currentSessionId) { return $false }
        $procPath = Get-KafePinProcessPath $Proc
        if (-not $procPath -or -not $procPath.Equals($appPath, [System.StringComparison]::OrdinalIgnoreCase)) { return $false }
        if ($notBeforeUnixMs -gt 0) {
          $started = [DateTimeOffset]$Proc.StartTime.ToUniversalTime()
          if (($started.ToUnixTimeMilliseconds() + 2000) -lt $notBeforeUnixMs) { return $false }
        }
        return $true
      } catch { return $false }
    }

    function Find-KafePinInCurrentSession {
      try {
        $found = @(Get-Process -Name 'KafePin Pro' -ErrorAction SilentlyContinue | Where-Object {
          try { [int]$_.SessionId -eq $currentSessionId } catch { $false }
        })
        foreach ($proc in $found) {
          $procPath = Get-KafePinProcessPath $proc
          if (Test-CurrentDesktopProcess $proc) { return $proc }
        }
        return $null
      } catch { return $null }
    }

    # v3.1.71'in Session 0'dan actigi hatali proses kaldiysa temizle. Sadece
    # interaktif olmayan KafePin Pro proseslerine dokunulur; diger kullanici
    # oturumlarindaki uygulamalar kapatilmaz.
    try {
      Get-Process -Name 'KafePin Pro' -ErrorAction SilentlyContinue | Where-Object {
        try { [int]$_.SessionId -le 0 } catch { $false }
      } | ForEach-Object {
        try { Stop-Process -Id ([int]$_.Id) -Force -ErrorAction SilentlyContinue } catch {}
      }
    } catch {}

    $forceRestart = $false
    try { $forceRestart = [bool]$request.forceRestart } catch {}

    # Güncelleme sonrası eski kabuğun aynı kullanıcı oturumunda açık kalması artık
    # başarı sayılmaz. forceRestart istenmişse tüm KafePin Pro kabuklarını kapat;
    # aksi halde de exact appPath dışındaki eski/kopya kabukları temizle.
    try {
      Get-Process -Name 'KafePin Pro' -ErrorAction SilentlyContinue | Where-Object {
        try { [int]$_.SessionId -eq $currentSessionId } catch { $false }
      } | ForEach-Object {
        $procPath = Get-KafePinProcessPath $_
        $wrongPath = (-not $procPath) -or (-not $procPath.Equals($appPath, [System.StringComparison]::OrdinalIgnoreCase))
        if ($forceRestart -or $wrongPath) {
          try { Stop-Process -Id ([int]$_.Id) -Force -ErrorAction Stop } catch {}
        }
      }
    } catch {}

    if ($forceRestart) {
      $stopDeadline = (Get-Date).AddSeconds(10)
      do {
        Start-Sleep -Milliseconds 200
        $left = @(Get-Process -Name 'KafePin Pro' -ErrorAction SilentlyContinue | Where-Object { try { [int]$_.SessionId -eq $currentSessionId } catch { $false } })
      } while ($left.Count -gt 0 -and (Get-Date) -lt $stopDeadline)
      if ($left.Count -gt 0) { throw 'Eski KafePin masaustu prosesi forceRestart sonrasinda kapanmadi.' }
    }
    $existing = Find-KafePinInCurrentSession
    if (-not $existing) {
      $started = Start-Process -FilePath $appPath -WorkingDirectory (Split-Path -Parent $appPath) -PassThru
      $deadline = (Get-Date).AddSeconds(20)
      do {
        Start-Sleep -Milliseconds 250
        $existing = Find-KafePinInCurrentSession
      } while (-not $existing -and (Get-Date) -lt $deadline)
    }
    if (-not $existing) { throw ('Exact KafePin masaüstü uygulaması interaktif Session ' + $currentSessionId + ' içinde başlatılamadı: ' + $appPath) }
    $verifiedPath = Get-KafePinProcessPath $existing
    if (-not $verifiedPath -or -not $verifiedPath.Equals($appPath, [System.StringComparison]::OrdinalIgnoreCase)) {
      throw ('Yanlış KafePin Pro.exe çalışıyor. Beklenen=' + $appPath + ' Çalışan=' + $verifiedPath)
    }
    $processStartUnixMs = ([DateTimeOffset]$existing.StartTime.ToUniversalTime()).ToUnixTimeMilliseconds()
    if ($notBeforeUnixMs -gt 0 -and ($processStartUnixMs + 2000) -lt $notBeforeUnixMs) { throw 'KafePin masaustu prosesi yeni build sonrasinda baslatilmamis.' }
    Write-Result $requestId $true $true ([Int64]$existing.Id) '' $verifiedPath $false $actionName ([Int64]$existing.Id) $processStartUnixMs $actualExeSha256
    exit 0
  }

  $target = [string]$request.folder
  if (-not $target) { throw 'Klasör yolu boş.' }
  $target = [System.IO.Path]::GetFullPath($target).TrimEnd('\')
  if (-not (Test-Path -LiteralPath $target -PathType Container)) { throw ('Klasör bulunamadı: ' + $target) }

  Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class KafePinDesktopNative {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern IntPtr SetActiveWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint flags);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extraInfo);
  [DllImport("user32.dll")] public static extern void SwitchToThisWindow(IntPtr hWnd, bool altTab);
}
'@

  function Normalize-Path([string]$Value) {
    try { return [System.IO.Path]::GetFullPath($Value).TrimEnd('\') } catch { return '' }
  }

  function Find-Window([string]$Wanted) {
    try {
      $shell = New-Object -ComObject Shell.Application
      foreach ($window in @($shell.Windows())) {
        try {
          if (-not $window.HWND) { continue }
          $url = [string]$window.LocationURL
          if (-not $url.StartsWith('file:', [System.StringComparison]::OrdinalIgnoreCase)) { continue }
          $candidate = Normalize-Path ([System.Uri]::UnescapeDataString(([System.Uri]$url).LocalPath))
          if ($candidate -ieq $Wanted) { return $window }
        } catch {}
      }
    } catch {}
    return $null
  }

  function Force-Foreground([IntPtr]$Hwnd) {
    [KafePinDesktopNative]::ShowWindowAsync($Hwnd, 9) | Out-Null
    try {
      $wshell = New-Object -ComObject WScript.Shell
      $wshell.SendKeys('%')
    } catch {}
    try {
      [KafePinDesktopNative]::keybd_event(0x12, 0, 0, [UIntPtr]::Zero)
      [KafePinDesktopNative]::keybd_event(0x12, 0, 2, [UIntPtr]::Zero)
    } catch {}
    [KafePinDesktopNative]::SwitchToThisWindow($Hwnd, $true)
    $flags = 0x0001 -bor 0x0002 -bor 0x0040
    [KafePinDesktopNative]::SetWindowPos($Hwnd, [IntPtr](-1), 0, 0, 0, 0, $flags) | Out-Null
    Start-Sleep -Milliseconds 40
    [KafePinDesktopNative]::SetWindowPos($Hwnd, [IntPtr](-2), 0, 0, 0, 0, $flags) | Out-Null
    [KafePinDesktopNative]::BringWindowToTop($Hwnd) | Out-Null
    [KafePinDesktopNative]::SetActiveWindow($Hwnd) | Out-Null
    [KafePinDesktopNative]::SetForegroundWindow($Hwnd) | Out-Null
  }

  $window = Find-Window $target
  if (-not $window) {
    # Bu script interaktif kullanıcının gerçek masaüstü oturumunda çalışır.
    # Shell.Application ile açmak Explorer'ın aynı kullanıcı oturumunda açılmasını sağlar.
    try {
      $shell = New-Object -ComObject Shell.Application
      $shell.Open($target)
    } catch {
      Start-Process -FilePath (Join-Path $env:WINDIR 'explorer.exe') -ArgumentList @($target) | Out-Null
    }
  }

  $deadline = (Get-Date).AddSeconds(5)
  $hwnd = [IntPtr]::Zero
  do {
    $window = Find-Window $target
    if ($window) {
      $hwnd = [IntPtr]([Int64]$window.HWND)
      for ($i=0; $i -lt 4; $i++) {
        Force-Foreground $hwnd
        Start-Sleep -Milliseconds 110
        if ([KafePinDesktopNative]::GetForegroundWindow() -eq $hwnd) {
          Write-Result $requestId $true $true ([Int64]$hwnd) '' '' $false $actionName
          exit 0
        }
      }
    }
    Start-Sleep -Milliseconds 140
  } while ((Get-Date) -lt $deadline)

  # Son güvenli deneme: klasörü tekrar Shell üzerinden çağır; ardından bulunan HWND'yi üstte tut.
  try {
    $shell = New-Object -ComObject Shell.Application
    $shell.Open($target)
  } catch {}
  Start-Sleep -Milliseconds 350
  $window = Find-Window $target
  if ($window) {
    $hwnd = [IntPtr]([Int64]$window.HWND)
    Force-Foreground $hwnd
    Start-Sleep -Milliseconds 180
    if ([KafePinDesktopNative]::GetForegroundWindow() -eq $hwnd) {
      Write-Result $requestId $true $true ([Int64]$hwnd) '' '' $false $actionName
      exit 0
    }
  }

  throw 'Explorer penceresi kullanıcı masaüstünde öne alınamadı.'
} catch {
  Write-Result $requestId $false $false 0 ([string]$_.Exception.Message) '' $false $actionName
  exit 31
}
