param(
  [string]$InstallRoot = 'C:\KafePin',
  [int]$TimeoutSeconds = 25,
  [string]$ExpectedExeSha256 = '',
  [Int64]$NotBeforeUnixMs = 0
)

$ErrorActionPreference = 'Stop'
$appPath = Join-Path $InstallRoot 'desktop-app\KafePin Pro.exe'
if (-not (Test-Path -LiteralPath $appPath -PathType Leaf)) { throw ('KafePin Pro.exe bulunamadi: ' + $appPath) }
$ExpectedExeSha256 = $ExpectedExeSha256.Trim().ToLowerInvariant()
$actualExeSha256 = (Get-FileHash -LiteralPath $appPath -Algorithm SHA256).Hash.ToLowerInvariant()
if ($ExpectedExeSha256 -and $actualExeSha256 -ne $ExpectedExeSha256) { throw ('KafePin EXE SHA dogrulanamadi. Beklenen=' + $ExpectedExeSha256 + ' Gercek=' + $actualExeSha256) }

function Get-InteractiveUser {
  try {
    $u = [string](Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).UserName
    if ($u) { return $u }
  } catch {}
  try {
    foreach ($p in @(Get-CimInstance Win32_Process -Filter "Name='explorer.exe'" -ErrorAction Stop | Sort-Object SessionId -Descending)) {
      if ([int]$p.SessionId -le 0) { continue }
      try {
        $owner = Invoke-CimMethod -InputObject $p -MethodName GetOwner -ErrorAction Stop
        if ($owner.User) {
          if ($owner.Domain) { return ([string]$owner.Domain + '\' + [string]$owner.User) }
          return [string]$owner.User
        }
      } catch {}
    }
  } catch {}
  return ''
}

function Get-InteractiveKafePin([string]$ExactPath = '') {
  try {
    foreach ($p in @(Get-CimInstance Win32_Process -Filter "Name='KafePin Pro.exe'" -ErrorAction SilentlyContinue)) {
      if ([int]$p.SessionId -le 0) { continue }
      $candidate = ''
      try { $candidate = [System.IO.Path]::GetFullPath([string]$p.ExecutablePath) } catch {}
      if (-not $ExactPath -or ($candidate -and $candidate.Equals($ExactPath,[System.StringComparison]::OrdinalIgnoreCase))) {
        if ($NotBeforeUnixMs -gt 0) {
          try {
            $started = [Management.ManagementDateTimeConverter]::ToDateTime([string]$p.CreationDate).ToUniversalTime()
            if (([DateTimeOffset]$started).ToUnixTimeMilliseconds() + 2000 -lt $NotBeforeUnixMs) { continue }
          } catch { continue }
        }
        return $p
      }
    }
  } catch {}
  return $null
}

$user = Get-InteractiveUser
if (-not $user) { throw 'Aktif Windows masaustu kullanicisi bulunamadi.' }
$exact = [System.IO.Path]::GetFullPath($appPath)

# Eski/yanlis kabuk kalmasin. Update sonrasi tek otorite exact desktop-app EXE'dir.
try {
  Get-CimInstance Win32_Process -Filter "Name='KafePin Pro.exe'" -ErrorAction SilentlyContinue | ForEach-Object {
    try { Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue } catch {}
  }
} catch {}
Start-Sleep -Milliseconds 700

$taskName = 'KafePin Pro Update Reopen'
$service = New-Object -ComObject 'Schedule.Service'
$service.Connect()
$root = $service.GetFolder('\')
try { $root.DeleteTask($taskName,0) } catch {}
$definition = $service.NewTask(0)
$definition.RegistrationInfo.Description = 'KafePin Pro update sonrasi exact masaustu kabugunu interaktif kullanici oturumunda acar.'
$definition.Settings.Enabled = $true
$definition.Settings.AllowDemandStart = $true
$definition.Settings.StartWhenAvailable = $true
$definition.Settings.Hidden = $true
$definition.Settings.ExecutionTimeLimit = 'PT1M'
$definition.Settings.MultipleInstances = 2
$definition.Principal.UserId = $user
$definition.Principal.LogonType = 3
$definition.Principal.RunLevel = 1
$action = $definition.Actions.Create(0)
$action.Path = $exact
$action.WorkingDirectory = Split-Path -Parent $exact
$task = $root.RegisterTaskDefinition($taskName,$definition,6,$user,$null,3,$null)
if (-not $task) { throw 'KafePin reopen gorevi kaydedilemedi.' }
$null = $task.Run($null)

$deadline = (Get-Date).AddSeconds([Math]::Max(5,$TimeoutSeconds))
$found = $null
do {
  Start-Sleep -Milliseconds 250
  $found = Get-InteractiveKafePin $exact
} while (-not $found -and (Get-Date) -lt $deadline)

try { $root.DeleteTask($taskName,0) } catch {}
if (-not $found) { throw ('Exact KafePin Pro.exe interaktif oturumda acilamadi: ' + $exact) }
Write-Output ('REOPEN_OK|' + [string]$found.ProcessId + '|' + [string]$found.SessionId + '|' + $exact + '|' + $actualExeSha256)
exit 0
