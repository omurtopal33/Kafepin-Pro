﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace KafePinProDesktop
{
    internal static class NativeMethods
    {
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        internal static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll")]
        internal static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")]
        internal static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
    }

    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            bool createdNew;
            using (Mutex mutex = new Mutex(true, "Local\\KafePinProDesktopApp", out createdNew))
            {
                if (!createdNew)
                {
                    IntPtr hwnd = NativeMethods.FindWindow(null, "KafePin Pro");
                    if (hwnd != IntPtr.Zero)
                    {
                        NativeMethods.ShowWindowAsync(hwnd, 9);
                        NativeMethods.SetForegroundWindow(hwnd);
                    }
                    return;
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MainForm());
            }
        }
    }

    internal sealed class MainForm : Form
    {
        private const string HomeUrl = "http://127.0.0.1:3000/kafepin-pro-yonetim.html";
        private readonly WebView2 browser;
        private readonly Panel splash;
        private readonly Label splashTitle;
        private readonly Label splashText;
        private readonly Button retryButton;
        private bool initializing;

        internal MainForm()
        {
            Text = "KafePin Pro";
            StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;
            MinimumSize = new Size(960, 650);
            BackColor = Color.FromArgb(9, 13, 20);
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

            browser = new WebView2();
            browser.Dock = DockStyle.Fill;
            browser.Visible = false;
            Controls.Add(browser);

            splash = new Panel();
            splash.Dock = DockStyle.Fill;
            splash.BackColor = Color.FromArgb(9, 13, 20);
            Controls.Add(splash);
            splash.BringToFront();

            splashTitle = new Label();
            splashTitle.AutoSize = false;
            splashTitle.TextAlign = ContentAlignment.MiddleCenter;
            splashTitle.ForeColor = Color.FromArgb(98, 240, 179);
            splashTitle.Font = new Font("Segoe UI", 28F, FontStyle.Bold);
            splashTitle.Text = "KafePin Pro";
            splashTitle.Height = 60;
            splash.Controls.Add(splashTitle);

            splashText = new Label();
            splashText.AutoSize = false;
            splashText.TextAlign = ContentAlignment.MiddleCenter;
            splashText.ForeColor = Color.FromArgb(190, 214, 232);
            splashText.Font = new Font("Segoe UI", 12F, FontStyle.Regular);
            splashText.Text = "Yonetim Merkezi baslatiliyor...";
            splashText.Height = 36;
            splash.Controls.Add(splashText);

            retryButton = new Button();
            retryButton.Text = "Yeniden Dene";
            retryButton.Width = 150;
            retryButton.Height = 38;
            retryButton.Visible = false;
            retryButton.FlatStyle = FlatStyle.Flat;
            retryButton.ForeColor = Color.White;
            retryButton.BackColor = Color.FromArgb(22, 69, 47);
            retryButton.FlatAppearance.BorderColor = Color.FromArgb(39, 138, 91);
            retryButton.Click += delegate { BeginInitialize(); };
            splash.Controls.Add(retryButton);

            Resize += delegate { LayoutSplash(); };
            Shown += delegate { BeginInitialize(); };
            FormClosing += delegate { try { browser.Dispose(); } catch { } };
            LayoutSplash();
        }

        private void LayoutSplash()
        {
            int w = ClientSize.Width;
            int h = ClientSize.Height;
            splashTitle.SetBounds(0, Math.Max(120, h / 2 - 100), w, 60);
            splashText.SetBounds(0, Math.Max(180, h / 2 - 35), w, 36);
            retryButton.Left = Math.Max(10, w / 2 - retryButton.Width / 2);
            retryButton.Top = Math.Max(230, h / 2 + 25);
        }

        private async void BeginInitialize()
        {
            if (initializing) return;
            initializing = true;
            retryButton.Visible = false;
            splashText.Text = "Yonetim Merkezi baslatiliyor...";

            try
            {
                string userData = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "KafePinPro", "WebView2");
                Directory.CreateDirectory(userData);

                // Loader DLL yolu acikca KafePin uygulama klasorune sabitlenir.
                // Boylece program Edge tarayicisini degil WebView2 Runtime'i kullanir.
                CoreWebView2Environment.SetLoaderDllFolderPath(AppDomain.CurrentDomain.BaseDirectory);
                CoreWebView2Environment env = await CoreWebView2Environment.CreateAsync(null, userData);
                await browser.EnsureCoreWebView2Async(env);

                browser.CoreWebView2.Settings.AreDevToolsEnabled = false;
                browser.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
                browser.CoreWebView2.Settings.IsStatusBarEnabled = false;
                browser.CoreWebView2.Settings.IsZoomControlEnabled = false;

                browser.CoreWebView2.NewWindowRequested += CoreWebView2_NewWindowRequested;
                browser.CoreWebView2.NavigationStarting += CoreWebView2_NavigationStarting;
                browser.CoreWebView2.ProcessFailed += delegate
                {
                    BeginInvoke((MethodInvoker)delegate
                    {
                        splash.Visible = true;
                        splash.BringToFront();
                        splashText.Text = "Goruntu motoru yeniden baslatiliyor...";
                        retryButton.Visible = true;
                    });
                };
                browser.NavigationCompleted += Browser_NavigationCompleted;

                bool ready = await WaitForServerAsync(45);
                if (!ready)
                {
                    splashText.Text = "KafePin sunucusuna ulasilamadi. Windows Sistem Yoneticisinin calistigini kontrol et.";
                    retryButton.Visible = true;
                    initializing = false;
                    return;
                }

                browser.Source = new Uri(HomeUrl);
            }
            catch (Exception ex)
            {
                splashText.Text = "KafePin Pro acilamadi: " + ex.Message;
                retryButton.Visible = true;
                initializing = false;
            }
        }

        private async Task<bool> WaitForServerAsync(int maxSeconds)
        {
            int attempts = Math.Max(1, maxSeconds * 2);
            for (int i = 0; i < attempts; i++)
            {
                bool ok = await Task.Run(delegate
                {
                    try
                    {
                        HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:3000/api/health");
                        req.Method = "GET";
                        req.Timeout = 1000;
                        req.ReadWriteTimeout = 1000;
                        using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                        {
                            return (int)resp.StatusCode >= 200 && (int)resp.StatusCode < 300;
                        }
                    }
                    catch { return false; }
                });
                if (ok) return true;
                await Task.Delay(500);
            }
            return false;
        }

        private void Browser_NavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            if (e.IsSuccess)
            {
                browser.Visible = true;
                splash.Visible = false;
                initializing = false;
            }
            else
            {
                browser.Visible = false;
                splash.Visible = true;
                splash.BringToFront();
                splashText.Text = "Yonetim Merkezi yuklenemedi. Tekrar denenebilir.";
                retryButton.Visible = true;
                initializing = false;
            }
        }

        private void CoreWebView2_NavigationStarting(object sender, CoreWebView2NavigationStartingEventArgs e)
        {
            if (IsLocalKafePinUrl(e.Uri)) return;
            e.Cancel = true;
            OpenExternal(e.Uri);
        }

        private void CoreWebView2_NewWindowRequested(object sender, CoreWebView2NewWindowRequestedEventArgs e)
        {
            e.Handled = true;
            if (IsLocalKafePinUrl(e.Uri))
            {
                browser.CoreWebView2.Navigate(e.Uri);
                return;
            }
            OpenExternal(e.Uri);
        }

        private static bool IsLocalKafePinUrl(string value)
        {
            Uri uri;
            if (!Uri.TryCreate(value, UriKind.Absolute, out uri)) return false;
            if (uri.Scheme == "about") return true;
            if (uri.Scheme != "http" && uri.Scheme != "https") return false;
            return string.Equals(uri.Host, "127.0.0.1", StringComparison.OrdinalIgnoreCase)
                || string.Equals(uri.Host, "localhost", StringComparison.OrdinalIgnoreCase);
        }

        private static void OpenExternal(string url)
        {
            try { Process.Start(url); } catch { }
        }
    }
}
