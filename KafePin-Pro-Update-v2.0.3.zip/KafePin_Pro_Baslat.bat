@echo off
setlocal
cd /d "%~dp0"
set "NODEEXE=node"
if exist "%ProgramFiles%\nodejs\node.exe" set "NODEEXE=%ProgramFiles%\nodejs\node.exe"
"%NODEEXE%" --version >nul 2>nul
if errorlevel 1 (
  echo Node.js bulunamadi.
  pause
  exit /b 1
)
set "KAFEPORT=3000"
for /f "tokens=1,2 delims==" %%A in ('findstr /R /B "PORT=" ".env" 2^>nul') do if /I "%%A"=="PORT" set "KAFEPORT=%%B"
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":%KAFEPORT%" ^| findstr LISTENING') do set KAFEPIN_PID=%%P
if defined KAFEPIN_PID exit /b 0
if not exist logs mkdir logs >nul 2>nul
set "KAFEPIN_LOG=%~dp0logs\kafepin.log"
set "KAFEPIN_ERRLOG=%~dp0logs\kafepin-error.log"
rem PowerShell ortamindaki PATH/PATH cakismazligi nedeniyle Start-Process
rem kullanilmaz. CMD, Program Files altindaki Node yolunu dogrudan calistirir.
start "" /b "%NODEEXE%" server.js > "%KAFEPIN_LOG%" 2> "%KAFEPIN_ERRLOG%"
exit /b 0
