require("dotenv").config();
const {
  MASA_TOKENS,
  MASA_IPS,
  VIP_MASALAR
} = require("./config/masalar");
const createFeeUtils = require("./utils/fee");
const createDateUtils =
  require("./utils/date");
const {
  logErr,
  logInfo
} = require("./utils/logger");
const createSpinService =
  require("./services/spinService");
const express = require("express");
// Canlı sistem günlüğü
const liveLogs = [];
const MAX_LIVE_LOG = 100;

function addLiveLog(type, text) {
  liveLogs.unshift({
    time: Date.now(),
    type,
    text
  });

  if (liveLogs.length > MAX_LIVE_LOG) {
    liveLogs.length = MAX_LIVE_LOG;
  }
}
const sqlite3 = require("sqlite3").verbose();
const cron = require("node-cron");
const path = require("path");
const https = require("https");
const os = require("os");
const fs = require("fs");
const crypto = require("crypto");
const { spawn } = require("child_process");
// KafePin Pro otomatik guncelleme merkezi. Depoda sadece program
// paketleri bulunur; kafe verileri, tokenlar ve yedekler asla yuklenmez.
const PRO_VERSION_FILE = path.join(__dirname, "kafepin-pro-version.json");
const PRO_UPDATE_MANIFEST_URL =
  "https://raw.githubusercontent.com/omurtopal33/Kafepin-Pro/main/latest.json";
let proUpdateCache = { checkedAt: 0, data: null, error: "" };

// Guncelleyici, sunucu kapaliyken tamamlanan kurulumu bu kucuk sonuc dosyasina
// yazar. Yeni sunucu acildiginda kaydi Canli Sistem Gunlugu'ne bir kez aktarir.
function importProUpdateResult() {
  const resultFile = path.join(__dirname, "logs", "kafepin-pro-update-result.json");
  try {
    const raw = fs.readFileSync(resultFile, "utf8").replace(/^\uFEFF/, "");
    const result = JSON.parse(raw);
    if (result && result.ok && result.version) {
      addLiveLog("pro_update", `⬆️ KafePin Pro v${result.version} guncellemesi basariyla kuruldu`);
    } else if (result && result.error) {
      addLiveLog("pro_update", `⚠️ KafePin Pro guncellemesi tamamlanamadi: ${String(result.error).slice(0, 180)}`);
    }
    fs.unlinkSync(resultFile);
  } catch (_err) {}
}
importProUpdateResult();

function getProVersion() {
  try {
    const raw = fs.readFileSync(PRO_VERSION_FILE, "utf8").replace(/^\uFEFF/, "");
    const value = JSON.parse(raw);
    return String(value.version || "1.0.0");
  } catch (_err) {
    return "1.0.0";
  }
}

function compareProVersions(a, b) {
  const aa = String(a || "0").split(".").map(x => Number(x) || 0);
  const bb = String(b || "0").split(".").map(x => Number(x) || 0);
  for (let i = 0; i < Math.max(aa.length, bb.length); i += 1) {
    if ((aa[i] || 0) !== (bb[i] || 0)) return (aa[i] || 0) > (bb[i] || 0) ? 1 : -1;
  }
  return 0;
}


function freshManifestUrl(url) {
  const sep = String(url).includes("?") ? "&" : "?";
  return `${url}${sep}kafepin_cb=${Date.now()}_${Math.random().toString(36).slice(2)}`;
}

function fetchManifestUrl(url, callback) {
  const request = https.get(url, {
    headers: {
      "User-Agent": "KafePin-Pro-Updater",
      "Cache-Control": "no-cache, no-store, max-age=0",
      "Pragma": "no-cache"
    }
  }, response => {
    if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
      response.resume();
      return fetchManifestUrl(response.headers.location, callback);
    }
    if (response.statusCode !== 200) {
      response.resume();
      return callback(new Error(`Guncelleme sunucusu HTTP ${response.statusCode}`));
    }
    let body = "";
    response.on("data", chunk => { body += chunk; });
    response.on("end", () => callback(null, body));
  });
  request.setTimeout(10000, () => request.destroy(new Error("Guncelleme kontrolu zaman asimina ugradi")));
  request.on("error", callback);
}

function fetchProUpdateManifest(callback) {
  // Her kontrolde benzersiz URL kullanilir. Böylece GitHub RAW / CDN
  // edge cache eski latest.json dosyasini dondurse bile yeni surum aninda gorulur.
  const urls = [
    PRO_UPDATE_MANIFEST_URL,
    "https://raw.githubusercontent.com/omurtopal33/Kafepin-Pro/main/latest.json",
    "https://cdn.jsdelivr.net/gh/omurtopal33/Kafepin-Pro@main/latest.json"
  ];
  let lastError = null;
  const tryNext = index => {
    if (index >= urls.length) return callback(lastError || new Error("Guncelleme merkezi kullanilamiyor"));
    const requestUrl = freshManifestUrl(urls[index]);
    fetchManifestUrl(requestUrl, (err, body) => {
      if (!err) return callback(null, body, requestUrl);
      lastError = err;
      tryNext(index + 1);
    });
  };
  tryNext(0);
}

function checkProUpdate(force, callback) {
  const now = Date.now();
  if (!force && proUpdateCache.data && now - proUpdateCache.checkedAt < 60000) return callback(null, proUpdateCache.data);
  fetchProUpdateManifest((err, body, manifestUrl) => {
    proUpdateCache.checkedAt = Date.now();
    if (err) { proUpdateCache.error = String(err.message || err); return callback(err); }
    try {
      const remote = JSON.parse(body);
      if (!remote || !/^\d+(\.\d+){1,3}$/.test(String(remote.version || "")) || !/^https:\/\//i.test(String(remote.downloadUrl || ""))) {
        throw new Error("Guncelleme manifest dosyasi gecersiz");
      }
      const current = getProVersion();
      proUpdateCache.error = "";
      proUpdateCache.data = {
        currentVersion: current,
        latestVersion: String(remote.version),
        available: compareProVersions(remote.version, current) > 0,
        notes: String(remote.notes || "Yeni surum hazir."),
        publishedAt: remote.publishedAt || null,
        downloadUrl: String(remote.downloadUrl),
        sha256: /^[a-f0-9]{64}$/i.test(String(remote.sha256 || "")) ? String(remote.sha256) : "",
        manifestUrl: String(manifestUrl || ""),
        checkedAt: proUpdateCache.checkedAt
      };
      callback(null, proUpdateCache.data);
    } catch (parseErr) {
      proUpdateCache.error = String(parseErr.message || parseErr);
      callback(parseErr);
    }
  });
}
let liveMessageId = 0;
const masaPingStats = {};
const latestRewardMap = {};
const OFFLINE_MS = 8 * 60 * 1000; // 8 dk
const PING_INTERVAL_MS = 10000; // client ping 10 sn varsayım
const OFFLINE_GRACE_MULTIPLIER = 6; // 6 ping kaçırmayı tolere et
const AUTO_RESET_MS = 12 * 60 * 1000;
const CLEANUP_MS = 20 * 60 * 1000; // 20 dk
const offlineCount = {};
const lastOfflineState = {};
const BOS_ODULLER = [
  "şansına küs",
  "bir dahaki sefere",
  "tekrar dene :)"
];

const lastStartSent = new Map();
const app = express();
const port = 3000;

app.use(express.json());

function isLocalhost(req) {
  const ip = (req.ip || "").replace("::ffff:", "");
  return ip === "127.0.0.1" || ip === "::1";
}

function setNoStore(res) {
  res.set("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.set("Pragma", "no-cache");
  res.set("Expires", "0");
}
function isActuallyOffline(masa, lastSeen, now) {
  if (!lastSeen) return true;

  const diff = now - lastSeen;

  const dynamicPing =
    masaPingStats[masa]?.avg || PING_INTERVAL_MS;

  const threshold = Math.max(
    OFFLINE_MS,
    dynamicPing * OFFLINE_GRACE_MULTIPLIER
  );

  return diff > threshold;
}

app.use((req, res, next) => {
  const p = req.path || "";

  const isProtected =
    p.startsWith("/admin") ||
    p.startsWith("/monitor") ||
    p === "/admin.html" ||
    p === "/monitor.html";

  if (isProtected && !isLocalhost(req)) {
    return res.status(403).send("Forbidden");
  }
  next();
});

app.use(express.static("public", {
  setHeaders(res, filePath) {
    const ext = path.extname(filePath || "").toLowerCase();
    if (ext === ".html") res.setHeader("Content-Type", "text/html; charset=utf-8");
    if (ext === ".css") res.setHeader("Content-Type", "text/css; charset=utf-8");
    if (ext === ".js") res.setHeader("Content-Type", "application/javascript; charset=utf-8");
    if (ext === ".json") res.setHeader("Content-Type", "application/json; charset=utf-8");
  }
}));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const db = new sqlite3.Database("./database.db");
const FULL_BACKUP_DIR = "D:\\KAFEPIN_YEDEK\\FULL\\ZIP";
const EVERYCAFE_DB_PATH = process.env.EVERYCAFE_DB_PATH || "C:\\Program Files (x86)\\EveryCafeManager\\ecmdata.ecm";
// Aktif/ücretsiz EveryCafe oturumları monitöre gecikmeden düşsün. Bağlantı
// salt-okunur olduğu için kısa aralık, kasa ve kapanış kayıtlarını değiştirmez.
const EVERYCAFE_SYNC_MS = 5 * 1000;
const EVERYCAFE_HEALTH_WARNING_MS = 3 * 60 * 1000;
let everyCafeSyncRunning = false;
let fullBackupRunning = false;
let lastFullBackup = null;
let everyCafeHealth = {
  lastSuccess: 0,
  lastError: "",
  failureSince: 0,
  warningActive: false
};
let lastEveryCafeDailyAudit = null;
const everyCafeSessionTypes = new Map();
// EveryCafe'de EndDate'i başlangıçtan ileride olan oturumlar süreli açılmıştır.
// Bu masalarda ilk fiyat basamağı 60. dakikadan sonra gelir.
const everyCafeTimedSessions = new Map();
// Süreli EveryCafe oturumlarında kaynak bitişi, canlı fiyatın da üst sınırıdır.
// Böylece EveryCafe kapanışı işlenene kadar monitör fazladan bir ücret basamağı göstermez.
const everyCafeScheduledEnds = new Map();

// EveryCafe'de "Beklemede" ekranında olan masa henüz Windows'a geçmemiştir.
// Bu kayıt izleme içindir; KafePin oturumu, ücret veya çark hakkı oluşturmaz.
const everyCafeWaitingMasalar = new Map();
const everyCafeWaitingLookupCache = new Map();
// Kesin EveryCafe kapanışını, sonrasında gelen bekleme pinglerinden ayırır.
const everyCafeRecentlyClosedMasalar = new Map();
// EveryCafe'de verilen "Ücretsiz Süre" dakikaları yalnızca canlı ücret
// göstergesinden düşülür. Kapanışta kaynak sistemin PaymentAmount değeri
// yine tek doğru tahsilat olarak kullanılmaya devam eder.
const everyCafeGiftMinutes = new Map();

function everyCafeGiftMinutesFromSource(value) {
  const raw = Math.max(0, Number(value) || 0);
  // EveryCafe süre alanlarını saniye saklar (ör. 60 dk ek süre = 3600).
  // Eski/alternatif sürümlerde dakika tutulursa 15/30/45/60 değerleri de
  // doğru çalışmaya devam eder.
  const minutes = raw >= 120 ? raw / 60 : raw;
  return Math.min(24 * 60, Math.round(minutes * 100) / 100);
}

function getEveryCafeGiftMinutes(masa) {
  return Math.min(24 * 60, Math.max(0, Number(everyCafeGiftMinutes.get(Number(masa))) || 0));
}

function isEveryCafeTimedMasa(masa) {
  return everyCafeTimedSessions.get(Number(masa)) === true;
}

function getEveryCafeScheduledEnd(masa) {
  return Math.max(0, Number(everyCafeScheduledEnds.get(Number(masa))) || 0);
}

function recordEveryCafeSyncSuccess() {
  const recovered = everyCafeHealth.warningActive;
  everyCafeHealth = { lastSuccess: Date.now(), lastError: "", failureSince: 0, warningActive: false };
  if (recovered) {
    addLiveLog("everycafe_health", "✅ EveryCafe bağlantısı yeniden sağlandı");
    if (TELEGRAM_ENABLED) sendTelegramMessage("✅ EveryCafe bağlantısı yeniden sağlandı.", () => {});
  }
}

function recordEveryCafeSyncFailure(scope, err) {
  const now = Date.now();
  if (!everyCafeHealth.failureSince) everyCafeHealth.failureSince = now;
  everyCafeHealth.lastError = String(err && (err.message || err) || "Bilinmeyen hata");
  if (everyCafeHealth.warningActive || now - everyCafeHealth.failureSince < EVERYCAFE_HEALTH_WARNING_MS) return;
  everyCafeHealth.warningActive = true;
  const minutes = Math.floor((now - everyCafeHealth.failureSince) / 60000);
  const text = `⚠️ EveryCafe bağlantısı ${minutes} dk veri okuyamadı: ${everyCafeHealth.lastError}`;
  addLiveLog("everycafe_health", text);
  if (TELEGRAM_ENABLED) sendTelegramMessage(text, () => {});
}

// 🔥 Masa bazlı queue sistemi
const finalizeQueues = new Map();
const finalizeInProgress = new Set();
function enqueueFinalize(masa, task) {
  const prev = finalizeQueues.get(masa) || Promise.resolve();

const next = prev
  .then(() => task())
  .catch((err) => {
    console.error("Queue task error:", err);
  })
  .finally(() => {
    // sadece en son promise ise sil
    if (finalizeQueues.get(masa) === next) {
      finalizeQueues.delete(masa);
    }
  });

finalizeQueues.set(masa, next);

  return next;
}


db.on("error", (err) => {
  console.error("SQLite error:", err);
});

process.on("uncaughtException", (err) => {
  console.error("UNCAUGHT EXCEPTION:", err);

  
});

process.on("unhandledRejection", (reason) => {
  console.error("UNHANDLED REJECTION:", reason);

  setTimeout(() => process.exit(1), 500);
});


db.serialize(() => {
  db.run("PRAGMA journal_mode=WAL;");
  db.run("PRAGMA synchronous=NORMAL;");
  db.run("PRAGMA temp_store=MEMORY;");
  db.run("PRAGMA foreign_keys=ON;");
  db.run("PRAGMA busy_timeout=10000;");
  db.run("PRAGMA cache_size=-20000;");
});

let aktifMasalar = {};
const diagnostics = {
  cleanupCount: 0,
  finalizeCount: 0,
  offlineCloseCount: 0,

  lastCleanup: 0,
  lastFinalize: 0,
  lastPing: 0,

  lastCleanupMasa: null,
  lastFinalizeMasa: null
};
const MASA_SAYISI = 23;
for (let i = 1; i <= MASA_SAYISI; i++) {
  masaPingStats[i] = {
    last: 0,
    avg: PING_INTERVAL_MS,
    lastSeen: 0,
    netSpeed: 0
  };
}



let SPIN_SURE_DK = 45;

let TEST_MODE = 0;
// EveryCafe aktifken manuel masa kapatma/sıfırlama işlemleri ancak bu mod açıkken yapılabilir.
let EVERYCAFE_MAINTENANCE_MODE = 0;
const TEST_SPIN_SURE_DK = 1;

const GUNLUK_SPIN_LIMIT = 5;

/*
SESSION ÜCRETİ
--------------
- İlk 60 dakika açılış ücreti
- 60 dakikadan sonra her 15 dakikada bir artış
- İlk artış için +2 dakika tolerans uygulanır

SPIN ÖDÜL MALİYETİ
------------------
Hafta içi:
- Normal 30 dk = 20
- Normal 60 dk = 40
- VIP 30 dk    = 30
- VIP 60 dk    = 60

Hafta sonu:
- Normal 30 dk = 25
- Normal 60 dk = 50
- VIP 30 dk    = 35
- VIP 60 dk    = 70

İçecek / ürün:
- Sabit 20 TL
*/

const NORMAL_OPENING = 50;
const VIP_OPENING = 70;

/*
60 dk referans ücret bilgileri
*/
const NORMAL_SAAT = 87.5;
const VIP_SAAT = 122.5;

const NORMAL_ARTIS = 25;
const VIP_ARTIS = 35;

const ICECEK_MALIYET = 20;
const BUYUK_ODUL_HEDEF = 14;
const BUYUK_ODUL_HEDEF_VIP = 10;
const {
  getPricingForTs,
  calcRealFee,
  feeAtTime: calculateFeeAtTime
} = createFeeUtils({
  VIP_MASALAR,
  NORMAL_OPENING,
  VIP_OPENING,
  NORMAL_SAAT,
  VIP_SAAT,
  NORMAL_ARTIS,
  VIP_ARTIS
});

function feeAtTime(masa, startTime, endTime) {
  const start = Number(startTime) || 0;
  const end = Number(endTime) || 0;
  if (!start || !end || end <= start) return 0;
  // EveryCafe ile birebir tarife: başlangıç ve tüm fiyat basamakları
  // kaynak sistemdeki normal ücret düzeniyle hesaplanır. Test gerekiyorsa
  // masa EveryCafe'de ayrıca ücretsiz açılır.
  // EveryCafe: açılır açılmaz taban ücret, her tam 30 dakikada artış.
  // Eski yardımcıdaki 5 dakika test toleransı burada kullanılmaz.
  const vip = VIP_MASALAR.includes(Number(masa));
  const opening = vip ? VIP_OPENING : NORMAL_OPENING;
  const increase = vip ? VIP_ARTIS : NORMAL_ARTIS;
  // EveryCafe'deki ücretsiz süre, müşterinin hesabına eklenen süre değildir;
  // sadece ücretli geçen zamandan düşer. Böylece canlı toplam, EveryCafe'nin
  // kapanışta tahsil ettiği tutardan erken artmaz.
  const billedElapsed = Math.max(0, (end - start) - getEveryCafeGiftMinutes(masa) * 60 * 1000);
  const stepMs = 30 * 60 * 1000;
  // EveryCafe tarifesinde her masa ilk 1 saatlik ücreti peşin öder.
  // İlk artış 61. dakikada, sonraki artışlar ise her 30 dakikada gelir.
  const firstIncreaseAt = 60 * 60 * 1000;
  const stepCount = billedElapsed <= firstIncreaseAt
    ? 0
    : Math.ceil((billedElapsed - firstIncreaseAt) / stepMs);
  return opening + Math.max(0, stepCount) * increase;
}

const {
  weightedRandom,
  getRewardCostAndType,
  isBigReward
} = createSpinService({
  getPricingForTs,
  ICECEK_MALIYET
});

/*
  Ücret geçiş sistemi:
  - Açılış ücreti ilk 62 dakikaya kadar geçerli
  - Sonrasında her 15 dakikada bir artış uygulanır
*/
const UCRET_ARTIS_BLOK_DK = 30;

const DAY_SHIFT_MS = 20 * 60 * 60 * 1000;
// Banka kesintisi her kart işlemi için kuruşa yuvarlanır.
const CARD_COMMISSION_RATE = 0.0187;
const CARD_SETTLEMENT_DELAY_MS = 24 * 60 * 60 * 1000;
const {
  dayKey,
  dayStartTs
} = createDateUtils(
  DAY_SHIFT_MS
);

// POS bankası gün içindeki kartları tek yatırımla gönderebildiği için bu anahtar
// kafe günü değil, bankanın takvim günündeki kart işlem grubunu temsil eder.
function cardSettlementKey(ts) {
  const d = new Date(Number(ts) || 0);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

let globalSpinCount = 0;

let freeMasalar = new Set();
const freeOfflineCleanupInProgress = new Set();
function reloadBlockedMasalar(cb) {
  db.all(
    "SELECT masa FROM blocked_masalar WHERE until_time > ?",
    [Date.now()],
    (err, rows) => {
      if (err) logErr("reloadBlockedMasalar", err);
      blockedMasalar = new Set((rows || []).map((r) => r.masa));
      cb && cb();
    }
  );
}

const LOCK_MS = 90 * 1000;

let sessionLocks = new Map();
let masaCloseLocks = {};
let blockedMasalar = new Set();
let tokenTracker = {};

const ISTANBUL_WEEKDAY_FMT = new Intl.DateTimeFormat("en-US", {
  timeZone: "Europe/Istanbul",
  weekday: "short"
});

function isWeekendTs(ts = Date.now()) {
  const wd = ISTANBUL_WEEKDAY_FMT.format(new Date(ts));
  return wd === "Sat" || wd === "Sun";
}


const TELEGRAM_ENABLED = process.env.TELEGRAM_ENABLED === "1";
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID || "";

const GUN_SONU_RAPOR_SAAT = 20;
const GUN_SONU_RAPOR_DAKIKA = 0;

let lastDailyReportKey = "";
const TELEGRAM_DEDUP_MS = 10000;
const telegramRecentMessages = new Map();

function shouldSendTelegramDedup(key, windowMs = TELEGRAM_DEDUP_MS) {
  const now = Date.now();
  const last = telegramRecentMessages.get(key) || 0;

  if (now - last < windowMs) {
    return false;
  }

  telegramRecentMessages.set(key, now);

if (telegramRecentMessages.size > 1000) {
  telegramRecentMessages.clear();
}

  return true;
}

if (TELEGRAM_ENABLED) {
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
    console.log("⚠️ Telegram açık ama TELEGRAM_BOT_TOKEN veya TELEGRAM_CHAT_ID eksik.");
  } else {
    console.log("✅ Telegram .env üzerinden aktif.");
  }
} else {
  console.log("ℹ️ Telegram devre dışı.");
}

function reloadFreeMasalar(cb) {

  db.all("SELECT masa FROM free_masalar WHERE enabled=1", (err, rows) => {
    if (err) logErr("reloadFreeMasalar", err);
    freeMasalar = new Set((rows || []).map((r) => r.masa));
    cb && cb();
  });
}

function isFreeMasa(masa) {
  return freeMasalar.has(masa);
}

function setForceNewSession(masa, cb) {
  const now = Date.now();
  db.run(
    "INSERT INTO force_new_sessions(masa, set_time) VALUES(?,?) ON CONFLICT(masa) DO UPDATE SET set_time=excluded.set_time",
    [masa, now],
    (err) => {
      logErr("setForceNewSession", err);
      cb && cb();
    }
  );
}

function clearForceNewSession(masa, cb) {
  db.run("DELETE FROM force_new_sessions WHERE masa=?", [masa], (err) => {
    logErr("clearForceNewSession", err);
    cb && cb();
  });
}

function hasForceNewSession(masa, cb) {
  db.get("SELECT 1 as ok FROM force_new_sessions WHERE masa=? LIMIT 1", [masa], (err, row) => {
    if (err) {
      logErr("hasForceNewSession", err);
      return cb(false);
    }
    cb(!!row);
  });
}

function runAlter(sql, label) {
  db.run(sql, (err) => {
    if (err && !String(err.message || err).includes("duplicate column name")) {
      logErr(label, err);
    }
  });
}

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS spins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      masa INTEGER,
      reward TEXT,
      time INTEGER,
      used INTEGER DEFAULT 0
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS spins_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      masa INTEGER,
      reward TEXT,
      time INTEGER,
      used INTEGER DEFAULT 0
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS rewards (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      weight INTEGER,
      active INTEGER DEFAULT 1
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS masalar (
      masa INTEGER PRIMARY KEY,
      start_time INTEGER
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS sessions (
      masa INTEGER PRIMARY KEY,
      start_time INTEGER,
      last_seen INTEGER,
      end_time INTEGER DEFAULT 0
    )
  `);

  runAlter("ALTER TABLE sessions ADD COLUMN final_fee REAL DEFAULT 0", "alter sessions final_fee");

  db.run(`
    CREATE TABLE IF NOT EXISTS free_masalar (
      masa INTEGER PRIMARY KEY,
      enabled INTEGER DEFAULT 1,
      set_time INTEGER
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS real_adjustments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      time INTEGER,
      day_key TEXT,
      masa INTEGER,
      amount REAL,
      kind TEXT,
      note TEXT
    )
  `);

reloadFreeMasalar(() => {
  reloadBlockedMasalar(() => {});
});
db.all("SELECT masa, last_seen FROM sessions WHERE end_time=0", (err, rows) => {

  if (!err && rows) {
    const now = Date.now();

rows.forEach(r => {
  const last = r.last_seen || now;

  if (!isActuallyOffline(r.masa, last, now)) {
    aktifMasalar[r.masa] = last;

    addLiveLog(
      "restore",
      `♻️ Masa ${r.masa} geri yüklendi`
    );
  }
});

console.log("♻️ aktifMasalar restore edildi:", Object.keys(aktifMasalar).length);
  } else {
    console.error("aktifMasalar restore hatası:", err);
  }

});

  runAlter(
    "ALTER TABLE real_adjustments ADD COLUMN session_start INTEGER DEFAULT 0",
    "alter real_adjustments session_start"
  );

  db.run(`
    CREATE TABLE IF NOT EXISTS session_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      masa INTEGER NOT NULL,
      start_time INTEGER NOT NULL,
      end_time INTEGER NOT NULL,
      last_seen INTEGER DEFAULT 0,
      minutes INTEGER DEFAULT 0,
      fee REAL DEFAULT 0,
      close_reason TEXT DEFAULT '',
      note TEXT DEFAULT '',
      created_at INTEGER DEFAULT 0
    )
  `);
  runAlter(
    "ALTER TABLE session_history ADD COLUMN adjustment REAL DEFAULT 0",
    "alter session_history adjustment"
  );
db.run(`
  CREATE TABLE IF NOT EXISTS daily_reports (
    report_date TEXT PRIMARY KEY,

    report_ts INTEGER,

    total_spins INTEGER DEFAULT 0,
    used_rewards INTEGER DEFAULT 0,

    brut_gelir REAL DEFAULT 0,
    admin_duzeltmeleri REAL DEFAULT 0,
    spin_maliyeti REAL DEFAULT 0,
    gercek_gelir REAL DEFAULT 0,

    ortalama_masa_geliri REAL DEFAULT 0,

    top_reward TEXT,
    top_reward_count INTEGER DEFAULT 0,

    top_masa INTEGER,
    top_masa_count INTEGER DEFAULT 0,

    top_revenue_masa TEXT,

    reward_list TEXT
  )
`);


  db.run(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_session_history_unique
    ON session_history(masa, start_time, end_time)
  `);


  db.run(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_real_adjustments_finalize_unique
    ON real_adjustments(masa, session_start, kind)
    WHERE kind='SESSION_FINALIZE'
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS session_locks (
      masa INTEGER PRIMARY KEY,
      until_time INTEGER,
      set_time INTEGER
    )
  `);

  db.all("SELECT masa, until_time FROM session_locks", (e, rows) => {
    if (e) {
      logErr("load session_locks", e);
      return;
    }
    sessionLocks = new Map();
    (rows || []).forEach((r) => {
      if (r && r.masa && r.until_time) sessionLocks.set(r.masa, r.until_time);
    });
(rows || []).forEach((r) => {
  if (r && r.masa && r.until_time > Date.now()) {
    masaCloseLocks[r.masa] = r.until_time;
  }
});
  });

  db.run(`
    CREATE TABLE IF NOT EXISTS force_new_sessions (
      masa INTEGER PRIMARY KEY,
      set_time INTEGER
    )
  `);
  db.run(`
    CREATE TABLE IF NOT EXISTS blocked_masalar (
      masa INTEGER PRIMARY KEY,
      until_time INTEGER,
      reason TEXT,
      set_time INTEGER
    )
  `);

  runAlter("ALTER TABLE daily_reports ADD COLUMN product_geliri REAL DEFAULT 0", "alter daily_reports product_geliri");
  runAlter("ALTER TABLE daily_reports ADD COLUMN product_adedi INTEGER DEFAULT 0", "alter daily_reports product_adedi");
  runAlter("ALTER TABLE daily_reports ADD COLUMN genel_gelir REAL DEFAULT 0", "alter daily_reports genel_gelir");
  runAlter("ALTER TABLE daily_reports ADD COLUMN nakit_odeme REAL DEFAULT 0", "alter daily_reports nakit_odeme");
  runAlter("ALTER TABLE daily_reports ADD COLUMN kart_odeme REAL DEFAULT 0", "alter daily_reports kart_odeme");
  runAlter("ALTER TABLE daily_reports ADD COLUMN bekleyen_odeme REAL DEFAULT 0", "alter daily_reports bekleyen_odeme");
  runAlter("ALTER TABLE daily_reports ADD COLUMN bekleyen_adet INTEGER DEFAULT 0", "alter daily_reports bekleyen_adet");
  runAlter("ALTER TABLE daily_reports ADD COLUMN giderler REAL DEFAULT 0", "alter daily_reports giderler");
  runAlter("ALTER TABLE daily_reports ADD COLUMN kart_komisyonu REAL DEFAULT 0", "alter daily_reports kart_komisyonu");
  runAlter("ALTER TABLE daily_reports ADD COLUMN net_isletme_sonucu REAL DEFAULT 0", "alter daily_reports net_isletme_sonucu");

  db.run(`
    CREATE TABLE IF NOT EXISTS product_catalog (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      price REAL DEFAULT 0,
      active INTEGER DEFAULT 1,
      sort_order INTEGER DEFAULT 0,
      created_at INTEGER DEFAULT 0,
      updated_at INTEGER DEFAULT 0
    )
  `);

  db.run(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_product_catalog_name_category
    ON product_catalog(name, category)
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS product_sales (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      time INTEGER NOT NULL,
      masa INTEGER DEFAULT 0,
      session_start INTEGER DEFAULT 0,
      product_id INTEGER DEFAULT 0,
      product_name TEXT NOT NULL,
      category TEXT NOT NULL,
      unit_price REAL DEFAULT 0,
      quantity INTEGER DEFAULT 1,
      total REAL DEFAULT 0,
      sale_type TEXT DEFAULT 'TABLE',
      note TEXT DEFAULT '',
      status TEXT DEFAULT 'OPEN',
      finalized_at INTEGER DEFAULT 0,
      payment_method TEXT DEFAULT 'PENDING',
      voided INTEGER DEFAULT 0,
      voided_at INTEGER DEFAULT 0
    )
  `);

  runAlter("ALTER TABLE product_sales ADD COLUMN status TEXT DEFAULT 'OPEN'", "alter product_sales status");
  runAlter("ALTER TABLE product_sales ADD COLUMN finalized_at INTEGER DEFAULT 0", "alter product_sales finalized_at");

  db.run(`CREATE INDEX IF NOT EXISTS idx_product_sales_time ON product_sales(time)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_product_sales_session ON product_sales(masa, session_start)`);

  runAlter("ALTER TABLE product_sales ADD COLUMN payment_method TEXT DEFAULT 'PENDING'", "alter product_sales payment_method");

  db.run(`
    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at INTEGER NOT NULL,
      paid_at INTEGER DEFAULT 0,
      masa INTEGER DEFAULT 0,
      session_start INTEGER DEFAULT 0,
      session_end INTEGER DEFAULT 0,
      product_sale_id INTEGER DEFAULT 0,
      computer_amount REAL DEFAULT 0,
      product_amount REAL DEFAULT 0,
      total_amount REAL DEFAULT 0,
      method TEXT DEFAULT 'PENDING',
      source TEXT DEFAULT 'SESSION',
      close_reason TEXT DEFAULT '',
      note TEXT DEFAULT '',
      voided INTEGER DEFAULT 0,
      voided_at INTEGER DEFAULT 0
    )
  `);

  db.run(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_session_unique
    ON payments(masa,session_start,session_end,source)
    WHERE source='SESSION'
  `);
  db.run(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_direct_sale_unique
    ON payments(product_sale_id)
    WHERE product_sale_id>0
  `);
  db.run(`CREATE INDEX IF NOT EXISTS idx_payments_created_at ON payments(created_at)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_payments_method ON payments(method,voided)`);

  runAlter("ALTER TABLE product_sales ADD COLUMN external_source TEXT DEFAULT ''", "alter product_sales external_source");
  runAlter("ALTER TABLE product_sales ADD COLUMN external_id TEXT DEFAULT ''", "alter product_sales external_id");
  runAlter("ALTER TABLE payments ADD COLUMN external_source TEXT DEFAULT ''", "alter payments external_source");
  runAlter("ALTER TABLE payments ADD COLUMN external_id TEXT DEFAULT ''", "alter payments external_id");
  db.run(`CREATE UNIQUE INDEX IF NOT EXISTS idx_product_sales_external_unique
    ON product_sales(external_source,external_id)
    WHERE external_source<>'' AND external_id<>''`);
  db.run(`CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_external_unique
    ON payments(external_source,external_id)
    WHERE external_source<>'' AND external_id<>''`);
  db.run(`CREATE TABLE IF NOT EXISTS everycafe_imports (
    session_id TEXT PRIMARY KEY,
    masa INTEGER NOT NULL,
    source_end INTEGER NOT NULL,
    total REAL DEFAULT 0,
    imported_at INTEGER NOT NULL
  )`);
  // EveryCafe'nin üye bakiye/tahsilat hareketleri oturumlardan ayrı tutulur.
  // HistoryID kaynak tarafta kalıcı olduğu için aynı üye ödemesi ikinci kez
  // KafePin'e aktarılmaz.
  db.run(`CREATE TABLE IF NOT EXISTS everycafe_member_imports (
    history_id INTEGER PRIMARY KEY,
    source_time INTEGER NOT NULL,
    amount REAL DEFAULT 0,
    imported_at INTEGER NOT NULL
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS everycafe_active_sessions (
    session_id TEXT PRIMARY KEY,
    masa INTEGER NOT NULL,
    source_start INTEGER NOT NULL,
    last_seen INTEGER NOT NULL,
    source_type TEXT DEFAULT ''
  )`);
  runAlter("ALTER TABLE everycafe_active_sessions ADD COLUMN source_type TEXT DEFAULT ''", "alter everycafe_active_sessions source_type");
  db.run(`CREATE UNIQUE INDEX IF NOT EXISTS idx_everycafe_active_masa
    ON everycafe_active_sessions(masa)`);

  db.run(`
    CREATE TABLE IF NOT EXISTS card_settlements (
      settlement_key TEXT PRIMARY KEY,
      actual_net REAL DEFAULT 0,
      confirmed_at INTEGER DEFAULT 0,
      note TEXT DEFAULT ''
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS accounting_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      time INTEGER NOT NULL,
      type TEXT NOT NULL,
      category TEXT DEFAULT '',
      amount REAL DEFAULT 0,
      method TEXT DEFAULT 'CASH',
      account TEXT DEFAULT '',
      note TEXT DEFAULT '',
      voided INTEGER DEFAULT 0,
      voided_at INTEGER DEFAULT 0
    )
  `);
  runAlter("ALTER TABLE accounting_entries ADD COLUMN account TEXT DEFAULT ''", "alter accounting_entries account");
  db.run(`CREATE INDEX IF NOT EXISTS idx_accounting_entries_time ON accounting_entries(time,voided)`);

  db.run(`
    CREATE TABLE IF NOT EXISTS account_transfers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      time INTEGER NOT NULL,
      from_account TEXT NOT NULL,
      to_account TEXT NOT NULL,
      amount REAL DEFAULT 0,
      note TEXT DEFAULT '',
      voided INTEGER DEFAULT 0,
      voided_at INTEGER DEFAULT 0
    )
  `);
  db.run(`CREATE INDEX IF NOT EXISTS idx_account_transfers_time ON account_transfers(time,voided)`);

  db.run(`
    CREATE TABLE IF NOT EXISTS admin_preferences (
      pref_key TEXT PRIMARY KEY,
      pref_value TEXT DEFAULT '',
      updated_at INTEGER DEFAULT 0
    )
  `);

  const starterProducts = [
    ["Nescafe Paket", "Sıcak İçecekler"],
    ["Türk Kahvesi", "Sıcak İçecekler"],
    ["Çay", "Sıcak İçecekler"],
    ["Churchill", "Soğuk İçecekler"],
    ["Enerji İçeceği", "Soğuk İçecekler"],
    ["Fanta", "Soğuk İçecekler"],
    ["Gazoz", "Soğuk İçecekler"],
    ["Kola", "Soğuk İçecekler"],
    ["Soda", "Soğuk İçecekler"],
    ["Soğuk Kahve", "Soğuk İçecekler"],
    ["Soğuk Çay", "Soğuk İçecekler"],
    ["Su", "Soğuk İçecekler"],
    ["Çamlıca Gazoz", "Soğuk İçecekler"],
    ["Eti Browni Gold", "Atıştırmalıklar"],
    ["Eti Hoşbeş Çilek Kremalı Gofret", "Atıştırmalıklar"],
    ["Eti Susamlı Çubuk Kraker", "Atıştırmalıklar"],
    ["Halley", "Atıştırmalıklar"],
    ["Pop Kek", "Atıştırmalıklar"],
    ["Sade Çubuk Kraker", "Atıştırmalıklar"],
    ["Çikolatalı Gofret", "Atıştırmalıklar"],
    ["Ülker Albeni", "Atıştırmalıklar"],
    ["Ülker Crax Acılı Çubuk Kraker", "Atıştırmalıklar"],
    ["Ülker Krispi Kraker", "Atıştırmalıklar"],
    ["Ülker Susamlı Çubuk Kraker", "Atıştırmalıklar"],
    ["Ülker Çizi", "Atıştırmalıklar"],
    ["Format", "Teknik Servis"],
    ["Bakım", "Teknik Servis"],
    ["Siyah Beyaz Çıktı", "Teknik Servis"],
    ["Renkli Çıktı", "Teknik Servis"]
  ];

  const seedNow = Date.now();
  starterProducts.forEach(([name, category], index) => {
    db.run(
      `INSERT OR IGNORE INTO product_catalog
       (name,category,price,active,sort_order,created_at,updated_at)
       VALUES (?,?,0,1,?,?,?)`,
      [name, category, index + 1, seedNow, seedNow],
      (seedErr) => logErr("seed product_catalog", seedErr)
    );
  });

  db.get("SELECT value FROM settings WHERE key='sure'", (err, row) => {
    if (err) {
      logErr("settings sure", err);
      return;
    }
    if (!row) {
      db.run("INSERT INTO settings (key,value) VALUES ('sure','45')");
      SPIN_SURE_DK = 45;
      return;
    }
    const v = parseInt(row.value, 10);
    if (!isNaN(v) && v > 0) SPIN_SURE_DK = v;
  });

  db.get("SELECT value FROM settings WHERE key='test_mode'", (err, row) => {
    if (err) {
      logErr("settings test_mode", err);
      return;
    }
    if (!row) {
      db.run("INSERT INTO settings (key,value) VALUES ('test_mode','0')");
      TEST_MODE = 0;
      return;
    }
    const v = parseInt(row.value, 10);
    TEST_MODE = v === 1 ? 1 : 0;
  });

  db.get("SELECT value FROM settings WHERE key='everycafe_maintenance_mode'", (err, row) => {
    if (err) return logErr("settings everycafe_maintenance_mode", err);
    if (!row) {
      db.run("INSERT INTO settings (key,value) VALUES ('everycafe_maintenance_mode','0')");
      EVERYCAFE_MAINTENANCE_MODE = 0;
      return;
    }
    EVERYCAFE_MAINTENANCE_MODE = String(row.value) === "1" ? 1 : 0;
  });

  db.run("CREATE INDEX IF NOT EXISTS idx_spins_masa_time ON spins(masa, time)");
  db.run("CREATE INDEX IF NOT EXISTS idx_spins_time ON spins(time)");
  db.run("CREATE INDEX IF NOT EXISTS idx_spins_log_time ON spins_log(time)");
  db.run("CREATE INDEX IF NOT EXISTS idx_spins_log_masa_time ON spins_log(masa, time)");
  db.run("CREATE INDEX IF NOT EXISTS idx_sessions_end_time ON sessions(end_time)");
  db.run("CREATE INDEX IF NOT EXISTS idx_real_adjustments_day_key ON real_adjustments(day_key)");
  db.run("CREATE INDEX IF NOT EXISTS idx_real_adjustments_masa_session_start ON real_adjustments(masa, session_start)");
  db.run("CREATE INDEX IF NOT EXISTS idx_session_history_masa_start_end ON session_history(masa, start_time, end_time)");

db.get("SELECT value FROM settings WHERE key='global_spin_count'", (err, row) => {
    if (err) {
      logErr("settings global_spin_count", err);
      return;
    }

    if (!row) {
      db.run("INSERT INTO settings (key,value) VALUES ('global_spin_count','0')");
      globalSpinCount = 0;
      return;
    }

    const v = parseInt(row.value, 10);
    globalSpinCount = !isNaN(v) && v >= 0 ? v : 0;

    db.get(
      "SELECT value FROM settings WHERE key='telegram_live_message_id'",
      (err, row) => {

        if (!err && row && row.value) {
          liveMessageId = parseInt(row.value, 10) || 0;
        }

      }
    );
});
});

function seedRewardsIfEmpty() {
  const myRewards = [
    { name: "Şansına küs", weight: 40 },
    { name: "Soda", weight: 6 },
    { name: "Bir dahaki sefere", weight: 20 },
    { name: "Enerji içeceği", weight: 4 },
    { name: "30 dakika ek süre", weight: 15 },
    { name: "Ülker Crax", weight: 5 },
    { name: "Kola", weight: 4 },
    { name: "60 dakika ek süre", weight: 4 },
    { name: "Çikolatalı Gofret", weight: 12 },
    { name: "Tekrar dene :)", weight: 6 }
  ];

  db.get("SELECT COUNT(*) as cnt FROM rewards", (err, row) => {
    if (err) {
      logErr("seedRewardsIfEmpty count", err);
      return;
    }

    const cnt = row && row.cnt ? row.cnt : 0;
    if (cnt > 0) return;

    console.log("🎁 Rewards boştu, başlangıç ödülleri yükleniyor...");

    db.serialize(() => {
      const stmt = db.prepare("INSERT INTO rewards (name, weight, active) VALUES (?,?,1)");
      myRewards.forEach((r) => stmt.run(r.name, r.weight));
      stmt.finalize(() => console.log("✅ Rewards yüklendi."));
    });
  });
}
seedRewardsIfEmpty();

function getSpinSureMs() {
  if (TEST_MODE === 1) return TEST_SPIN_SURE_DK * 60 * 1000;
  const dk = parseInt(SPIN_SURE_DK, 10);
  const safe = !isNaN(dk) && dk > 0 ? dk : 45;
  return safe * 60 * 1000;
}

// Çarktan kazanılıp EveryCafe'ye verilen ücretsiz süre, ücret gibi çark
// hakkını da erteler. Böylece hediye dakikaları yeni bir çark turu sayılmaz.
function getSpinReadyAt(masa, startTime) {
  return (Number(startTime) || 0) + getSpinSureMs() + getEveryCafeGiftMinutes(masa) * 60 * 1000;
}

function getReqIp(req) {
  return String(req.socket?.remoteAddress || req.ip || "")
    .split(",")[0]
    .trim()
    .replace("::ffff:", "");
}

function getMasaFromRequest(req) {
  const masa = parseInt(req.body?.masa, 10);
  const token = String(req.body?.token || "").trim();
  const ip = getReqIp(req);

  if (!masa || masa < 1 || masa > MASA_SAYISI) {
    return null;
  }

  if (!token) {
    return null;
  }

  if (MASA_TOKENS[masa] !== token) {
    return null;
  }

// IP kontrolü kaldırıldı.
// İstenirse sadece log tutabiliriz.
logInfo("TOKEN_LOGIN", {
  masa,
  ip
});


return masa;
}

function sumRealRevenueInRangeFromSessions(sessions, start, end, nowTs) {
  let sum = 0;

  (sessions || []).forEach((s) => {
    const masa = s.masa;
    if (isFreeMasa(masa)) return;

    const st = s.start_time || 0;
    if (!st) return;

    const sessionEnd = s.end_time && s.end_time > 0 ? s.end_time : s.last_seen || nowTs;

    if (sessionEnd <= start) return;
    if (st >= end) return;

    const a = Math.max(start, st);
    const b = Math.min(end, sessionEnd);
    if (b <= a) return;

    const feeB = feeAtTime(masa, st, b);
    const feeA = feeAtTime(masa, st, a);
    const delta = feeB - feeA;

    if (delta > 0) sum += delta;
  });

  return sum;
}

// Kapanan oturumlar SESSION_FINALIZE kaydında tek toplam olarak tutulur.
// Oturum gün devrini geçtiyse bu toplamı kapanış/başlangıç gününe yığmak
// yerine, aktif oturumlarda olduğu gibi ücret eğrisine göre aralıklara böler.
function sumFinalizedRevenueInRange(adjustments, start, end) {
  let sum = 0;

  (adjustments || []).forEach((a) => {
    if (String(a.kind || "").trim() !== "SESSION_FINALIZE") return;

    const masa = Number(a.masa) || 0;
    const sessionStart = Number(a.session_start) || 0;
    const sessionEnd = Number(a.time) || 0;
    const recordedTotal = Math.max(Number(a.amount) || 0, 0);

    if (!masa || !sessionStart || !sessionEnd || sessionEnd <= sessionStart) return;
    if (sessionEnd <= start || sessionStart >= end) return;

    // Tüm zamanlar toplamında veritabanına sabitlenen kesin tutarı kullan.
    if (start <= sessionStart && end >= sessionEnd) {
      sum += recordedTotal;
      return;
    }

    const rangeStart = Math.max(start, sessionStart);
    const rangeEnd = Math.min(end, sessionEnd);
    if (rangeEnd <= rangeStart) return;

    const feeAtRangeEnd = feeAtTime(masa, sessionStart, rangeEnd);
    const feeAtRangeStart =
      rangeStart <= sessionStart ? 0 : feeAtTime(masa, sessionStart, rangeStart);

    sum += Math.max(Math.min(feeAtRangeEnd - feeAtRangeStart, recordedTotal), 0);
  });

  return sum;
}

function isLocked(masa, now) {
  const until = sessionLocks.get(masa) || 0;
  if (!until) return false;
  if (now < until) return true;

  sessionLocks.delete(masa);
  db.run("DELETE FROM session_locks WHERE masa=?", [masa], (err) => logErr("unlock delete session_locks", err));
  return false;
}

function setLock(masa, untilTs) {
  sessionLocks.set(masa, untilTs);
  const now = Date.now();
  db.run(
    "INSERT INTO session_locks(masa, until_time, set_time) VALUES(?,?,?) ON CONFLICT(masa) DO UPDATE SET until_time=excluded.until_time, set_time=excluded.set_time",
    [masa, untilTs, now],
    (err) => logErr("setLock", err)
  );
}

function recordTokenHit(masa, req) {
  const ip = getReqIp(req);
  const now = Date.now();

  if (!tokenTracker[masa]) tokenTracker[masa] = [];

  tokenTracker[masa].push({
    ip,
    time: now
  });

  tokenTracker[masa] = tokenTracker[masa]
    .filter((x) => now - x.time <= 24 * 60 * 60 * 1000)
    .slice(-50);
}



function isBlockedMasa(masa, cb) {
  db.get(
    "SELECT until_time FROM blocked_masalar WHERE masa=?",
    [masa],
    (err, row) => {
      if (err) {
        logErr("isBlockedMasa", err);
        return cb(false, 0);
      }

      if (!row) {
        blockedMasalar.delete(masa);
        return cb(false, 0);
      }

      const untilTime = parseInt(row.until_time, 10) || 0;

      if (untilTime <= Date.now()) {
        db.run("DELETE FROM blocked_masalar WHERE masa=?", [masa], (e2) => {
          logErr("isBlockedMasa delete expired", e2);
        });
        blockedMasalar.delete(masa);
        return cb(false, 0);
      }

      blockedMasalar.add(masa);
      return cb(true, untilTime);
    }
  );
}

function setBlockedMasa(masa, untilTime, reason, cb) {
  db.run(
    `
    INSERT INTO blocked_masalar(masa, until_time, reason, set_time)
    VALUES(?,?,?,?)
    ON CONFLICT(masa) DO UPDATE SET
      until_time=excluded.until_time,
      reason=excluded.reason,
      set_time=excluded.set_time
    `,
    [masa, untilTime, String(reason || ""), Date.now()],
    (err) => {
      if (err) logErr("setBlockedMasa", err);
      if (!err) blockedMasalar.add(masa);
      cb && cb(err);
    }
  );
}

function clearBlockedMasa(masa, cb) {
  db.run("DELETE FROM blocked_masalar WHERE masa=?", [masa], (err) => {
    if (err) logErr("clearBlockedMasa", err);
    blockedMasalar.delete(masa);
    cb && cb(err);
  });
}

function telegramEscape(s) {
  return String(s || "");
}

function sendTelegramMessage(text, cb) {
  if (!TELEGRAM_ENABLED) return cb && cb(null, { ok: false, disabled: true });

  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
    return cb && cb(new Error("Telegram token/chat_id eksik"));
  }

  const body = JSON.stringify({
    chat_id: TELEGRAM_CHAT_ID,
    text: telegramEscape(text)
  });

  let callbackDone = false;
  const finish = (err, data) => {
    if (callbackDone) return;
    callbackDone = true;
    if (cb) cb(err, data);
  };

  const req = https.request(
    {
      hostname: "api.telegram.org",
      path: `/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(body)
      }
    },
    (res2) => {
      let data = "";
      res2.on("data", (chunk) => (data += chunk));
      res2.on("end", () => {
        if (res2.statusCode >= 200 && res2.statusCode < 300) {
          return finish(null, data);
        }
        return finish(new Error(`Telegram HTTP ${res2.statusCode}: ${data}`));
      });
    }
  );

  req.setTimeout(12000, () => {
    req.destroy(new Error("Telegram isteği 12 saniyede zaman aşımına uğradı"));
  });
  req.on("error", (err) => finish(err));
  req.write(body);
  req.end();
}
function editTelegramMessage(messageId, text, cb) {

  const body = JSON.stringify({
    chat_id: TELEGRAM_CHAT_ID,
    message_id: messageId,
    text
  });

  const req = https.request(
    {
      hostname: "api.telegram.org",
      path: `/bot${TELEGRAM_BOT_TOKEN}/editMessageText`,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(body)
      }
    },
    res => {

      let data = "";

      res.on("data", c => data += c);

      res.on("end", ()=>{

        if(res.statusCode>=200 && res.statusCode<300){
          cb && cb(null,data);
        }else{
          cb && cb(new Error(data));
        }

      });

    }
  );

  req.on("error",err=>cb&&cb(err));

  req.write(body);

  req.end();

}
function deleteTelegramMessage(messageId, cb) {

    if (!TELEGRAM_ENABLED || !messageId) {
        cb && cb();
        return;
    }

    const url =
        `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/deleteMessage`;

    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            chat_id: TELEGRAM_CHAT_ID,
            message_id: messageId
        })
    })
    .then(r => r.json())
    .then(d => {

        if (!d.ok) {
            console.log("Telegram mesaj silinemedi:", d.description);
            cb && cb(new Error(d.description || "Telegram mesajı silinemedi"));
            return;
        } else {
            console.log("🗑 Telegram canlı mesaj silindi.");
        }

        cb && cb(null);

    })
    .catch(err => {

        console.error("deleteTelegramMessage:", err);
        cb && cb(err);

    });

}
let liveMonitorMoveTimer = null;

function moveLiveMonitorToBottomSoon() {
  if (!TELEGRAM_ENABLED) return;

  if (liveMonitorMoveTimer) {
    clearTimeout(liveMonitorMoveTimer);
  }

  // Peş peşe masa kapanışlarında bütün bildirimlerin gönderilmesini bekle,
  // sonra canlı durum mesajını yalnızca bir kez en alta taşı.
  liveMonitorMoveTimer = setTimeout(() => {
    liveMonitorMoveTimer = null;

    if (liveMonitorBusy) {
      moveLiveMonitorToBottomSoon();
      return;
    }

    const oldMessageId = liveMessageId;
    if (!oldMessageId) {
      sendLiveMonitor();
      return;
    }

    deleteTelegramMessage(oldMessageId, (deleteErr) => {
      if (deleteErr) {
        console.error("Canlı durum alta taşınamadı:", deleteErr);
        return;
      }

      liveMessageId = 0;
      db.run(
        "UPDATE settings SET value='0' WHERE key='telegram_live_message_id'",
        () => sendLiveMonitor()
      );
    });
  }, 2500);
}

let liveMonitorBusy = false;

function sendLiveMonitor() {
  if (liveMonitorBusy) return;
  liveMonitorBusy = true;
  const finishLiveMonitor = () => {
    liveMonitorBusy = false;
  };

  db.all("SELECT * FROM sessions WHERE end_time=0",(e,rows)=>{

    if(e) {
      finishLiveMonitor();
      return;
    }

let txt = "📊 KAFEPİN CANLI DURUM\n\n";

txt += "🕒 " + new Date().toLocaleTimeString("tr-TR") + "\n\n";

let toplam = 0;
(rows || []).sort((a, b) => a.masa - b.masa);
(rows || []).forEach(r => {

    const dakika = Math.floor((Date.now() - r.start_time) / 60000);

    const fee = feeAtTime(
        r.masa,
        r.start_time,
        Date.now()
    );

    toplam += fee;

    const icon = VIP_MASALAR.includes(r.masa) ? "⭐" : "🖥️";

    txt += `${icon} Masa ${String(r.masa).padStart(2, "0")} | ⏱️ ${dakika} dk | 💰 ${fee.toFixed(2)} ₺\n`;

});

txt += "\n━━━━━━━━━━━━━━━━━━━━━━\n";
txt += `🎮 Aktif Masa : ${(rows || []).length}\n`;
txt += `💰 Aktif Toplam : ${toplam.toFixed(2)} ₺\n`;
const liveNow = Date.now();
const liveDayStart = dayStartTs(liveNow);
const liveDayEnd = liveDayStart + 24 * 60 * 60 * 1000;

db.get(
  `SELECT COALESCE(SUM(total),0) AS total,
          COALESCE(SUM(quantity),0) AS quantity
   FROM product_sales
   WHERE time>=? AND time<? AND voided=0`,
  [liveDayStart, liveDayEnd],
  (productErr, productRow) => {
    if (productErr) logErr("sendLiveMonitor product totals", productErr);

    db.get(
      `SELECT
         COALESCE(SUM(CASE WHEN method='CASH' AND COALESCE(NULLIF(paid_at,0),created_at)>=? AND COALESCE(NULLIF(paid_at,0),created_at)<? THEN total_amount ELSE 0 END),0) AS cash,
         COALESCE(SUM(CASE WHEN method='CARD' AND COALESCE(NULLIF(paid_at,0),created_at)>=? AND COALESCE(NULLIF(paid_at,0),created_at)<? THEN total_amount ELSE 0 END),0) AS card,
         COALESCE(SUM(CASE WHEN method='PENDING' AND created_at>=? AND created_at<? THEN total_amount ELSE 0 END),0) AS pending,
         COALESCE(SUM(CASE WHEN method='PENDING' AND created_at>=? AND created_at<? THEN 1 ELSE 0 END),0) AS pending_count
       FROM payments
       WHERE voided=0`,
      [liveDayStart, liveDayEnd, liveDayStart, liveDayEnd, liveDayStart, liveDayEnd, liveDayStart, liveDayEnd],
      (paymentErr, paymentRow) => {
        if (paymentErr) logErr("sendLiveMonitor payment totals", paymentErr);

        getRangeStats(liveDayStart, liveDayEnd, (rangeErr, dailyStats) => {
        if (rangeErr) logErr("sendLiveMonitor daily range stats", rangeErr);
        dailyStats = dailyStats || {};

        const masaGeliri = Number(dailyStats.gercekGelir) || 0;
        const productTotal = Number(dailyStats.productGeliri) || Number(productRow && productRow.total) || 0;
        const productQuantity = Number(dailyStats.productAdedi) || Number(productRow && productRow.quantity) || 0;
        const genelGelir = masaGeliri + productTotal;
        const cash = Number(paymentRow && paymentRow.cash) || 0;
        const card = Number(paymentRow && paymentRow.card) || 0;
        const pending = Number(paymentRow && paymentRow.pending) || 0;
        const pendingCount = Number(paymentRow && paymentRow.pending_count) || 0;

        txt += `\n🖥️ Masa Geliri : ${masaGeliri.toFixed(2)} ₺`;
        txt += `\n☕ Ürün/Hizmet Geliri : ${productTotal.toFixed(2)} ₺ (${productQuantity} adet)`;
        txt += `\n💰 Genel Gelir : ${genelGelir.toFixed(2)} ₺`;
        txt += `\n💵 Nakit : ${cash.toFixed(2)} ₺`;
        txt += `\n💳 Kart : ${card.toFixed(2)} ₺`;
        txt += `\n⏳ Bekleyen : ${pending.toFixed(2)} ₺ (${pendingCount} hesap)`;
        txt += `\n🧾 Tahsil Edilen : ${(cash + card).toFixed(2)} ₺`;
        txt += `\n🕒 Son Güncelleme : ${new Date().toLocaleTimeString("tr-TR")}`;

    if(liveMessageId==0){

      sendTelegramMessage(txt,(err,data)=>{

        if(err){
          console.error("sendLiveMonitor sendTelegramMessage:", err);
          finishLiveMonitor();
          return;
        }

        try{

          const j=JSON.parse(data);

          liveMessageId=j.result.message_id;
          db.run(
            `
            INSERT INTO settings(key,value)
            VALUES('telegram_live_message_id',?)
            ON CONFLICT(key)
            DO UPDATE SET value=excluded.value
            `,
            [String(liveMessageId)],
            () => finishLiveMonitor()
          );

        }catch(parseErr){
          console.error("Canlı Telegram message_id okunamadı:", parseErr);
          finishLiveMonitor();
        }

      });

    }else{

editTelegramMessage(liveMessageId, txt, (err) => {

    if (!err) {
        console.log("✅ Canlı durum güncellendi");
        finishLiveMonitor();
        return;
    }

    console.error("❌ editTelegramMessage hatası:", err);

    const editError = String(err && err.message ? err.message : err).toLowerCase();
    const messageNoLongerExists =
      editError.includes("message to edit not found") ||
      editError.includes("message can't be edited") ||
      editError.includes("message_id_invalid");

    if (!messageNoLongerExists) {
      // Geçici ağ/Telegram hatasında yeni mesaj atma; aynı mesajı sonraki
      // zamanlayıcı turunda tekrar düzenlemeyi dene.
      finishLiveMonitor();
      return;
    }

    liveMessageId = 0;

    db.run(
      "UPDATE settings SET value='0' WHERE key='telegram_live_message_id'",
      () => {
        finishLiveMonitor();
        setTimeout(sendLiveMonitor, 500);
      }
    );

});

    }

        });

      }
    );
  }
);

  });

}
function sendSessionStartTelegram(masa, startTime) {
  if (!TELEGRAM_ENABLED) return;

  const last = lastStartSent.get(masa) || 0;
if (startTime - last < 10000) return;

  lastStartSent.set(masa, startTime);

  const msg =
    `🟢 Masa ${masa} bağlandı\n` +
    `🕒 Başlangıç: ${new Date(startTime).toLocaleString("tr-TR")}`;

  sendTelegramMessage(msg, (err) => {
    if (err) {
      logErr("sendSessionStartTelegram", err);
      return;
    }
    moveLiveMonitorToBottomSoon();
  });
}

function sendSessionEndTelegram(masa, startTime, endTime, fee) {
  if (!TELEGRAM_ENABLED) return;

  const dedupKey = `end:${masa}:${startTime}`;
  if (!shouldSendTelegramDedup(dedupKey, TELEGRAM_DEDUP_MS)) return;

  
db.get(
  `
  SELECT COALESCE(SUM(amount),0) as adj
  FROM real_adjustments
  WHERE masa=? 
    AND session_start=? 
    AND kind IN ('MANUAL_FEE_ADJUST','ZERO_FEE')
  `,
  [masa, startTime],
  (err, row) => {

const adj = (row && row.adj) ? Number(row.adj) : 0;

const finalFee =
  Number(fee) || 0;

let minutes = Math.floor((endTime - startTime) / 60000);
    if (minutes < 0) minutes = 0;

    const saat = Math.floor(minutes / 60);
    const dk2 = minutes % 60;

    const msg =
      `🔴 Masa ${masa} kapandı\n` +
      `🕒 Başlangıç: ${new Date(startTime).toLocaleString("tr-TR")}\n` +
      `🕒 Bitiş: ${new Date(endTime).toLocaleString("tr-TR")}\n` +
      `⏱️ Süre: ${saat}s ${dk2}dk\n` +
      `💰 Normal: ${fee} ₺\n` +
      `🛠️ Düzeltme: ${adj} ₺\n` +
      `🟢 Final: ${finalFee} ₺`;

sendTelegramMessage(msg, (err2) => {

  if (err2) {
    logErr("sendSessionEndTelegram", err2);
    return;
  }

  addLiveLog(
    "telegram",
    `📨 Telegram gönderildi • Masa ${masa}`
  );
  moveLiveMonitorToBottomSoon();

});

  }
);
}
function cleanupMasa(masa) {
diagnostics.cleanupCount++;
diagnostics.lastCleanup = Date.now();
diagnostics.lastCleanupMasa = masa;
  delete aktifMasalar[masa];
  delete latestRewardMap[masa];

  delete offlineCount[masa];
  delete lastOfflineState[masa];

  delete tokenTracker[masa];

  masaCloseLocks[masa] = Date.now() + 30000;

  // 30 saniye sonra kilidi temizle
  setTimeout(() => {
    delete masaCloseLocks[masa];
  }, 30000);

  if (masaPingStats[masa]) {
    masaPingStats[masa].last = 0;
    masaPingStats[masa].avg = PING_INTERVAL_MS;
    masaPingStats[masa].lastSeen = 0;
    masaPingStats[masa].netSpeed = 0;
  }
}

function sendBigRewardTelegram(masa, reward, time) {
  if (!TELEGRAM_ENABLED) return;

  const dedupKey = `big:${masa}:${reward}:${time}`;
  if (!shouldSendTelegramDedup(dedupKey, 30000)) return;

  const msg =
    `🎉 BÜYÜK ÖDÜL ÇIKTI\n` +
    `🖥️ Masa: ${masa}\n` +
    `🎁 Ödül: ${reward}\n` +
    `🕒 Saat: ${new Date(time).toLocaleString("tr-TR")}`;

  sendTelegramMessage(msg, (err) => {
    if (err) {
      logErr("sendBigRewardTelegram", err);
      return;
    }
    moveLiveMonitorToBottomSoon();
  });
}

function buildDailyTelegramReport(reportDateTs, stats) {
  const dateText = new Date(reportDateTs).toLocaleString("tr-TR");
  const startText = new Date(dayStartTs(reportDateTs)).toLocaleString("tr-TR");

  const topRewardText = stats.topReward
    ? `${stats.topReward.reward} (${stats.topReward.adet})`
    : "-";

  const topMasaText = stats.topMasa
    ? `Masa ${stats.topMasa.masa} (${stats.topMasa.adet} spin)`
    : "-";

  let rewardListText = "";
  if (stats.rewardList && stats.rewardList.length) {
    stats.rewardList.forEach((r) => {
      rewardListText += `\n${r.reward}: ${parseInt(r.adet, 10) || 0}`;
    });
  } else {
    rewardListText = "\n-";
  }

  return [
    "📊 KAFE GÜN SONU RAPORU",
    "",
    `🕒 Rapor Saati: ${dateText}`,
    `🎯 Gün Başlangıcı: ${startText}`,
    "",
    `💠 Toplam Spin: ${parseInt(stats.totalSpins || 0, 10)}`,
    `✅ Onaylanan Ödül: ${parseInt(stats.usedRewards || 0, 10)}`,
    "",
    `💰 Masa Brüt Geliri: ${(Number(stats.brutGelir) || 0).toFixed(2)} ₺`,
`🛠️ Admin Düzeltmeleri: ${(Number(stats.adminDuzeltmeleri) || 0).toFixed(2)} ₺`,
`🎁 Spin Maliyeti: ${(Number(stats.spinMaliyeti) || 0).toFixed(2)} ₺`,
`🖥️ Masa Gerçek Geliri: ${(Number(stats.gercekGelir) || 0).toFixed(2)} ₺`,
`☕ Ürün/Hizmet Geliri: ${(Number(stats.productGeliri) || 0).toFixed(2)} ₺ (${Number(stats.productAdedi) || 0} adet)`,
`🖥️ EveryCafe Genel Ciro: ${(Number(stats.everyCafeGenelGelir) || 0).toFixed(2)} ₺`,
`🧾 KafePin Doğrudan Satış: ${(Number(stats.kafePinDirectGeliri) || 0).toFixed(2)} ₺`,
`🟢 Genel Gelir: ${(Number(stats.genelGelir) || 0).toFixed(2)} ₺`,
    "",
`💵 Nakit Tahsilat: ${(Number(stats.nakitOdeme) || 0).toFixed(2)} ₺`,
`💳 Kart Tahsilat: ${(Number(stats.kartOdeme) || 0).toFixed(2)} ₺`,
`🧾 Tahsil Edilen: ${(Number(stats.tahsilEdilen) || 0).toFixed(2)} ₺`,
`⏳ Bekleyen Ödeme: ${(Number(stats.bekleyenOdeme) || 0).toFixed(2)} ₺ (${Number(stats.bekleyenAdet) || 0} hesap)`,
    "",
`🧾 Giderler: ${(Number(stats.giderler) || 0).toFixed(2)} ₺`,
`🏦 Kart Komisyonu (%1,87): ${(Number(stats.kartKomisyonu) || 0).toFixed(2)} ₺`,
`📈 Net İşletme Sonucu: ${(Number(stats.netIsletmeSonucu) || 0).toFixed(2)} ₺`,
    "",
`🏆 En çok çıkan ödül: ${topRewardText}`,
`🖥️ En çok spin atan masa: ${topMasaText}`,
`📈 Ortalama masa geliri: ${(Number(stats.ortalamaMasaGeliri) || 0).toFixed(2)} ₺`,
`💰 En çok gelir getiren masa: ${stats.topRevenueMasaText || "-"}`,
"",
    `🎁 Bugün çıkan ödüller:${rewardListText}`
  ].join("\n");
}

function getCommerceRangeStats(startTs, endTs, cb) {
  db.get(
    `SELECT COALESCE(SUM(total),0) AS total,
            COALESCE(SUM(quantity),0) AS quantity,
            COALESCE(SUM(CASE WHEN external_source='EVERYCAFE_DIRECT' THEN total ELSE 0 END),0) AS everycafe_direct_total,
            COALESCE(SUM(CASE WHEN external_source='EVERYCAFE_MEMBER' THEN total ELSE 0 END),0) AS everycafe_member_total,
            COALESCE(SUM(CASE WHEN sale_type='DIRECT' AND COALESCE(external_source,'') NOT IN ('EVERYCAFE_DIRECT','EVERYCAFE_MEMBER') THEN total ELSE 0 END),0) AS kafepin_direct_total
     FROM product_sales
     WHERE voided=0 AND time>=? AND time<?`,
    [startTs, endTs],
    (productErr, productRow) => {
      if (productErr) return cb(productErr);
      db.get(
        `SELECT
           COALESCE(SUM(CASE WHEN method='CASH' AND COALESCE(NULLIF(paid_at,0),created_at)>=? AND COALESCE(NULLIF(paid_at,0),created_at)<? THEN total_amount ELSE 0 END),0) AS cash,
           COALESCE(SUM(CASE WHEN method='CARD' AND COALESCE(NULLIF(paid_at,0),created_at)>=? AND COALESCE(NULLIF(paid_at,0),created_at)<? THEN total_amount ELSE 0 END),0) AS card,
           COALESCE(SUM(CASE WHEN method='CARD' AND COALESCE(NULLIF(paid_at,0),created_at)>=? AND COALESCE(NULLIF(paid_at,0),created_at)<? THEN ROUND(total_amount * ${CARD_COMMISSION_RATE}, 2) ELSE 0 END),0) AS card_commission,
           COALESCE(SUM(CASE WHEN method='PENDING' AND created_at>=? AND created_at<? THEN total_amount ELSE 0 END),0) AS pending,
           COALESCE(SUM(CASE WHEN method='PENDING' AND created_at>=? AND created_at<? THEN 1 ELSE 0 END),0) AS pending_count
         FROM payments
         WHERE voided=0`,
        [startTs, endTs, startTs, endTs, startTs, endTs, startTs, endTs, startTs, endTs],
        (paymentErr, paymentRow) => {
          if (paymentErr) return cb(paymentErr);
          const productGeliri = Number(productRow && productRow.total) || 0;
          const nakitOdeme = Number(paymentRow && paymentRow.cash) || 0;
          const kartOdeme = Number(paymentRow && paymentRow.card) || 0;
          db.get(
            `SELECT
               COALESCE(SUM(CASE WHEN type='EXPENSE' THEN amount ELSE 0 END),0) AS expenses,
               COALESCE(SUM(CASE WHEN type='CAPITAL_IN' THEN amount ELSE 0 END),0) AS capital_in,
               COALESCE(SUM(CASE WHEN type='CAPITAL_OUT' THEN amount ELSE 0 END),0) AS capital_out
             FROM accounting_entries
             WHERE voided=0 AND time>=? AND time<?`,
            [startTs, endTs],
            (accountingErr, accountingRow) => {
              if (accountingErr) return cb(accountingErr);
              cb(null, {
                productGeliri,
                productAdedi: Number(productRow && productRow.quantity) || 0,
                everyCafeDirectGeliri: Number(productRow && productRow.everycafe_direct_total) || 0,
                everyCafeUyeGeliri: Number(productRow && productRow.everycafe_member_total) || 0,
                kafePinDirectGeliri: Number(productRow && productRow.kafepin_direct_total) || 0,
                nakitOdeme,
                kartOdeme,
                bekleyenOdeme: Number(paymentRow && paymentRow.pending) || 0,
                bekleyenAdet: Number(paymentRow && paymentRow.pending_count) || 0,
                tahsilEdilen: nakitOdeme + kartOdeme,
                giderler: Number(accountingRow && accountingRow.expenses) || 0,
                sermayeGirisi: Number(accountingRow && accountingRow.capital_in) || 0,
                sermayeCekisi: Number(accountingRow && accountingRow.capital_out) || 0,
                kartKomisyonu: Number(paymentRow && paymentRow.card_commission) || 0
              });
            }
          );
        }
      );
    }
  );
}

function buildCardSettlementGroups(paymentRows, settlementRows, now = Date.now()) {
  const confirmations = new Map(
    (settlementRows || []).map((row) => [String(row.settlement_key), row])
  );
  const groups = new Map();
  (paymentRows || []).forEach((payment) => {
    if (payment.method !== "CARD" || Number(payment.voided)) return;
    const paidAt = Number(payment.paid_at) || Number(payment.created_at) || 0;
    if (!paidAt) return;
    const key = cardSettlementKey(paidAt);
    const amount = Number(payment.total_amount) || 0;
    if (!groups.has(key)) groups.set(key, {
      key,
      gross: 0,
      expectedCommission: 0,
      latestPaidAt: 0,
      paymentCount: 0
    });
    const group = groups.get(key);
    group.gross += amount;
    group.expectedCommission += Math.round(amount * CARD_COMMISSION_RATE * 100) / 100;
    group.latestPaidAt = Math.max(group.latestPaidAt, paidAt);
    group.paymentCount += 1;
  });

  return [...groups.values()].map((group) => {
    const saved = confirmations.get(group.key);
    const confirmed = !!(saved && Number(saved.confirmed_at) > 0);
    const actualNet = confirmed ? (Number(saved.actual_net) || 0) : 0;
    const commission = confirmed
      ? Math.max(group.gross - actualNet, 0)
      : group.expectedCommission;
    const settlementAt = group.latestPaidAt + CARD_SETTLEMENT_DELAY_MS;
    return {
      ...group,
      expectedNet: group.gross - group.expectedCommission,
      actualNet,
      commission,
      confirmed,
      confirmedAt: confirmed ? Number(saved.confirmed_at) || 0 : 0,
      note: confirmed ? String(saved.note || "") : "",
      settlementAt,
      settled: confirmed || settlementAt <= now
    };
  }).sort((a, b) => b.latestPaidAt - a.latestPaidAt);
}

function getCardSettlementGroupsFromDb(paymentRows, now, cb) {
  db.all("SELECT * FROM card_settlements", (err, settlementRows) => {
    if (err) return cb(err);
    cb(null, buildCardSettlementGroups(paymentRows, settlementRows, now));
  });
}

function actualCardCommissionForRange(paymentRows, groups, startTs, endTs) {
  const groupMap = new Map((groups || []).map((group) => [group.key, group]));
  return (paymentRows || []).reduce((sum, payment) => {
    if (payment.method !== "CARD" || Number(payment.voided)) return sum;
    const paidAt = Number(payment.paid_at) || Number(payment.created_at) || 0;
    if (paidAt < startTs || paidAt >= endTs) return sum;
    const expected = Math.round((Number(payment.total_amount) || 0) * CARD_COMMISSION_RATE * 100) / 100;
    const group = groupMap.get(cardSettlementKey(paidAt));
    if (!group || !group.confirmed || !(Number(group.expectedCommission) > 0)) return sum + expected;
    return sum + (expected * ((Number(group.commission) || 0) / Number(group.expectedCommission)));
  }, 0);
}

function getRangeStats(startTs, endTs, cb) {
  db.all("SELECT * FROM sessions", (err2, sessions) => {

    if (err2) {
      logErr("getRangeStats sessions", err2);
      return cb(err2);
    }
    if (!sessions) sessions = [];
const masaRevenueMap = {};
    const addMasaRevenue = (masa, amount) => {
      const masaNo = Number(masa) || 0;
      const value = Number(amount) || 0;
      if (!masaNo || !value) return;
      masaRevenueMap[masaNo] = (Number(masaRevenueMap[masaNo]) || 0) + value;
    };

    const now = Date.now();

    const activeSessions = (sessions || []).filter((s) => !s.end_time || s.end_time === 0);
    const liveRealBrutGelir = sumRealRevenueInRangeFromSessions(
      activeSessions, startTs, endTs, now
    );

    // Genel toplamla masa sıralaması aynı günlük aralığı kullanmalı.
    activeSessions.forEach((session) => {
      const masa = Number(session.masa) || 0;
      const sessionStart = Number(session.start_time) || 0;
      const sessionEnd = Number(session.last_seen) || now;
      if (!masa || !sessionStart || isFreeMasa(masa)) return;
      if (sessionEnd <= startTs || sessionStart >= endTs) return;

      const rangeStart = Math.max(startTs, sessionStart);
      const rangeEnd = Math.min(endTs, sessionEnd);
      if (rangeEnd <= rangeStart) return;

      addMasaRevenue(
        masa,
        Math.max(
          feeAtTime(masa, sessionStart, rangeEnd) -
          feeAtTime(masa, sessionStart, rangeStart),
          0
        )
      );
    });

    db.all(
      "SELECT time, amount, kind, masa, session_start FROM real_adjustments",
      (eAdj, adjRows) => {
      if (eAdj) {
        logErr("getRangeStats real_adjustments", eAdj);
        return cb(eAdj);
      }

      adjRows = adjRows || [];

      let finalizedSessionRange = 0;
      let feeAdjustRange = 0;
      let spinCostRange = 0;

      (adjRows || []).forEach((a) => {
        const amt = Number(a.amount) || 0;
        const kind = String(a.kind || "").trim();

        if (kind === "SESSION_FINALIZE") {
          const sessionStart = Number(a.session_start) || 0;
          const sessionEnd = Number(a.time) || 0;
          const masa = Number(a.masa) || 0;

          if (!sessionStart || !sessionEnd || !masa) return;
          if (sessionEnd <= startTs || sessionStart >= endTs) return;

          const rangeStart = Math.max(sessionStart, startTs);
          const rangeEnd = Math.min(sessionEnd, endTs);
          if (rangeEnd <= rangeStart) return;

          // Kapanış sırasında sabitlenen kesin brüt tutar esastır.
          // 0 ₺ kapanmış kısa/ücretsiz oturum tarifeden tekrar hesaplanmaz.
          const recordedTotal = Math.max(amt, 0);
          if (recordedTotal <= 0) return;

          if (rangeStart <= sessionStart && rangeEnd >= sessionEnd) {
            finalizedSessionRange += recordedTotal;
            addMasaRevenue(masa, recordedTotal);
            return;
          }

          const feeAtRangeEnd = feeAtTime(masa, sessionStart, rangeEnd);
          const feeAtRangeStart =
            rangeStart <= sessionStart
              ? 0
              : feeAtTime(masa, sessionStart, rangeStart);

          const allocatedFinalized = Math.max(
            Math.min(feeAtRangeEnd - feeAtRangeStart, recordedTotal),
            0
          );
          finalizedSessionRange += allocatedFinalized;
          addMasaRevenue(masa, allocatedFinalized);
          return;
        }

        const t = Number(a.time || a.session_start || 0);
        if (t < startTs || t >= endTs) return;

        if (kind === "MANUAL_FEE_ADJUST" || kind === "ZERO_FEE") {
          feeAdjustRange += amt;
          addMasaRevenue(a.masa, amt);
          return;
        }

if (
  kind === "SPIN_TIME_COST" ||
  kind === "SPIN_ITEM_COST"
) {
          const cost = Math.max(-amt, 0);
          spinCostRange += cost;
          addMasaRevenue(a.masa, -cost);
 return;
        }
      });

      const brutGelir = liveRealBrutGelir + finalizedSessionRange;
      const adminDuzeltmeleri = feeAdjustRange;
      const spinMaliyeti = spinCostRange;
const gercekGelir =
    brutGelir +
    adminDuzeltmeleri -
    spinMaliyeti;

      db.get("SELECT COUNT(*) as cnt FROM spins_log WHERE time>=? AND time<?", [startTs, endTs], (eSpin, spinRow) => {
        if (eSpin) {
          logErr("getRangeStats spins_log count", eSpin);
          return cb(eSpin);
        }

        db.get(
          "SELECT COUNT(*) as cnt FROM spins_log WHERE time>=? AND time<? AND used=1",
          [startTs, endTs],
          (eUsed, usedRow) => {
            if (eUsed) {
              logErr("getRangeStats spins_log used count", eUsed);
              return cb(eUsed);
            }

            db.get(
              `
              SELECT reward, COUNT(*) as adet
              FROM spins_log
              WHERE time>=? AND time<? AND used=1
              GROUP BY reward
              ORDER BY adet DESC, reward ASC
              LIMIT 1
              `,
              [startTs, endTs],
              (eTopReward, topRewardRow) => {
                if (eTopReward) {
                  logErr("getRangeStats top reward", eTopReward);
                  return cb(eTopReward);
                }

                db.get(
                  `
                  SELECT masa, COUNT(*) as adet
                  FROM spins_log
                  WHERE time>=? AND time<?
                  GROUP BY masa
                  ORDER BY adet DESC, masa ASC
                  LIMIT 1
                  `,
                  [startTs, endTs],
                  (eTopMasa, topMasaRow) => {
                    if (eTopMasa) {
                      logErr("getRangeStats top masa", eTopMasa);
                      return cb(eTopMasa);
                    }

                    db.all(
                      `
                      SELECT reward, COUNT(*) as adet
                      FROM spins_log
                      WHERE time>=? AND time<?
                      GROUP BY reward
                      ORDER BY adet DESC, reward ASC
                      `,
                      [startTs, endTs],
                      (eList, rewardRows) => {
if (eList) rewardRows = [];

{
    let ortalamaMasaGeliri = 0;
    let topRevenueMasaText = "-";
    const revenueMasaRows = Object.entries(masaRevenueMap)
      .map(([masa, gelir]) => ({ masa: Number(masa), gelir: Number(gelir) || 0 }))
      .filter((row) => row.gelir > 0);

    if (revenueMasaRows.length) {

      const toplamGelir =
        revenueMasaRows.reduce(
          (t, r) => t + (Number(r.gelir) || 0),
          0
        );

      ortalamaMasaGeliri =
        toplamGelir / revenueMasaRows.length;

      revenueMasaRows.sort(
        (a, b) =>
          (Number(b.gelir) || 0) -
          (Number(a.gelir) || 0)
      );

      const top = revenueMasaRows[0];

      topRevenueMasaText =
        `Masa ${top.masa} (${(Number(top.gelir) || 0).toFixed(2)} ₺)`;
    }

    const baseStats = {
      brutGelir,
      adminDuzeltmeleri,
      spinMaliyeti,
      gercekGelir,

      ortalamaMasaGeliri,
      topRevenueMasaText,

      brut: brutGelir,
      net: gercekGelir,
      spinCost: spinMaliyeti,

      totalSpins: (spinRow && spinRow.cnt) || 0,
      usedRewards: (usedRow && usedRow.cnt) || 0,

      topReward: topRewardRow
        ? {
            reward: topRewardRow.reward || "-",
            adet: parseInt(topRewardRow.adet, 10) || 0
          }
        : null,

      topMasa: topMasaRow
        ? {
            masa: topMasaRow.masa || "-",
            adet: parseInt(topMasaRow.adet, 10) || 0
          }
        : null,

      rewardList: rewardRows || []
    };

    getCommerceRangeStats(startTs, endTs, (commerceErr, commerce) => {
      if (commerceErr) return cb(commerceErr);
      // Masa sıralamasında yalnız bilgisayar değil, o masaya yazılan ürünler de yer alır.
      db.all(
        `SELECT masa, COALESCE(SUM(total),0) AS total
         FROM product_sales
         WHERE voided=0 AND sale_type='TABLE' AND masa>0 AND time>=? AND time<?
         GROUP BY masa`,
        [startTs, endTs],
        (productMapErr, productRows) => {
          if (productMapErr) logErr("getRangeStats table product totals", productMapErr);
          (productRows || []).forEach((row) => addMasaRevenue(row.masa, row.total));

          const enrichedRows = Object.entries(masaRevenueMap)
            .map(([masa, gelir]) => ({ masa: Number(masa), gelir: Number(gelir) || 0 }))
            .filter((row) => row.gelir > 0)
            .sort((a, b) => b.gelir - a.gelir || a.masa - b.masa);
          const enrichedAverage = enrichedRows.length
            ? enrichedRows.reduce((sum, row) => sum + row.gelir, 0) / enrichedRows.length
            : 0;
          const enrichedTopText = enrichedRows.length
            ? `Masa ${enrichedRows[0].masa} (${enrichedRows[0].gelir.toFixed(2)} ₺)`
            : "-";

          return cb(null, {
            ...baseStats,
            ...commerce,
            ortalamaMasaGeliri: enrichedAverage,
            topRevenueMasaText: enrichedTopText,
            genelGelir: gercekGelir + (Number(commerce.productGeliri) || 0),
            everyCafeGenelGelir:
              gercekGelir +
              (Number(commerce.productGeliri) || 0) -
              (Number(commerce.kafePinDirectGeliri) || 0),
            netIsletmeSonucu:
              gercekGelir +
              (Number(commerce.productGeliri) || 0) -
              (Number(commerce.giderler) || 0) -
              (Number(commerce.kartKomisyonu) || 0)
          });
        }
      );
    });

  }

                      }
                    );
                  }
                );
              }
            );
          }
        );
      });
    });
  });
}

function sendEndOfDayTelegramReport(cb, reportEndTs) {
  const endTs = Number(reportEndTs) || Date.now();
  const reportTs = Math.max(endTs - 1, 0);
  const startTs = dayStartTs(reportTs);

  const reportKey = `daily-report:${dayKey(reportTs)}:${GUN_SONU_RAPOR_SAAT}:${GUN_SONU_RAPOR_DAKIKA}`;
  if (!shouldSendTelegramDedup(reportKey, 5 * 60 * 1000)) {
    return getRangeStats(startTs, endTs, (err, stats) => {
      if (err) return cb && cb(err);
      return cb && cb(null, { ...stats, skipped: true, reason: "dedup" });
    });
  }

  getRangeStats(startTs, endTs, (err, stats) => {
    if (err) return cb && cb(err);

saveDailyReport(reportTs, stats, (saveErr) => {

  if (saveErr) {
    logErr("saveDailyReport", saveErr);
  }

  const msg = buildDailyTelegramReport(reportTs, stats);

  sendTelegramMessage(msg, (e2) => {

    if (e2) {
      logErr("sendEndOfDayTelegramReport telegram", e2);
      return cb && cb(e2);
    }

    console.log("✅ Gün sonu Telegram raporu gönderildi.");

    addLiveLog(
      "daily_report",
      "🌙 Gün sonu raporu Telegram'a gönderildi"
    );
    moveLiveMonitorToBottomSoon();

    return cb && cb(null, stats);

  });

});
  });
}
function saveDailyReport(reportTs, stats, cb) {

  const reportDate = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Istanbul",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date(reportTs));

  db.run(
    `
    INSERT OR REPLACE INTO daily_reports (
      report_date,
      report_ts,

      total_spins,
      used_rewards,

      brut_gelir,
      admin_duzeltmeleri,
      spin_maliyeti,
      gercek_gelir,
      product_geliri,
      product_adedi,
      genel_gelir,
      nakit_odeme,
      kart_odeme,
      bekleyen_odeme,
      bekleyen_adet,
      giderler,
      kart_komisyonu,
      net_isletme_sonucu,

      ortalama_masa_geliri,

      top_reward,
      top_reward_count,

      top_masa,
      top_masa_count,

      top_revenue_masa,

      reward_list
    )
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `,
    [
      reportDate,
      reportTs,

      Number(stats.totalSpins || 0),
      Number(stats.usedRewards || 0),

      Number(stats.brutGelir || 0),
      Number(stats.adminDuzeltmeleri || 0),
      Number(stats.spinMaliyeti || 0),
      Number(stats.gercekGelir || 0),
      Number(stats.productGeliri || 0),
      Number(stats.productAdedi || 0),
      Number(stats.genelGelir || 0),
      Number(stats.nakitOdeme || 0),
      Number(stats.kartOdeme || 0),
      Number(stats.bekleyenOdeme || 0),
      Number(stats.bekleyenAdet || 0),
      Number(stats.giderler || 0),
      Number(stats.kartKomisyonu || 0),
      Number(stats.netIsletmeSonucu || 0),

      Number(stats.ortalamaMasaGeliri || 0),

      stats.topReward ? stats.topReward.reward : "",
      stats.topReward ? Number(stats.topReward.adet || 0) : 0,

      stats.topMasa ? Number(stats.topMasa.masa || 0) : 0,
      stats.topMasa ? Number(stats.topMasa.adet || 0) : 0,

      stats.topRevenueMasaText || "",

      JSON.stringify(stats.rewardList || [])
    ],
    (err) => {

      if (err) {
        logErr("saveDailyReport", err);
      } else {
        console.log("💾 Gün sonu raporu kaydedildi.");
      }

      if (cb) cb(err);

    }
  );

}

// Eski hesapla 0 ₺ oturumu ücretli saymış en son kayıtlı raporu da düzeltir.
// Telegram'da daha önce gönderilmiş mesaj değişmez; admin rapor kaydı doğru olur.
function repairLatestStoredDailyReport() {
  db.get(
    "SELECT report_ts FROM daily_reports ORDER BY report_ts DESC LIMIT 1",
    (selectErr, row) => {
      if (selectErr) {
        logErr("repairLatestStoredDailyReport select", selectErr);
        return;
      }

      const reportTs = Number(row && row.report_ts) || 0;
      if (!reportTs) return;

      const startTs = dayStartTs(reportTs);
      const endTs = reportTs + 1;
      getRangeStats(startTs, endTs, (statsErr, stats) => {
        if (statsErr) {
          logErr("repairLatestStoredDailyReport stats", statsErr);
          return;
        }

        saveDailyReport(reportTs, stats, (saveErr) => {
          if (saveErr) return;
          addLiveLog(
            "daily_report_repair",
            `🧮 Son gün sonu raporu kesin gelirle düzeltildi: ${Number(stats.everyCafeGenelGelir || 0).toFixed(2)} ₺`
          );
        });
      });
    }
  );
}

function maybeSendScheduledDailyReport() {
  if (!TELEGRAM_ENABLED) return;

  const now = new Date();
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();

  if (currentHour !== GUN_SONU_RAPOR_SAAT || currentMinute !== GUN_SONU_RAPOR_DAKIKA) {
    return;
  }

  const reportKey = dayKey(Date.now()) + `-${GUN_SONU_RAPOR_SAAT}:${GUN_SONU_RAPOR_DAKIKA}`;
  if (lastDailyReportKey === reportKey) return;

  lastDailyReportKey = reportKey;

  sendEndOfDayTelegramReport((err) => {
    if (err) {
      console.log("Gün sonu raporu gönderilemedi:", err.message || err);
    }
  });
}

function insertSessionHistory(sessionRow, fee, closeReason, note, cb) {
  try {
    if (!sessionRow) return cb && cb(null);

    const masa = parseInt(sessionRow.masa, 10) || 0;
    const startTime = parseInt(sessionRow.start_time, 10) || 0;
    const endTime = parseInt(sessionRow.end_time, 10) || 0;
    const lastSeen = parseInt(sessionRow.last_seen, 10) || 0;

    if (!masa || !startTime || !endTime || endTime <= startTime) {
      return cb && cb(null);
    }

    let minutes = Math.floor((endTime - startTime) / 60000);
    if (minutes < 0) minutes = 0;

    // Kesinleşen tutarı 0 ₺ olan kısa/ücretsiz/iptal oturumlar geçmişe yazılmaz.
    if ((Number(fee) || 0) <= 0) {
      return cb && cb(null);
    }

db.run(
  `
INSERT OR IGNORE INTO session_history
(masa, start_time, end_time, last_seen, minutes, fee, adjustment, close_reason, note, created_at)
VALUES (?,?,?,?,?,?,?,?,?,?)
  `,
[
  masa,
  startTime,
  endTime,
  lastSeen,
  minutes,

  Number(fee) || 0,

  Number(sessionRow.adjustment) || 0,

  String(closeReason || ""),
  String(note || ""),
  Date.now()
],
  function (err) {
    if (err) {
      logErr("insertSessionHistory", err);
      return cb && cb(err);
    }

    // 🔥 BURAYA KOY
    if ((this.changes || 0) === 0) {
      // zaten var → sorun yok
    }
    return cb && cb(null);
  }
);
  } catch (err) {
    logErr("insertSessionHistory catch", err);
    return cb && cb(err);
  }
}
function withTimeout(promise, ms = 8000) {
  return Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error("Finalize timeout")), ms)
    )
  ]);
}
function finalizeEndedSessionToAdjustments(row, now, cb) {
  db.get(
    `SELECT 1 FROM real_adjustments 
     WHERE masa=? AND session_start=? AND kind='SESSION_FINALIZE'`,
    [row.masa, row.start_time],
    (err, exists) => {

      if (exists) {
        db.get(
          "SELECT final_fee FROM sessions WHERE masa=? AND start_time=?",
          [row.masa, row.start_time],
          (e2, sRow) => {
            if (sRow) {
              db.run(
                "DELETE FROM sessions WHERE masa=? AND start_time=?",
                [row.masa, row.start_time],
                () => cb && cb()
              );
            } else {
              cb && cb();
            }
          }
        );
        return;
      }

      if (!row) return cb && cb();

      const key = `${row.masa}-${row.start_time}`;

      if (finalizeInProgress.has(key)) {
        return enqueueFinalize(row.masa, async () => {}).then(() => {
          cb && cb();
        });
      }

      finalizeInProgress.add(key);

      const masa = row.masa;

      enqueueFinalize(masa, async () => {
        try {
          await withTimeout(
            new Promise((resolve) => {

              const safety = setTimeout(() => {
                console.error("⚠️ finalize timeout");
                resolve();
              }, 7000);

              const start = row.start_time;
              const end = row.end_time;
const safeEnd = Math.min(end, (row.last_seen || end) + 15000);

              if (!masa || !start || !end || end <= start) {
                clearTimeout(safety);
                return resolve();
              }

if (isFreeMasa(masa)) {
  const minutes = Math.floor((end - start) / 60000);
  const seconds = Math.floor(((end - start) % 60000) / 1000);

  return db.run(
    "DELETE FROM sessions WHERE masa=? AND start_time=?",
    [masa, start],
    (freeDeleteErr) => {
      if (freeDeleteErr) {
        logErr("DELETE free session", freeDeleteErr);
        clearTimeout(safety);
        return resolve();
      }

      cleanupMasa(masa);
      addLiveLog(
        "free_session_end",
        `🔵 Masa ${masa} ücretsiz olarak kapandı • ${minutes} dk ${seconds} sn • Gelir yazılmadı`
      );

      clearTimeout(safety);
      return resolve();
    }
  );
}

const baseFee = feeAtTime(masa, start, safeEnd);
const frozenFee = row.final_fee || 0;
const isShortSession = baseFee <= 0;

db.get(
  `
  SELECT COALESCE(SUM(amount),0) as adj
  FROM real_adjustments
  WHERE masa=? AND session_start=? 
  AND kind IN ('MANUAL_FEE_ADJUST','ZERO_FEE')
  `,
  [masa, start],
  (e2, rowAdj) => {

    const adj = (rowAdj && rowAdj.adj) ? Number(rowAdj.adj) : 0;
const rawFee =
  isShortSession
    ? 0
    : frozenFee > 0
    ? frozenFee
    : Math.max(baseFee, 0);

// SESSION_FINALIZE brüt ücreti, adjustment kayıtları ise düzeltmeyi temsil eder.
// Final ücret hiçbir zaman negatif olamaz.
const finalFee = Math.max(rawFee + adj, 0);
    const dk = dayKey(end);

    db.serialize(() => {

db.run("BEGIN IMMEDIATE TRANSACTION", (err) => {

    if (err) {

        logErr("BEGIN IMMEDIATE TRANSACTION", err);

        clearTimeout(safety);

        return resolve();

    }

    db.run(
      `INSERT OR IGNORE INTO real_adjustments
           (time, day_key, masa, amount, kind, note, session_start)
           VALUES (?,?,?,?,?,?,?)`,
          [end, dk, masa, rawFee, "SESSION_FINALIZE", `Masa ${masa}`, start],
(insertErr) => {

    if (insertErr) {

        logErr("SESSION_FINALIZE INSERT", insertErr);

        return db.run("ROLLBACK", () => {

            clearTimeout(safety);

            resolve();

        });

    }

insertSessionHistory(
  {
    masa,
    start_time: start,
    end_time: end,
    last_seen: end,
    adjustment: adj
  },
  finalFee,
  "FINALIZED",
  "",
  (historyErr) => {

      if (historyErr) {

          logErr("insertSessionHistory", historyErr);

          return db.run("ROLLBACK", () => {

              clearTimeout(safety);

              resolve();

          });

      }

db.run(
  "UPDATE sessions SET final_fee=? WHERE masa=? AND start_time=?",
  [finalFee, masa, start],
  (updateErr) => {

      if (updateErr) {

          logErr("UPDATE final_fee", updateErr);

          return db.run("ROLLBACK", () => {

              clearTimeout(safety);

              resolve();

          });

      }

db.run(
  "DELETE FROM sessions WHERE masa=? AND start_time=?",
  [masa, start],
  (deleteErr) => {

    if (deleteErr) {

      logErr("DELETE session", deleteErr);

      return db.run("ROLLBACK", () => {
        clearTimeout(safety);
        resolve();
      });

    }

    db.run("COMMIT", (commitErr) => {

      if (commitErr) {

        logErr("finalize COMMIT", commitErr);

        return db.run("ROLLBACK", () => {
          clearTimeout(safety);
          resolve();
        });

      }

      diagnostics.finalizeCount++;
      diagnostics.lastFinalize = Date.now();
      diagnostics.lastFinalizeMasa = masa;

      cleanupMasa(masa);

      const minutes = Math.floor((end - start) / 60000);
      const seconds = Math.floor(((end - start) % 60000) / 1000);

      addLiveLog(
        "session_end",
        `🔴 Session kapandı • Masa ${masa} • ${minutes} dk ${seconds} sn • ${finalFee.toFixed(2)} TL`
      );

      recordClosedRolloverResult(masa, start, end, finalFee);
      sendSessionEndTelegram(masa, start, end, finalFee);

      clearTimeout(safety);
      resolve();

    }); // COMMIT

  } // deleteErr
); // DELETE

} // updateErr
); // UPDATE

} // historyErr
); // insertSessionHistory

} // INSERT callback
); // INSERT

}); // BEGIN IMMEDIATE

}); // serialize

}); // rowAdj

            }) // new Promise
          );
        } finally {
          finalizeInProgress.delete(key);
        }
      }).then(() => cb && cb());
    }
  );
}
function backfillMissingFinalizedSessions() {
  db.all(`
    SELECT *
    FROM sessions
    WHERE end_time > 0
  `, (err, rows) => {

    const now = Date.now();

    (rows || []).forEach((r) => {

      const masa = r.masa;
      const st = r.start_time;
      const end = r.end_time;

      if (!masa || !st || !end) return;

      // 🔥 HISTORY VAR MI?
      db.get(`
        SELECT 1 FROM session_history
        WHERE masa=? AND start_time=? AND end_time=?
      `, [masa, st, end], (e2, exists) => {

        if (exists) return;

        const fee = Number(r.final_fee) || feeAtTime(masa, st, end);

        insertSessionHistory(
          r,
          fee,
          "BACKFILL_FIX",
          "Missing history recovered",
          () => {}
        );

      });

    });

  });
}
setInterval(backfillMissingFinalizedSessions, 60 * 1000);
// EveryCafe aktarımı açıkken masa oturumunun tek sahibi EveryCafe'dir.
// Kapanıştan sonra gelen son istemci pingleri yeni, boş bir KafePin
// oturumu oluşturmamalıdır; gerçek başlangıcı kaynak senkronu oluşturur.
function ensureSessionStarted(masa, now, cb) {
  getEveryCafeConfig((configErr, config) => {
    if (!configErr && config && config.enabled) {
      return cb && cb(null, { masa, sourceManaged: true });
    }
    ensureSessionStartedLocal(masa, now, cb);
  });
}

function ensureSessionStartedLocal(masa, now, cb) {
  if (isFreeMasa(masa)) return cb && cb(null, null);

  hasForceNewSession(masa, (forceNew) => {

    db.get("SELECT * FROM sessions WHERE masa=?", [masa], (err, row) => {


      if (err) {
        logErr("ensureSessionStarted select", err);
        return cb && cb(err);
      }

      // 🔹 Force new session varsa
      if (forceNew) {
        db.run(
          `
          INSERT INTO sessions (masa,start_time,last_seen,end_time,final_fee)
          VALUES (?,?,?,0,0)
          ON CONFLICT(masa) DO UPDATE SET
            start_time=excluded.start_time,
            last_seen=excluded.last_seen,
            end_time=0,
            final_fee=0
          `,
          [masa, now, now],
          (e2) => {
            logErr("ensureSessionStarted force new", e2);
            if (!e2) {
              clearForceNewSession(masa);
              addLiveLog(
  "session_start",
  `🟢 Session başladı • Masa ${masa}`
);

sendSessionStartTelegram(masa, now);
            }
            return cb && cb(e2 || null, {
              masa,
              start_time: now,
              last_seen: now,
              end_time: 0,
              final_fee: 0
            });
          }
        );
        return;
      }

      // 🔹 Session yoksa yeni başlat
      if (!row) {
        db.run(
          "INSERT INTO sessions (masa,start_time,last_seen,end_time,final_fee) VALUES (?,?,?,0,0)",
          [masa, now, now],
          (e2) => {
            logErr("ensureSessionStarted insert", e2);
           if (!e2) {
  addLiveLog(
    "session_start",
    `🟢 Session başladı • Masa ${masa}`
  );

  sendSessionStartTelegram(masa, now);
}
            return cb && cb(e2 || null, {
              masa,
              start_time: now,
              last_seen: now,
              end_time: 0,
              final_fee: 0
            });
          }
        );
        return;
      }

      // 🔹 start_time yoksa düzelt
      if (!row.start_time || row.start_time <= 0) {
        db.run(
          "UPDATE sessions SET start_time=?, last_seen=?, end_time=0, final_fee=0 WHERE masa=?",
          [now, now, masa],
          (e2) => {
            logErr("ensureSessionStarted repair start_time", e2);
            if (!e2) {
  addLiveLog(
    "session_start",
    `🟢 Session başladı • Masa ${masa}`
  );

  sendSessionStartTelegram(masa, now);
}
            return cb && cb(e2 || null, {
              ...row,
              start_time: now,
              last_seen: now,
              end_time: 0,
              final_fee: 0
            });
          }
        );
        return;
      }

      // 🔹 Session kapanmışsa yenisini başlat
      if (row.end_time && row.end_time > 0) {
        db.run(
          "UPDATE sessions SET start_time=?, last_seen=?, end_time=0, final_fee=0 WHERE masa=?",
          [now, now, masa],
          (e2) => {
            logErr("ensureSessionStarted restart closed session", e2);
            if (!e2) {
  addLiveLog(
    "session_start",
    `🟢 Session başladı • Masa ${masa}`
  );

  sendSessionStartTelegram(masa, now);
}
            return cb && cb(e2 || null, {
              ...row,
              start_time: now,
              last_seen: now,
              end_time: 0,
              final_fee: 0
            });
          }
        );
        return;
      }

      // 🔹 Normal durumda sadece ping güncelle
      db.run(
        "UPDATE sessions SET last_seen=? WHERE masa=?",
        [now, masa],
        (e2) => {
          logErr("ensureSessionStarted update last_seen", e2);
          return cb && cb(e2 || null, {
            ...row,
            last_seen: now
          });
        }
      );

    });
  });
}

function upsertSessionPing(masa, now) {
  if (isFreeMasa(masa)) {
    db.get("SELECT * FROM sessions WHERE masa=?", [masa], (err, row) => {
      if (err) {
        logErr("upsertSessionPing free select", err);
        return;
      }
      if (row && (!row.end_time || row.end_time === 0)) {
        finalizeEndedSessionToAdjustments({ ...row, end_time: now }, now, () => {});
      }
    });
    return;
  }

  hasForceNewSession(masa, (forceNew) => {
    db.get("SELECT * FROM sessions WHERE masa=?", [masa], (err, row) => {
      if (err) {
        logErr("upsertSessionPing select", err);
        return;
      }

      if (forceNew) {
        if (row && row.end_time && row.end_time > 0) {
          finalizeEndedSessionToAdjustments(row, now, () => {});
        }

        db.run(
          "INSERT INTO sessions (masa,start_time,last_seen,end_time,final_fee) VALUES (?,?,?,0,0) ON CONFLICT(masa) DO UPDATE SET start_time=excluded.start_time, last_seen=excluded.last_seen, end_time=0, final_fee=0",
          [masa, now, now],
          (e2) => {
            logErr("upsertSessionPing force new session", e2);
            if (!e2) sendSessionStartTelegram(masa, now);
            clearForceNewSession(masa);
          }
        );
        return;
      }

      ensureSessionStarted(masa, now, () => {});
    });
  });
}

function finalizeOpenProductSales(masa, endTime, paymentMethod, cb) {
  db.run(
    `UPDATE product_sales
     SET status='FINALIZED', finalized_at=?, payment_method=?
     WHERE masa=? AND sale_type='TABLE' AND status='OPEN' AND voided=0`,
    [Number(endTime) || Date.now(), normalizePaymentMethod(paymentMethod), masa],
    (err) => {
      if (err) logErr("finalizeOpenProductSales", err);
      cb && cb(err || null);
    }
  );
}

function normalizePaymentMethod(value, fallback = "PENDING") {
  const method = String(value || "").trim().toUpperCase();
  return ["CASH", "CARD", "PENDING"].includes(method) ? method : fallback;
}

function createSessionPaymentRecord({
  masa,
  sessionStart,
  sessionEnd,
  computerAmount,
  productAmount,
  method,
  closeReason
}, cb) {
  const computer = Math.max(Number(computerAmount) || 0, 0);
  const products = Math.max(Number(productAmount) || 0, 0);
  const total = computer + products;
  if (total <= 0) return cb && cb(null, null);

  const normalizedMethod = normalizePaymentMethod(method);
  const now = Date.now();
  db.run(
    `INSERT OR IGNORE INTO payments
     (created_at,paid_at,masa,session_start,session_end,product_sale_id,
      computer_amount,product_amount,total_amount,method,source,close_reason,note,voided,voided_at)
     VALUES (?,?,?,?,?,0,?,?,?,?,'SESSION',?,'',0,0)`,
    [
      now,
      normalizedMethod === "PENDING" ? 0 : now,
      masa,
      Number(sessionStart) || Number(sessionEnd) || now,
      Number(sessionEnd) || now,
      computer,
      products,
      total,
      normalizedMethod,
      String(closeReason || "").slice(0, 60)
    ],
    function (err) {
      if (err) return cb && cb(err);
      cb && cb(null, { id: this.lastID || 0, total, method: normalizedMethod });
    }
  );
}

function finalizeAndPrepareSession(masa, endTime, cb, options = {}) {
  const now = Date.now();
  const todayStart = dayStartTs(now);

  db.get("SELECT * FROM sessions WHERE masa=?", [masa], (err, row) => {
    if (err) {
      logErr("finalizeAndPrepareSession select", err);
      return cb && cb(err);
    }

const afterFinalize = () => {
  db.get(
    `SELECT COALESCE(SUM(total),0) AS total,
            COALESCE(MIN(session_start),0) AS first_session_start
     FROM product_sales
     WHERE masa=? AND sale_type='TABLE' AND status='OPEN' AND voided=0`,
    [masa],
    (productTotalErr, productRow) => {
      if (productTotalErr) return cb && cb(productTotalErr);

      const sessionStart = Number(row && row.start_time) ||
        Number(productRow && productRow.first_session_start) ||
        Number(endTime) || now;

      const finishWithComputerAmount = (computerAmount) => {
        createSessionPaymentRecord(
          {
            masa,
            sessionStart,
            sessionEnd: endTime,
            computerAmount,
            productAmount: Number(productRow && productRow.total) || 0,
            method: options.paymentMethod || "PENDING",
            closeReason: options.closeReason || "SESSION_CLOSE"
          },
          (paymentErr, paymentInfo) => {
            if (paymentErr) return cb && cb(paymentErr);

            finalizeOpenProductSales(masa, endTime, paymentInfo ? paymentInfo.method : "PENDING", (productErr) => {
              if (productErr) return cb && cb(productErr);

              if (paymentInfo && paymentInfo.total > 0) {
                addLiveLog(
                  "payment_created",
                  `💳 Masa ${masa} ödeme • ${paymentInfo.total.toFixed(2)} ₺ • ${paymentInfo.method}`
                );
              }

    db.run("DELETE FROM masalar WHERE masa=?", [masa], (e1) => {
      logErr("autoResetIfStale delete masalar", e1);

      db.run(
        "DELETE FROM spins WHERE masa=? AND time>=?",
        [masa, todayStart],
        (e2) => {

cleanupMasa(masa);
          return cb && cb(null, true, paymentInfo || null);
        }
      );
    });
            });
          }
        );
      };

      if (!row || !row.start_time) return finishWithComputerAmount(0);
      db.get(
        `SELECT fee FROM session_history
         WHERE masa=? AND start_time=?
         ORDER BY end_time DESC LIMIT 1`,
        [masa, row.start_time],
        (historyErr, historyRow) => {
          if (historyErr) return cb && cb(historyErr);
          finishWithComputerAmount(Number(historyRow && historyRow.fee) || 0);
        }
      );
    }
  );

};

    if (row && (!row.end_time || row.end_time === 0)) {
      return finalizeEndedSessionToAdjustments({ ...row, end_time: endTime }, now, (e2) => {
        if (e2) {
          logErr("finalizeAndPrepareSession finalize", e2);
          return cb && cb(e2);
        }
        return afterFinalize();
      });
    }

    return afterFinalize();
  });
}

// EveryCafe aktif oturumunu kendi kapanış/tahsilat kaydıyla yönetir. Bu
// masada ping kesilse bile KafePin'in eski 8 dk offline kapatması çalışmaz;
// aksi halde EveryCafe henüz kapatmamışken sahte ödeme oluşabilir.
function closeSessionIfOffline(masa, now, cb) {
  if (everyCafeWaitingMasalar.has(masa)) return cb && cb();
  db.get(
    "SELECT 1 AS ok FROM everycafe_active_sessions WHERE masa=? LIMIT 1",
    [masa],
    (mappingErr, mapping) => {
      if (mappingErr) {
        logErr("closeSessionIfOffline EveryCafe mapping", mappingErr);
        return cb && cb();
      }
      if (mapping) return cb && cb();
      return closeSessionIfOfflineLocal(masa, now, cb);
    }
  );
}

function closeSessionIfOfflineLocal(masa, now, cb) {
  if (isFreeMasa(masa)) {
    // Ücretsiz masalar ücret oturumu oluşturmaz; bu nedenle normal offline
    // kapanış yolunda sessions kaydı bulunmayabilir. Son canlı ping görüldükten
    // sonra 8 dakika boyunca yeni ping gelmezse test bitmiş kabul edilir ve
    // masa ücretsiz listesinden otomatik çıkarılır.
    const freeLastSeen = Number(aktifMasalar[masa]) ||
      Number(masaPingStats[masa] && masaPingStats[masa].lastSeen) || 0;

    // Sunucu yeni açıldığında henüz ping görmediğimiz kayıtları yanlışlıkla silme.
    if (!freeLastSeen || !isActuallyOffline(masa, freeLastSeen, now)) {
      return cb && cb();
    }

    if (freeOfflineCleanupInProgress.has(masa)) return cb && cb();
    freeOfflineCleanupInProgress.add(masa);

    return autoApprovePendingRewardsForMasa(
      masa,
      "ücretsiz masa offline kapanışı",
      (approveErr) => {
        if (approveErr) logErr("free offline auto approve reward", approveErr);

        finalizeAndPrepareSession(masa, freeLastSeen, (finalizeErr) => {
          if (finalizeErr) {
            logErr("free offline finalizeAndPrepareSession", finalizeErr);
            freeOfflineCleanupInProgress.delete(masa);
            return cb && cb();
          }

          db.run(
            "UPDATE free_masalar SET enabled=0, set_time=? WHERE masa=?",
            [Date.now(), masa],
            (disableErr) => {
              if (disableErr) {
                logErr("free offline disable", disableErr);
              } else {
                freeMasalar.delete(masa);
                addLiveLog(
                  "free_offline_close",
                  `🔵 Masa ${masa} ping kesildiği için ücretsiz moddan otomatik çıkarıldı`
                );
              }

              freeOfflineCleanupInProgress.delete(masa);
              return cb && cb();
            }
          );
        }, { paymentMethod: "PENDING", closeReason: "FREE_OFFLINE" });
      }
    );
  }

  db.get(
    "SELECT * FROM sessions WHERE masa=?",
    [masa],
    (err, row) => {

      if (err) {
        logErr("closeSessionIfOffline select", err);
        return cb && cb();
      }

      if (!row) return cb && cb();
      if (row.end_time && row.end_time > 0) return cb && cb();

      const firstLastSeen = row.last_seen || 0;

      // İlk kontrolde offline değilse çık
      if (!isActuallyOffline(masa, firstLastSeen, now)) {
        return cb && cb();
      }

      autoApprovePendingRewardsForMasa(
        masa,
        "8 dakikalık offline kapanışı",
        (approveErr) => {

        if (approveErr) {
          logErr("closeSessionIfOffline auto approve reward", approveErr);
          return cb && cb();
        }

        // Session tekrar okunuyor
        db.get(
          "SELECT * FROM sessions WHERE masa=?",
          [masa],
          (e2, currentRow) => {

            if (e2) {
              logErr("closeSessionIfOffline recheck", e2);
              return cb && cb();
            }

            if (!currentRow) {
              return cb && cb();
            }

            if (currentRow.start_time !== row.start_time) {
              return cb && cb();
            }

            if (currentRow.end_time && currentRow.end_time > 0) {
              return cb && cb();
            }

            // ***** EN ÖNEMLİ KISIM *****
            const refreshedLastSeen = currentRow.last_seen || 0;

            if (!isActuallyOffline(masa, refreshedLastSeen, Date.now())) {
              return cb && cb();
            }

            diagnostics.offlineCloseCount++;

            return finalizeAndPrepareSession(
              masa,
              refreshedLastSeen || Date.now(),
              (err3) => {

                if (err3) {
                  logErr(
                    "closeSessionIfOffline finalizeAndPrepareSession",
                    err3
                  );
                }

                return cb && cb();
              },
              { paymentMethod: "PENDING", closeReason: "OFFLINE_8_MIN" }
            );

          }
        );

      });

    }
  );
}

function autoResetIfStale(masa, now, cb) {
  const lastSeen = aktifMasalar[masa] || 0;
  if (!lastSeen) return cb && cb();
  if (now - lastSeen < AUTO_RESET_MS) return cb && cb();

  const todayStart = dayStartTs(now);

db.run("DELETE FROM masalar WHERE masa=?", [masa], (e1) => {
  logErr("autoResetIfStale delete masalar", e1);

    db.run("DELETE FROM spins WHERE masa=? AND time>=?", [masa, todayStart], (e2) => {
      logErr("autoResetIfStale delete spins", e2);

      db.get("SELECT * FROM sessions WHERE masa=?", [masa], (err, row) => {

        if (err) {
          logErr("autoResetIfStale select session", err);

cleanupMasa(masa);
return cb && cb();
        }

        if (row && (!row.end_time || row.end_time === 0)) {

          return finalizeAndPrepareSession(
            masa,
            lastSeen,
            () => cb && cb(),
            { paymentMethod: "PENDING", closeReason: "AUTO_STALE" }
          );
        }

cleanupMasa(masa);
cb && cb();

      });

    });

  });

}
function getPendingRewardForMasa(masa, cb) {
  const now = Date.now();
  const todayStart = dayStartTs(now);

  db.get(
    `
    SELECT id, masa, reward, time, used
    FROM spins
    WHERE masa = ?
      AND used = 0
      AND time >= ?
    ORDER BY id DESC
    LIMIT 1
    `,
    [masa, todayStart],
    (err, row) => {
      if (err) {
        logErr("getPendingRewardForMasa", err);
        return cb(err);
      }
      return cb(null, row || null);
    }
  );
}

function getAnyPendingReward(cb) {
  const now = Date.now();
  const todayStart = dayStartTs(now);

  db.get(
    `
    SELECT id, masa, reward, time, used
    FROM spins
    WHERE used = 0
      AND time >= ?
    ORDER BY time DESC, id DESC
    LIMIT 1
    `,
    [todayStart],
    (err, row) => {
      if (err) {
        logErr("getAnyPendingReward", err);
        return cb(err);
      }
      return cb(null, row || null);
    }
  );
}

function blockIfPendingReward(masa, res, next) {
  getPendingRewardForMasa(masa, (err, pendingRow) => {
    if (err) {
      return res.json({ ok: false, error: String(err) });
    }

    if (pendingRow) {
      return res.json({
        ok: false,
        error: "Bu masada bekleyen ödül onayı var. Önce ödülü onaylayın.",
        code: "PENDING_REWARD_APPROVAL",
        pendingReward: {
          id: pendingRow.id,
          masa: pendingRow.masa,
          reward: pendingRow.reward,
          time: pendingRow.time
        }
      });
    }

    return next();
  });
}

function blockIfAnyPendingReward(res, next) {
  getAnyPendingReward((err, pendingRow) => {
    if (err) {
      return res.json({ ok: false, error: String(err) });
    }

    if (pendingRow) {
      return res.json({
        ok: false,
        error: "Sistemde bekleyen ödül onayı var. Önce ödülü onaylayın.",
        code: "PENDING_REWARD_APPROVAL",
        pendingReward: {
          id: pendingRow.id,
          masa: pendingRow.masa,
          reward: pendingRow.reward,
          time: pendingRow.time
        }
      });
    }

    return next();
  });
}

app.get("/api/health", (req, res) => {
  setNoStore(res);
  db.get("SELECT 1 as ok", (err) => {
    if (err) {
      logErr("/api/health", err);
      return res.status(500).json({ ok: false, db: false });
    }
    return res.json({ ok: true, db: true, time: Date.now() });
  });
});

app.get("/admin/pro/update-status", (req, res) => {
  if (!isLocalhost(req)) return res.status(403).json({ ok: false, error: "Yerel erisim gerekli" });
  const force = String(req.query.force || "") === "1";
  const audit = String(req.query.audit || "") === "1";
  checkProUpdate(force, (err, status) => {
    if (err) {
      if (audit) addLiveLog("pro_update_check", "⚠️ Guncelleme kontrolu yapilamadi");
      return res.json({ ok: false, currentVersion: getProVersion(), error: "Guncelleme kontrol edilemedi. Internet baglantisini kontrol et." });
    }
    if (audit) addLiveLog("pro_update_check", status.available
      ? `⬆️ Guncelleme kontrolu • yeni surum hazir: v${status.latestVersion}`
      : `✅ Guncelleme kontrolu • sistem guncel: v${status.currentVersion}`);
    return res.json({ ok: true, ...status });
  });
});

const PRO_UPDATE_STATE_FILE = path.join(__dirname, "logs", "kafepin-pro-update-state.json");

function writeProUpdateState(stage, message, extra = {}) {
  try {
    fs.mkdirSync(path.dirname(PRO_UPDATE_STATE_FILE), { recursive: true });
    fs.writeFileSync(PRO_UPDATE_STATE_FILE, JSON.stringify({
      ok: true,
      running: !["success", "error"].includes(stage),
      stage,
      message,
      time: Date.now(),
      ...extra
    }, null, 2), "utf8");
  } catch (_err) {}
}

function downloadUpdateFile(url, destination, callback) {
  const request = https.get(url, {
    headers: {
      "User-Agent": "KafePin-Pro-Updater",
      "Cache-Control": "no-cache, no-store, max-age=0",
      "Pragma": "no-cache"
    }
  }, response => {
    if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
      response.resume();
      return downloadUpdateFile(response.headers.location, destination, callback);
    }
    if (response.statusCode !== 200) {
      response.resume();
      return callback(new Error(`Paket indirme HTTP ${response.statusCode}`));
    }
    const output = fs.createWriteStream(destination);
    response.pipe(output);
    output.on("finish", () => output.close(() => callback(null)));
    output.on("error", err => {
      try { fs.unlinkSync(destination); } catch (_err) {}
      callback(err);
    });
  });
  request.setTimeout(30000, () => request.destroy(new Error("Paket indirme zaman asimina ugradi")));
  request.on("error", err => {
    try { fs.unlinkSync(destination); } catch (_err) {}
    callback(err);
  });
}

app.get("/admin/pro/update-progress", (req, res) => {
  if (!isLocalhost(req)) return res.status(403).json({ ok: false, error: "Yerel erisim gerekli" });
  setNoStore(res);
  try {
    const state = JSON.parse(fs.readFileSync(PRO_UPDATE_STATE_FILE, "utf8").replace(/^\uFEFF/, ""));
    if (state && state.running === false && Date.now() - Number(state.time || 0) > 30000) {
      return res.json({ ok: true, running: false, stage: "idle", message: "Bekleyen guncelleme islemi yok" });
    }
    return res.json({ ok: true, ...state });
  } catch (_err) {
    return res.json({ ok: true, running: false, stage: "idle", message: "Bekleyen guncelleme islemi yok" });
  }
});


function runChildTracked(command, args, timeoutMs, callback) {
  let finished = false;
  let stderr = "";
  let stdout = "";
  let child = null;
  const done = (err) => {
    if (finished) return;
    finished = true;
    if (timer) clearTimeout(timer);
    callback(err, { stdout, stderr });
  };

  try {
    child = spawn(command, args, { windowsHide: true });
  } catch (err) {
    return done(err);
  }

  child.stdout && child.stdout.on("data", chunk => { stdout += chunk.toString("utf8"); });
  child.stderr && child.stderr.on("data", chunk => { stderr += chunk.toString("utf8"); });
  child.on("error", err => done(err));
  child.on("close", code => {
    if (code === 0) return done(null);
    done(new Error(`${command} cikis kodu ${code}${stderr.trim() ? `: ${stderr.trim().slice(0, 500)}` : ""}`));
  });

  const timer = setTimeout(() => {
    try { child.kill(); } catch (_err) {}
    done(new Error(`${command} zaman asimina ugradi`));
  }, timeoutMs);
}


// ================= KAFEPIN PRO MASAUSTU UYGULAMASI =================
// Edge uygulama penceresi yerine KafePin'in kendi WebView2 tabanli EXE'si
// kullanilir. Bu bolum sadece masaustu kabugunu hazirlar; guncelleme motoruna
// ve kafe is mantigina dokunmaz.
const KAFEPIN_DESKTOP_APP_VERSION = "1.0.1";
const KAFEPIN_DESKTOP_APP_DIR = path.join(__dirname, "desktop-app");
const KAFEPIN_DESKTOP_APP_EXE = path.join(KAFEPIN_DESKTOP_APP_DIR, "KafePin Pro.exe");
const KAFEPIN_DESKTOP_APP_MARKER = path.join(KAFEPIN_DESKTOP_APP_DIR, "desktop-app-installed.json");
const KAFEPIN_DESKTOP_APP_SETUP = path.join(__dirname, "KafePin_Desktop_App_Setup.ps1");
let kafepinDesktopSetupRunning = false;

function getKafePinDesktopAppVersion() {
  try {
    const data = JSON.parse(fs.readFileSync(KAFEPIN_DESKTOP_APP_MARKER, "utf8").replace(/^\uFEFF/, ""));
    return String(data.version || "");
  } catch (_err) {
    return "";
  }
}

function ensureKafePinDesktopApp(force = false) {
  if (process.platform !== "win32") return;
  if (kafepinDesktopSetupRunning) return;

  const installedVersion = getKafePinDesktopAppVersion();
  if (!force && installedVersion === KAFEPIN_DESKTOP_APP_VERSION && fs.existsSync(KAFEPIN_DESKTOP_APP_EXE)) {
    return;
  }
  if (!fs.existsSync(KAFEPIN_DESKTOP_APP_SETUP)) {
    addLiveLog("desktop_app", "⚠️ Masaustu uygulamasi kurulum dosyasi bulunamadi");
    return;
  }

  kafepinDesktopSetupRunning = true;
  addLiveLog("desktop_app", "🪟 KafePin Pro masaustu uygulamasi hazirlaniyor");

  runChildTracked(
    "powershell.exe",
    [
      "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", KAFEPIN_DESKTOP_APP_SETUP,
      "-InstallRoot", __dirname,
      "-AppVersion", KAFEPIN_DESKTOP_APP_VERSION,
      "-Launch"
    ],
    240000,
    (err, result) => {
      kafepinDesktopSetupRunning = false;
      if (err) {
        const detail = String((result && result.stderr) || err.message || err).trim();
        addLiveLog("desktop_app", `⚠️ Masaustu uygulamasi hazirlanamadi: ${detail.slice(0, 180)}`);
        return;
      }
      addLiveLog("desktop_app", "✅ KafePin Pro masaustu uygulamasi hazir • masaustu kisayolu olusturuldu");
    }
  );
}

function extractUpdateZipTracked(zipPath, destination, callback) {
  try { fs.mkdirSync(destination, { recursive: true }); } catch (err) { return callback(err); }

  // Windows 11'de yerlesik tar.exe ZIP acar. Bu yol PowerShell'den tamamen bagimsizdir.
  runChildTracked("tar.exe", ["-xf", zipPath, "-C", destination], 45000, (tarErr) => {
    if (!tarErr) return callback(null);

    // tar.exe kullanilamazsa .NET ZipFile kontrollu fallback.
    const helper = path.join(os.tmpdir(), `kafepin-extract-${Date.now()}-${Math.random().toString(36).slice(2)}.ps1`);
    const script = [
      "param([string]$ZipPath,[string]$Destination)",
      "$ErrorActionPreference='Stop'",
      "Add-Type -AssemblyName System.IO.Compression.FileSystem",
      "[IO.Compression.ZipFile]::ExtractToDirectory($ZipPath,$Destination)"
    ].join("\r\n");

    try { fs.writeFileSync(helper, script, "utf8"); }
    catch (err) { return callback(new Error(`ZIP acma yardimcisi yazilamadi: ${err.message || err}`)); }

    runChildTracked("powershell.exe", [
      "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", helper,
      "-ZipPath", zipPath, "-Destination", destination
    ], 45000, (psErr) => {
      try { fs.unlinkSync(helper); } catch (_err) {}
      if (!psErr) return callback(null);
      callback(new Error(`ZIP acilamadi. tar: ${tarErr.message || tarErr}; .NET: ${psErr.message || psErr}`));
    });
  });
}

function parseUpdaterArg(args, flag) {
  const i = Array.isArray(args) ? args.indexOf(flag) : -1;
  return i >= 0 && i + 1 < args.length ? String(args[i + 1] || "") : "";
}

function applyPreparedUpdateDirect(zipPath, expectedVersion, onError) {
  const installWork = fs.mkdtempSync(path.join(os.tmpdir(), "kafepin-direct-apply-"));
  const expanded = path.join(installWork, "expanded");
  let finished = false;

  const fail = err => {
    if (finished) return;
    finished = true;
    const message = String((err && err.message) || err || "Bilinmeyen guncelleme hatasi");
    try { writeProUpdateState("error", message, { version: expectedVersion || "" }); } catch (_err) {}
    try {
      fs.writeFileSync(
        path.join(__dirname, "logs", "kafepin-pro-update-result.json"),
        JSON.stringify({ ok: false, error: message, time: new Date().toISOString() }, null, 2),
        "utf8"
      );
    } catch (_err) {}
    try { fs.rmSync(installWork, { recursive: true, force: true }); } catch (_err) {}
    addLiveLog("pro_update", `⚠️ Guncelleme tamamlanamadi: ${message.slice(0, 180)}`);
    if (onError) onError(new Error(message));
  };

  writeProUpdateState("extract", "Paket aciliyor", { version: expectedVersion || "" });

  extractUpdateZipTracked(zipPath, expanded, extractErr => {
    if (extractErr) return fail(extractErr);

    try {
      writeProUpdateState("verify", "Paket icerigi dogrulaniyor", { version: expectedVersion || "" });

      const infoPath = path.join(expanded, "update.json");
      if (!fs.existsSync(infoPath)) throw new Error("Paket tanim dosyasi update.json bulunamadi");
      const info = JSON.parse(fs.readFileSync(infoPath, "utf8").replace(/^\uFEFF/, ""));
      const targetVersion = String(info.version || "");
      const files = Array.isArray(info.files) ? info.files.map(String) : [];

      if (!/^\d+(\.\d+){1,3}$/.test(targetVersion)) throw new Error("Paket surumu gecersiz");
      if (expectedVersion && targetVersion !== expectedVersion) {
        throw new Error(`Paket surumu uyusmuyor. Beklenen ${expectedVersion}, paket ${targetVersion}`);
      }
      if (!files.length) throw new Error("Paket dosya listesi bos");

      for (const rel of files) {
        if (!rel || /(^|[\\/])\.\.([\\/]|$)/.test(rel) || path.isAbsolute(rel)) {
          throw new Error(`Gecersiz paket yolu: ${rel}`);
        }
        const src = path.join(expanded, rel);
        if (!fs.existsSync(src) || !fs.statSync(src).isFile()) {
          throw new Error(`Paket dosyasi eksik: ${rel}`);
        }
      }

      writeProUpdateState("copy", `Dosyalar kuruluyor: v${targetVersion}`, { version: targetVersion });

      // Node server calisirken JS/HTML dosyalari Windows'ta guvenle degistirilebilir.
      // Server ancak tum kopyalama ve surum yazma bittikten SONRA kapanir.
      for (const rel of files) {
        const src = path.join(expanded, rel);
        const dst = path.join(__dirname, rel);
        fs.mkdirSync(path.dirname(dst), { recursive: true });
        fs.copyFileSync(src, dst);
      }

      // Yeni manager dosyasini ProgramData'ya da koy. Calisan manager eski kodla
      // serveri yeniden kaldirabilir; reboot sonrasi yeni manager kesin yuklenir.
      const managerSource = path.join(__dirname, "KafePin_System_Manager.ps1");
      if (fs.existsSync(managerSource)) {
        const systemRoot = path.join(process.env.ProgramData || "C:\\ProgramData", "KafePinPro");
        fs.mkdirSync(systemRoot, { recursive: true });
        try { fs.copyFileSync(managerSource, path.join(systemRoot, "KafePin_System_Manager.ps1")); } catch (_err) {}
        try { fs.unlinkSync(path.join(systemRoot, "server.manual-stop")); } catch (_err) {}
        try { fs.unlinkSync(path.join(systemRoot, "maintenance.lock")); } catch (_err) {}
      }

      const versionData = {
        version: targetVersion,
        channel: "stable",
        mode: "panel-direct-updater",
        installedAt: new Date().toISOString()
      };
      fs.writeFileSync(
        path.join(__dirname, "kafepin-pro-version.json"),
        JSON.stringify(versionData, null, 2) + "\n",
        "utf8"
      );

      fs.mkdirSync(path.join(__dirname, "logs"), { recursive: true });
      fs.writeFileSync(
        path.join(__dirname, "logs", "kafepin-pro-update-result.json"),
        JSON.stringify({ ok: true, version: targetVersion, time: new Date().toISOString() }, null, 2),
        "utf8"
      );
      writeProUpdateState("success", `Guncelleme tamamlandi: v${targetVersion}`, {
        version: targetVersion,
        running: false
      });
      addLiveLog("pro_update", `✅ v${targetVersion} dosyalari kuruldu • server yeniden baslatiliyor`);

      finished = true;
      try { fs.rmSync(installWork, { recursive: true, force: true }); } catch (_err) {}

      // Sunucu sadece HER SEY bittikten sonra kapanir.
      // Windows KafePin Pro Server Manager otomatik geri kaldirir.
      setTimeout(() => process.exit(0), 1200);
    } catch (err) {
      fail(err);
    }
  });
}

// Eski fonksiyon adi korunuyor ki mevcut panel endpointleri degismeden calissin.
// Artik gizli/detached PowerShell updater BASLATMAZ.
function launchProUpdaterExternal(_updaterPath, updaterArgs, onError) {
  try {
    const zipPath = parseUpdaterArg(updaterArgs, "-LocalZipPath");
    const expectedVersion = parseUpdaterArg(updaterArgs, "-ExpectedVersion");
    if (!zipPath || !fs.existsSync(zipPath)) {
      throw new Error("Kurulacak ZIP paketi bulunamadi");
    }
    applyPreparedUpdateDirect(zipPath, expectedVersion, onError);
    return true;
  } catch (err) {
    if (onError) onError(err);
    return false;
  }
}
app.post("/admin/pro/apply-update", (req, res) => {
  if (!isLocalhost(req)) return res.status(403).json({ ok: false, error: "Yerel erisim gerekli" });
  checkProUpdate(true, (err, status) => {
    if (err || !status || !status.available) return res.status(409).json({ ok: false, error: "Yuklenecek yeni surum bulunamadi" });
    const updater = path.join(__dirname, "KafePin_Pro_OtoGuncelle.ps1");
    if (!fs.existsSync(updater)) return res.status(500).json({ ok: false, error: "Otomatik guncelleme dosyasi bulunamadi" });

    writeProUpdateState("backup", "Emniyet yedegi aliniyor", { version: status.latestVersion });
    addLiveLog("pro_update", `⬆️ KafePin Pro v${status.latestVersion} kurulumu • emniyet yedegi aliniyor`);

    createFullProjectBackup((backupErr, safetyBackup) => {
      if (backupErr) {
        writeProUpdateState("error", `Emniyet yedegi alinamadi: ${backupErr.message || backupErr}`, { version: status.latestVersion });
        addLiveLog("pro_update", `⚠️ Guncelleme iptal edildi • yedek alinamadi: ${String(backupErr.message || backupErr).slice(0, 160)}`);
        return res.status(500).json({ ok: false, error: `Emniyet yedegi alinamadi: ${backupErr.message || backupErr}` });
      }

      const workDir = fs.mkdtempSync(path.join(os.tmpdir(), "kafepin-pro-download-"));
      const zipPath = path.join(workDir, `KafePin-Pro-Update-v${status.latestVersion}.zip`);
      writeProUpdateState("download", "Guncelleme paketi indiriliyor", { version: status.latestVersion, safetyBackup: safetyBackup && safetyBackup.fileName });

      downloadUpdateFile(status.downloadUrl, zipPath, downloadErr => {
        if (downloadErr) {
          try { fs.rmSync(workDir, { recursive: true, force: true }); } catch (_err) {}
          writeProUpdateState("error", `Paket indirilemedi: ${downloadErr.message || downloadErr}`, { version: status.latestVersion });
          addLiveLog("pro_update", `⚠️ Guncelleme paketi indirilemedi: ${String(downloadErr.message || downloadErr).slice(0, 160)}`);
          return res.status(502).json({ ok: false, error: `Paket indirilemedi: ${downloadErr.message || downloadErr}` });
        }

        try {
          if (status.sha256) {
            const hash = crypto.createHash("sha256").update(fs.readFileSync(zipPath)).digest("hex").toLowerCase();
            const expectedHash = String(status.sha256).toLowerCase();
            if (hash !== expectedHash) {
              addLiveLog("pro_update", `⚠️ SHA-256 uyusmazligi • beklenen ${expectedHash.slice(0, 12)}... • gelen ${hash.slice(0, 12)}...`);
              throw new Error(`Indirilen paketin SHA-256 dogrulamasi basarisiz (beklenen ${expectedHash.slice(0,12)}..., gelen ${hash.slice(0,12)}...)`);
            }
          }
        } catch (verifyErr) {
          try { fs.rmSync(workDir, { recursive: true, force: true }); } catch (_err) {}
          writeProUpdateState("error", verifyErr.message || String(verifyErr), { version: status.latestVersion });
          return res.status(500).json({ ok: false, error: verifyErr.message || String(verifyErr) });
        }

        writeProUpdateState("install", "Paket dogrulandi; kurulum baslatiliyor", { version: status.latestVersion, safetyBackup: safetyBackup && safetyBackup.fileName });
        addLiveLog("pro_update", `💾 Emniyet yedegi hazir • ${safetyBackup && safetyBackup.fileName ? safetyBackup.fileName : "tamam"}`);
        res.json({ ok: true, message: "Yedek ve paket dogrulandi; kurulum baslatiliyor", version: status.latestVersion, safetyBackup: safetyBackup && safetyBackup.fileName });

        setTimeout(() => {
          launchProUpdaterExternal(updater, [
            "-LocalZipPath", zipPath,
            "-ExpectedVersion", status.latestVersion,
            "-SkipBackup"
          ], spawnErr => {
            writeProUpdateState("error", `Kurucu baslatilamadi: ${spawnErr.message || spawnErr}`, { version: status.latestVersion });
            addLiveLog("pro_update", "⚠️ Otomatik guncelleme kurucusu baslatilamadi");
          });
        }, 500);
      });
    });
  });
});

// Internet olmadiginda da ayni guvenli akis kullanilabilir. Dosya secme
// penceresi sunucunun calistigi bilgisayarda acilir; tarayici dosya yoluna
// erismek zorunda kalmaz.
app.post("/admin/pro/apply-local-update", (req, res) => {
  if (!isLocalhost(req)) return res.status(403).json({ ok: false, error: "Yerel erisim gerekli" });
  const updater = path.join(__dirname, "KafePin_Pro_OtoGuncelle.ps1");
  if (!fs.existsSync(updater)) return res.status(500).json({ ok: false, error: "Guncelleme dosyasi bulunamadi" });
  const picker = [
    "Add-Type -AssemblyName System.Windows.Forms",
    "$d=New-Object System.Windows.Forms.OpenFileDialog",
    "$d.Title='KafePin Pro guncelleme paketi secin'",
    "$d.Filter='KafePin guncelleme paketi (*.zip)|*.zip'",
    "$d.Multiselect=$false",
    "if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){[Console]::OutputEncoding=[Text.Encoding]::UTF8;Write-Output $d.FileName}"
  ].join(";");
  const pickerProcess = spawn("powershell.exe", ["-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", picker], { windowsHide: false });
  let selected = "";
  let pickerError = "";
  let replied = false;
  pickerProcess.stdout.on("data", chunk => { selected += chunk.toString("utf8"); });
  pickerProcess.stderr.on("data", chunk => { pickerError += chunk.toString("utf8"); });
  pickerProcess.on("error", err => {
    if (replied) return;
    replied = true;
    res.status(500).json({ ok: false, error: String(err.message || err) });
  });
  pickerProcess.on("close", () => {
    if (replied) return;
    const zipPath = selected.trim();
    if (!zipPath) { replied = true; return res.json({ ok: false, cancelled: true, error: pickerError.trim() || "Paket secilmedi" }); }
    if (!/\.zip$/i.test(zipPath) || !fs.existsSync(zipPath)) { replied = true; return res.status(400).json({ ok: false, error: "Gecerli bir ZIP paketi secilmedi" }); }

    writeProUpdateState("backup", "Yerel paket icin emniyet yedegi aliniyor");
    createFullProjectBackup((backupErr, safetyBackup) => {
      if (backupErr) {
        replied = true;
        writeProUpdateState("error", `Emniyet yedegi alinamadi: ${backupErr.message || backupErr}`);
        return res.status(500).json({ ok: false, error: `Emniyet yedegi alinamadi: ${backupErr.message || backupErr}` });
      }
      addLiveLog("pro_update", `⬆️ Yerel guncelleme paketi kurulumu • ${path.basename(zipPath)}`);
      writeProUpdateState("install", "Yerel paket kurulumu baslatiliyor", { safetyBackup: safetyBackup && safetyBackup.fileName });
      replied = true;
      res.json({ ok: true, message: "Emniyet yedegi alindi; secilen paket kuruluyor", safetyBackup: safetyBackup && safetyBackup.fileName });
      setTimeout(() => {
        launchProUpdaterExternal(updater, ["-LocalZipPath", zipPath, "-SkipBackup"], spawnErr => {
          writeProUpdateState("error", `Kurucu baslatilamadi: ${spawnErr.message || spawnErr}`);
        });
      }, 500);
    });
  });
});

// Pro Yonetim Merkezi yalnizca ayni bilgisayardan (veya Tailscale'in yerel
// proxy'sinden) kullanilir. Yeniden baslatma, kullanicinin BAT menusune
// girmesine gerek kalmadan ana programdaki tek dugmeden yapilir.
app.post("/admin/pro/restart", (req, res) => {
  if (!isLocalhost(req)) return res.status(403).json({ ok: false, error: "Yerel erisim gerekli" });
  res.json({ ok: true, message: "Sunucu Windows Sistem Yoneticisi tarafindan yeniden baslatilacak" });
  setTimeout(() => process.exit(0), 300);
});

function getProBackupList() {
  try {
    return fs.readdirSync(FULL_BACKUP_DIR, { withFileTypes: true })
      .filter(entry => entry.isFile() && /^KafePin_.*\.zip$/i.test(entry.name))
      .map(entry => {
        const fullPath = path.join(FULL_BACKUP_DIR, entry.name);
        const stat = fs.statSync(fullPath);
        return { fileName: entry.name, time: stat.mtimeMs, size: stat.size };
      })
      .sort((a, b) => b.time - a.time);
  } catch (_err) {
    return [];
  }
}

app.get("/admin/pro/backups", (req, res) => {
  if (!isLocalhost(req)) return res.status(403).json({ ok: false, error: "Yerel erisim gerekli" });
  res.json({ ok: true, destination: FULL_BACKUP_DIR, list: getProBackupList().slice(0, 30) });
});

app.post("/admin/pro/db-backup", (req, res) => {
  if (!isLocalhost(req)) return res.status(403).json({ ok: false, error: "Yerel erisim gerekli" });
  const dbDir = "D:\\KAFEPIN_YEDEK\\DB";
  try { fs.mkdirSync(dbDir, { recursive: true }); } catch (err) { return res.status(500).json({ ok: false, error: String(err.message || err) }); }
  const output = path.join(dbDir, `database_${backupFileStamp()}.db`);
  db.backup(output, err => {
    if (err) return res.status(500).json({ ok: false, error: String(err.message || err) });
    addLiveLog("db_backup", `💾 Veritabanı yedeği alındı • ${path.basename(output)}`);
    res.json({ ok: true, path: output, time: Date.now() });
  });
});

app.post("/admin/pro/open-folder", (req, res) => {
  if (!isLocalhost(req)) return res.status(403).json({ ok: false, error: "Yerel erisim gerekli" });

  const kind = String((req.body || {}).kind || "app").toLowerCase();
  const destinations = {
    app: __dirname,
    backups: "D:\\KAFEPIN_YEDEK",
    db: "D:\\KAFEPIN_YEDEK\\DB",
    full: FULL_BACKUP_DIR
  };
  const folder = destinations[kind] || destinations.app;

  try {
    if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
  } catch (err) {
    return res.status(500).json({ ok: false, error: `Klasor hazirlanamadi: ${err.message || err}` });
  }

  const scriptPath = path.join(
    os.tmpdir(),
    `kafepin-open-folder-${Date.now()}-${Math.random().toString(36).slice(2)}.ps1`
  );
  const psq = value => String(value).replace(/'/g, "''");

  const script = [
    "$ErrorActionPreference = 'Stop'",
    `$folder = '${psq(folder)}'`,
    "$target = [IO.Path]::GetFullPath($folder).TrimEnd([char]92)",
    "",
    "Add-Type -TypeDefinition @\"",
    "using System;",
    "using System.Runtime.InteropServices;",
    "public static class KafePinExplorerFront {",
    "  [DllImport(\"user32.dll\")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);",
    "  [DllImport(\"user32.dll\")] public static extern bool SetForegroundWindow(IntPtr hWnd);",
    "  [DllImport(\"user32.dll\")] public static extern void SwitchToThisWindow(IntPtr hWnd, bool fAltTab);",
    "  [DllImport(\"user32.dll\")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint flags);",
    "}",
    "\"@",
    "",
    "function Get-KafePinExplorerWindow {",
    "  try {",
    "    $shell = New-Object -ComObject Shell.Application",
    "    foreach ($w in @($shell.Windows())) {",
    "      try {",
    "        $fullName = [string]$w.FullName",
    "        if (-not $fullName -or [IO.Path]::GetFileName($fullName) -ine 'explorer.exe') { continue }",
    "        $url = [string]$w.LocationURL",
    "        if (-not $url) { continue }",
    "        $local = ([Uri]$url).LocalPath",
    "        if (-not $local) { continue }",
    "        $norm = [IO.Path]::GetFullPath($local).TrimEnd([char]92)",
    "        if ($norm -ieq $target) { return $w }",
    "      } catch {}",
    "    }",
    "  } catch {}",
    "  return $null",
    "}",
    "",
    "function Bring-KafePinExplorerFront($w) {",
    "  $hwnd = [IntPtr][int64]$w.HWND",
    "  if ($hwnd -eq [IntPtr]::Zero) { return }",
    "  [KafePinExplorerFront]::ShowWindowAsync($hwnd, 9) | Out-Null",
    "  # Kisa sure topmost yapip geri alarak pencereyi gorunur sekilde one getir.",
    "  [KafePinExplorerFront]::SetWindowPos($hwnd, [IntPtr](-1), 0, 0, 0, 0, 0x0043) | Out-Null",
    "  Start-Sleep -Milliseconds 80",
    "  [KafePinExplorerFront]::SetWindowPos($hwnd, [IntPtr](-2), 0, 0, 0, 0, 0x0043) | Out-Null",
    "  [KafePinExplorerFront]::SetForegroundWindow($hwnd) | Out-Null",
    "  [KafePinExplorerFront]::SwitchToThisWindow($hwnd, $true)",
    "}",
    "",
    "$window = Get-KafePinExplorerWindow",
    "if (-not $window) {",
    "  # Once Windows Shell COM ile ac. Bu, mevcut masaustu Explorer oturumunu kullanir.",
    "  try {",
    "    $shell = New-Object -ComObject Shell.Application",
    "    $shell.Explore($folder)",
    "  } catch {",
    "    $arg = '/separate,\"' + $folder + '\"'",
    "    Start-Process -FilePath (Join-Path $env:WINDIR 'explorer.exe') -ArgumentList $arg -ErrorAction Stop | Out-Null",
    "  }",
    "",
    "  $deadline = (Get-Date).AddSeconds(6)",
    "  do {",
    "    Start-Sleep -Milliseconds 250",
    "    $window = Get-KafePinExplorerWindow",
    "    if ($window) { break }",
    "  } while ((Get-Date) -lt $deadline)",
    "}",
    "",
    "if (-not $window) {",
    "  # Son bir dogrudan Explorer denemesi; argumanda eski \\\" kacis hatasi YOK.",
    "  $arg = '/separate,\"' + $folder + '\"'",
    "  Start-Process -FilePath (Join-Path $env:WINDIR 'explorer.exe') -ArgumentList $arg -ErrorAction Stop | Out-Null",
    "  $deadline2 = (Get-Date).AddSeconds(4)",
    "  do {",
    "    Start-Sleep -Milliseconds 250",
    "    $window = Get-KafePinExplorerWindow",
    "    if ($window) { break }",
    "  } while ((Get-Date) -lt $deadline2)",
    "}",
    "",
    "if (-not $window) { throw ('Explorer penceresi acilamadi veya dogrulanamadi: ' + $folder) }",
    "Bring-KafePinExplorerFront $window",
    "Write-Output 'KAFEPIN_EXPLORER_OK'"
  ].join("\r\n");

  try {
    fs.writeFileSync(scriptPath, script, "utf8");
  } catch (err) {
    return res.status(500).json({ ok: false, error: `Explorer yardimcisi yazilamadi: ${err.message || err}` });
  }

  runChildTracked(
    "powershell.exe",
    ["-NoProfile", "-ExecutionPolicy", "Bypass", "-STA", "-File", scriptPath],
    15000,
    (err, result) => {
      try { fs.unlinkSync(scriptPath); } catch (_err) {}

      if (err) {
        const detail = String((result && result.stderr) || "").trim();
        const message = detail
          ? `Explorer acilamadi: ${detail.slice(0, 400)}`
          : `Explorer acilamadi: ${err.message || err}`;
        addLiveLog("folder_open", `⚠️ ${message.slice(0, 180)}`);
        return res.status(500).json({ ok: false, error: message });
      }

      const stdout = String((result && result.stdout) || "");
      if (!stdout.includes("KAFEPIN_EXPLORER_OK")) {
        const message = "Explorer islemi tamamlandi ancak pencere dogrulanamadi";
        addLiveLog("folder_open", `⚠️ ${message} • ${folder}`);
        return res.status(500).json({ ok: false, error: message });
      }

      addLiveLog("folder_open", `📁 Explorer penceresi dogrulandi ve one getirildi • ${folder}`);
      return res.json({ ok: true, path: folder, kind, verified: true });
    }
  );
});
app.get("/admin/pro/runtime", (req, res) => {
  if (!isLocalhost(req)) return res.status(403).json({ ok: false, error: "Yerel erisim gerekli" });
  setNoStore(res);
  res.json({
    ok: true,
    pid: process.pid,
    root: __dirname,
    port: Number(port || 3000),
    version: getProVersion()
  });
});

app.get("/admin/pro/manager-info", (req, res) => {
  if (!isLocalhost(req)) return res.status(403).json({ ok: false, error: "Yerel erisim gerekli" });
  setNoStore(res);
  const systemRoot = path.join(process.env.ProgramData || "C:\\ProgramData", "KafePinPro");
  const tokenFile = path.join(systemRoot, "manager.token");
  try {
    const token = fs.readFileSync(tokenFile, "utf8").trim();
    if (!token) throw new Error("Sistem yoneticisi tokeni bos");
    res.json({ ok: true, controlUrl: "http://127.0.0.1:2999", token });
  } catch (err) {
    res.status(503).json({ ok: false, error: `Windows Sistem Yoneticisi hazir degil: ${err.message || err}` });
  }
});

app.post("/admin/pro/stop", (req, res) => {
  if (!isLocalhost(req)) return res.status(403).json({ ok: false, error: "Yerel erisim gerekli" });
  res.json({ ok: true, message: "Sunucu durduruluyor" });
  setTimeout(() => process.exit(0), 250);
});

app.post("/admin/pro/restore", (req, res) => {
  if (!isLocalhost(req)) return res.status(403).json({ ok: false, error: "Yerel erisim gerekli" });
  const fileName = path.basename(String((req.body || {}).fileName || ""));
  if (!/^KafePin_.*\.zip$/i.test(fileName)) return res.status(400).json({ ok: false, error: "Gecersiz yedek dosyasi" });
  const zipPath = path.join(FULL_BACKUP_DIR, fileName);
  if (!fs.existsSync(zipPath)) return res.status(404).json({ ok: false, error: "Yedek bulunamadi" });
  if (fullBackupRunning) return res.status(409).json({ ok: false, error: "Once devam eden yedekleme bitsin" });

  addLiveLog("pro_restore", `↩️ Yedekten geri yukleme istendi • ${fileName}`);

  createFullProjectBackup((backupErr, safetyBackup) => {
    if (backupErr) return res.status(500).json({ ok: false, error: `Emniyet yedegi alinamadi: ${backupErr.message || backupErr}` });

    const restoreSystemRoot = path.join(process.env.ProgramData || "C:\\ProgramData", "KafePinPro");
    const restoreMaintenanceLock = path.join(restoreSystemRoot, "maintenance.lock");
    try {
      fs.mkdirSync(restoreSystemRoot, { recursive: true });
      fs.writeFileSync(restoreMaintenanceLock, String(Date.now()), "utf8");
    } catch (lockErr) {
      return res.status(500).json({ ok: false, error: `Sistem bakim kilidi olusturulamadi: ${lockErr.message || lockErr}` });
    }

    addLiveLog("pro_restore", `💾 Geri yukleme oncesi emniyet yedegi alindi • ${safetyBackup && safetyBackup.fileName ? safetyBackup.fileName : "hazir"}`);
    res.json({ ok: true, message: "Geri yukleme baslatiliyor", safetyBackup: safetyBackup && safetyBackup.fileName });

    setTimeout(() => {
      const scriptPath = path.join(os.tmpdir(), `kafepin-restore-${Date.now()}.ps1`);
      const escapePs = value => String(value).replace(/'/g, "''");
      const script = [
        "$ErrorActionPreference = 'Stop'",
        `$target = '${escapePs(__dirname)}'`,
        `$zip = '${escapePs(zipPath)}'`,
        "$systemRoot = Join-Path $env:ProgramData 'KafePinPro'",
        "$lock = Join-Path $systemRoot 'maintenance.lock'",
        "try {",
        "  Start-Sleep -Seconds 2",
        "  Get-ChildItem -LiteralPath $target -Force | Remove-Item -Recurse -Force",
        "  Add-Type -AssemblyName System.IO.Compression.FileSystem",
        "  [IO.Compression.ZipFile]::ExtractToDirectory($zip, $target)",
        "} finally {",
        "  Remove-Item -LiteralPath $lock -Force -ErrorAction SilentlyContinue",
        "  try { Start-ScheduledTask -TaskName 'KafePin Pro Server Manager' -ErrorAction SilentlyContinue } catch { try { schtasks.exe /Run /TN 'KafePin Pro Server Manager' | Out-Null } catch {} }",
        "  Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue",
        "}"
      ].join("\\r\\n");

      try {
        fs.writeFileSync(scriptPath, script, "utf8");
        const child = spawn("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", scriptPath], {
          detached: true,
          stdio: "ignore",
          windowsHide: true
        });
        child.unref();
      } catch (err) {
        try { fs.unlinkSync(restoreMaintenanceLock); } catch (_unlockErr) {}
        logErr("pro restore launch", err);
      }
      process.exit(0);
    }, 300);
  });
});
app.get("/debug/live", async (req, res) => {
  try {
    setNoStore(res);

    const now = Date.now();

    const tasks = [];

    for (let masa = 1; masa <= MASA_SAYISI; masa++) {
      tasks.push(new Promise((resolve) => {

        const lastSeen = aktifMasalar[masa] || 0;
        const online = !isActuallyOffline(masa, lastSeen, now);

        if (lastOfflineState[masa] === true && online === false) {
          offlineCount[masa] = (offlineCount[masa] || 0) + 1;
        }
        lastOfflineState[masa] = online;

        const ping = masaPingStats[masa] || {};

        db.get("SELECT * FROM sessions WHERE masa=?", [masa], (err, s) => {

          let minutes = 0;
          let fee = 0;
          let adj = 0;
          let productTotal = 0;

          if (!err && s && s.start_time && (!s.end_time || s.end_time === 0)) {
            const end = s.last_seen || now;
            const scheduledEnd = isEveryCafeTimedMasa(masa) ? getEveryCafeScheduledEnd(masa) : 0;
            // EveryCafe'de 60 dk'lık oturum [başlangıç, bitiş) aralığıdır:
            // bitiş anı henüz +25/+35 basamağı değildir. Kaynak süre uzatırsa
            // EndDate zaten yeni bitişe taşınır ve yeni ücret o zaman görünür.
            const billedEnd = scheduledEnd > Number(s.start_time)
              ? Math.min(end, scheduledEnd - 1)
              : end;
            minutes = Math.floor((billedEnd - s.start_time) / 60000);
            // EveryCafe'de ücretsiz açılan oturumda yerel eski bir kayıt kalsa
            // bile monitör/Canlı Panel bilgisayar ücreti göstermemelidir.
            fee = isFreeMasa(masa) ? 0 : feeAtTime(masa, s.start_time, billedEnd);
          }

          const finish = () => {
const BASE = 60;
const STEP = 30;
const giftMinutes = getEveryCafeGiftMinutes(masa);
const billedMinutes = Math.max(0, minutes - giftMinutes);

let nextIncreaseInSec = null;

if (minutes != null) {

  if (billedMinutes < BASE) {
    nextIncreaseInSec = (BASE - billedMinutes) * 60;
  } else {
    const diff = billedMinutes - BASE;
    const mod = diff % STEP;
    const remaining = mod === 0 ? STEP : (STEP - mod);

    nextIncreaseInSec = remaining * 60;
  }

}
const realFee = fee + adj;
            const totalWithProducts = realFee + productTotal;
            resolve({
              masa,
              online,
              lastSeen,
              lastSeenAgoSec: lastSeen ? Math.floor((now - lastSeen) / 1000) : null,
              avgPingMs: Math.floor(ping.avg || 0),
              netSpeed: ping.netSpeed || 0,
              lastPingDiffMs: ping.last ? (now - ping.last) : null,
              locked: isLocked(masa, now),
lastReward: latestRewardMap[masa] || "-",
              free: isFreeMasa(masa),
              blocked: blockedMasalar.has(masa),

             minutes,
fee,
feeAdj: realFee,
realFee,
productTotal,
totalWithProducts,
offlineCount: offlineCount[masa] || 0,
giftMinutes,
nextIncreaseInSec,
            });
          };

          if (!err && s) {
            db.all(
              "SELECT amount FROM real_adjustments WHERE masa=? AND session_start=?",
              [masa, s.start_time || 0],
              (e2, rows) => {

                if (!e2 && rows) {
                  adj = rows.reduce((sum, r) => sum + (r.amount || 0), 0);
                }

                db.get(
                  `SELECT COALESCE(SUM(total),0) AS total
                   FROM product_sales
                   WHERE masa=? AND session_start=? AND sale_type='TABLE'
                     AND status='OPEN' AND voided=0`,
                  [masa, s.start_time || 0],
                  (productErr, productRow) => {
                    if (!productErr && productRow) productTotal = Number(productRow.total) || 0;
                    finish();
                  }
                );
              }
            );
          } else {
            finish();
          }

        });

      }));
    }

const out = await Promise.all(tasks);

db.get(
  `
  SELECT
    COALESCE((
      SELECT SUM(h.fee)
      FROM session_history h
      WHERE h.end_time >= ?
    ),0)
    + COALESCE((
      SELECT SUM(p.total)
      FROM product_sales p
      LEFT JOIN session_history h
        ON h.masa=p.masa AND h.start_time=p.session_start
      WHERE p.voided=0 AND (
        (p.sale_type='TABLE' AND p.status='FINALIZED' AND h.end_time >= ?)
        OR (p.sale_type='DIRECT' AND p.time >= ?)
      )
    ),0) AS gelir
  `,
  [now - (60 * 60 * 1000), now - (60 * 60 * 1000), now - (60 * 60 * 1000)],
  (eHour, hourRow) => {

    const thisHourRevenue =
      !eHour && hourRow
        ? Number(hourRow.gelir) || 0
        : 0;

    res.json({
      now,
      masalar: out,

      totalRevenue: out.reduce(
        (sum, m) => sum + (m.totalWithProducts || m.feeAdj || 0),
        0
      ),

      thisHourRevenue
    });

  }
);

  } catch (err) {
    console.error("/debug/live ERROR:", err);
    res.status(500).json({ ok: false });
  }
});
function getDayAwareDashboardStats(startTs, endTs, cb) {
  db.all(
    "SELECT masa,start_time,last_seen,end_time FROM sessions WHERE start_time<? AND (end_time=0 OR end_time>?)",
    [endTs, startTs],
    (activeErr, activeRows) => {
      if (activeErr) return cb(activeErr);

      db.all(
        "SELECT masa,start_time,end_time,fee FROM session_history WHERE start_time<? AND end_time>?",
        [endTs, startTs],
        (historyErr, historyRows) => {
          if (historyErr) return cb(historyErr);

          db.all(
            `SELECT masa,session_start,amount,kind,time FROM real_adjustments
             WHERE (kind='SESSION_FINALIZE' AND session_start<? AND time>?)
                OR (kind<>'SESSION_FINALIZE' AND time>=? AND time<?)`,
            [endTs, startTs, startTs, endTs],
            (adjustErr, adjustmentRows) => {
              if (adjustErr) return cb(adjustErr);

              const sessionsByKey = new Map();
              const masaSummary = new Map();
              const finalizedByKey = new Map();

              (adjustmentRows || []).forEach((row) => {
                if (String(row.kind || "").trim() !== "SESSION_FINALIZE") return;
                const masa = Number(row.masa) || 0;
                const sessionStart = Number(row.session_start) || 0;
                if (!masa || !sessionStart) return;
                finalizedByKey.set(`${masa}:${sessionStart}`, row);
              });
              const ensureMasa = (masa) => {
                const key = Number(masa);
                if (!masaSummary.has(key)) {
                  masaSummary.set(key, { masa:key, minutes:0, revenue:0, sessions:0 });
                }
                return masaSummary.get(key);
              };

              const addSession = (row, isActive) => {
                const masa = Number(row.masa) || 0;
                const sessionStart = Number(row.start_time) || 0;
                if (!masa || !sessionStart || isFreeMasa(masa)) return;

                const rawEnd = isActive
                  ? (Number(row.last_seen) || endTs)
                  : (Number(row.end_time) || 0);
                const rangeStart = Math.max(startTs, sessionStart);
                const rangeEnd = Math.min(endTs, rawEnd);
                if (rangeEnd <= rangeStart) return;

                const key = `${masa}:${sessionStart}`;
                if (sessionsByKey.has(key)) return;

                let gross = 0;

                if (isActive) {
                  gross = Math.max(
                    feeAtTime(masa, sessionStart, rangeEnd) -
                    feeAtTime(masa, sessionStart, rangeStart),
                    0
                  );
                } else {
                  const finalized = finalizedByKey.get(key);
                  const recordedTotal = Math.max(
                    Number(finalized ? finalized.amount : row.fee) || 0,
                    0
                  );

                  // Kapanmış oturumda veritabanına sabitlenen kesin tutar esastır.
                  // Böylece kısa, ücretsiz veya 0 ₺ yapılan oturum tekrar 50 ₺ olmaz.
                  if (recordedTotal <= 0) return;

                  const sessionEnd = Number(row.end_time) || rangeEnd;
                  if (rangeStart <= sessionStart && rangeEnd >= sessionEnd) {
                    gross = recordedTotal;
                  } else {
                    gross = Math.max(
                      Math.min(
                        feeAtTime(masa, sessionStart, rangeEnd) -
                        feeAtTime(masa, sessionStart, rangeStart),
                        recordedTotal
                      ),
                      0
                    );
                  }
                }
                const minutes = Math.max(0, (rangeEnd - rangeStart) / 60000);
                const item = { masa, sessionStart, minutes, revenue:gross };
                sessionsByKey.set(key, item);

                const summary = ensureMasa(masa);
                summary.minutes += minutes;
                summary.revenue += gross;
                summary.sessions += 1;
              };

              (historyRows || []).forEach((row) => addSession(row, false));
              (activeRows || []).forEach((row) => addSession(row, true));

              (adjustmentRows || []).forEach((row) => {
                if (String(row.kind || "").trim() === "SESSION_FINALIZE") return;
                const masa = Number(row.masa) || 0;
                if (!masa || isFreeMasa(masa)) return;
                const amount = Number(row.amount) || 0;
                const sessionKey = `${masa}:${Number(row.session_start) || 0}`;
                const session = sessionsByKey.get(sessionKey);
                if (session) session.revenue += amount;
                ensureMasa(masa).revenue += amount;
              });

              // Dashboard oturum adedi yalnızca bu gün aralığında gerçek ücret
              // oluşturan oturumları sayar. İlk ücretsiz dakikalardaki aktif
              // oturumlar ve devirden sonra henüz yeni ücret üretmeyen oturumlar
              // gelir gibi oturum adedini de şişirmemelidir.
              db.all(
                `SELECT masa,session_start,total
                 FROM product_sales
                 WHERE voided=0 AND sale_type='TABLE' AND masa>0
                   AND time>=? AND time<?`,
                [startTs, endTs],
                (productErr, productRows) => {
                  if (productErr) return cb(productErr);
                  (productRows || []).forEach((row) => {
                    const masa = Number(row.masa) || 0;
                    const total = Number(row.total) || 0;
                    if (!masa || !total) return;
                    const session = sessionsByKey.get(`${masa}:${Number(row.session_start) || 0}`);
                    if (session) session.revenue += total;
                    ensureMasa(masa).revenue += total;
                  });

                  const sessionList = Array.from(sessionsByKey.values()).filter(
                    (session) => Number(session.revenue) > 0
                  );
                  const masaList = Array.from(masaSummary.values());
                  const totalSessions = sessionList.length;
                  const totalMinutes = sessionList.reduce((sum, x) => sum + x.minutes, 0);
                  const totalRevenue = masaList.reduce((sum, x) => sum + x.revenue, 0);

                  masaList.sort((a,b) => b.minutes - a.minutes || a.masa - b.masa);
                  const busiest = masaList.find((x) => x.minutes > 0) || null;
                  const revenueSorted = [...masaList].sort((a,b) => b.revenue - a.revenue || a.masa - b.masa);
                  const bestRevenue = revenueSorted.find((x) => x.revenue > 0) || null;

                  return cb(null, {
                    totalSessions,
                    totalRevenue,
                    avgFee: totalSessions ? totalRevenue / totalSessions : 0,
                    avgMinutes: totalSessions ? totalMinutes / totalSessions : 0,
                    busiestTable: busiest ? busiest.masa : null,
                    busiestMinutes: busiest ? busiest.minutes : 0,
                    bestRevenueTable: bestRevenue ? bestRevenue.masa : null,
                    bestRevenue: bestRevenue ? bestRevenue.revenue : 0
                  });
                }
              );
            }
          );
        }
      );
    }
  );
}

let tailscaleHealthCache = {
  checkedAt: 0,
  online: false,
  detail: "Henüz kontrol edilmedi"
};

function checkTailscaleHealth(cb) {
  const now = Date.now();
  if (now - tailscaleHealthCache.checkedAt < 60000) {
    return cb(null, tailscaleHealthCache);
  }

  const interfaces = os.networkInterfaces();
  const tailscaleEntries = Object.entries(interfaces)
    .filter(([name]) => String(name).toLowerCase().includes("tailscale"))
    .flatMap(([, entries]) => entries || []);
  const ipv4 = tailscaleEntries.find((entry) =>
    entry && entry.family === "IPv4" && /^100\./.test(String(entry.address || ""))
  );

  const online = Boolean(ipv4);
  const detail = online ? `Bağlı • ${ipv4.address}` : "Bağlı değil";
  tailscaleHealthCache = { checkedAt: now, online, detail };
  cb(null, tailscaleHealthCache);
}

app.get("/admin/system-health", (req, res) => {
  setNoStore(res);
  const startedAt = Date.now() - Math.floor(process.uptime() * 1000);

  db.get("SELECT 1 AS ok", (dbErr) => {
    checkTailscaleHealth((tailErr, tailscale) => {
      const telegramConfigured = Boolean(
        TELEGRAM_ENABLED && TELEGRAM_BOT_TOKEN && TELEGRAM_CHAT_ID
      );

      res.json({
        ok: !dbErr,
        checkedAt: Date.now(),
        server: { ok: true, startedAt, uptimeSeconds: Math.floor(process.uptime()) },
        database: { ok: !dbErr, detail: dbErr ? String(dbErr.message || dbErr) : "Bağlı" },
        telegram: {
          ok: telegramConfigured,
          enabled: TELEGRAM_ENABLED,
          detail: telegramConfigured ? "Hazır" : (TELEGRAM_ENABLED ? "Ayar eksik" : "Kapalı")
        },
        tailscale: tailscale || { online: false, detail: tailErr ? "Kontrol edilemedi" : "Bilinmiyor" }
      });
    });
  });
});

app.get("/admin/daily-comparison", (req, res) => {
  setNoStore(res);

  const now = Date.now();
  const todayStart = dayStartTs(now);
  const dayMs = 24 * 60 * 60 * 1000;
  const ranges = {
    today: [todayStart, now],
    yesterday: [todayStart - dayMs, todayStart],
    lastWeekSameDay: [todayStart - 7 * dayMs, todayStart - 6 * dayMs]
  };

  const readRange = ([start, end]) =>
    new Promise((resolve, reject) => {
      getRangeStats(start, end, (err, stats) => {
        if (err) return reject(err);
        getDayAwareDashboardStats(start, end, (dashboardErr, dashboardStats) => {
          if (dashboardErr) return reject(dashboardErr);
          resolve({
            ...(stats || {}),
            totalSessions: Number((dashboardStats && dashboardStats.totalSessions) || 0)
          });
        });
      });
    });

  Promise.all([
    readRange(ranges.today),
    readRange(ranges.yesterday),
    readRange(ranges.lastWeekSameDay)
  ])
    .then(([today, yesterday, lastWeekSameDay]) => {
      // Karşılaştırmada masa geliriyle birlikte o gün satılan ürün/hizmetleri
      // de kullan. getRangeStats tüm aralıklarda aynı kafe günü sınırını kullanır.
      const revenue = (x) => Number(x.genelGelir || 0);
      const todayRevenue = revenue(today);
      const yesterdayRevenue = revenue(yesterday);
      const lastWeekRevenue = revenue(lastWeekSameDay);
      const percent = (base) => base === 0 ? null : ((todayRevenue - base) / Math.abs(base)) * 100;

      res.json({
        ok: true,
        today: { revenue: todayRevenue, sessions: Number(today.totalSessions || 0) },
        yesterday: { revenue: yesterdayRevenue, sessions: Number(yesterday.totalSessions || 0) },
        lastWeekSameDay: { revenue: lastWeekRevenue, sessions: Number(lastWeekSameDay.totalSessions || 0) },
        versusYesterdayPercent: percent(yesterdayRevenue),
        versusLastWeekPercent: percent(lastWeekRevenue)
      });
    })
    .catch((err) => {
      logErr("/admin/daily-comparison", err);
      res.status(500).json({ ok: false });
    });
});

app.get("/admin/dashboard-stats", (req, res) => {

  setNoStore(res);

  const todayStart = dayStartTs(Date.now());

  db.get(
    `
SELECT
  COUNT(*) as totalSessions,
  COALESCE(AVG(minutes),0) as avgMinutes,
  COALESCE(AVG(CASE WHEN fee > 0 THEN fee END),0) as avgFee,
  COALESCE(SUM(fee),0) as totalRevenue,

  (SELECT COUNT(*) FROM session_history WHERE fee > 0) AS allTimeSessions,

  (SELECT COALESCE(AVG(minutes),0)
   FROM session_history WHERE fee > 0) AS allTimeAvgMinutes,

  (SELECT COALESCE(AVG(h.fee + COALESCE((
    SELECT SUM(p.total) FROM product_sales p
    WHERE p.masa=h.masa AND p.session_start=h.start_time
      AND p.sale_type='TABLE' AND p.voided=0
  ),0)),0)
 FROM session_history h
 WHERE h.fee>0 OR EXISTS(
   SELECT 1 FROM product_sales p
   WHERE p.masa=h.masa AND p.session_start=h.start_time
     AND p.sale_type='TABLE' AND p.voided=0
 )) AS allTimeAvgFee,

  (SELECT COALESCE(SUM(h.fee + COALESCE((
    SELECT SUM(p.total) FROM product_sales p
    WHERE p.masa=h.masa AND p.session_start=h.start_time
      AND p.sale_type='TABLE' AND p.voided=0
  ),0)),0)
   FROM session_history h) AS allTimeRevenue,

  (SELECT COALESCE(MAX(h.fee + COALESCE((
    SELECT SUM(p.total)
    FROM product_sales p
    WHERE p.masa=h.masa
      AND p.session_start=h.start_time
      AND p.sale_type='TABLE'
      AND p.voided=0
  ),0)),0)
   FROM session_history h) AS allTimeMaxFee,
(SELECT COALESCE(MAX(minutes),0)
 FROM session_history WHERE fee > 0) AS longestSessionMinutes,

(SELECT masa
 FROM session_history
 WHERE fee > 0
 ORDER BY minutes DESC
 LIMIT 1) AS longestSessionTable,

(SELECT COALESCE(SUM(h.fee + COALESCE((
  SELECT SUM(p.total) FROM product_sales p
  WHERE p.masa=h.masa AND p.session_start=h.start_time
    AND p.sale_type='TABLE' AND p.voided=0
),0)),0)
 FROM session_history h
 WHERE h.end_time >= strftime('%s','now','start of month')*1000
) AS thisMonthRevenue,

(SELECT COALESCE(SUM(h.fee + COALESCE((
  SELECT SUM(p.total) FROM product_sales p
  WHERE p.masa=h.masa AND p.session_start=h.start_time
    AND p.sale_type='TABLE' AND p.voided=0
),0)),0)
 FROM session_history h
 WHERE h.end_time >= strftime('%s','now','-30 day')*1000
) AS last30Revenue,

(SELECT SUM(h.fee + COALESCE((
  SELECT SUM(p.total) FROM product_sales p
  WHERE p.masa=h.masa AND p.session_start=h.start_time
    AND p.sale_type='TABLE' AND p.voided=0
),0))
 FROM session_history h
 GROUP BY DATE(h.end_time/1000,'unixepoch','localtime')
 ORDER BY SUM(h.fee + COALESCE((
  SELECT SUM(p.total) FROM product_sales p
  WHERE p.masa=h.masa AND p.session_start=h.start_time
    AND p.sale_type='TABLE' AND p.voided=0
 ),0)) DESC
 LIMIT 1
) AS bestDailyRevenue,

(SELECT DATE(h.end_time/1000,'unixepoch','localtime')
 FROM session_history h
 GROUP BY DATE(h.end_time/1000,'unixepoch','localtime')
 ORDER BY SUM(h.fee + COALESCE((
  SELECT SUM(p.total) FROM product_sales p
  WHERE p.masa=h.masa AND p.session_start=h.start_time
    AND p.sale_type='TABLE' AND p.voided=0
 ),0)) DESC
 LIMIT 1
) AS bestDailyRevenueDate,

(SELECT masa
 FROM session_history
 WHERE fee > 0
 GROUP BY masa
 ORDER BY AVG(minutes) DESC
 LIMIT 1
) AS avgLeaderTable,

(SELECT ROUND(AVG(minutes))
 FROM session_history
 WHERE fee > 0
 GROUP BY masa
 ORDER BY AVG(minutes) DESC
 LIMIT 1
) AS avgLeaderMinutes

FROM session_history
WHERE end_time >= ? AND fee > 0
    `,
    [todayStart],
    (err, stats) => {

      if (err) {
        logErr("dashboard-stats", err);
        return res.json({ ok:false });
      }
let onlineCount = 0;
let offlineCount = 0;
let freeCount = 0;
const onlineMasalar = [];
const offlineMasalar = [];

const now = Date.now();

for (let masa = 1; masa <= MASA_SAYISI; masa++) {

  if (isFreeMasa(masa)) {
    freeCount++;
    continue;
  }

  const lastSeen = aktifMasalar[masa] || 0;

  const online = !isActuallyOffline(
    masa,
    lastSeen,
    now
  );

if (online) {

  onlineCount++;
  onlineMasalar.push(masa);

} else {

  offlineCount++;
  offlineMasalar.push(masa);

}
}
db.all(
  `
SELECT
    masa,

    COUNT(CASE WHEN end_time >= ? AND fee > 0 THEN 1 END) AS sessionCount,
    SUM(CASE WHEN end_time >= ? THEN fee + COALESCE((
      SELECT SUM(p.total) FROM product_sales p
      WHERE p.masa=session_history.masa AND p.session_start=session_history.start_time
        AND p.sale_type='TABLE' AND p.voided=0
    ),0) ELSE 0 END) AS totalFee,

    COUNT(CASE WHEN fee > 0 THEN 1 END) AS allSessionCount,
    SUM(fee + COALESCE((
      SELECT SUM(p.total) FROM product_sales p
      WHERE p.masa=session_history.masa AND p.session_start=session_history.start_time
        AND p.sale_type='TABLE' AND p.voided=0
    ),0)) AS allTotalFee

FROM session_history
GROUP BY masa
  `,
  [todayStart, todayStart],   // <-- BURADA VİRGÜL OLMALI
  (err2, masaStats) => {

    if (err2) {
      logErr("dashboard-masa-stats", err2);
      return res.json({ ok:false });
    }

    let busiestTable = null;
    let busiestCount = 0;

    let bestRevenueTable = null;
    let bestRevenue = 0;
let allTimeBusyTable = null;
let allTimeBusyCount = 0;

let allTimeBestRevenueTable = null;
let allTimeBestRevenue = 0;

for (const row of masaStats) {

  // Bugün
  if (row.sessionCount > busiestCount) {
    busiestCount = row.sessionCount;
    busiestTable = row.masa;
  }

  if (Number(row.totalFee) > bestRevenue) {
    bestRevenue = Number(row.totalFee);
    bestRevenueTable = row.masa;
  }

  // Tüm zamanlar
  if (row.allSessionCount > allTimeBusyCount) {
    allTimeBusyCount = row.allSessionCount;
    allTimeBusyTable = row.masa;
  }

  if (Number(row.allTotalFee) > allTimeBestRevenue) {
    allTimeBestRevenue = Number(row.allTotalFee);
    allTimeBestRevenueTable = row.masa;
  }

}

getDayAwareDashboardStats(todayStart, now, (dayErr, todayStats) => {
  if (dayErr) {
    logErr("dashboard day-aware stats", dayErr);
    return res.json({ ok:false });
  }

  // Dashboard'daki ciro kartları, muhasebe ile aynı kaynaktan hesaplanır:
  // gerçek masa geliri + masa/doğrudan ürün-hizmet geliri. Böylece eski
  // yalnızca oturum toplamı hiçbir kartta genel ciro gibi görünmez.
  const monthDate = new Date(now);
  monthDate.setDate(1);
  monthDate.setHours(20, 0, 0, 0);
  const monthStart = monthDate.getTime() > now
    ? new Date(monthDate.getFullYear(), monthDate.getMonth() - 1, 1, 20, 0, 0, 0).getTime()
    : monthDate.getTime();
  const last30Start = now - (30 * 24 * 60 * 60 * 1000);

  getRangeStats(0, now + 1, (allRangeErr, allRange) => {
    if (allRangeErr) {
      logErr("dashboard all-time general revenue", allRangeErr);
      return res.json({ ok:false });
    }
    getRangeStats(monthStart, now + 1, (monthRangeErr, monthRange) => {
      if (monthRangeErr) {
        logErr("dashboard month general revenue", monthRangeErr);
        return res.json({ ok:false });
      }
      getRangeStats(last30Start, now + 1, (last30RangeErr, last30Range) => {
        if (last30RangeErr) {
          logErr("dashboard last30 general revenue", last30RangeErr);
          return res.json({ ok:false });
        }

return res.json({

  ok:true,

  totalSessions: todayStats.totalSessions,
  avgMinutes: Number(todayStats.avgMinutes || 0),
  avgFee: Number(todayStats.avgFee || 0),
  totalRevenue: Number(todayStats.totalRevenue || 0),

  busiestTable: todayStats.busiestTable,
  busiestCount: todayStats.totalSessions,
  busiestMinutes: Number(todayStats.busiestMinutes || 0),

  bestRevenueTable: todayStats.bestRevenueTable,
  bestRevenue: Number(todayStats.bestRevenue || 0),

  // 👇 BURAYA EKLE
  allTimeSessions: stats.allTimeSessions || 0,
  allTimeRevenue: Number(allRange.genelGelir || 0),
  allTimeAvgFee: Number(stats.allTimeAvgFee || 0),
  allTimeAvgMinutes: Number(stats.allTimeAvgMinutes || 0),
  allTimeMaxFee: Number(stats.allTimeMaxFee || 0),
longestSessionMinutes: Number(stats.longestSessionMinutes || 0),
longestSessionTable: stats.longestSessionTable,

thisMonthRevenue: Number(monthRange.genelGelir || 0),
last30Revenue: Number(last30Range.genelGelir || 0),
bestDailyRevenue: Number(stats.bestDailyRevenue || 0),
bestDailyRevenueDate: stats.bestDailyRevenueDate,
avgLeaderTable: stats.avgLeaderTable,
avgLeaderMinutes: Number(stats.avgLeaderMinutes || 0),

  allTimeBusyTable,
  allTimeBusyCount,

  allTimeBestRevenueTable,
  allTimeBestRevenue,
  // 👆 BURAYA KADAR

onlineCount,
offlineCount,

onlineMasalar,
offlineMasalar,

freeCount,

});

      });
    });
  });

});

  }
);

    }
  );

});
app.get("/admin/session-history", (req, res) => {
  setNoStore(res);
  db.all(
    `
SELECT 
  id,
  masa,
  start_time,
  end_time,
  minutes,
  fee,
  adjustment,
  close_reason,
  COALESCE((
    SELECT SUM(p.total)
    FROM product_sales p
    WHERE p.masa=session_history.masa
      AND p.session_start=session_history.start_time
      AND p.sale_type='TABLE'
      AND p.voided=0
  ),0) AS product_total
FROM session_history
WHERE fee > 0
    ORDER BY id DESC
    LIMIT 100
    `,
    (err, rows) => {
      if (err) {
        logErr("session-history", err);
        return res.json({ ok: false });
      }
      res.json({ ok: true, list: rows || [] });
    }
  );
});

app.post("/admin/session-history/clear", (req, res) => {
  setNoStore(res);

  db.run("DELETE FROM session_history", (err) => {
    if (err) {
      logErr("/admin/session-history/clear", err);
      return res.json({ ok: false, error: String(err) });
    }

    return res.json({
      ok: true,
      msg: "Session geçmişi temizlendi"
    });
  });
});

app.post("/admin/session-history/delete", (req, res) => {
  setNoStore(res);

  const id = parseInt((req.body || {}).id, 10);

  if (!id) {
    return res.json({ ok: false, error: "Geçersiz id" });
  }

  db.run("DELETE FROM session_history WHERE id=?", [id], function (err) {
    if (err) {
      logErr("/admin/session-history/delete", err);
      return res.json({ ok: false, error: String(err) });
    }

    if ((this.changes || 0) === 0) {
      return res.json({ ok: false, error: "Kayıt bulunamadı" });
    }

    return res.json({
      ok: true,
      msg: "Session kaydı silindi"
    });
  });
});

app.get("/api/client-config", (req, res) => {
  setNoStore(res);

  const ip = getReqIp(req);

  const found = Object.entries(MASA_IPS).find(
    ([, masaIp]) => masaIp === ip
  );

  if (!found) {
    return res.json({
      ok: false,
      error: `Bu IP için masa tanımı yok: ${ip}`
    });
  }

  const masa = parseInt(found[0], 10);

  return res.json({
    ok: true,
    masa,
    token: MASA_TOKENS[masa],
    ip
  });
});
app.post("/api/ping", (req, res) => {
diagnostics.lastPing = Date.now();
  try {
    setNoStore(res);

    const masa = getMasaFromRequest(req);

    if (!masa) {
      return res.json({ ok: false, error: "Geçersiz masa, token veya IP" });
    }

    isBlockedMasa(masa, (blocked, untilTime) => {
      if (blocked) {
        return res.json({
          ok: false,
          error: "Masa geçici bloklu",
          blocked: true,
          until: untilTime
        });
      }

recordTokenHit(masa, req);

const now = Date.now();

const netSpeed =
  Number(req.body?.netSpeed || 0);

const prevPing = masaPingStats[masa]?.last || 0;


// 2 saniyeden sık ping gelirse ignore et
if (prevPing && now - prevPing < 2000) {
  return res.json({
    ok: true,
    masa,
    throttled: true
  });
}

if (isLocked(masa, now)) {
  return res.json({ ok: true, masa, locked: true });
}
if (masaCloseLocks[masa] && Date.now() < masaCloseLocks[masa]) {
    return res.json({
        ok: false,
        closing: true
    });
}

// Ping bekleme ekranında da gelir. EveryCafe masa henüz Windows'a geçmemiş
// diyorsa normal KafePin oturumu ve ücret başlatılmaz.
isEveryCafeClientWaiting(masa, (waitingErr, waiting) => {
  if (waitingErr) {
    logErr("/api/ping EveryCafe bekleme kontrolü", waitingErr);
  }
  if (!waitingErr && waiting) {
    return setEveryCafeWaitingMasa(masa, now, (setErr) => {
      if (setErr) return res.status(500).json({ ok: false, error: "Bekleme durumu kaydedilemedi" });
      return res.json({ ok: true, masa, waiting: true });
    });
  }

ensureSessionStarted(masa, now, (err, sessionResult) => {
  if (err) {
    return res.status(500).json({ ok: false, error: "Session başlatılamadı" });
  }

  // EveryCafe kapandıktan sonra istemci birkaç ping daha gönderebilir.
  // Bu pingler yalnızca ağ yaşam belirtisidir; yeni KafePin oturumu,
  // gelir veya admin panelinde sahte "Bağlı" masa yaratmaz.
  if (sessionResult && sessionResult.sourceManaged) {
    // Ücretsiz/EveryCafe kaynaklı masa ücret oturumu oluşturmaz; fakat
    // istemcinin gerçek ping ve ağ hızı bilgisi monitörde aynen görünür.
    aktifMasalar[masa] = now;
    if (!masaPingStats[masa]) {
      masaPingStats[masa] = { last: 0, avg: PING_INTERVAL_MS, lastSeen: 0, netSpeed: 0, connectedLogged: false };
    }
    const sourcePrev = masaPingStats[masa].last || 0;
    if (sourcePrev > 0) {
      const diff = now - sourcePrev;
      masaPingStats[masa].avg = masaPingStats[masa].avg > 0
        ? (masaPingStats[masa].avg * 0.7 + diff * 0.3)
        : diff;
    } else {
      masaPingStats[masa].avg = PING_INTERVAL_MS;
    }
    masaPingStats[masa].last = now;
    masaPingStats[masa].lastSeen = now;
    masaPingStats[masa].netSpeed = Number(netSpeed || 0);
    return res.json({ ok: true, masa, sourceManaged: true });
  }

  // 🔥 Ping geldiyse masa aktiftir
  aktifMasalar[masa] = now;

  if (masaCloseLocks[masa] && now < masaCloseLocks[masa]) {
    return res.json({
      ok: false,
      locked: true
    });
  }

  if (!masaPingStats[masa]) {
    masaPingStats[masa] = {
      last: now,
      avg: PING_INTERVAL_MS,
      lastSeen: now,
      netSpeed: 0,
      connectedLogged: false
    };
  }

  const prev = masaPingStats[masa].last;

  if (prev > 0) {
    const diff = now - prev;

    masaPingStats[masa].avg =
      masaPingStats[masa].avg > 0
        ? (masaPingStats[masa].avg * 0.7 + diff * 0.3)
        : diff;
  } else {
    // İlk pingte önceki zaman yoktur. Date.now() - 0 hesabı çok büyük,
    // sahte bir ping değeri üretirdi; ilk örneği başlangıç olarak kabul et.
    masaPingStats[masa].avg = PING_INTERVAL_MS;
  }

const oldSpeed = Number(masaPingStats[masa].netSpeed || 0);
const newSpeed = Number(netSpeed || 0);

masaPingStats[masa].last = now;
masaPingStats[masa].lastSeen = now;
masaPingStats[masa].netSpeed = newSpeed;

if (!masaPingStats[masa].connectedLogged) {
  masaPingStats[masa].connectedLogged = true;

  addLiveLog(
    "connect",
    `🟢 Masa ${masa} bağlandı (${newSpeed} Mbps)`
  );
}

if (oldSpeed === 1000 && newSpeed === 100) {
  addLiveLog(
    "speed_100",
    `🐢 Masa ${masa} 100 Mbps'e düştü`
  );
}

if (oldSpeed === 100 && newSpeed === 1000) {
  addLiveLog(
    "speed_1000",
    `🚀 Masa ${masa} tekrar 1000 Mbps oldu`
  );
}

  return res.json({
    ok: true,
    masa,
    sessionStarted: true,
    startTime: now
  });

}); // ensureSessionStarted
}); // isEveryCafeClientWaiting
}); // isBlockedMasa


} catch (err) {
    logErr("/api/ping", err);
    return res.status(500).json({ ok: false });
  }
});
app.post("/api/status", (req, res) => {
console.log("STATUS BODY:", req.body);
  try {
    setNoStore(res);

    const masa = getMasaFromRequest(req);
console.log("STATUS MASA:", masa);

    if (!masa) {
      return res.json({ ok: false, error: "Geçersiz masa, token veya IP", kalan: 0 });
    }

    isBlockedMasa(masa, (blocked, untilTime) => {
      if (blocked) {
        return res.json({
          ok: false,
          error: "Masa geçici bloklu",
          kalan: 0,
          blocked: true,
          until: untilTime
        });
      }

recordTokenHit(masa, req);

const now = Date.now();

if (masaCloseLocks[masa] && now < masaCloseLocks[masa]) {
  return res.json({
    ok: true,
    masa,
    kalan: getSpinSureMs(),
    locked: true
  });
}

if (everyCafeWaitingMasalar.has(masa)) {
  return res.json({ ok: true, masa, kalan: 0, waiting: true });
}
   

const locked = isLocked(masa, now);

      const continueStatus = () => {
        db.get("SELECT * FROM masalar WHERE masa=?", [masa], (err, row) => {
          if (err) {
            logErr("/api/status SELECT masalar", err);
            return res.status(500).json({ ok: false, error: "DB status hata", kalan: 0 });
          }

          const SURE = getSpinSureMs();

          if (locked) {
            return res.json({ ok: true, masa, kalan: SURE, locked: true });
          }

          if (!row) {
  db.run(
    "INSERT INTO masalar (masa,start_time) VALUES (?,?) ON CONFLICT(masa) DO NOTHING",
    [masa, now],
    (e2) => {
      if (e2) {
        logErr("/api/status INSERT masalar", e2);
        return res.status(500).json({ ok: false, error: "DB insert hata", kalan: 0 });
      }
      return res.json({ ok: true, masa, kalan: SURE });
    }
  );
  return;
}

          const kalan = getSpinReadyAt(masa, row.start_time) - now;
          return res.json({ ok: true, masa, kalan: kalan > 0 ? kalan : 0 });
        });
      };

      if (locked) return continueStatus();
      ensureSessionStarted(masa, now, (eStart) => {
        if (eStart) {
          logErr("/api/status ensureSessionStarted", eStart);
        }
        continueStatus();
      });
    });
  } catch (err) {
    logErr("/api/status", err);
    return res.status(500).json({ ok: false, error: "Status hata", kalan: 0 });
  }
});
app.post("/admin/set-start-time", (req, res) => {

    const { masa, saat } = req.body;

    if (!masa || !saat)
        return res.json({ ok:false, error:"Eksik bilgi" });

    const p = saat.split(":");

    if (p.length < 2)
        return res.json({ ok:false, error:"Saat hatalı" });

    db.get(
        "SELECT * FROM sessions WHERE masa=? AND end_time=0",
        [masa],
        (err,row)=>{

            if(err || !row)
                return res.json({ok:false,error:"Aktif oturum bulunamadı"});

            const d=new Date();

            d.setHours(
                Number(p[0]),
                Number(p[1]),
                Number(p[2]||0),
                0
            );

            // Gün değişmiş olmasın
            if(d.getTime()>Date.now())
                d.setDate(d.getDate()-1);

            const yeniStart=d.getTime();

            db.run(
                "UPDATE sessions SET start_time=? WHERE masa=? AND end_time=0",
                [yeniStart,masa],
                err2=>{

                    if(err2)
                        return res.json({ok:false,error:err2.message});

                    res.json({ok:true});

                });

        });

});
app.get("/api/rewards", (req, res) => {
  setNoStore(res);
  db.all("SELECT name, weight, active FROM rewards WHERE active=1 ORDER BY id ASC", (err, rows) => {
    if (err) {
      logErr("/api/rewards", err);
      return res.status(500).json([]);
    }
    res.json(rows || []);
  });
});

app.post("/api/spin", (req, res) => {
  try {
    setNoStore(res);

    const masa = getMasaFromRequest(req);

    if (!masa) {
      return res.json({ error: "Geçersiz masa, token veya IP" });
    }

    isBlockedMasa(masa, (blocked, untilTime) => {
      if (blocked) {
        return res.json({
          error: "Masa geçici bloklu",
          blocked: true,
          until: untilTime
        });
      }

      recordTokenHit(masa, req);

      const now = Date.now();
      aktifMasalar[masa] = now;

      if (isLocked(masa, now)) {
        return res.json({ error: "Masa hazırlanıyor" });
      }

      ensureSessionStarted(masa, now, (eStart) => {
        if (eStart) {
          return res.status(500).json({ error: "Session başlatılamadı" });
        }

        db.serialize(() => {
         
db.run("BEGIN IMMEDIATE TRANSACTION", (e0) => {
            if (e0) {
              logErr("/api/spin BEGIN", e0);
              return res.status(500).json({ error: "DB hata (begin)" });
            }

            db.get("SELECT * FROM masalar WHERE masa=?", [masa], (errMasa, masaRow) => {
              if (errMasa) {
                logErr("/api/spin SELECT masalar", errMasa);
                return db.run("ROLLBACK", () => {
                  return res.status(500).json({ error: "DB hata (masa kontrol)" });
                });
              }

              const SURE = getSpinSureMs();

              if (!masaRow) {
                return db.run("ROLLBACK", () => {
                  return res.json({ error: "Henüz süre başlamadı" });
                });
              }

              if (now < getSpinReadyAt(masa, masaRow.start_time)) {
                return db.run("ROLLBACK", () => {
                  return res.json({ error: "Henüz hakkınız yok" });
                });
              }

              db.get(
                `SELECT COUNT(*) AS cnt
                 FROM spins
                 WHERE masa=?
                   AND time>=COALESCE(
                     (SELECT start_time FROM sessions
                      WHERE masa=? AND COALESCE(end_time,0)=0
                      LIMIT 1), 0)`,
                [masa, masa],
                (errCnt, rowCnt) => {
                  if (errCnt) {
                    logErr("/api/spin COUNT spins", errCnt);
                    return db.run("ROLLBACK", () => {
                      return res.status(500).json({ error: "DB hata (hak kontrol)" });
                    });
                  }

                  const usedThisSession = rowCnt && rowCnt.cnt ? rowCnt.cnt : 0;

                  if (usedThisSession >= GUNLUK_SPIN_LIMIT) {
                    return db.run("ROLLBACK", () => {
                      return res.json({ error: `Bugün hakkınız bitti (${GUNLUK_SPIN_LIMIT})` });
                    });
                  }

                  db.all("SELECT * FROM rewards WHERE active=1", (errRewards, rewardRows) => {
                    if (errRewards) {
                      logErr("/api/spin SELECT rewards", errRewards);
                      return db.run("ROLLBACK", () => {
                        return res.status(500).json({ error: "DB hata (ödül liste)" });
                      });
                    }

                    if (!rewardRows || rewardRows.length === 0) {
                      return db.run("ROLLBACK", () => {
                        return res.json({ error: "Ödül yok" });
                      });
                    }

                    db.get(
                      "SELECT value FROM settings WHERE key='global_spin_count'",
                      (errGsc, gscRow) => {
                        if (errGsc) {
                          logErr("/api/spin SELECT global_spin_count", errGsc);
                          return db.run("ROLLBACK", () => {
                            return res.status(500).json({ error: "DB hata (global_spin_count read)" });
                          });
                        }

                        let dbGlobalSpinCount = 0;
                        if (gscRow) {
                          const parsed = parseInt(gscRow.value, 10);
                          dbGlobalSpinCount = !isNaN(parsed) && parsed >= 0 ? parsed : 0;
                        }

                        let selected = weightedRandom(rewardRows);

                        const isVipMasa = VIP_MASALAR.includes(masa);
                        const hedef = isVipMasa ? BUYUK_ODUL_HEDEF_VIP : BUYUK_ODUL_HEDEF;

                        let nextGlobalSpinCount = dbGlobalSpinCount;

                        if (nextGlobalSpinCount < hedef) {
                          if ((selected.name || "").toLowerCase().includes("60")) {
                            selected =
                              rewardRows.find(
                                (r) => !String(r.name || "").toLowerCase().includes("60")
                              ) || rewardRows[0];
                          }
                        } else {
                          nextGlobalSpinCount = 0;
                        }

nextGlobalSpinCount++;

latestRewardMap[masa] = selected.name;

db.run(
                          "INSERT INTO spins (masa,reward,time) VALUES (?,?,?)",
                          [masa, selected.name, Date.now()],
                          (e1) => {
                            if (e1) {
                              logErr("/api/spin INSERT spins", e1);
                              return db.run("ROLLBACK", () => {
                                return res.status(500).json({ error: "DB hata (spins)" });
                              });
                            }

                            db.run(
                              "INSERT INTO spins_log (masa,reward,time) VALUES (?,?,?)",
                              [masa, selected.name, Date.now()],
                              (e2) => {
                                if (e2) {
                                  logErr("/api/spin INSERT spins_log", e2);
                                  return db.run("ROLLBACK", () => {
                                    return res.status(500).json({ error: "DB hata (spins_log)" });
                                  });
                                }

                                db.run(
                                  "UPDATE masalar SET start_time=? WHERE masa=?",
                                  [Date.now(), masa],
                                  (e3) => {
                                    if (e3) {
                                      logErr("/api/spin UPDATE masalar", e3);
                                      return db.run("ROLLBACK", () => {
                                        return res.status(500).json({ error: "DB hata (masalar)" });
                                      });
                                    }

                                    db.run(
                                      "INSERT INTO settings(key,value) VALUES('global_spin_count',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                                      [String(nextGlobalSpinCount)],
                                      (e4) => {
                                        if (e4) {
                                          logErr("/api/spin UPDATE global_spin_count", e4);
                                          return db.run("ROLLBACK", () => {
                                            return res.status(500).json({ error: "DB hata (global_spin_count write)" });
                                          });
                                        }

                                        db.run("COMMIT", (e5) => {
                                          if (e5) {
                                            logErr("/api/spin COMMIT", e5);
                                            return db.run("ROLLBACK", () => {
                                              return res.status(500).json({ error: "DB hata (commit)" });
                                            });
                                          }

                                          globalSpinCount = nextGlobalSpinCount;

                                          logInfo("SPIN_OK", {
                                            masa,
                                            reward: selected.name,
                                            time: Date.now(),
                                            nextGlobalSpinCount
                                          });
addLiveLog(
  "reward",
  `🎁 Masa ${masa} "${selected.name}" ödülünü kazandı`
);

                                          if (isBigReward(selected.name)) {
                                            sendBigRewardTelegram(masa, selected.name, Date.now());
                                          }

                                          return res.json({
                                            ok: true,
                                            reward: selected.name
                                          });
                                        });
                                      }
                                    );
                                  }
                                );
                              }
                            );
                          }
                        );
                      }
                    );
                  });
                }
              );
            });
          });
        });
      });
    });
  } catch (err) {
    logErr("/api/spin", err);
    return res.status(500).json({ error: "Spin genel hata" });
  }
});

app.get("/api/masalar", (req, res) => {
  setNoStore(res);

  const now = Date.now();

  const SURE = getSpinSureMs();

  db.all("SELECT * FROM masalar", (err, rows) => {
    if (err) {
      logErr("/api/masalar select masalar", err);
      return res.status(500).json([]);
    }

    const map = {};
    (rows || []).forEach((r) => (map[r.masa] = r));

    let done = 0;

    function stepDone() {
      done++;
      if (done !== MASA_SAYISI) return;

      const liste = [];

      for (let masa = 1; masa <= MASA_SAYISI; masa++) {
        const recentlyClosed = everyCafeRecentlyClosedMasalar.get(masa);
        // EveryCafe kapandığını kesin olarak bildirdikten sonra istemci kısa süre
        // "beklemede" pingleri gönderebilir. Bu pingleri yeni masa gibi göstermeyiz;
        // ancak EveryCafe gerçek bir yeni oturum gönderince aşağıdaki aktif senkron
        // bu kaydı siler.
        if (recentlyClosed) {
          liste.push({
            masa,
            online: false,
            durum: "kapali",
            kalan: 0,
            closedByEveryCafe: true,
            closedAt: Number(recentlyClosed.closedAt) || 0,
            freeClosed: recentlyClosed.free === true,
            everyCafeTimed: recentlyClosed.timed === true,
            closedTotal: Math.max(0, Number(recentlyClosed.total) || 0),
            closedComputerTotal: Math.max(0, Number(recentlyClosed.computerTotal) || 0),
            closedProductTotal: Math.max(0, Number(recentlyClosed.productTotal) || 0)
          });
          continue;
        }
        const everyCafeWaiting = everyCafeWaitingMasalar.get(masa);
        if (everyCafeWaiting) {
          liste.push({
            masa,
            online: true,
            durum: "everycafe_beklemede",
            waitingOnly: true,
            kalan: 0,
            netSpeed: 0,
            realFee: 0,
            everyCafeTimed: false,
            everyCafeGiftMinutes: 0
          });
          continue;
        }
        const lastSeen = aktifMasalar[masa] || 0;
        const online = !isActuallyOffline(masa, lastSeen, now);
        const everyCafeType = String(everyCafeSessionTypes.get(masa) || "");
        const everyCafeTimed = isEveryCafeTimedMasa(masa) || everyCafeType.toLocaleLowerCase("tr-TR").includes("süreli");
        const everyCafeGift = getEveryCafeGiftMinutes(masa);

        if (!online) {
          liste.push({
  masa,
  online: false,
  durum: "kapali",
  kalan: 0,
  netSpeed: Number(masaPingStats?.[masa]?.netSpeed || 0)
});
          continue;
        }

        const row = map[masa];
if (!row) {
  liste.push({
    masa,
    online: true,
    durum: "bagli",
    kalan: 0,
    netSpeed: Number(masaPingStats?.[masa]?.netSpeed || 0),
    everyCafeTimed,
    everyCafeGiftMinutes: everyCafeGift
  });
  continue;
}

        let kalan = getSpinReadyAt(masa, row.start_time) - now;
        if (kalan < 0) kalan = 0;
const scheduledEnd = isEveryCafeTimedMasa(masa) ? getEveryCafeScheduledEnd(masa) : 0;
const realFee = isFreeMasa(masa) ? 0 : feeAtTime(
  masa,
  row.start_time,
  // Süreli EveryCafe oturumunda tam bitiş saniyesi ilk ek ücret basamağı
  // değildir. Örn. 60 dk normal=50 ₺, VIP=70 ₺ olarak kalır.
  scheduledEnd > Number(row.start_time) ? Math.min(now, scheduledEnd - 1) : now
);
if (kalan === 0)
  liste.push({
    masa,
    online: true,
    durum: "hazir",
    kalan: 0,
    netSpeed: masaPingStats[masa]?.netSpeed || 0,
    realFee,
    everyCafeTimed,
    everyCafeScheduledEnd: scheduledEnd,
    everyCafeGiftMinutes: everyCafeGift
  });

else liste.push({
  masa,
  online: true,
  durum: "bekliyor",
  kalan,
  netSpeed: masaPingStats[masa]?.netSpeed || 0,
  realFee,
  everyCafeTimed,
  everyCafeScheduledEnd: scheduledEnd,
  everyCafeGiftMinutes: everyCafeGift
});
      }

      res.json(liste);
    }

    for (let masa = 1; masa <= MASA_SAYISI; masa++) {
      closeSessionIfOffline(masa, now, () => {
        autoResetIfStale(masa, now, stepDone);
      });
    }
  });
});

app.get("/monitor/last", (req, res) => {
  setNoStore(res);
  const todayStart = dayStartTs(Date.now());
  db.get("SELECT * FROM spins_log WHERE time>=? ORDER BY id DESC LIMIT 1", [todayStart], (err, row) => {
    if (err) {
      logErr("/monitor/last", err);
      return res.json({});
    }
    res.json(row || {});
  });
});

app.get("/monitor/lucky", (req, res) => {
  setNoStore(res);
  const todayStart = dayStartTs(Date.now());

db.all(
  `
  SELECT masa, reward
  FROM spins_log
  WHERE time >= ?
  `,
  [todayStart],
    (err, rows) => {
      if (err) {
        logErr("/monitor/lucky", err);
        return res.json({ masa: "-", adet: 0 });
      }

      const filtered = (rows || []).filter((r) => {
        const reward = String(r.reward || "").trim().toLocaleLowerCase("tr-TR");
        return !BOS_ODULLER.includes(reward);
      });

      if (!filtered.length) {
        return res.json({ masa: "-", adet: 0 });
      }

      const count = {};
      filtered.forEach((r) => {
        count[r.masa] = (count[r.masa] || 0) + 1;
      });

      const masa = Object.keys(count).sort((a, b) => {
        if (count[b] !== count[a]) return count[b] - count[a];
        return Number(a) - Number(b);
      })[0];

      return res.json({ masa, adet: count[masa] || 0 });
    }
  );
});

app.get("/monitor/list", (req, res) => {
  setNoStore(res);
  const todayStart = dayStartTs(Date.now());
  db.all("SELECT * FROM spins_log WHERE time>=? ORDER BY id DESC LIMIT 200", [todayStart], (err, rows) => {
    if (err) {
      logErr("/monitor/list", err);
      return res.json([]);
    }
    res.json(rows || []);
  });
});

app.get("/admin/list", (req, res) => {
  setNoStore(res);

  const todayStart = dayStartTs(Date.now());

  db.all(
    "SELECT * FROM spins WHERE time>=? ORDER BY id DESC LIMIT 200",
    [todayStart],
    (err, rows) => {

      if (err) {
        logErr("/admin/list", err);
        return res.json([]);
      }

      res.json(rows || []);
    }
  );
});
function approveRewardById(id, options, cb) {
  const opts = options || {};
  const spinId = parseInt(id, 10);

  if (!spinId) {
    return cb(new Error("Geçersiz id"));
  }

  db.get("SELECT * FROM spins WHERE id=?", [spinId], (selectErr, row) => {
    if (selectErr) {
      logErr("approveRewardById select spins", selectErr);
      return cb(selectErr);
    }

    if (!row) {
      return cb(new Error("Ödül kaydı bulunamadı"));
    }

    if (row.used === 1) {
      return cb(null, { ok: true, alreadyUsed: true, row });
    }

    const rewardInfo = getRewardCostAndType(
      row.masa,
      row.reward,
      row.time || Date.now()
    );
    const now = Math.max(1, Number(opts.approvalTime) || Date.now());
    const dk = dayKey(now);

    db.serialize(() => {
      db.run("BEGIN IMMEDIATE TRANSACTION", (beginErr) => {
        if (beginErr) {
          logErr("approveRewardById begin", beginErr);
          return cb(new Error("DB hata (begin): " + String(beginErr)));
        }

        db.run(
          "UPDATE spins SET used=1 WHERE id=? AND used=0",
          [spinId],
          function (spinErr) {
            if (spinErr) {
              logErr("approveRewardById update spins", spinErr);
              return db.run("ROLLBACK", () => {
                cb(new Error("DB hata (spins): " + String(spinErr)));
              });
            }

            if ((this.changes || 0) === 0) {
              return db.run("ROLLBACK", () => {
                cb(null, { ok: true, alreadyUsed: true, row });
              });
            }

            db.run(
              `
              UPDATE spins_log
              SET used=1
              WHERE id = (
                SELECT id
                FROM spins_log
                WHERE masa=?
                  AND reward=?
                  AND used=0
                ORDER BY id DESC
                LIMIT 1
              )
              `,
              [row.masa, row.reward],
              (logErrValue) => {
                if (logErrValue) {
                  logErr("approveRewardById update spins_log", logErrValue);
                  return db.run("ROLLBACK", () => {
                    cb(new Error("DB hata (spins_log): " + String(logErrValue)));
                  });
                }

                const note =
                  rewardInfo.kind === "time"
                    ? `Masa ${row.masa} süre ödülü kullanıldı: ${row.reward}`
                    : `Masa ${row.masa} ürün ödülü onaylandı: ${row.reward}`;

                const commitApproval = () => {
                  db.run("COMMIT", (commitErr) => {
                    if (commitErr) {
                      logErr("approveRewardById commit", commitErr);
                      return db.run("ROLLBACK", () => {
                        cb(new Error("DB hata (commit): " + String(commitErr)));
                      });
                    }

                    if (rewardInfo.amount > 0) {
                      latestRewardMap[row.masa] =
                        rewardInfo.amount + " ₺ " + note;
                    }

                    const logText = opts.automatic
                      ? `🤖 Masa ${row.masa} "${row.reward}" ödülü ${opts.reason || "masa kapanışı"} sırasında otomatik onaylandı`
                      : `✅ Masa ${row.masa} "${row.reward}" ödülü onaylandı`;

                    addLiveLog(
                      opts.automatic ? "reward_auto_used" : "reward_used",
                      logText
                    );

                    return cb(null, {
                      ok: true,
                      reward: row.reward,
                      kind: rewardInfo.kind,
                      costApplied: rewardInfo.amount,
                      row
                    });
                  });
                };

                if (rewardInfo.amount <= 0) {
                  return commitApproval();
                }

                const adjustmentKind =
                  rewardInfo.kind === "time"
                    ? "SPIN_TIME_COST"
                    : "SPIN_ITEM_COST";

                db.run(
                  "INSERT INTO real_adjustments(time, day_key, masa, amount, kind, note, session_start) VALUES(?,?,?,?,?,?,?)",
                  [
                    now,
                    dk,
                    row.masa,
                    -rewardInfo.amount,
                    adjustmentKind,
                    note,
                    0
                  ],
                  (adjustmentErr) => {
                    if (adjustmentErr) {
                      logErr(
                        "approveRewardById insert real_adjustments",
                        adjustmentErr
                      );
                      return db.run("ROLLBACK", () => {
                        cb(
                          new Error(
                            "DB hata (real_adjustments): " +
                              String(adjustmentErr)
                          )
                        );
                      });
                    }

                    return commitApproval();
                  }
                );
              }
            );
          }
        );
      });
    });
  });
}

function autoApprovePendingRewardsForMasa(masa, reason, cb) {
  const todayStart = dayStartTs(Date.now());

  db.all(
    `
    SELECT id
    FROM spins
    WHERE masa=?
      AND used=0
      AND time>=?
    ORDER BY id ASC
    `,
    [masa, todayStart],
    (listErr, rows) => {
      if (listErr) {
        logErr("autoApprovePendingRewardsForMasa list", listErr);
        return cb(listErr);
      }

      const pending = rows || [];
      const approved = [];

      const approveNext = (index) => {
        if (index >= pending.length) {
          return cb(null, approved);
        }

        approveRewardById(
          pending[index].id,
          { automatic: true, reason },
          (approveErr, result) => {
            if (approveErr) return cb(approveErr);
            if (result && !result.alreadyUsed) approved.push(result);
            return approveNext(index + 1);
          }
        );
      };

      return approveNext(0);
    }
  );
}

// EveryCafe kapanışı doğrulandıysa o oturuma ait bekleyen çark ödülleri de
// kapanışın parçası olarak onaylanır. Ödül maliyeti kapanış zamanına yazılır.
function autoApproveEveryCafeClosedSessionRewards(masa, startTime, endTime, cb = () => {}) {
  db.all(
    `SELECT id FROM spins
     WHERE masa=? AND used=0 AND time>=? AND time<=?
     ORDER BY id ASC`,
    [masa, startTime, endTime],
    (err, rows) => {
      if (err) return cb(err);
      const ids = (rows || []).map((row) => Number(row.id)).filter(Boolean);
      const next = (index) => {
        if (index >= ids.length) return cb(null, { approved: ids.length });
        approveRewardById(
          ids[index],
          { automatic: true, reason: "EveryCafe kapanışı", approvalTime: endTime },
          (approveErr) => approveErr ? cb(approveErr) : next(index + 1)
        );
      };
      next(0);
    }
  );
}

// Önceki sürümde kapanmış EveryCafe oturumlarında kalmış bekleyen ödülleri de
// güvenli biçimde bir kez tamamlar. Başka kapanış türlerine hiç dokunmaz.
function reconcileEveryCafeClosedRewardApprovals(cb = () => {}) {
  db.all(
    `SELECT DISTINCT h.masa,h.start_time,h.end_time
     FROM session_history h
     JOIN spins s ON s.masa=h.masa AND s.time>=h.start_time AND s.time<=h.end_time
     WHERE h.close_reason='EVERYCAFE' AND s.used=0
     ORDER BY h.end_time ASC LIMIT 100`,
    (err, rows) => {
      if (err) return cb(err);
      let approved = 0;
      const next = (index) => {
        if (index >= (rows || []).length) return cb(null, { approved });
        const row = rows[index];
        autoApproveEveryCafeClosedSessionRewards(row.masa, row.start_time, row.end_time, (approveErr, result) => {
          if (approveErr) return cb(approveErr);
          approved += Number(result && result.approved) || 0;
          next(index + 1);
        });
      };
      next(0);
    }
  );
}

app.post("/admin/use", (req, res) => {
  setNoStore(res);

  const id = parseInt((req.body || {}).id, 10);

  approveRewardById(id, { automatic: false }, (err, result) => {
    if (err) {
      return res.json({ ok: false, error: String(err.message || err) });
    }

    return res.json(result);
  });
});

app.post("/admin/fee-adjust", (req, res) => {
  setNoStore(res);

  const masa = parseInt((req.body || {}).masa, 10);
  const amount = parseFloat((req.body || {}).amount);
  const now = Date.now();

  if (!masa || masa < 1 || masa > MASA_SAYISI) {
    return res.json({ ok: false, error: "Geçersiz masa" });
  }

if (!Number.isFinite(amount)) {
  return res.json({ ok: false, error: "Geçersiz sayı" });
}

  if (isFreeMasa(masa)) {
    return res.json({ ok: false, error: "FREE masaya düzeltme uygulanmaz" });
  }

  const dk = dayKey(now);

  db.get("SELECT * FROM sessions WHERE masa=?", [masa], (err, s) => {
    if (err) return res.json({ ok: false, error: String(err) });
    if (!s) return res.json({ ok: false, error: "Aktif/geçerli session bulunamadı" });

    const note = `Masa ${masa} manuel ücret düzeltme ${amount > 0 ? "+" : ""}${amount} TL`;

db.run(
  "INSERT INTO real_adjustments(time, day_key, masa, amount, kind, note, session_start) VALUES(?,?,?,?,?,?,?)",
  [now, dk, masa, amount, "MANUAL_FEE_ADJUST", note, s.start_time || 0],
function (e2) {

  if (e2) {
    return res.json({ ok: false, error: String(e2) });
  }

  addLiveLog(
    "fee_adjust",
    `💰 Masa ${masa} manuel ücret düzeltildi (${amount > 0 ? "+" : ""}${amount} TL)`
  );

  return res.json({ ok: true });

}
    );

  }
);
  });


app.get("/admin/rewards", (req, res) => {
  setNoStore(res);
  db.all("SELECT * FROM rewards ORDER BY id ASC", (err, rows) => {
    if (err) {
      logErr("/admin/rewards", err);
      return res.json([]);
    }
    res.json(rows || []);
  });
});

app.post("/admin/reward/add", (req, res) => {
  setNoStore(res);

  const name = String((req.body || {}).name || "").trim();
  const weight = parseInt((req.body || {}).weight, 10);
  const active = (req.body || {}).active === 0 || (req.body || {}).active === false ? 0 : 1;

  if (!name) return res.json({ ok: false, error: "Ödül adı boş" });
  if (isNaN(weight) || weight < 1 || weight > 100000) return res.json({ ok: false, error: "Geçersiz ağırlık" });

  db.run("INSERT INTO rewards (name, weight, active) VALUES (?,?,?)", [name, weight, active], function (err) {
    if (err) return res.json({ ok: false, error: String(err) });
    return res.json({ ok: true, id: this.lastID });
  });
});

app.post("/admin/reward/delete", (req, res) => {
  setNoStore(res);

  const id = parseInt((req.body || {}).id, 10);
  if (!id) return res.json({ ok: false, error: "Geçersiz id" });

  db.run("DELETE FROM rewards WHERE id=?", [id], (err) => {
    if (err) return res.json({ ok: false, error: String(err) });
    return res.json({ ok: true });
  });
});

app.post("/admin/reward/update", (req, res) => {
  setNoStore(res);

  const id = parseInt((req.body || {}).id, 10);
  const name = String((req.body || {}).name || "").trim();
  const weight = parseInt((req.body || {}).weight, 10);
  const active = (req.body || {}).active === 0 || (req.body || {}).active === false ? 0 : 1;

  if (!id) return res.json({ ok: false, error: "Geçersiz id" });
  if (!name) return res.json({ ok: false, error: "Ödül adı boş" });
  if (isNaN(weight) || weight < 1 || weight > 100000) return res.json({ ok: false, error: "Geçersiz ağırlık" });

  db.run("UPDATE rewards SET name=?, weight=?, active=? WHERE id=?", [name, weight, active, id], (err) => {
    if (err) return res.json({ ok: false, error: String(err) });
    return res.json({ ok: true });
  });
});

app.get("/admin/today-spins", (req, res) => {
  setNoStore(res);
  const todayStart = dayStartTs(Date.now());

  // Hak masa-günlük değil, aktif müşteri oturumunundur. Eski müşterinin
  // spinleri günlük istatistikte korunur; ancak yeni oturum 0/5 ile başlar.
  db.all(
    `SELECT s.masa, s.start_time, COUNT(sp.id) AS cnt
     FROM sessions s
     LEFT JOIN spins sp ON sp.masa=s.masa AND sp.time>=s.start_time
     WHERE COALESCE(s.end_time,0)=0
     GROUP BY s.masa,s.start_time`,
    [],
    (err, rows) => {
    if (err) {
      logErr("/admin/today-spins", err);
      return res.json({ start: todayStart, limit: GUNLUK_SPIN_LIMIT, list: [] });
    }

    const map = {};
    (rows || []).forEach((r) => {
      map[r.masa] = r.cnt;
    });

    const out = [];
    // Kapalı masalar listelenmez. Yeni müşteri açıldığında aktif session
    // oluşur ve önceki müşterinin haklarından tamamen bağımsız 5 hak gelir.
    for (const row of rows || []) {
      const masa = Number(row.masa);
      const used = map[masa] || 0;
      out.push({
        masa,
        used,
        limit: GUNLUK_SPIN_LIMIT,
        left: Math.max(GUNLUK_SPIN_LIMIT - used, 0),
        isVip: VIP_MASALAR.includes(masa) ? 1 : 0
      });
    }

    res.json({ start: todayStart, limit: GUNLUK_SPIN_LIMIT, list: out });
  });
});

app.get("/admin/today-given-rewards", (req, res) => {
  setNoStore(res);

  const todayStart = dayStartTs(Date.now());

  db.all(
    `
    SELECT reward, COUNT(*) as adet
    FROM spins_log
    WHERE time >= ?
      AND used = 1
    GROUP BY reward
    ORDER BY adet DESC, reward ASC
    `,
    [todayStart],
    (err, rows) => {
      if (err) return res.json({ ok: false, error: String(err), list: [] });

      const list = (rows || []).filter((x) => {
        const r = String(x.reward || "").trim().toLocaleLowerCase("tr-TR");
        return !BOS_ODULLER.includes(r);
      });

      return res.json({ ok: true, start: todayStart, list });
    }
  );
});

app.get("/admin/today-empty-rewards", (req, res) => {
  setNoStore(res);

  const todayStart = dayStartTs(Date.now());

  db.all(
    `
    SELECT reward, COUNT(*) as adet
    FROM spins_log
    WHERE time >= ?
    GROUP BY reward
    ORDER BY adet DESC, reward ASC
    `,
    [todayStart],
    (err, rows) => {
      if (err) return res.json({ ok: false, error: String(err), list: [] });

      const list = (rows || []).filter((x) => {
        const r = String(x.reward || "").trim().toLocaleLowerCase("tr-TR");
        return BOS_ODULLER.includes(r);
      });

      return res.json({ ok: true, start: todayStart, list });
    }
  );
});

app.get("/admin/sure", (req, res) => {
  setNoStore(res);
  res.json({ dakika: parseInt(SPIN_SURE_DK, 10) || 45 });
});

app.post("/admin/sure", (req, res) => {
  setNoStore(res);
  const dakika = parseInt((req.body || {}).dakika, 10);

  if (isNaN(dakika) || dakika < 5 || dakika > 600) {
    return res.json({ ok: false, error: "Geçersiz süre (5-600 dk)" });
  }

  db.run(
    "INSERT INTO settings(key,value) VALUES('sure',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
    [String(dakika)],
    () => {
      SPIN_SURE_DK = dakika;
      res.json({ ok: true, dakika });
    }
  );
});

app.get("/admin/test-mode", (req, res) => {
  setNoStore(res);
  res.json({ ok: true, enabled: TEST_MODE === 1 });
});

app.post("/admin/test-mode", (req, res) => {
  setNoStore(res);
  const enabled = (req.body || {}).enabled ? 1 : 0;

  db.run(
    "INSERT INTO settings(key,value) VALUES('test_mode',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
    [String(enabled)],
    (err) => {
      if (err) return res.json({ ok: false, error: String(err) });
      TEST_MODE = enabled;
      res.json({ ok: true, enabled: TEST_MODE === 1 });
    }
  );
});

const PRODUCT_CATEGORIES = [
  "Sıcak İçecekler",
  "Soğuk İçecekler",
  "Atıştırmalıklar",
  "Teknik Servis"
];

// Türkçe kategori adlarının geçmişte yanlış karakter kodlamasıyla oluşmuş
// kopyalarını tek bir doğru ada indirger. Bu eşleme yalnız bilinen KafePin
// ürün kategorilerine uygulanır; kullanıcı ürün adlarına dokunulmaz.
const PRODUCT_CATEGORY_ALIASES = new Map([
  ["SÄ±cak Ä°Ã§ecekler", "Sıcak İçecekler"],
  ["SoÄŸuk Ä°Ã§ecekler", "Soğuk İçecekler"],
  ["AtÄ±ÅŸtÄ±rmalÄ±klar", "Atıştırmalıklar"]
]);

// Windows-1252 olarak yanlış yorumlanmış UTF-8 metni güvenli biçimde geri çevirir.
// Sadece tipik mojibake işaretleri varsa çalışır; normal Türkçe metne dokunmaz.
const CP1252_REVERSE = new Map([
  ["€",0x80],["‚",0x82],["ƒ",0x83],["„",0x84],["…",0x85],["†",0x86],
  ["‡",0x87],["ˆ",0x88],["‰",0x89],["Š",0x8A],["‹",0x8B],["Œ",0x8C],
  ["Ž",0x8E],["‘",0x91],["’",0x92],["“",0x93],["”",0x94],["•",0x95],
  ["–",0x96],["—",0x97],["˜",0x98],["™",0x99],["š",0x9A],["›",0x9B],
  ["œ",0x9C],["ž",0x9E],["Ÿ",0x9F]
]);

function decodeCp1252MojibakeOnce(value) {
  const text = String(value || "");
  const bytes = [];

  for (const ch of text) {
    if (CP1252_REVERSE.has(ch)) {
      bytes.push(CP1252_REVERSE.get(ch));
      continue;
    }

    const code = ch.codePointAt(0);
    if (code >= 0 && code <= 255) {
      bytes.push(code);
      continue;
    }

    return null;
  }

  const decoded = Buffer.from(bytes).toString("utf8");
  if (!decoded || decoded.includes("\uFFFD")) return null;
  return decoded;
}

function normalizeTurkishText(value) {
  let current = String(value || "").trim();

  // Ã, Ä, Å, Â dizileri UTF-8/Windows-1252 bozulmasının tipik izleridir.
  for (let pass = 0; pass < 3; pass++) {
    if (!/[ÃÄÅÂ]/.test(current)) break;
    const decoded = decodeCp1252MojibakeOnce(current);
    if (!decoded || decoded === current) break;
    current = decoded;
  }

  return current;
}

function normalizeProductName(value) {
  return normalizeTurkishText(value).slice(0, 80);
}

function normalizeProductCategory(value) {
  const raw = normalizeTurkishText(value).slice(0, 50);
  return PRODUCT_CATEGORY_ALIASES.get(raw) || raw;
}

function getMergedCatalogValues(good, bad) {
  const rows = [good, bad];
  const positivePriceRows = rows
    .filter((r) => (Number(r.price) || 0) > 0)
    .sort((a, b) => (Number(b.updated_at) || 0) - (Number(a.updated_at) || 0));

  const latest = rows
    .slice()
    .sort((a, b) => (Number(b.updated_at) || 0) - (Number(a.updated_at) || 0))[0] || good;

  const priceSource = positivePriceRows[0] || latest;

  return {
    price: Number(priceSource.price) || 0,
    active: Number(latest.active) === 0 ? 0 : 1,
    sortOrder: Number(latest.sort_order) || Number(good.sort_order) || Number(bad.sort_order) || 0,
    createdAt: Math.min(
      Number(good.created_at) || Date.now(),
      Number(bad.created_at) || Date.now()
    ),
    updatedAt: Math.max(
      Number(good.updated_at) || 0,
      Number(bad.updated_at) || 0,
      Date.now()
    )
  };
}

function cleanupBrokenProductCatalog() {
  db.all(
    `SELECT id,name,category,price,active,sort_order,created_at,updated_at
     FROM product_catalog ORDER BY id`,
    (err, rows) => {
      if (err) {
        logErr("product mojibake repair select catalog", err);
        return;
      }

      const list = rows || [];
      const repairRow = (index) => {
        if (index >= list.length) {
          return cleanupBrokenProductSalesText(() => {
            addLiveLog("system", "✅ Bozuk/yinelenen Türkçe ürün kayıtları temizlendi");
          });
        }

        const bad = list[index];
        const fixedName = normalizeProductName(bad.name);
        const fixedCategory = normalizeProductCategory(bad.category);

        if (fixedName === bad.name && fixedCategory === bad.category) {
          return repairRow(index + 1);
        }

        db.get(
          `SELECT id,name,category,price,active,sort_order,created_at,updated_at
           FROM product_catalog
           WHERE name=? AND category=? AND id<>?
           ORDER BY updated_at DESC,id ASC LIMIT 1`,
          [fixedName, fixedCategory, bad.id],
          (findErr, good) => {
            if (findErr) {
              logErr("product mojibake repair find duplicate", findErr);
              return repairRow(index + 1);
            }

            // Doğru karşılığı yoksa aynı kaydı yerinde düzelt; fiyat/id korunur.
            if (!good) {
              return db.run(
                `UPDATE product_catalog
                 SET name=?,category=?,updated_at=?
                 WHERE id=?`,
                [fixedName, fixedCategory, Math.max(Number(bad.updated_at)||0, Date.now()), bad.id],
                (updateErr) => {
                  if (updateErr) {
                    logErr("product mojibake repair rename catalog", updateErr);
                    return repairRow(index + 1);
                  }

                  db.run(
                    `UPDATE product_sales
                     SET product_name=?,category=?
                     WHERE product_id=?`,
                    [fixedName, fixedCategory, bad.id],
                    (salesErr) => {
                      if (salesErr) logErr("product mojibake repair sales rename", salesErr);
                      repairRow(index + 1);
                    }
                  );
                }
              );
            }

            // Doğru ve bozuk iki kayıt varsa tek kayda birleştir.
            const merged = getMergedCatalogValues(good, bad);
            db.run(
              `UPDATE product_catalog
               SET price=?,active=?,sort_order=?,created_at=?,updated_at=?
               WHERE id=?`,
              [
                merged.price,
                merged.active,
                merged.sortOrder,
                merged.createdAt,
                merged.updatedAt,
                good.id
              ],
              (mergeErr) => {
                if (mergeErr) {
                  logErr("product mojibake repair merge catalog", mergeErr);
                  return repairRow(index + 1);
                }

                // Eski satış kayıtlarını doğru ürün ID/ad/kategorisine bağla.
                db.run(
                  `UPDATE product_sales
                   SET product_id=?,product_name=?,category=?
                   WHERE product_id=?`,
                  [good.id, fixedName, fixedCategory, bad.id],
                  (salesErr) => {
                    if (salesErr) logErr("product mojibake repair sales relink", salesErr);

                    db.run(
                      "DELETE FROM product_catalog WHERE id=?",
                      [bad.id],
                      (deleteErr) => {
                        if (deleteErr) logErr("product mojibake repair delete duplicate", deleteErr);
                        repairRow(index + 1);
                      }
                    );
                  }
                );
              }
            );
          }
        );
      };

      repairRow(0);
    }
  );
}

function cleanupBrokenProductSalesText(done) {
  db.all(
    `SELECT id,product_name,category FROM product_sales ORDER BY id`,
    (err, rows) => {
      if (err) {
        logErr("product mojibake repair select sales", err);
        return done && done();
      }

      const list = rows || [];
      const repairSale = (index) => {
        if (index >= list.length) return done && done();
        const sale = list[index];
        const fixedName = normalizeProductName(sale.product_name);
        const fixedCategory = normalizeProductCategory(sale.category);

        if (fixedName === sale.product_name && fixedCategory === sale.category) {
          return repairSale(index + 1);
        }

        db.run(
          "UPDATE product_sales SET product_name=?,category=? WHERE id=?",
          [fixedName, fixedCategory, sale.id],
          (updateErr) => {
            if (updateErr) logErr("product mojibake repair sale text", updateErr);
            repairSale(index + 1);
          }
        );
      };

      repairSale(0);
    }
  );
}

function normalizeAndDedupeProductRows(rows) {
  const chosen = new Map();

  (rows || []).forEach((source) => {
    const row = {
      ...source,
      name: normalizeProductName(source.name),
      category: normalizeProductCategory(source.category)
    };
    const key = `${row.name}\u0000${row.category}`;
    const previous = chosen.get(key);

    if (!previous) {
      chosen.set(key, row);
      return;
    }

    const rowPrice = Number(row.price) || 0;
    const prevPrice = Number(previous.price) || 0;
    const rowUpdated = Number(row.updated_at) || 0;
    const prevUpdated = Number(previous.updated_at) || 0;

    if (
      (rowPrice > 0 && prevPrice <= 0) ||
      (rowPrice > 0 && prevPrice > 0 && rowUpdated > prevUpdated) ||
      (rowPrice === prevPrice && rowUpdated > prevUpdated)
    ) {
      chosen.set(key, row);
    }
  });

  return Array.from(chosen.values());
}

// Sunucu tamamen ayağa kalktıktan sonra çalışır; açılışı bloke etmez.
setTimeout(() => {
  try {
    cleanupBrokenProductCatalog();
  } catch (err) {
    logErr("product mojibake repair startup", err);
  }
}, 2500);

app.get("/admin/products", (req, res) => {
  setNoStore(res);
  const showAll = String(req.query.all || "") === "1";
  db.all(
    `SELECT id,name,category,price,active,sort_order,created_at,updated_at
     FROM product_catalog
     ${showAll ? "" : "WHERE active=1"}
     ORDER BY category, sort_order, name`,
    (err, rows) => {
      if (err) return res.json({ ok: false, error: String(err) });
      res.json({
        ok: true,
        categories: PRODUCT_CATEGORIES,
        list: normalizeAndDedupeProductRows(rows || [])
      });
    }
  );
});

app.post("/admin/products/save", (req, res) => {
  setNoStore(res);
  const body = req.body || {};
  const id = parseInt(body.id, 10) || 0;
  const name = normalizeProductName(String(body.name || "").trim().slice(0, 80));
  const category = normalizeProductCategory(String(body.category || "").trim().slice(0, 50));
  const price = Number(body.price);
  const active = body.active === false || Number(body.active) === 0 ? 0 : 1;
  const sortOrder = parseInt(body.sortOrder, 10) || 0;
  const now = Date.now();

  if (!name) return res.json({ ok: false, error: "Ürün adı gerekli" });
  if (!category) return res.json({ ok: false, error: "Kategori gerekli" });
  if (!Number.isFinite(price) || price < 0) {
    return res.json({ ok: false, error: "Geçerli bir fiyat gir" });
  }

  if (id > 0) {
    return db.run(
      `UPDATE product_catalog
       SET name=?,category=?,price=?,active=?,sort_order=?,updated_at=?
       WHERE id=?`,
      [name, category, price, active, sortOrder, now, id],
      function (err) {
        if (err) return res.json({ ok: false, error: String(err) });
        if (!this.changes) return res.json({ ok: false, error: "Ürün bulunamadı" });
        addLiveLog("product_update", `🧾 Ürün güncellendi • ${name} • ${price.toFixed(2)} ₺`);
        res.json({ ok: true, id });
      }
    );
  }

  db.run(
    `INSERT INTO product_catalog
     (name,category,price,active,sort_order,created_at,updated_at)
     VALUES (?,?,?,?,?,?,?)`,
    [name, category, price, active, sortOrder, now, now],
    function (err) {
      if (err) return res.json({ ok: false, error: String(err) });
      addLiveLog("product_add", `➕ Ürün eklendi • ${name} • ${price.toFixed(2)} ₺`);
      res.json({ ok: true, id: this.lastID });
    }
  );
});

app.post("/admin/products/delete", (req, res) => {
  setNoStore(res);
  const id = parseInt((req.body || {}).id, 10) || 0;
  if (!id) return res.json({ ok: false, error: "Geçersiz ürün" });

  db.get("SELECT name FROM product_catalog WHERE id=?", [id], (selectErr, product) => {
    if (selectErr) return res.json({ ok: false, error: String(selectErr) });
    if (!product) return res.json({ ok: false, error: "Ürün bulunamadı" });

    db.run("DELETE FROM product_catalog WHERE id=?", [id], (err) => {
      if (err) return res.json({ ok: false, error: String(err) });
      addLiveLog("product_delete", `🗑️ Ürün silindi • ${product.name}`);
      res.json({ ok: true });
    });
  });
});

app.post("/admin/product-sales/add", (req, res) => {
  setNoStore(res);
  const body = req.body || {};
  const productId = parseInt(body.productId, 10) || 0;
  const quantity = Math.max(1, Math.min(parseInt(body.quantity, 10) || 1, 99));
  const direct = !!body.direct;
  const masa = direct ? 0 : (parseInt(body.masa, 10) || 0);
  const directPaymentMethod = normalizePaymentMethod(body.paymentMethod, "PENDING");
  const note = String(body.note || "").trim().slice(0, 160);

  if (!productId) return res.json({ ok: false, error: "Ürün seç" });
  if (!direct && (masa < 1 || masa > MASA_SAYISI)) {
    return res.json({ ok: false, error: "Masa 1-23 arasında olmalı" });
  }
  if (direct && !["CASH", "CARD"].includes(directPaymentMethod)) {
    return res.json({ ok: false, error: "Doğrudan satış için Nakit veya Kart seç" });
  }

  db.get(
    "SELECT * FROM product_catalog WHERE id=? AND active=1",
    [productId],
    (productErr, product) => {
      if (productErr) return res.json({ ok: false, error: String(productErr) });
      if (!product) return res.json({ ok: false, error: "Aktif ürün bulunamadı" });

      const unitPrice = Number(product.price) || 0;
      if (unitPrice <= 0) {
        return res.json({ ok: false, error: `${product.name} için önce fiyat gir` });
      }

      const saveSale = (sessionStart) => {
        const now = Date.now();
        const total = unitPrice * quantity;
        db.run(
          `INSERT INTO product_sales
           (time,masa,session_start,product_id,product_name,category,unit_price,
            quantity,total,sale_type,note,status,finalized_at,payment_method,voided,voided_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,0)`,
          [
            now, masa, Number(sessionStart) || 0, product.id, normalizeProductName(product.name),
            normalizeProductCategory(product.category), unitPrice, quantity, total,
            direct ? "DIRECT" : "TABLE", note,
            direct ? "FINALIZED" : "OPEN", direct ? now : 0,
            direct ? directPaymentMethod : "PENDING"
          ],
          function (insertErr) {
            if (insertErr) return res.json({ ok: false, error: String(insertErr) });
            const saleId = this.lastID;

            const finishSale = () => {
            addLiveLog(
              "product_sale",
              `${direct ? "🧾 Doğrudan" : `☕ Masa ${masa}`} • ${quantity}x ${product.name} • ${total.toFixed(2)} ₺`
            );
            res.json({ ok: true, id: saleId, total });
            };

            if (!direct) return finishSale();
            db.run(
              `INSERT INTO payments
               (created_at,paid_at,masa,session_start,session_end,product_sale_id,
                computer_amount,product_amount,total_amount,method,source,close_reason,note,voided,voided_at)
               VALUES (?,?,0,0,?,?,0,?,?,?,'DIRECT_PRODUCT','DIRECT_SALE','',0,0)`,
              [now, now, now, saleId, total, total, directPaymentMethod],
              (paymentErr) => {
                if (paymentErr) {
                  db.run("UPDATE product_sales SET voided=1,voided_at=? WHERE id=?", [Date.now(), saleId]);
                  return res.json({ ok: false, error: String(paymentErr) });
                }
                finishSale();
              }
            );
          }
        );
      };

      if (direct) return saveSale(0);

      db.get(
        "SELECT start_time FROM sessions WHERE masa=? AND (end_time=0 OR end_time IS NULL)",
        [masa],
        (sessionErr, sessionRow) => {
          if (sessionErr) return res.json({ ok: false, error: String(sessionErr) });
          const online = !isActuallyOffline(masa, aktifMasalar[masa] || 0, Date.now());
          if (!sessionRow && !isFreeMasa(masa) && !online) {
            return res.json({ ok: false, error: `Masa ${masa} aktif değil` });
          }
          saveSale(sessionRow ? sessionRow.start_time : (aktifMasalar[masa] || Date.now()));
        }
      );
    }
  );
});

app.post("/admin/product-sales/add-custom-direct", (req, res) => {
  setNoStore(res);
  const body = req.body || {};
  const name = String(body.name || "").trim().slice(0, 100);
  const unitPrice = Number(body.unitPrice);
  const quantity = Math.max(1, Math.min(parseInt(body.quantity, 10) || 1, 99));
  const paymentMethod = normalizePaymentMethod(body.paymentMethod, "PENDING");

  if (!name) return res.json({ ok: false, error: "Ürün/hizmet adı gir" });
  if (!Number.isFinite(unitPrice) || unitPrice <= 0) {
    return res.json({ ok: false, error: "Geçerli bir birim fiyat gir" });
  }
  if (!['CASH', 'CARD'].includes(paymentMethod)) {
    return res.json({ ok: false, error: "Doğrudan satış için Nakit veya Kart seç" });
  }

  const now = Date.now();
  const total = unitPrice * quantity;
  db.run(
    `INSERT INTO product_sales
     (time,masa,session_start,product_id,product_name,category,unit_price,
      quantity,total,sale_type,note,status,finalized_at,payment_method,voided,voided_at)
     VALUES (?,0,0,0,?,'Liste Dışı',?,?,?,'DIRECT',?,'FINALIZED',?,?,0,0)`,
    [now, name, unitPrice, quantity, total, 'Serbest doğrudan satış', now, paymentMethod],
    function (insertErr) {
      if (insertErr) return res.json({ ok: false, error: String(insertErr) });
      const saleId = this.lastID;
      db.run(
        `INSERT INTO payments
         (created_at,paid_at,masa,session_start,session_end,product_sale_id,
          computer_amount,product_amount,total_amount,method,source,close_reason,note,voided,voided_at)
         VALUES (?,?,0,0,?,?,0,?,?,?,'DIRECT_PRODUCT','DIRECT_SALE','Serbest doğrudan satış',0,0)`,
        [now, now, now, saleId, total, total, paymentMethod],
        (paymentErr) => {
          if (paymentErr) {
            db.run("UPDATE product_sales SET voided=1,voided_at=? WHERE id=?", [Date.now(), saleId]);
            return res.json({ ok: false, error: String(paymentErr) });
          }
          addLiveLog("product_sale", `🧾 Serbest doğrudan satış • ${quantity}x ${name} • ${total.toFixed(2)} ₺`);
          res.json({ ok: true, id: saleId, total });
        }
      );
    }
  );
});

// Eski EveryCafe "Üye Geliri" KafePin'e otomatik gelmez. Bir defalık
// geçmiş eşleştirme için tarihli nakit/kart doğrudan satış kaydı ekler.
app.post("/admin/product-sales/add-history-member-income", (req, res) => {
  setNoStore(res);
  const body = req.body || {};
  const rawDate = String(body.date || "");
  const amount = Number(body.amount);
  const paymentMethod = normalizePaymentMethod(body.paymentMethod, "CASH");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(rawDate)) return res.json({ ok:false, error:"Geçerli tarih seç" });
  if (!Number.isFinite(amount) || amount <= 0) return res.json({ ok:false, error:"Geçerli tutar gir" });
  if (!['CASH', 'CARD'].includes(paymentMethod)) return res.json({ ok:false, error:"Nakit veya Kart seç" });
  const [year, month, day] = rawDate.split("-").map(Number);
  const saleTime = new Date(year, month - 1, day, 12, 0, 0, 0).getTime();
  if (!Number.isFinite(saleTime)) return res.json({ ok:false, error:"Geçerli tarih seç" });
  const dayEnd = saleTime + (24 * 60 * 60 * 1000);
  const name = "EveryCafe Üye Geliri (geçmiş aktarım)";
  db.get(
    `SELECT id FROM product_sales
     WHERE voided=0 AND sale_type='DIRECT' AND product_name=? AND time>=? AND time<? LIMIT 1`,
    [name, saleTime, dayEnd],
    (existsErr, existing) => {
      if (existsErr) return res.json({ ok:false, error:String(existsErr) });
      if (existing) return res.json({ ok:false, error:"Bu tarih için Üye Geliri zaten eklenmiş" });
      db.run(
        `INSERT INTO product_sales
         (time,masa,session_start,product_id,product_name,category,unit_price,quantity,total,sale_type,note,status,finalized_at,payment_method,voided,voided_at)
         VALUES (?,0,0,0,?,'EveryCafe Geçmiş Aktarım',?,1,?,'DIRECT',?,'FINALIZED',?,?,0,0)`,
        [saleTime, name, amount, amount, "EveryCafe Üye Geliri • geçmiş eşleştirme", saleTime, paymentMethod],
        function(insertErr) {
          if (insertErr) return res.json({ ok:false, error:String(insertErr) });
          const saleId = this.lastID;
          db.run(
            `INSERT INTO payments
             (created_at,paid_at,masa,session_start,session_end,product_sale_id,computer_amount,product_amount,total_amount,method,source,close_reason,note,voided,voided_at)
             VALUES (?,?,0,0,?,?,0,?,?,?,'DIRECT_PRODUCT','DIRECT_SALE','EveryCafe Üye Geliri geçmiş aktarımı',0,0)`,
            [saleTime, saleTime, saleTime, saleId, amount, amount, paymentMethod],
            (paymentErr) => {
              if (paymentErr) {
                db.run("UPDATE product_sales SET voided=1,voided_at=? WHERE id=?", [Date.now(), saleId]);
                return res.json({ ok:false, error:String(paymentErr) });
              }
              addLiveLog("product_sale", `EveryCafe geçmiş üye geliri eklendi • ${rawDate} • ${amount.toFixed(2)} ₺ • ${paymentMethod}`);
              res.json({ ok:true, id:saleId, total:amount, date:rawDate });
            }
          );
        }
      );
    }
  );
});

app.post("/admin/product-sales/void", (req, res) => {
  setNoStore(res);
  const id = parseInt((req.body || {}).id, 10) || 0;
  if (!id) return res.json({ ok: false, error: "Geçersiz satış" });

  db.get("SELECT * FROM product_sales WHERE id=? AND voided=0", [id], (selectErr, sale) => {
    if (selectErr) return res.json({ ok: false, error: String(selectErr) });
    if (!sale) return res.json({ ok: false, error: "Satış bulunamadı veya zaten iptal" });
    db.run(
      "UPDATE product_sales SET voided=1,voided_at=? WHERE id=? AND voided=0",
      [Date.now(), id],
      function (err) {
        if (err) return res.json({ ok: false, error: String(err) });
        db.run(
          "UPDATE payments SET voided=1,voided_at=? WHERE product_sale_id=? AND voided=0",
          [Date.now(), id],
          (paymentVoidErr) => {
            if (paymentVoidErr) return res.json({ ok: false, error: String(paymentVoidErr) });
            addLiveLog("product_void", `↩️ Satış iptal • ${sale.product_name} • ${Number(sale.total).toFixed(2)} ₺`);
            res.json({ ok: true });
          }
        );
      }
    );
  });
});

// EveryCafe canlı entegrasyonu yalnızca kaynak veritabanını salt-okunur açar.
// Test başlatıldığı andan sonraki kapanan oturumlar SessionID ile bir defa içeri alınır.
function everyCafeTableNumber(clientName) {
  const match = String(clientName || "").match(/MASA\s*[-_]?\s*(\d+)/i);
  const masa = match ? Number(match[1]) : 0;
  return masa >= 1 && masa <= MASA_SAYISI ? masa : 0;
}

// EveryCafe'de yalnız doğrudan ürün/teknik servis tahsilatı için açılan
// "Doğrudan Satış" sipariş masası KafePin'de masa oturumu değildir. Ancak
// nakit/kart tahsilatı ve ürünleri, KafePin'in doğrudan satışına aktarılır.
function isEveryCafeDirectSaleClient(clientName) {
  const normalized = String(clientName || "")
    .toLocaleLowerCase("tr-TR")
    .replace(/ı/g, "i")
    .replace(/ğ/g, "g")
    .replace(/ş/g, "s")
    .replace(/ç/g, "c")
    .replace(/ö/g, "o")
    .replace(/ü/g, "u")
    .trim();
  return normalized === "dogrudan satis";
}

function everyCafePaymentMethod(value) {
  // EveryCafe varsayılanında 1=Nakit, 2=Kart. Bilinmeyen tip güvenli olarak bekler.
  return Number(value) === 1 ? "CASH" : Number(value) === 2 ? "CARD" : "PENDING";
}

function findMatchingKafePinSession(masa, sourceStart, sourceEnd, cb) {
  const windowMs = 20 * 60 * 1000;
  const params = [masa, sourceStart - windowMs, sourceStart + windowMs];
  db.get(
    `SELECT masa,start_time,end_time,last_seen
     FROM sessions WHERE masa=? AND start_time BETWEEN ? AND ?`,
    params,
    (activeErr, activeRow) => {
      if (activeErr) return cb(activeErr);
      if (activeRow) return cb(null, activeRow);
      db.get(
        `SELECT masa,start_time,end_time,last_seen
         FROM session_history WHERE masa=? AND start_time BETWEEN ? AND ?
         ORDER BY end_time DESC LIMIT 1`,
        params,
        cb
      );
    }
  );
}

function getEveryCafeConfig(cb) {
  db.all(
    "SELECT key,value FROM settings WHERE key IN ('everycafe_sync_enabled','everycafe_sync_start_at')",
    (err, rows) => {
      if (err) return cb(err);
      const values = Object.fromEntries((rows || []).map((row) => [row.key, row.value]));
      cb(null, {
        enabled: values.everycafe_sync_enabled === "1",
        startAt: Number(values.everycafe_sync_start_at) || 0
      });
    }
  );
}

function getEveryCafeManualSafety(cb) {
  db.all(
    "SELECT key,value FROM settings WHERE key IN ('everycafe_sync_enabled','everycafe_maintenance_mode')",
    (err, rows) => {
      if (err) return cb(err);
      const values = Object.fromEntries((rows || []).map((row) => [row.key, row.value]));
      cb(null, {
        everyCafeEnabled: values.everycafe_sync_enabled === "1",
        maintenanceEnabled: values.everycafe_maintenance_mode === "1"
      });
    }
  );
}

function requireEveryCafeMaintenance(res, next) {
  getEveryCafeManualSafety((err, safety) => {
    if (err) return res.json({ ok: false, error: String(err) });
    if (safety.everyCafeEnabled && !safety.maintenanceEnabled) {
      return res.status(409).json({
        ok: false,
        code: "EVERYCAFE_MAINTENANCE_REQUIRED",
        error: "EveryCafe aktarımı açık. Bu işlem sadece Bakım Modu açıkken kullanılabilir."
      });
    }
    return next();
  });
}

app.get("/admin/maintenance-mode", (req, res) => {
  setNoStore(res);
  getEveryCafeManualSafety((err, safety) => {
    if (err) return res.json({ ok: false, error: String(err) });
    res.json({ ok: true, enabled: safety.maintenanceEnabled, everyCafeEnabled: safety.everyCafeEnabled });
  });
});

app.post("/admin/maintenance-mode", (req, res) => {
  setNoStore(res);
  const enabled = (req.body || {}).enabled ? 1 : 0;
  db.run(
    "INSERT INTO settings(key,value) VALUES('everycafe_maintenance_mode',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
    [String(enabled)],
    (err) => {
      if (err) return res.json({ ok: false, error: String(err) });
      EVERYCAFE_MAINTENANCE_MODE = enabled;
      addLiveLog("everycafe_maintenance_mode", enabled ? "🛠️ EveryCafe bakım modu açıldı" : "🔒 EveryCafe bakım modu kapatıldı");
      getEveryCafeConfig((configErr, config) => {
        res.json({ ok: true, enabled: enabled === 1, everyCafeEnabled: !configErr && !!(config && config.enabled) });
      });
    }
  );
});

function readEveryCafeClosedSessions(sinceMs, limit, cb) {
  const source = new sqlite3.Database(EVERYCAFE_DB_PATH, sqlite3.OPEN_READONLY, (openErr) => {
    if (openErr) return cb(openErr);
    const close = () => source.close(() => {});
    source.all(
      `SELECT SessionID,ClientName,StartDate,EndDate,PaymentMethod,PaymentAmount,
              SessionType,SessionTypeText,SessionDetailDataText,Price
       FROM Sessions
       WHERE COALESCE(Deleted,0)=0 AND COALESCE(IsPaid,0)=1
         AND COALESCE(EndDate,0)>?
       ORDER BY EndDate ASC LIMIT ?`,
      [Math.floor(Math.max(Number(sinceMs) || 0, 0) / 1000), Math.max(1, Math.min(Number(limit) || 50, 200))],
      (sessionErr, sessionRows) => {
        if (sessionErr) { close(); return cb(sessionErr); }
        const sessions = (sessionRows || []).filter((row) =>
          everyCafeTableNumber(row.ClientName) > 0 || isEveryCafeDirectSaleClient(row.ClientName)
        );
        if (!sessions.length) { close(); return cb(null, []); }
        const ids = sessions.map((row) => row.SessionID);
        source.all(
          `SELECT OrderID,SessionID,StockName,Quantity,Price,AddDate,OrderIsActive
           FROM Orders
           WHERE SessionID IN (${ids.map(() => "?").join(",")})
           ORDER BY AddDate ASC`,
          ids,
          (orderErr, orderRows) => {
            close();
            if (orderErr) return cb(orderErr);
            const ordersBySession = new Map();
            (orderRows || []).forEach((order) => {
              const list = ordersBySession.get(order.SessionID) || [];
              list.push(order);
              ordersBySession.set(order.SessionID, list);
            });
            cb(null, sessions.map((session) => ({ ...session, orders: ordersBySession.get(session.SessionID) || [] })));
          }
        );
      }
    );
  });
}

// Üye bakiyesi EveryCafe'de Sessions tablosunda değil MemberPaymentHistory'de
// yer alır. PaymentMethod 1=Nakit, 2=Kart; diğer teknik/hediye hareketleri
// tahsilat olmadığı için güvenle dışarıda bırakılır.
function readEveryCafeMemberPayments(sinceMs, limit, cb) {
  const source = new sqlite3.Database(EVERYCAFE_DB_PATH, sqlite3.OPEN_READONLY, (openErr) => {
    if (openErr) return cb(openErr);
    source.all(
      `SELECT HistoryID,MemberID,PaymentAmount,PaymentMethod,IsActive,PaymentDate,PaymentKey,Note,CashierName
       FROM MemberPaymentHistory
       WHERE COALESCE(IsActive,1)<>0
         AND COALESCE(PaymentDate,0)>?
         AND PaymentMethod IN (1,2)
         AND COALESCE(PaymentAmount,0)>0
       ORDER BY PaymentDate ASC, HistoryID ASC LIMIT ?`,
      [Math.floor(Math.max(Number(sinceMs) || 0, 0) / 1000), Math.max(1, Math.min(Number(limit) || 100, 500))],
      (readErr, rows) => {
        source.close(() => {});
        if (readErr) return cb(readErr);
        cb(null, rows || []);
      }
    );
  });
}

// Açık EveryCafe oturumlarının başlangıç anı KafePin'in tek ücret başlangıcıdır.
// Kaynak sadece okunur; burada EveryCafe'ye hiçbir veri yazılmaz.
function readEveryCafeActiveSessions(limit, cb) {
  const source = new sqlite3.Database(EVERYCAFE_DB_PATH, sqlite3.OPEN_READONLY, (openErr) => {
    if (openErr) return cb(openErr);
    source.all(
      `SELECT s.SessionID,s.ClientName,s.StartDate,s.EndDate,s.SessionType,s.SessionTypeText,
              s.SessionDetailDataText,s.Price,s.PaymentAmount,s.GiftTime,
              COALESCE(c.ClientStatus,0) AS ClientStatus
       FROM Sessions s
       LEFT JOIN Clients c ON c.ClientGuid=s.ClientGuid
       WHERE COALESCE(s.Deleted,0)=0
         AND COALESCE(s.IsActive,0)=1
       ORDER BY StartDate ASC LIMIT ?`,
      [Math.max(1, Math.min(Number(limit) || 100, 200))],
      (readErr, rows) => {
        if (readErr) {
          source.close(() => {});
          return cb(readErr);
        }
        const sessions = (rows || []).map((row) => ({
          ...row,
          masa: everyCafeTableNumber(row.ClientName),
          start: Number(row.StartDate) * 1000,
          // EveryCafe sürümlerinde Windows'a geçmiş istemci 1, 4, 128 veya 1024
          // bayrağıyla gelebilir. 128 özellikle ücretsiz oturum açıldığında
          // görülür. Gerçek bekleme ekranı ise tam olarak 2'dir.
          // Aktif Session kaydı varken 1'i bekleme saymak masa ücretini ve
          // çarkı yanlışlıkla durduruyordu.
          isRunning: Number(row.ClientStatus) === 1
            || ((Number(row.ClientStatus) & 4) === 4)
            || ((Number(row.ClientStatus) & 128) === 128)
            || ((Number(row.ClientStatus) & 1024) === 1024)
        })).filter((row) => row.SessionID && row.masa && row.start);
        if (!sessions.length) {
          source.close(() => {});
          return cb(null, []);
        }
        const ids = sessions.map((row) => row.SessionID);
        source.all(
          `SELECT OrderID,SessionID,StockName,Quantity,Price,AddDate,OrderIsActive
           FROM Orders
           WHERE SessionID IN (${ids.map(() => "?").join(",")})
           ORDER BY AddDate ASC`,
          ids,
          (orderErr, orderRows) => {
            source.close(() => {});
            if (orderErr) return cb(orderErr);
            const ordersBySession = new Map();
            (orderRows || []).forEach((order) => {
              const list = ordersBySession.get(order.SessionID) || [];
              list.push(order);
              ordersBySession.set(order.SessionID, list);
            });
            cb(null, sessions.map((session) => ({
              ...session,
              orders: ordersBySession.get(session.SessionID) || []
            })));
          }
        );
      }
    );
  });
}

function isEveryCafeFreeSession(session) {
  // EveryCafe'in metni Windows/SQLite kodlamasından farklı biçimde gelebilir.
  // Bu nedenle Türkçe karaktere doğrudan bağlı kalmadan hem oturum türünü hem
  // ayrıntı metnini ASCII'ye normalize ederek kontrol ederiz. SessionType=20,
  // hem baştan ücretsiz açılan hem de ücretli açılıp "Ücretsiz Kapat" yapılan
  // oturumun kaynak işaretidir. İkinci durumda PaymentAmount eski tahmini
  // ücret olarak sıfırlanmadan kalabilir; ücret kararı için kullanılmaz.
  const normalize = (value) => String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
  const typeText = [session && session.SessionTypeText, session && session.SessionDetailDataText]
    .map(normalize)
    .join(" ");
  const explicitFreeText = /(^|\s)(ucretsiz|free|complimentary|gratis)(\s|$)/.test(typeText);
  const freeType = Number(session && session.SessionType) === 20;
  return explicitFreeText || freeType;
}

function importEveryCafeOpenOrders(sourceSession, localStart, cb) {
  const masa = Number(sourceSession.masa) || 0;
  const orders = (sourceSession.orders || []).map((order) => ({
    id: String(order.OrderID || "").trim(),
    name: String(order.StockName || "EveryCafe Ürün").trim().slice(0, 100),
    quantity: Math.max(1, Number(order.Quantity) || 1),
    price: Math.max(0, Number(order.Price) || 0),
    time: (Number(order.AddDate) || Number(sourceSession.StartDate)) * 1000,
    active: Number(order.OrderIsActive) !== 0
  })).filter((order) => order.id);
  let index = 0;
  // EveryCafe bazı sürümlerde silinen siparişi hiç döndürmez, bazılarında
  // OrderIsActive=0 döndürür. Önce bu açık oturumun eski ürünlerini iptal
  // eder, aşağıda hâlâ aktif olanları tekrar etkinleştiririz; iki durumda da
  // KafePin canlı toplamı kaynakla aynı kalır.
  const clearRemovedOrders = (done) => db.run(
    "UPDATE product_sales SET voided=1,voided_at=? WHERE external_source='EVERYCAFE' AND masa=? AND session_start=? AND status='OPEN' AND voided=0",
    [Date.now(), masa, localStart],
    done
  );
  const next = (err) => {
    if (err || index >= orders.length) return cb(err || null);
    const order = orders[index++];
    const total = Math.round(order.quantity * order.price * 100) / 100;
    const externalId = `ORDER:${order.id}`;
    if (!order.active) {
      return db.run(
        "UPDATE product_sales SET voided=1,voided_at=? WHERE external_source='EVERYCAFE' AND external_id=? AND voided=0",
        [Date.now(), externalId],
        next
      );
    }
    db.run(
      `INSERT OR IGNORE INTO product_sales
       (time,masa,session_start,product_id,product_name,category,unit_price,quantity,total,sale_type,note,status,finalized_at,payment_method,voided,voided_at,external_source,external_id)
       VALUES (?,?,?,?,?,?,?,? ,?,'TABLE',?,'OPEN',0,'PENDING',0,0,'EVERYCAFE',?)`,
      [order.time, masa, localStart, 0, order.name, "EveryCafe", order.price, order.quantity, total,
        `EveryCafe açık oturum: ${sourceSession.SessionID}`, `ORDER:${order.id}`],
      (insertErr) => {
        if (insertErr) return next(insertErr);
        db.run(
          `UPDATE product_sales
           SET time=?,masa=?,session_start=?,product_name=?,category='EveryCafe',unit_price=?,quantity=?,total=?,status='OPEN',finalized_at=0,payment_method='PENDING',voided=0,voided_at=0
           WHERE external_source='EVERYCAFE' AND external_id=?`,
          [order.time, masa, localStart, order.name, order.price, order.quantity, total, externalId],
          next
        );
      }
    );
  };
  clearRemovedOrders((clearErr) => next(clearErr || null));
}

// EveryCafe aynı SessionID'yi başka masaya taşıdığında KafePin'deki açık
// müşteri kaydını da taşır. Süre, ürün ve kullanılmamış ödül aynı müşteride kalır.
function transferEveryCafeActiveSession(from, to, cb) {
  if (!from || !to || from === to) return cb(null, { skipped: true });
  const run = (sql, params = []) => new Promise((resolve, reject) => {
    db.run(sql, params, function (err) { return err ? reject(err) : resolve(this.changes || 0); });
  });
  const get = (sql, params = []) => new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => err ? reject(err) : resolve(row || null));
  });
  (async () => {
    let transaction = false;
    setLock(from, Date.now() + LOCK_MS);
    setLock(to, Date.now() + LOCK_MS);
    try {
      const source = await get("SELECT * FROM sessions WHERE masa=? AND (end_time=0 OR end_time IS NULL)", [from]);
      const target = await get("SELECT masa FROM sessions WHERE masa=? AND (end_time=0 OR end_time IS NULL)", [to]);
      if (target) throw new Error(`Masa ${to} üzerinde zaten açık bir KafePin oturumu var`);
      if (!source) {
        await run("UPDATE free_masalar SET enabled=0,set_time=? WHERE masa=? AND enabled=1", [Date.now(), from]);
        freeMasalar.delete(from);
        delete aktifMasalar[from];
        everyCafeSessionTypes.delete(from);
        everyCafeTimedSessions.delete(from);
        everyCafeScheduledEnds.delete(from);
        everyCafeGiftMinutes.delete(from);
        return cb(null, { moved: true, free: true });
      }
      await run("BEGIN IMMEDIATE TRANSACTION");
      transaction = true;
      const moved = await run("UPDATE sessions SET masa=? WHERE masa=? AND start_time=?", [to, from, source.start_time]);
      if (moved !== 1) throw new Error("Açık oturum yeni masaya taşınamadı");
      await run("DELETE FROM masalar WHERE masa=?", [to]);
      await run("UPDATE masalar SET masa=? WHERE masa=?", [to, from]);
      await run("UPDATE spins SET masa=? WHERE masa=? AND used=0", [to, from]);
      await run("UPDATE spins_log SET masa=? WHERE masa=? AND used=0", [to, from]);
      await run("UPDATE real_adjustments SET masa=? WHERE masa=? AND session_start=?", [to, from, source.start_time]);
      await run("UPDATE product_sales SET masa=?,session_start=? WHERE masa=? AND session_start=? AND status='OPEN' AND voided=0", [to, source.start_time, from, source.start_time]);
      await run("COMMIT");
      transaction = false;
      aktifMasalar[to] = aktifMasalar[from] || source.last_seen || Date.now();
      delete aktifMasalar[from];
      everyCafeSessionTypes.set(to, String(everyCafeSessionTypes.get(from) || ""));
      everyCafeTimedSessions.set(to, isEveryCafeTimedMasa(from));
      everyCafeScheduledEnds.set(to, getEveryCafeScheduledEnd(from));
      everyCafeGiftMinutes.set(to, getEveryCafeGiftMinutes(from));
      everyCafeGiftMinutes.delete(from);
      everyCafeSessionTypes.delete(from);
      everyCafeTimedSessions.delete(from);
      everyCafeScheduledEnds.delete(from);
      masaPingStats[to] = masaPingStats[from] || masaPingStats[to];
      delete masaPingStats[from];
      latestRewardMap[to] = latestRewardMap[from] || latestRewardMap[to] || null;
      delete latestRewardMap[from];
      offlineCount[to] = offlineCount[from] || 0;
      offlineCount[from] = 0;
      lastOfflineState[to] = lastOfflineState[from] || false;
      lastOfflineState[from] = false;
      masaCloseLocks[from] = Date.now() + 30000;
      masaCloseLocks[to] = Date.now() + 10000;
      addLiveLog("everycafe_transfer", `🔄 EveryCafe masa aktarımı • Masa ${from} → ${to} • ürünler ve süre taşındı`);
      cb(null, { moved: true, free: false });
    } catch (err) {
      if (transaction) { try { await run("ROLLBACK"); } catch (_rollbackErr) {} }
      cb(err);
    } finally {
      sessionLocks.delete(from);
      sessionLocks.delete(to);
      db.run("DELETE FROM session_locks WHERE masa IN (?,?)", [from, to], () => {});
    }
  })();
}

// Bekleme ekranındaki EveryCafe kaydı KafePin'de oturum, ücret veya ödeme yaratmaz.
// Eski sürümden kalmış aynı geçici kayıt varsa yalnızca o kaynak oturuma ait olanı temizler.
function clearEveryCafeWaitingSession(sourceSession, cb = () => {}) {
  const sessionId = String(sourceSession.SessionID || "");
  const masa = Number(sourceSession.masa) || 0;
  const start = Number(sourceSession.start) || 0;
  if (!sessionId || !masa || !start) return cb(null, { cleared: false });
  db.get(
    "SELECT masa,source_start FROM everycafe_active_sessions WHERE session_id=?",
    [sessionId],
    (mapErr, mapping) => {
      if (mapErr) return cb(mapErr);
      if (!mapping) return cb(null, { cleared: false });
      const mappedMasa = Number(mapping.masa) || masa;
      const mappedStart = Number(mapping.source_start) || start;
      db.serialize(() => {
        db.run("BEGIN IMMEDIATE", (beginErr) => {
          if (beginErr) return cb(beginErr);
          const rollback = (err) => db.run("ROLLBACK", () => cb(err));
          db.run(
            "DELETE FROM product_sales WHERE external_source='EVERYCAFE' AND masa=? AND session_start=? AND status='OPEN' AND voided=0",
            [mappedMasa, mappedStart],
            (productErr) => {
              if (productErr) return rollback(productErr);
              db.run(
                "DELETE FROM sessions WHERE masa=? AND start_time=?",
                [mappedMasa, mappedStart],
                (sessionErr) => {
                  if (sessionErr) return rollback(sessionErr);
                  db.run("DELETE FROM everycafe_active_sessions WHERE session_id=?", [sessionId], (deleteErr) => {
                    if (deleteErr) return rollback(deleteErr);
                    db.run("COMMIT", (commitErr) => {
                      if (commitErr) return rollback(commitErr);
                      delete aktifMasalar[mappedMasa];
                      everyCafeSessionTypes.delete(mappedMasa);
                      everyCafeTimedSessions.delete(mappedMasa);
                      everyCafeScheduledEnds.delete(mappedMasa);
                      everyCafeGiftMinutes.delete(mappedMasa);
                      addLiveLog("everycafe_waiting", `EveryCafe bekleme kaydı temizlendi • Masa ${mappedMasa}`);
                      cb(null, { cleared: true });
                    });
                  });
                }
              );
            }
          );
        });
      });
    }
  );
}

// Eski sürümde bekleme ekranı yanlışlıkla kısa bir offline oturumu gibi
// kapanmışsa ödeme bekliyor ve gelir kaydı bırakabiliyordu. Gerçek müşteri
// daha Windows'a geçmeden 2 dk altında biten bu kayıtlar ücretlendirilemez.
function clearInvalidShortOfflinePendingSessions(cb = () => {}) {
  const maxDuration = 2 * 60 * 1000;
  db.all(
    `SELECT id,masa,session_start
     FROM payments
     WHERE COALESCE(voided,0)=0 AND method='PENDING' AND source='SESSION'
       AND close_reason='OFFLINE_8_MIN' AND session_end>session_start
       AND session_end-session_start<?`,
    [maxDuration],
    (readErr, rows) => {
      if (readErr || !(rows || []).length) return cb(readErr || null, { cleared: 0 });
      let index = 0;
      let cleared = 0;
      const next = () => {
        if (index >= rows.length) return cb(null, { cleared });
        const row = rows[index++];
        db.serialize(() => {
          db.run("BEGIN IMMEDIATE", (beginErr) => {
            if (beginErr) return cb(beginErr);
            const rollback = (err) => db.run("ROLLBACK", () => cb(err));
            db.run("UPDATE payments SET voided=1,voided_at=? WHERE id=?", [Date.now(), row.id], (paymentErr) => {
              if (paymentErr) return rollback(paymentErr);
              db.run("DELETE FROM real_adjustments WHERE masa=? AND session_start=? AND kind='SESSION_FINALIZE'", [row.masa, row.session_start], (adjustErr) => {
                if (adjustErr) return rollback(adjustErr);
                db.run("DELETE FROM session_history WHERE masa=? AND start_time=?", [row.masa, row.session_start], (historyErr) => {
                  if (historyErr) return rollback(historyErr);
                  db.run("COMMIT", (commitErr) => {
                    if (commitErr) return rollback(commitErr);
                    cleared += 1;
                    addLiveLog("everycafe_waiting", `EveryCafe bekleme kaydÄ±ndaki hatalÄ± Ã¶deme temizlendi â€¢ Masa ${row.masa}`);
                    next();
                  });
                });
              });
            });
          });
        });
      };
      next();
    }
  );
}

// EveryCafe bekleme ekranında henüz Sessions kaydı oluşmaz; istemci durumu
// 2'dir. Bu durumda KafePin'in normal ping mekanizmasının açtığı geçici
// oturumu temizler, fakat masa monitörde "Beklemede" olarak kalır.
function readEveryCafeWaitingTables(limit, cb) {
  const source = new sqlite3.Database(EVERYCAFE_DB_PATH, sqlite3.OPEN_READONLY, (openErr) => {
    if (openErr) return cb(openErr);
    source.all(
      `SELECT ClientName,ClientStatus,ClientLastCheck
       FROM Clients
       WHERE COALESCE(ClientStatus,0)=2 AND COALESCE(ClientIsDeleted,0)=0
       ORDER BY ClientName ASC LIMIT ?`,
      [Math.max(1, Math.min(Number(limit) || 100, 200))],
      (readErr, rows) => {
        source.close(() => {});
        if (readErr) return cb(readErr);
        cb(null, (rows || [])
          .map((row) => ({ masa: everyCafeTableNumber(row.ClientName), name: row.ClientName }))
          .filter((row) => row.masa > 0));
      }
    );
  });
}

// Ping akÄ±ÅŸÄ±nda EveryCafe dosyasÄ±nÄ± her seferinde okumamak iÃ§in 3 sn
// Ã¶nbellek kullanÄ±r. Bekleme ekranÄ±nda ilk ping dahi oturum oluÅŸturmaz.
function isEveryCafeClientWaiting(masa, cb) {
  const key = Number(masa);
  const cached = everyCafeWaitingLookupCache.get(key);
  const now = Date.now();
  if (cached && now - cached.checkedAt < 3000) return cb(null, cached.waiting);
  readEveryCafeWaitingTables(100, (readErr, tables) => {
    if (readErr) return cb(readErr);
    const waitingSet = new Set((tables || []).map((row) => Number(row.masa)));
    everyCafeWaitingLookupCache.set(key, { checkedAt: now, waiting: waitingSet.has(key) });
    cb(null, waitingSet.has(key));
  });
}

function setEveryCafeWaitingMasa(masa, now, cb = () => {}) {
  const existing = everyCafeWaitingMasalar.get(masa);
  // Hesap kesilince EveryCafe istemciyi hemen bekleme durumuna geçirir.
  // Kapanış aktarımı en fazla bir senkron turu süreceği için yerel eski
  // oturumu 35 sn korur; monitör bu sırada zaten sadece Beklemede gösterir.
  if (!existing) {
    everyCafeWaitingMasalar.set(masa, { waitingAt: now, clientWaiting: true, cleaned: false });
    return cb(null);
  }
  if (existing.clientWaiting && (existing.cleaned || now - Number(existing.waitingAt || now) < 35 * 1000)) {
    return cb(null);
  }
  everyCafeWaitingMasalar.set(masa, { ...existing, clientWaiting: true, cleaned: true });
  db.serialize(() => {
    db.run("BEGIN IMMEDIATE", (beginErr) => {
      if (beginErr) return cb(beginErr);
      const rollback = (err) => db.run("ROLLBACK", () => cb(err));
      db.run("DELETE FROM sessions WHERE masa=?", [masa], (sessionErr) => {
        if (sessionErr) return rollback(sessionErr);
        db.run("DELETE FROM masalar WHERE masa=?", [masa], (masaErr) => {
          if (masaErr) return rollback(masaErr);
          db.run("COMMIT", (commitErr) => {
            if (commitErr) return rollback(commitErr);
            delete aktifMasalar[masa];
            cb(null);
          });
        });
      });
    });
  });
}

function syncEveryCafeWaitingTables(cb = () => {}) {
  readEveryCafeWaitingTables(100, (readErr, tables) => {
    if (readErr) return cb(readErr);
    const seen = new Set((tables || []).map((row) => Number(row.masa)));
    let index = 0;
    const next = () => {
      if (index >= tables.length) {
        for (const [masa, state] of everyCafeWaitingMasalar.entries()) {
          if (state && state.clientWaiting && !seen.has(masa)) everyCafeWaitingMasalar.delete(masa);
        }
        return cb(null, { waiting: seen.size });
      }
      setEveryCafeWaitingMasa(Number(tables[index++].masa), Date.now(), (setErr) => {
        if (setErr) return cb(setErr);
        next();
      });
    };
    next();
  });
}

function syncEveryCafeActiveSessionsCore(cb = () => {}) {
  getEveryCafeConfig((configErr, config) => {
    if (configErr || !config.enabled || !config.startAt) {
      return cb(configErr || null, { skipped: true, reason: "disabled" });
    }
    readEveryCafeActiveSessions(100, (readErr, sessions) => {
      if (readErr) return cb(readErr);
      const now = Date.now();
      let index = 0;
      let synced = 0;
      const waitingSeen = new Set();
      const next = () => {
        if (index >= sessions.length) {
          for (const masa of everyCafeWaitingMasalar.keys()) {
            const state = everyCafeWaitingMasalar.get(masa);
            if (!waitingSeen.has(masa) && !(state && state.clientWaiting)) everyCafeWaitingMasalar.delete(masa);
          }
          return cb(null, { synced, checked: sessions.length, waiting: waitingSeen.size });
        }
        const sourceSession = sessions[index++];
        const sessionId = String(sourceSession.SessionID);
        const masa = Number(sourceSession.masa);
        const start = Number(sourceSession.start);

        if (!sourceSession.isRunning) {
          everyCafeWaitingMasalar.set(masa, { sessionId, start });
          waitingSeen.add(masa);
          return clearEveryCafeWaitingSession(sourceSession, (waitingErr) => {
            if (waitingErr) return cb(waitingErr);
            return next();
          });
        }

        const saveMapping = () => db.run(
          `INSERT OR REPLACE INTO everycafe_active_sessions(session_id,masa,source_start,last_seen,source_type)
           VALUES(?,?,?,?,?)`,
          [sessionId, masa, start, now, String(sourceSession.SessionTypeText || "")],
          (mapErr) => {
            if (mapErr) return cb(mapErr);
            everyCafeSessionTypes.set(masa, String(sourceSession.SessionTypeText || ""));
            everyCafeWaitingMasalar.delete(masa);
            everyCafeRecentlyClosedMasalar.delete(masa);
            everyCafeTimedSessions.set(masa, Number(sourceSession.EndDate) > Number(sourceSession.StartDate));
            everyCafeScheduledEnds.set(masa, Math.max(0, Number(sourceSession.EndDate) * 1000 || 0));
            everyCafeGiftMinutes.set(masa, everyCafeGiftMinutesFromSource(sourceSession.GiftTime));
            // Çarkın 45 dakikası ve masa kartı, EveryCafe'nin gerçek
            // oturum başlangıcı ile başlar; istemci pinginden türetilmez.
            db.run(
              "INSERT INTO masalar(masa,start_time) VALUES(?,?) ON CONFLICT(masa) DO UPDATE SET start_time=excluded.start_time",
              [masa, start],
              (masaErr) => { if (masaErr) logErr("EveryCafe masalar başlangıç", masaErr); }
            );
            if (isEveryCafeFreeSession(sourceSession)) {
              // EveryCafe'de ücretsiz açılan masa admin panelindeki ücretsiz
              // listesine de anında girer; normal oturum yaratılmaz.
              return db.run(
                "INSERT INTO free_masalar(masa,enabled,set_time) VALUES(?,?,?) ON CONFLICT(masa) DO UPDATE SET enabled=1,set_time=excluded.set_time",
                [masa, 1, now],
                (freeErr) => {
                  if (freeErr) return cb(freeErr);
                  freeMasalar.add(masa);
                  aktifMasalar[masa] = now;
                  db.run("DELETE FROM sessions WHERE masa=?", [masa], (deleteErr) => {
                    if (deleteErr) return cb(deleteErr);
                    synced += 1;
                    next();
                  });
                }
              );
            }
            if (isFreeMasa(masa)) return next();
            db.get("SELECT masa,start_time,end_time FROM sessions WHERE masa=?", [masa], (sessionErr, local) => {
              if (sessionErr) return cb(sessionErr);
              const write = !local || Number(local.end_time) > 0
                ? `INSERT INTO sessions (masa,start_time,last_seen,end_time,final_fee)
                   VALUES (?,?,?,0,0)
                   ON CONFLICT(masa) DO UPDATE SET start_time=excluded.start_time,last_seen=excluded.last_seen,end_time=0,final_fee=0`
                : "UPDATE sessions SET start_time=?, last_seen=CASE WHEN COALESCE(last_seen,0)>? THEN last_seen ELSE ? END, end_time=0, final_fee=0 WHERE masa=?";
              const params = !local || Number(local.end_time) > 0
                ? [masa, start, now]
                : [start, now, now, masa];
              db.run(write, params, (writeErr) => {
                if (writeErr) return cb(writeErr);
                // Monitör ve canlı panelde EveryCafe'de açık olan masa da canlı görünür.
                aktifMasalar[masa] = now;
                importEveryCafeOpenOrders(sourceSession, start, (orderErr) => {
                  if (orderErr) return cb(orderErr);
                  synced += 1;
                  next();
                });
              });
            });
          }
        );
        db.get("SELECT masa FROM everycafe_active_sessions WHERE session_id=?", [sessionId], (previousErr, previous) => {
          if (previousErr) return cb(previousErr);
          const previousMasa = Number(previous && previous.masa) || 0;
          if (!previousMasa || previousMasa === masa) return saveMapping();
          db.get(
            "SELECT session_id FROM everycafe_active_sessions WHERE masa=? AND session_id<>?",
            [masa, sessionId],
            (targetMapErr, targetMap) => {
              if (targetMapErr) return cb(targetMapErr);
              if (targetMap) return cb(new Error(`EveryCafe hedef masa ${masa} için başka açık oturum bildiriyor`));
              transferEveryCafeActiveSession(previousMasa, masa, (transferErr) => {
                if (transferErr) return cb(transferErr);
                saveMapping();
              });
            }
          );
        });
      };
      next();
    });
  });
}

function syncEveryCafeActiveSessions(cb = () => {}) {
  getEveryCafeConfig((configErr, config) => {
    if (configErr || !config.enabled || !config.startAt) {
      return cb(configErr || null, { skipped: true, reason: "disabled" });
    }
    syncEveryCafeWaitingTables((waitingErr) => {
      if (waitingErr) return cb(waitingErr);
      syncEveryCafeActiveSessionsCore(cb);
    });
  });
}

// EveryCafe kapanışında yalnız kapanmış eski oturuma ait çark zamanlayıcısını
// siler. Başka müşteri bu masayı bu arada yeniden açtıysa (start_time > end)
// onun yeni zamanlayıcısına dokunmaz.
function clearClosedEveryCafeMasaTimer(masa, endTime, cb = () => {}) {
  db.run(
    "DELETE FROM masalar WHERE masa=? AND COALESCE(start_time,0)<=?",
    [masa, endTime],
    (err) => {
      if (err) logErr("clearClosedEveryCafeMasaTimer", err);
      cb(err || null);
    }
  );
}

function importEveryCafeDirectSale(session, cb) {
  const sessionId = String(session && session.SessionID || "").trim();
  const end = (Number(session && session.EndDate) || 0) * 1000;
  const total = Math.round((Number(session && session.PaymentAmount) || 0) * 100) / 100;
  const method = everyCafePaymentMethod(session && session.PaymentMethod);
  const orders = (session && session.orders || []).map((order) => ({
    id: String(order.OrderID || "").trim(),
    name: String(order.StockName || "EveryCafe Doğrudan Satış").trim().slice(0, 100),
    quantity: Math.max(1, Number(order.Quantity) || 1),
    price: Math.max(0, Number(order.Price) || 0),
    time: (Number(order.AddDate) || Number(session.EndDate)) * 1000,
    active: Number(order.OrderIsActive) !== 0
  })).filter((order) => order.id && order.price > 0 && order.active);
  const productTotal = Math.round(orders.reduce((sum, order) => sum + order.quantity * order.price, 0) * 100) / 100;

  if (!sessionId || !end || total <= 0 || !["CASH", "CARD"].includes(method)) {
    return cb(null, { skipped: true });
  }
  // İndirim/iade gibi kaynakta farklı bir akış varsa, tahsilatı yanlış yazmak
  // yerine aktarımı durdurup kasa uyarısında görünmesini tercih ederiz.
  if (Math.abs(productTotal - total) > 0.01) {
    return cb(new Error(`EveryCafe Doğrudan Satış ürün toplamı (${productTotal.toFixed(2)} ₺) tahsilattan (${total.toFixed(2)} ₺) farklı`));
  }

  db.get("SELECT 1 AS ok FROM everycafe_imports WHERE session_id=?", [sessionId], (existingErr, existing) => {
    if (existingErr) return cb(existingErr);
    if (existing) return cb(null, { skipped: true });
    db.serialize(() => {
      db.run("BEGIN IMMEDIATE", (beginErr) => {
        if (beginErr) return cb(beginErr);
        let failed = false;
        const fail = (err) => {
          if (failed) return;
          failed = true;
          db.run("ROLLBACK", () => cb(err));
        };
        let index = 0;
        const addOrders = () => {
          if (failed) return;
          if (index >= orders.length) return addPayment();
          const order = orders[index++];
          const orderTotal = Math.round(order.quantity * order.price * 100) / 100;
          const externalId = `DIRECT_ORDER:${order.id}`;
          db.run(
            `INSERT OR IGNORE INTO product_sales
             (time,masa,session_start,product_id,product_name,category,unit_price,quantity,total,sale_type,note,status,finalized_at,payment_method,voided,voided_at,external_source,external_id)
             VALUES (?,0,0,0,?,'EveryCafe Doğrudan Satış',?,?,?,'DIRECT',?,'FINALIZED',?,?,0,0,'EVERYCAFE_DIRECT',?)`,
            [order.time, order.name, order.price, order.quantity, orderTotal,
              `EveryCafe Doğrudan Satış: ${sessionId}`, end, method, externalId],
            (orderErr) => {
              if (orderErr) return fail(orderErr);
              db.run(
                `UPDATE product_sales
                 SET time=?,product_name=?,category='EveryCafe Doğrudan Satış',unit_price=?,quantity=?,total=?,status='FINALIZED',finalized_at=?,payment_method=?,voided=0,voided_at=0
                 WHERE external_source='EVERYCAFE_DIRECT' AND external_id=?`,
                [order.time, order.name, order.price, order.quantity, orderTotal, end, method, externalId],
                (updateErr) => updateErr ? fail(updateErr) : addOrders()
              );
            }
          );
        };
        const addPayment = () => db.run(
          `INSERT INTO payments
           (created_at,paid_at,masa,session_start,session_end,product_sale_id,computer_amount,product_amount,total_amount,method,source,close_reason,note,voided,voided_at,external_source,external_id)
           VALUES (?,?,0,0,0,0,0,?,?,?,'EVERYCAFE_DIRECT','EVERYCAFE_DIRECT',?,0,0,'EVERYCAFE_DIRECT',?)`,
          [end, end, productTotal, total, method, `EveryCafe Doğrudan Satış: ${session.ClientName}`, `DIRECT_SESSION:${sessionId}`],
          (paymentErr) => {
            if (paymentErr) return fail(paymentErr);
            db.run(
              "INSERT INTO everycafe_imports(session_id,masa,source_end,total,imported_at) VALUES(?,?,?,?,?)",
              [sessionId, 0, end, total, Date.now()],
              (importErr) => {
                if (importErr) return fail(importErr);
                db.run("COMMIT", (commitErr) => {
                  if (commitErr) return fail(commitErr);
                  addLiveLog("everycafe_direct_sale", `🧾 EveryCafe doğrudan satış aktarıldı • ${total.toFixed(2)} ₺ • ${method === "CASH" ? "Nakit" : "Kart"}`);
                  cb(null, { imported: true, direct: true, total, method });
                });
              }
            );
          }
        );
        addOrders();
      });
    });
  });
}

function importEveryCafeSession(session, cb) {
  const sessionId = String(session.SessionID || "").trim();
  if (isEveryCafeDirectSaleClient(session.ClientName)) {
    return importEveryCafeDirectSale(session, cb);
  }
  const masa = everyCafeTableNumber(session.ClientName);
  const start = Number(session.StartDate) * 1000;
  const end = Number(session.EndDate) * 1000;
  const total = Math.round((Number(session.PaymentAmount) || 0) * 100) / 100;
  const sourceWasFree = isEveryCafeFreeSession(session);
  if (!sessionId || !masa || !start || !end || total < 0) return cb(null, { skipped: true });

  // Ücretsiz EveryCafe oturumu aktifken KafePin'de normal session
  // oluşturulmadığı için eşleşme aramayız. Kapanışta ücretsiz etiketi ve
  // varsa geçici canlı kaydı doğrudan temizlenir.
  if (sourceWasFree || total === 0) {
    return db.get("SELECT total FROM everycafe_imports WHERE session_id=?", [sessionId], (existingErr, existing) => {
      if (existingErr) return cb(existingErr);
      // Kaynakta saklanan ücretsiz kapanış yalnızca ilk defa temizlenir.
      // Eski kapanış, yeni açılan aynı masayı tekrar etkileyemez.
      if (sourceWasFree && existing && Number(existing.total) === 0) {
        return cb(null, { skipped: true, reason: "already_finalized_free" });
      }
      // Kaynak ücretsiz kapanışı sonradan güncellerse daha önce yanlışlıkla
      // yazılmış tahsilatı da temizle. İşlem idempotenttir: import kaydı zaten
      // 0 olsa bile eski sürümden kalmış history/payment satırları olabilir.
      db.serialize(() => {
        db.run("BEGIN IMMEDIATE");
        // Eski bir ücretsiz kapanış, aynı masada daha sonra açılmış aktif
        // oturumun durumunu silemez.
        let preserveNewerActiveMasa = false;
        const clearFreeStatus = (done) => {
          if (!sourceWasFree) return done(null);
          db.get(
            "SELECT session_id FROM everycafe_active_sessions WHERE masa=? AND source_start>? LIMIT 1",
            [masa, start],
            (newerErr, newerActive) => {
              if (newerErr) return done(newerErr);
              preserveNewerActiveMasa = Boolean(newerActive);
              if (preserveNewerActiveMasa) return done(null);
              db.run("UPDATE free_masalar SET enabled=0,set_time=? WHERE masa=?", [Date.now(), masa], done);
            }
          );
        };
        clearFreeStatus((freeErr) => {
          if (freeErr) return db.run("ROLLBACK", () => cb(freeErr));
          // Kaynak ücretsiz kapatmayı kesin kabul eder. Aynı oturum için daha
          // önce KafePin tarafından oluşturulmuş yerel SESSION ödemesi de varsa
          // onu kaldır; aksi halde kasa kontrolü sahte fark üretir.
          db.run(
            "DELETE FROM payments WHERE (external_source='EVERYCAFE' AND external_id=?) OR (source='SESSION' AND masa=? AND session_start BETWEEN ? AND ?)",
            [`SESSION:${sessionId}`, masa, start - 20 * 60 * 1000, start + 20 * 60 * 1000],
            (paymentErr) => {
            if (paymentErr) return db.run("ROLLBACK", () => cb(paymentErr));
          // EveryCafe'de Ücretsiz Kapat seçildiyse, açık oturumdayken
          // aktarılmış ürünler de satış/ciro kabul edilmeden tamamen silinir.
          db.run("DELETE FROM product_sales WHERE external_source='EVERYCAFE' AND masa=? AND session_start BETWEEN ? AND ?", [masa, start - 20 * 60 * 1000, start + 20 * 60 * 1000], (productErr) => {
            if (productErr) return db.run("ROLLBACK", () => cb(productErr));
            db.run("DELETE FROM sessions WHERE masa=? AND start_time BETWEEN ? AND ?", [masa, start - 20 * 60 * 1000, start + 20 * 60 * 1000], (sessionErr) => {
              if (sessionErr) return db.run("ROLLBACK", () => cb(sessionErr));
              // Eski sürümde yerel kapanış tamamlanmışsa session_history satırı
              // kalmış olabilir. EveryCafe ücretsiz kapatmayı kesin kaynak kabul
              // ettiğinden, aynı başlangıca ait geçmiş ve düzeltmeler de silinir.
              db.run("DELETE FROM session_history WHERE masa=? AND start_time BETWEEN ? AND ?", [masa, start - 20 * 60 * 1000, start + 20 * 60 * 1000], (historyErr) => {
                if (historyErr) return db.run("ROLLBACK", () => cb(historyErr));
                db.run("DELETE FROM real_adjustments WHERE masa=? AND session_start BETWEEN ? AND ?", [masa, start - 20 * 60 * 1000, start + 20 * 60 * 1000], (adjustmentErr) => {
                  if (adjustmentErr) return db.run("ROLLBACK", () => cb(adjustmentErr));
                  db.run("DELETE FROM everycafe_active_sessions WHERE session_id=?", [sessionId], (activeErr) => {
                    if (activeErr) return db.run("ROLLBACK", () => cb(activeErr));
                    if (!preserveNewerActiveMasa) {
                      everyCafeSessionTypes.delete(masa);
                      everyCafeTimedSessions.delete(masa);
                      everyCafeScheduledEnds.delete(masa);
                      everyCafeGiftMinutes.delete(masa);
                    }
                    // EveryCafe ücretsiz kapatılan kaydı kaynakta saklar. Daha
                    // önce 0 olarak işlenmiş kayıt, sunucu açılınca yeni kapanış
                    // gibi monitöre tekrar düşmez. Yalnız ilk gerçek kapanışta
                    // 40 saniyelik kart işareti oluşturulur.
                    const existingClosed = everyCafeRecentlyClosedMasalar.get(masa);
                    const alreadyImportedAsFree = existing && Number(existing.total) === 0;
                    if (!preserveNewerActiveMasa && !alreadyImportedAsFree && (!existingClosed || existingClosed.free !== true)) {
                      everyCafeRecentlyClosedMasalar.set(masa, {
                        closedAt: Date.now(), free: true, timed: false,
                        total: 0, computerTotal: 0, productTotal: 0
                      });
                    }
                    db.run("INSERT INTO everycafe_imports(session_id,masa,source_end,total,imported_at) VALUES(?,?,?,?,?) ON CONFLICT(session_id) DO UPDATE SET masa=excluded.masa,source_end=excluded.source_end,total=0,imported_at=excluded.imported_at", [sessionId, masa, end, 0, Date.now()], (importErr) => {
                      if (importErr) return db.run("ROLLBACK", () => cb(importErr));
                      db.run("COMMIT", (commitErr) => {
                        if (commitErr) return db.run("ROLLBACK", () => cb(commitErr));
                        if (preserveNewerActiveMasa) {
                          aktifMasalar[masa] = Date.now();
                        } else {
                          if (sourceWasFree) freeMasalar.delete(masa);
                          delete aktifMasalar[masa];
                        }
                        addLiveLog("everycafe_import", `🖥️ EveryCafe ücretsiz kapanış • Masa ${masa} ücretsiz listeden çıkarıldı`);
                        clearClosedEveryCafeMasaTimer(masa, end, () => cb(null, { imported: true, masa, total: 0 }));
                      });
                    });
                  });
                });
              });
            });
          });
          });
        });
      });
    });
  }

  findMatchingKafePinSession(masa, start, end, (matchErr, localSession) => {
    if (matchErr) return cb(matchErr);
    // Eşleşme yoksa aktarım yapılmaz: yanlış masa veya çift kayıt riski adminin
    // kontrolü olmadan gelir haline dönüştürülmez.
    if (!localSession) return cb(null, { skipped: true, reason: "no_matching_kafepin_session" });
    const localStart = Number(localSession.start_time) || start;
    db.get("SELECT 1 AS ok FROM everycafe_imports WHERE session_id=?", [sessionId], (existingErr, existing) => {
    if (existingErr) return cb(existingErr);
    if (existing) return cb(null, { skipped: true });

    const orders = (session.orders || []).map((order) => ({
      id: String(order.OrderID || "").trim(),
      name: String(order.StockName || "EveryCafe Ürün").trim().slice(0, 100),
      quantity: Math.max(1, Number(order.Quantity) || 1),
      price: Math.max(0, Number(order.Price) || 0),
      time: (Number(order.AddDate) || Number(session.EndDate)) * 1000,
      active: Number(order.OrderIsActive) !== 0
    })).filter((order) => order.id && order.price > 0 && order.active);
    const rawProductTotal = orders.reduce((sum, order) => sum + order.quantity * order.price, 0);
    if (rawProductTotal > total + 0.01) {
      return cb(new Error(`EveryCafe ürün toplamı (${rawProductTotal.toFixed(2)} ₺) oturum tahsilatından büyük`));
    }
    const productTotal = Math.round(rawProductTotal * 100) / 100;
    const computerTotal = Math.round((total - productTotal) * 100) / 100;
    const method = everyCafePaymentMethod(session.PaymentMethod);

      db.serialize(() => {
        db.run("BEGIN IMMEDIATE");
      let failed = false;
      const fail = (err) => {
        if (failed) return;
        failed = true;
        db.run("ROLLBACK", () => cb(err));
      };
      let index = 0;
      const reconcileLocalSession = () => {
        db.run(
          "UPDATE product_sales SET voided=1,voided_at=? WHERE external_source='EVERYCAFE' AND masa=? AND session_start=? AND voided=0",
          [Date.now(), masa, localStart],
          (productVoidErr) => {
            if (productVoidErr) return fail(productVoidErr);
            db.run(
              "DELETE FROM real_adjustments WHERE masa=? AND session_start=? AND kind='SESSION_FINALIZE'",
              [masa, localStart],
              (adjustDeleteErr) => {
                if (adjustDeleteErr) return fail(adjustDeleteErr);
                db.run(
                  "DELETE FROM session_history WHERE masa=? AND start_time=?",
                  [masa, localStart],
                  (historyDeleteErr) => {
                    if (historyDeleteErr) return fail(historyDeleteErr);
                    db.run(
                      `INSERT INTO real_adjustments(time,day_key,masa,amount,kind,note,session_start)
                       VALUES(?,?,?,?,?,?,?)`,
                      [end, dayKey(end), masa, computerTotal, "SESSION_FINALIZE", "EveryCafe gerçek kapanış", localStart],
                      (adjustInsertErr) => adjustInsertErr ? fail(adjustInsertErr) : addLocalHistory()
                    );
                  }
                );
              }
            );
          }
        );
      };
      const addLocalHistory = () => {
        if (computerTotal <= 0) return addOrder();
        const minutes = Math.max(0, Math.floor((end - localStart) / 60000));
        db.run(
          `INSERT INTO session_history
           (masa,start_time,end_time,last_seen,minutes,fee,adjustment,close_reason,note,created_at)
           VALUES(?,?,?,?,?,?,0,'EVERYCAFE','EveryCafe gerçek kapanış',?)`,
          [masa, localStart, end, end, minutes, computerTotal, Date.now()],
          (historyInsertErr) => historyInsertErr ? fail(historyInsertErr) : addOrder()
        );
      };
      const addOrder = () => {
        if (failed) return;
        if (index >= orders.length) return addPayment();
        const order = orders[index++];
        const orderTotal = Math.round(order.quantity * order.price * 100) / 100;
        db.run(
          `INSERT OR IGNORE INTO product_sales
           (time,masa,session_start,product_id,product_name,category,unit_price,quantity,total,sale_type,note,status,finalized_at,payment_method,voided,voided_at,external_source,external_id)
           VALUES (?,?,?,?,?,?,?,? ,?,'TABLE',?,'FINALIZED',?,?,0,0,'EVERYCAFE',?)`,
          [order.time, masa, localStart, 0, order.name, "EveryCafe", order.price, order.quantity, orderTotal,
            `EveryCafe oturum: ${sessionId}`, end, method, `ORDER:${order.id}`],
          (orderErr) => {
            if (orderErr) return fail(orderErr);
            db.run(
              `UPDATE product_sales
               SET time=?,masa=?,session_start=?,product_name=?,category='EveryCafe',unit_price=?,quantity=?,total=?,status='FINALIZED',finalized_at=?,payment_method=?,voided=0,voided_at=0
               WHERE external_source='EVERYCAFE' AND external_id=?`,
              [order.time, masa, localStart, order.name, order.price, order.quantity, orderTotal, end, method, `ORDER:${order.id}`],
              (updateErr) => updateErr ? fail(updateErr) : addOrder()
            );
          }
        );
      };
      const addPayment = () => {
        db.run(
          `UPDATE product_sales
           SET status='FINALIZED', finalized_at=?, payment_method=?
           WHERE external_source='EVERYCAFE' AND masa=? AND session_start=? AND voided=0`,
          [end, method, masa, localStart],
          (finalizeProductsErr) => {
            if (finalizeProductsErr) return fail(finalizeProductsErr);
        db.run(
          `INSERT INTO payments
           (created_at,paid_at,masa,session_start,session_end,product_sale_id,computer_amount,product_amount,total_amount,method,source,close_reason,note,voided,voided_at,external_source,external_id)
           VALUES (?,?,?,?,?,0,?,?,?,?, 'EVERYCAFE','EVERYCAFE_SYNC',?,0,0,'EVERYCAFE',?)`,
          [end, method === "PENDING" ? 0 : end, masa, localStart, end, computerTotal, productTotal, total, method,
            `EveryCafe: ${session.ClientName}`, `SESSION:${sessionId}`],
          (paymentErr) => {
            if (paymentErr) return fail(paymentErr);
            db.run(
              "INSERT INTO everycafe_imports(session_id,masa,source_end,total,imported_at) VALUES(?,?,?,?,?)",
              [sessionId, masa, end, total, Date.now()],
              (importErr) => {
                if (importErr) return fail(importErr);
                db.run("DELETE FROM sessions WHERE masa=? AND start_time=?", [masa, localStart], (sessionDeleteErr) => {
                  if (sessionDeleteErr) return fail(sessionDeleteErr);
                db.run("DELETE FROM everycafe_active_sessions WHERE session_id=?", [sessionId], (activeDeleteErr) => {
                  if (activeDeleteErr) return fail(activeDeleteErr);
                const recentlyClosedTimed = isEveryCafeTimedMasa(masa);
                everyCafeSessionTypes.delete(masa);
                everyCafeTimedSessions.delete(masa);
                everyCafeScheduledEnds.delete(masa);
                everyCafeGiftMinutes.delete(masa);
                // Monitör sayfası yenilense bile son kapanış tutarı 40 saniye
                // görüntülenebilir. Sonra kart istemci tarafında tamamen gizlenir.
                everyCafeRecentlyClosedMasalar.set(masa, {
                  closedAt: Date.now(),
                  free: false,
                  timed: recentlyClosedTimed,
                  total,
                  computerTotal,
                  productTotal
                });
                db.run("COMMIT", (commitErr) => {
                  if (commitErr) return fail(commitErr);
                  addLiveLog("everycafe_import", `🖥️ EveryCafe doğrulandı ve aktarıldı • Masa ${masa} • ${total.toFixed(2)} ₺ • ${method}`);
                  clearClosedEveryCafeMasaTimer(masa, end, () => cb(null, { imported: true, masa, total }));
                });
                });
                });
              }
            );
          }
        );
          }
        );
      };
      reconcileLocalSession();
    });
  });
  });
}

// EveryCafe'de "bakiye ekle" ile oluşan gerçek üye tahsilatını KafePin'de
// masası olmayan, tahsil edilmiş bir gelir olarak saklar. Oturum aktarımından
// bağımsızdır; böylece EveryCafe raporundaki Üye Gelirleri de toplamda eşleşir.
function importEveryCafeMemberPayment(payment, cb) {
  const historyId = Number(payment && payment.HistoryID) || 0;
  const sourceTime = (Number(payment && payment.PaymentDate) || 0) * 1000;
  const amount = Math.round((Number(payment && payment.PaymentAmount) || 0) * 100) / 100;
  const method = everyCafePaymentMethod(payment && payment.PaymentMethod);
  if (!historyId || !sourceTime || amount <= 0 || !['CASH', 'CARD'].includes(method)) {
    return cb(null, { skipped: true });
  }

  const externalId = `MEMBER_PAYMENT:${historyId}`;
  db.get("SELECT 1 AS ok FROM everycafe_member_imports WHERE history_id=?", [historyId], (existingErr, existing) => {
    if (existingErr) return cb(existingErr);
    if (existing) return cb(null, { skipped: true });
    const noteText = String(payment.Note || '').trim().slice(0, 120);
    const productName = 'EveryCafe Üye Geliri';
    const note = `EveryCafe üye bakiyesi${noteText ? ` • ${noteText}` : ''}`;
    db.serialize(() => {
      db.run("BEGIN IMMEDIATE", (beginErr) => {
        if (beginErr) return cb(beginErr);
        const rollback = (err) => db.run("ROLLBACK", () => cb(err));
        db.run(
          `INSERT INTO product_sales
           (time,masa,session_start,product_id,product_name,category,unit_price,quantity,total,sale_type,note,status,finalized_at,payment_method,voided,voided_at,external_source,external_id)
           VALUES (?,0,0,0,?,'EveryCafe Üye',?,1,?,'DIRECT',?,'FINALIZED',?,?,0,0,'EVERYCAFE_MEMBER',?)`,
          [sourceTime, productName, amount, amount, note, sourceTime, method, externalId],
          function (saleErr) {
            if (saleErr) return rollback(saleErr);
            const saleId = this.lastID;
            db.run(
              `INSERT INTO payments
               (created_at,paid_at,masa,session_start,session_end,product_sale_id,computer_amount,product_amount,total_amount,method,source,close_reason,note,voided,voided_at,external_source,external_id)
               VALUES (?,?,0,0,0,?,0,?,?,?,'EVERYCAFE_MEMBER','MEMBER_BALANCE',?,0,0,'EVERYCAFE_MEMBER',?)`,
              [sourceTime, sourceTime, saleId, amount, amount, method, note, externalId],
              (paymentErr) => {
                if (paymentErr) return rollback(paymentErr);
                db.run(
                  "INSERT INTO everycafe_member_imports(history_id,source_time,amount,imported_at) VALUES(?,?,?,?)",
                  [historyId, sourceTime, amount, Date.now()],
                  (importErr) => {
                    if (importErr) return rollback(importErr);
                    db.run("COMMIT", (commitErr) => {
                      if (commitErr) return rollback(commitErr);
                      addLiveLog("everycafe_member_income", `EveryCafe üye geliri aktarıldı • ${amount.toFixed(2)} ₺ • ${method === 'CASH' ? 'Nakit' : 'Kart'}`);
                      cb(null, { imported: true, amount, method });
                    });
                  }
                );
              }
            );
          }
        );
      });
    });
  });
}

function syncEveryCafeClosedSessions(cb = () => {}) {
  if (everyCafeSyncRunning) return cb(null, { skipped: true, reason: "busy" });
  everyCafeSyncRunning = true;
  getEveryCafeConfig((configErr, config) => {
    if (configErr || !config.enabled || !config.startAt) {
      everyCafeSyncRunning = false;
      return cb(configErr || null, { skipped: true, reason: "disabled" });
    }
    readEveryCafeClosedSessions(config.startAt, 100, (readErr, sessions) => {
      if (readErr) {
        everyCafeSyncRunning = false;
        return cb(readErr);
      }
      let index = 0;
      let imported = 0;
      const next = () => {
        if (index >= sessions.length) {
          return readEveryCafeMemberPayments(config.startAt, 500, (memberReadErr, memberPayments) => {
            if (memberReadErr) {
              everyCafeSyncRunning = false;
              return cb(memberReadErr);
            }
            let memberIndex = 0;
            let memberImported = 0;
            const importNextMember = () => {
              if (memberIndex >= memberPayments.length) {
                return reconcileEveryCafeClosedRewardApprovals((rewardErr, rewardResult) => {
                  everyCafeSyncRunning = false;
                  if (rewardErr) return cb(rewardErr);
                  return cb(null, {
                    imported,
                    checked: sessions.length,
                    memberImported,
                    memberChecked: memberPayments.length,
                    autoApprovedRewards: Number(rewardResult && rewardResult.approved) || 0
                  });
                });
              }
              importEveryCafeMemberPayment(memberPayments[memberIndex++], (memberImportErr, memberResult) => {
                if (memberImportErr) {
                  everyCafeSyncRunning = false;
                  return cb(memberImportErr);
                }
                if (memberResult && memberResult.imported) memberImported += 1;
                importNextMember();
              });
            };
            importNextMember();
          });
        }
        importEveryCafeSession(sessions[index++], (importErr, result) => {
          if (importErr) {
            everyCafeSyncRunning = false;
            return cb(importErr);
          }
          if (result && result.imported) imported += 1;
          next();
        });
      };
      next();
    });
  });
}

app.get("/admin/everycafe/status", (req, res) => {
  setNoStore(res);
  getEveryCafeConfig((configErr, config) => {
    if (configErr) return res.json({ ok: false, error: String(configErr) });
    readEveryCafeClosedSessions(Math.max(config.startAt - 24 * 60 * 60 * 1000, 0), 10, (readErr, sessions) => {
      if (readErr) return res.json({ ok: false, error: `EveryCafe okunamadı: ${readErr.message || readErr}` });
      readEveryCafeActiveSessions(100, (activeErr, activeSessions) => {
        if (activeErr) return res.json({ ok: false, error: `EveryCafe aktif masa okunamadı: ${activeErr.message || activeErr}` });
        const todayStart = dayStartTs(Date.now());
        db.get("SELECT COUNT(*) AS count, MAX(imported_at) AS last_import FROM everycafe_imports", (importErr, imported) => {
          if (importErr) return res.json({ ok: false, error: String(importErr) });
          db.all(
            `SELECT id,time,total,payment_method,note
             FROM product_sales
             WHERE voided=0
               AND (external_source='EVERYCAFE_MEMBER' OR category='EveryCafe Geçmiş Aktarım')
             ORDER BY time DESC,id DESC`,
            (memberErr, memberRows) => {
              if (memberErr) return res.json({ ok: false, error: String(memberErr) });
              const memberList = memberRows || [];
              const memberToday = memberList.filter((row) => Number(row.time) >= todayStart);
              const calendarNow = new Date();
              const memberMonthStart = new Date(calendarNow.getFullYear(), calendarNow.getMonth(), 1, 0, 0, 0, 0).getTime();
              const memberMonth = memberList.filter((row) => Number(row.time) >= memberMonthStart);
              const memberStats = (rows) => ({
                count: rows.length,
                total: Math.round(rows.reduce((sum, row) => sum + (Number(row.total) || 0), 0) * 100) / 100,
                cash: Math.round(rows.filter((row) => String(row.payment_method) === 'CASH').reduce((sum, row) => sum + (Number(row.total) || 0), 0) * 100) / 100,
                card: Math.round(rows.filter((row) => String(row.payment_method) === 'CARD').reduce((sum, row) => sum + (Number(row.total) || 0), 0) * 100) / 100
              });
          db.get(
            `SELECT COUNT(*) AS count, COALESCE(SUM(total_amount),0) AS total,
                    COALESCE(SUM(CASE WHEN method='CASH' THEN total_amount ELSE 0 END),0) AS cash,
                    COALESCE(SUM(CASE WHEN method='CARD' THEN total_amount ELSE 0 END),0) AS card,
                    COALESCE(SUM(product_amount),0) AS product
             FROM payments
             WHERE voided=0 AND created_at>=?
               AND source='EVERYCAFE' AND external_source='EVERYCAFE'`,
            [todayStart],
            (todayErr, today) => {
              if (todayErr) return res.json({ ok: false, error: String(todayErr) });
              db.get(
                `SELECT
                   COALESCE(SUM(CASE WHEN created_at>=? THEN total_amount ELSE 0 END),0) AS today_total,
                   COALESCE(SUM(CASE WHEN created_at>=? AND method='CASH' THEN total_amount ELSE 0 END),0) AS today_cash,
                   COALESCE(SUM(CASE WHEN created_at>=? AND method='CARD' THEN total_amount ELSE 0 END),0) AS today_card,
                   COALESCE(SUM(CASE WHEN created_at>=? THEN 1 ELSE 0 END),0) AS today_count,
                   COALESCE(SUM(total_amount),0) AS all_time_total,
                   COALESCE(SUM(CASE WHEN method='CASH' THEN total_amount ELSE 0 END),0) AS all_time_cash,
                   COALESCE(SUM(CASE WHEN method='CARD' THEN total_amount ELSE 0 END),0) AS all_time_card,
                   COUNT(*) AS all_time_count
                 FROM payments
                 WHERE voided=0 AND source='EVERYCAFE_DIRECT' AND external_source='EVERYCAFE_DIRECT'`,
                [todayStart, todayStart, todayStart, todayStart],
                (directErr, directRow) => {
                  if (directErr) return res.json({ ok: false, error: String(directErr) });
              const statusNow = Date.now();
              const active = (activeSessions || []).map((row) => {
                const masa = everyCafeTableNumber(row.ClientName);
                const start = Number(row.StartDate) * 1000;
                const end = Number(row.EndDate) * 1000;
                const giftMinutes = everyCafeGiftMinutesFromSource(row.GiftTime);
                const productTotal = (row.orders || []).reduce((sum, order) => {
                  if (Number(order.OrderIsActive) === 0) return sum;
                  return sum + (Number(order.Quantity) || 0) * (Number(order.Price) || 0);
                }, 0);
                // Bitiş anında tarifeyi bir sonraki 30 dakikalık basamağa
                // taşımayız. Uzatma varsa EveryCafe EndDate'i büyütür.
                const billedUntil = end > start ? Math.min(statusNow, end - 1) : statusNow;
                // EveryCafe'nin ücretsiz açtığı masa için aktif kartta da
                // bilgisayar ücreti hesaplanmaz. Ürün varsa yalnızca ürün
                // toplamı görünür; kapanış tahsilatı yine EveryCafe kaynağıdır.
                const computerTotal = masa && start && !isEveryCafeFreeSession(row)
                  ? Math.max(feeAtTime(masa, start, billedUntil), 0)
                  : 0;
                return {
                  masa,
                  start,
                  end,
                  free: isEveryCafeFreeSession(row),
                  giftMinutes,
                  computerTotal,
                  productTotal,
                  total: Math.round((computerTotal + productTotal) * 100) / 100,
                  endingSoon: end > statusNow && end - statusNow <= 10 * 60 * 1000
                };
              });
              const activeLiveTotal = Math.round(active.reduce((sum, row) => sum + row.total, 0) * 100) / 100;
              res.json({
                ok: true,
                path: EVERYCAFE_DB_PATH,
                enabled: config.enabled,
                startAt: config.startAt,
                health: {
                  lastSuccess: everyCafeHealth.lastSuccess,
                  lastError: everyCafeHealth.lastError,
                  failureSince: everyCafeHealth.failureSince,
                  warningActive: everyCafeHealth.warningActive,
                  staleSeconds: everyCafeHealth.failureSince
                    ? Math.floor((Date.now() - everyCafeHealth.failureSince) / 1000)
                    : 0
                },
                lastCheck: everyCafeHealth.lastSuccess,
                dailyAudit: lastEveryCafeDailyAudit,
                importedCount: Number(imported && imported.count) || 0,
                lastImport: Number(imported && imported.last_import) || 0,
                activeCount: (activeSessions || []).length,
                today: {
                  count: (Number(today && today.count) || 0) + (Number(directRow && directRow.today_count) || 0) + memberStats(memberToday).count,
                  total: (Number(today && today.total) || 0) + (Number(directRow && directRow.today_total) || 0) + memberStats(memberToday).total,
                  cash: (Number(today && today.cash) || 0) + (Number(directRow && directRow.today_cash) || 0) + memberStats(memberToday).cash,
                  card: (Number(today && today.card) || 0) + (Number(directRow && directRow.today_card) || 0) + memberStats(memberToday).card,
                  product: Number(today && today.product) || 0,
                  sessionTotal: Number(today && today.total) || 0,
                  sessionCash: Number(today && today.cash) || 0,
                  sessionCard: Number(today && today.card) || 0
                },
                directSales: {
                  today: {
                    count: Number(directRow && directRow.today_count) || 0,
                    total: Number(directRow && directRow.today_total) || 0,
                    cash: Number(directRow && directRow.today_cash) || 0,
                    card: Number(directRow && directRow.today_card) || 0
                  },
                  allTime: {
                    count: Number(directRow && directRow.all_time_count) || 0,
                    total: Number(directRow && directRow.all_time_total) || 0,
                    cash: Number(directRow && directRow.all_time_cash) || 0,
                    card: Number(directRow && directRow.all_time_card) || 0
                  }
                },
                memberIncome: {
                  today: memberStats(memberToday),
                  month: memberStats(memberMonth),
                  allTime: memberStats(memberList),
                  recent: memberList.slice(0, 12)
                },
                active: {
                  liveTotal: activeLiveTotal,
                  endingSoonCount: active.filter((row) => row.endingSoon).length,
                  giftedCount: active.filter((row) => row.giftMinutes > 0).length,
                  rows: active
                },
                recent: sessions.map((row) => ({
                  sessionId: row.SessionID,
                  masa: everyCafeTableNumber(row.ClientName),
                  end: Number(row.EndDate) * 1000,
                  method: everyCafePaymentMethod(row.PaymentMethod),
                  freeClosed: !isEveryCafeDirectSaleClient(row.ClientName) && isEveryCafeFreeSession(row),
                  total: (!isEveryCafeDirectSaleClient(row.ClientName) && isEveryCafeFreeSession(row)) ? 0 : (Number(row.PaymentAmount) || 0),
                  productTotal: (!isEveryCafeDirectSaleClient(row.ClientName) && isEveryCafeFreeSession(row)) ? 0 : (row.orders || []).reduce((sum, order) => sum + (Number(order.Quantity) || 0) * (Number(order.Price) || 0), 0)
                }))
              });
                }
              );
            }
          );
            }
          );
        });
      });
    });
  });
});

app.post("/admin/everycafe/start-test", (req, res) => {
  setNoStore(res);
  const startAt = Date.now();
  db.serialize(() => {
    db.run("INSERT INTO settings(key,value) VALUES('everycafe_sync_enabled','1') ON CONFLICT(key) DO UPDATE SET value='1'");
    db.run("INSERT INTO settings(key,value) VALUES('everycafe_sync_start_at',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", [String(startAt)], (err) => {
      if (err) return res.json({ ok: false, error: String(err) });
      addLiveLog("everycafe_test_started", "🧪 EveryCafe canlı test başladı • yalnız bu andan sonraki kapanışlar aktarılacak");
      syncEveryCafeActiveSessions((syncErr, result) => {
        if (syncErr) return res.json({ ok: false, error: `EveryCafe aktif masa okunamadı: ${syncErr.message || syncErr}` });
        res.json({ ok: true, startAt, activeSynced: Number(result && result.synced) || 0 });
      });
    });
  });
});

app.post("/admin/everycafe/stop", (req, res) => {
  setNoStore(res);
  db.run("INSERT INTO settings(key,value) VALUES('everycafe_sync_enabled','0') ON CONFLICT(key) DO UPDATE SET value='0'", (err) => {
    if (err) return res.json({ ok: false, error: String(err) });
    addLiveLog("everycafe_test_stopped", "⏸️ EveryCafe canlı aktarımı durduruldu");
    res.json({ ok: true });
  });
});

app.post("/admin/everycafe/sync-now", (req, res) => {
  setNoStore(res);
  syncEveryCafeClosedSessions((err, result) => {
    if (err) return res.json({ ok: false, error: String(err) });
    syncEveryCafeActiveSessions((activeErr, activeResult) => {
      if (activeErr) return res.json({ ok: false, error: String(activeErr) });
      // Elle yapılan kontrol de bağlantının sağlıklı olduğunu görünür biçimde
      // kaydeder. Böylece arayüzde "son kontrol" anı hemen güncellenir.
      if (!((result && result.reason === "disabled") || (activeResult && activeResult.reason === "disabled"))) {
        recordEveryCafeSyncSuccess();
      }
      res.json({ ok: true, checkedAt: Date.now(), activeSynced: Number(activeResult && activeResult.synced) || 0, ...(result || {}) });
    });
  });
});

// EveryCafe'deki nakit/kart seçimi ve tahsilat tutarı, KafePin'e aktarılmış
// ödeme ile karşılaştırılır. Fark varsa kasa uyarısında görünür.
app.get("/admin/everycafe/payment-audit", (req, res) => {
  setNoStore(res);
  getEveryCafeConfig((configErr, config) => {
    if (configErr) return res.json({ ok: false, error: String(configErr) });
    if (!config.enabled || !config.startAt) return res.json({ ok: true, issues: [] });
    const auditStart = Math.max(dayStartTs(Date.now()) - (6 * 24 * 60 * 60 * 1000), config.startAt);
    readEveryCafeClosedSessions(auditStart, 200, (sourceErr, sourceSessions) => {
      if (sourceErr) return res.json({ ok: false, error: String(sourceErr) });
      db.all(
        `SELECT id,masa,session_start,session_end,total_amount,method,external_id,external_source
         FROM payments
         WHERE voided=0
           AND ((source='EVERYCAFE' AND external_source='EVERYCAFE')
             OR (source='EVERYCAFE_DIRECT' AND external_source='EVERYCAFE_DIRECT'))`,
        (paymentErr, paymentRows) => {
          if (paymentErr) return res.json({ ok: false, error: String(paymentErr) });
          db.all("SELECT session_id FROM everycafe_imports", (importErr, importRows) => {
            if (importErr) return res.json({ ok: false, error: String(importErr) });
            const paymentByExternalId = new Map((paymentRows || []).map((row) => [String(row.external_id || ""), row]));
            const importedIds = new Set((importRows || []).map((row) => String(row.session_id || "")));
            const issues = [];
            (sourceSessions || []).forEach((session) => {
              const sessionId = String(session.SessionID || "");
              const directSale = isEveryCafeDirectSaleClient(session.ClientName);
              // "Ücretsiz Kapat" sonrası EveryCafe eski PaymentAmount değerini
              // saklayabilir. SessionType=20 kesin ücretsiz kapanıştır.
              if (!directSale && isEveryCafeFreeSession(session)) return;
              const local = paymentByExternalId.get(
                directSale
                  ? `DIRECT_SESSION:${sessionId}`
                  : `SESSION:${sessionId}`
              );
              // Aktarım daha önce admin tarafından silindiyse tekrar uyarı üretmeyiz.
              if (!local && importedIds.has(sessionId)) return;
              if (!local) {
                if (Date.now() - Number(session.EndDate || 0) * 1000 < 90 * 1000) return;
                issues.push({
                  code: "EVERYCAFE_MISSING_IMPORT",
                  time: Number(session.EndDate) * 1000,
                  everyCafePaymentId: 0,
                  text: directSale
                    ? "EveryCafe Doğrudan Satış tahsilatı KafePin'e aktarılmamış"
                    : `EveryCafe Masa ${everyCafeTableNumber(session.ClientName)} kapanışı KafePin'e aktarılmamış`
                });
                return;
              }
              const sourceTotal = Math.round((Number(session.PaymentAmount) || 0) * 100) / 100;
              const localTotal = Math.round((Number(local.total_amount) || 0) * 100) / 100;
              const sourceMethod = everyCafePaymentMethod(session.PaymentMethod);
              if (Math.abs(sourceTotal - localTotal) > 0.01) {
                issues.push({
                  code: "EVERYCAFE_TOTAL_MISMATCH",
                  time: Number(session.EndDate) * 1000,
                  everyCafePaymentId: Number(local.id),
                  text: directSale
                    ? `EveryCafe Doğrudan Satış: tahsilat ${sourceTotal.toFixed(2)} ₺, KafePin kaydı ${localTotal.toFixed(2)} ₺`
                    : `EveryCafe Masa ${local.masa}: tahsilat ${sourceTotal.toFixed(2)} ₺, KafePin kaydı ${localTotal.toFixed(2)} ₺`
                });
              }
              if (sourceMethod !== "PENDING" && String(local.method) !== sourceMethod) {
                issues.push({
                  code: "EVERYCAFE_METHOD_MISMATCH",
                  time: Number(session.EndDate) * 1000,
                  everyCafePaymentId: Number(local.id),
                  text: directSale
                    ? `EveryCafe Doğrudan Satış: ödeme ${sourceMethod === "CASH" ? "nakit" : "kart"}, KafePin kaydı ${local.method === "CASH" ? "nakit" : local.method === "CARD" ? "kart" : "bekliyor"}`
                    : `EveryCafe Masa ${local.masa}: ödeme ${sourceMethod === "CASH" ? "nakit" : "kart"}, KafePin kaydı ${local.method === "CASH" ? "nakit" : local.method === "CARD" ? "kart" : "bekliyor"}`
                });
              }
            });
            res.json({ ok: true, issues });
          });
        }
      );
    });
  });
});

// 20:00 kafe günü sınırını geçen EveryCafe kapanışlarını bilgi amaçlı
// bölümlendirir. Tahsilat kaydını bölmez; öncesi + sonrası her zaman
// EveryCafe'nin tek gerçek toplamına eşittir.
app.get("/admin/everycafe/day-splits", (req, res) => {
  setNoStore(res);
  const earliest = Date.now() - (14 * 24 * 60 * 60 * 1000);
  db.all(
    `SELECT id,masa,session_start,session_end,computer_amount,product_amount,total_amount,method
     FROM payments
     WHERE voided=0 AND source='EVERYCAFE' AND external_source='EVERYCAFE'
       AND session_start>0 AND session_end>? 
     ORDER BY session_end DESC LIMIT 30`,
    [earliest],
    (paymentErr, payments) => {
      if (paymentErr) return res.json({ ok: false, error: String(paymentErr) });
      const candidates = (payments || []).filter((payment) => {
        const boundary = dayStartTs(Number(payment.session_end) || 0);
        return Number(payment.session_start) < boundary && boundary < Number(payment.session_end);
      });
      let index = 0;
      const rows = [];
      const next = () => {
        if (index >= candidates.length) return res.json({ ok: true, rows });
        const payment = candidates[index++];
        const masa = Number(payment.masa) || 0;
        const start = Number(payment.session_start) || 0;
        const end = Number(payment.session_end) || 0;
        const boundary = dayStartTs(end);
        const computerTotal = Math.max(Number(payment.computer_amount) || 0, 0);
        // Açılış ücreti sınır öncesine, sonradan gelen basamaklar doğru güne gider.
        const beforeComputer = Math.min(computerTotal, Math.max(feeAtTime(masa, start, boundary), 0));
        const afterComputer = Math.max(computerTotal - beforeComputer, 0);
        db.all(
          `SELECT time,total FROM product_sales
           WHERE voided=0 AND external_source='EVERYCAFE' AND masa=? AND session_start=?`,
          [masa, start],
          (productErr, productRows) => {
            if (productErr) return res.json({ ok: false, error: String(productErr) });
            let beforeProduct = 0;
            let afterProduct = 0;
            (productRows || []).forEach((sale) => {
              if (Number(sale.time) < boundary) beforeProduct += Number(sale.total) || 0;
              else afterProduct += Number(sale.total) || 0;
            });
            // Ürün aktarımının gecikmesi/iptali olsa bile toplamı tahsilatla eşit tut.
            const recordedProduct = Math.max(Number(payment.product_amount) || 0, 0);
            const observedProduct = beforeProduct + afterProduct;
            if (Math.abs(recordedProduct - observedProduct) > 0.01) afterProduct += recordedProduct - observedProduct;
            const before = Math.round((beforeComputer + beforeProduct) * 100) / 100;
            const total = Math.round((Number(payment.total_amount) || 0) * 100) / 100;
            rows.push({
              masa, start, end, boundary,
              before,
              after: Math.round((total - before) * 100) / 100,
              total,
              method: String(payment.method || "PENDING")
            });
            next();
          }
        );
      };
      next();
    }
  );
});

app.get("/admin/product-sales/summary", (req, res) => {
  setNoStore(res);
  const now = Date.now();
  const start = dayStartTs(now);
  const end = start + 24 * 60 * 60 * 1000;
  const monthDate = new Date(now);
  monthDate.setDate(1);
  monthDate.setHours(20, 0, 0, 0);
  const monthStart = monthDate.getTime() > now
    ? new Date(monthDate.getFullYear(), monthDate.getMonth() - 1, 1, 20, 0, 0, 0).getTime()
    : monthDate.getTime();

  db.all(
    `SELECT id,time,masa,session_start,product_id,product_name,category,
            unit_price,quantity,total,sale_type,note,status,payment_method,external_source
     FROM product_sales
     WHERE time>=? AND time<? AND voided=0
     ORDER BY id DESC`,
    [start, end],
    (err, rows) => {
      if (err) return res.json({ ok: false, error: String(err) });
      const list = rows || [];
      const categoryTotals = {};
      const tableTotals = {};
      let total = 0;
      let directTotal = 0;
      let everyCafeDirectTotal = 0;
      let everyCafeMemberTotal = 0;
      let todayQuantity = 0;

      list.forEach((sale) => {
        const amount = Number(sale.total) || 0;
        total += amount;
        todayQuantity += Number(sale.quantity) || 0;
        categoryTotals[sale.category] = (Number(categoryTotals[sale.category]) || 0) + amount;
        if (sale.sale_type === "DIRECT") {
          if (sale.external_source === "EVERYCAFE_DIRECT") everyCafeDirectTotal += amount;
          else if (sale.external_source === "EVERYCAFE_MEMBER") everyCafeMemberTotal += amount;
          else directTotal += amount;
        }
        if (sale.masa > 0 && sale.status === "OPEN") {
          tableTotals[sale.masa] = (Number(tableTotals[sale.masa]) || 0) + amount;
        }
      });

      // Oturum hizmetini ürün ve doğrudan satıştan ayrı tutuyoruz.
      db.get(
        `SELECT COALESCE(SUM(fee),0) AS total
         FROM session_history
         WHERE end_time>=? AND end_time<?`,
        [start, end],
        (sessionErr, sessionRow) => {
          if (sessionErr) return res.json({ ok: false, error: String(sessionErr) });
          const sessionTotal = Number(sessionRow && sessionRow.total) || 0;
      db.all(
        `SELECT masa, COALESCE(SUM(total),0) AS total
         FROM product_sales
         WHERE voided=0 AND sale_type='TABLE' AND status='OPEN' AND masa>0
         GROUP BY masa`,
        (openErr, openRows) => {
          if (openErr) return res.json({ ok: false, error: String(openErr) });

          Object.keys(tableTotals).forEach((masa) => delete tableTotals[masa]);
          (openRows || []).forEach((row) => {
            tableTotals[row.masa] = Number(row.total) || 0;
          });

          // Açık masanın bilgisayar ücreti yalnızca ürün ekranındaki canlı
          // bilgi içindir; kapanmamış oturum kesin gelire dahil edilmez.
          db.all(
            "SELECT masa,start_time FROM sessions WHERE COALESCE(end_time,0)=0",
            (openSessionErr, openSessionRows) => {
              if (openSessionErr) return res.json({ ok: false, error: String(openSessionErr) });
              const openSessionDetails = (openSessionRows || [])
                .map((row) => {
                  const masa = Number(row.masa) || 0;
                  const scheduledEnd = isEveryCafeTimedMasa(masa) ? getEveryCafeScheduledEnd(masa) : 0;
                  const billedUntil = scheduledEnd > Number(row.start_time)
                    ? Math.min(now, scheduledEnd - 1)
                    : now;
                  return {
                    masa,
                    fee: masa > 0 && !isFreeMasa(masa) && !everyCafeWaitingMasalar.has(masa)
                      ? Math.max(0, feeAtTime(masa, row.start_time, billedUntil))
                      : 0
                  };
                })
                .filter((row) => row.masa > 0 && row.fee > 0)
                .sort((a, b) => a.masa - b.masa);
              const openSessionTotal = openSessionDetails.reduce((sum, row) => sum + row.fee, 0);

          db.get(
            `SELECT COALESCE(SUM(total),0) AS total,
                    COALESCE(SUM(quantity),0) AS quantity,
                    COALESCE(SUM(CASE WHEN sale_type='DIRECT' AND COALESCE(external_source,'') NOT IN ('EVERYCAFE_DIRECT','EVERYCAFE_MEMBER') THEN total ELSE 0 END),0) AS all_time_direct_total,
                    COALESCE(SUM(CASE WHEN sale_type='DIRECT' AND COALESCE(external_source,'') NOT IN ('EVERYCAFE_DIRECT','EVERYCAFE_MEMBER') AND time>=? THEN total ELSE 0 END),0) AS month_direct_total,
                    COALESCE(SUM(CASE WHEN sale_type='DIRECT' AND external_source='EVERYCAFE_DIRECT' THEN total ELSE 0 END),0) AS all_time_everycafe_direct_total,
                    COALESCE(SUM(CASE WHEN sale_type='DIRECT' AND external_source='EVERYCAFE_DIRECT' AND time>=? THEN total ELSE 0 END),0) AS month_everycafe_direct_total
             FROM product_sales
             WHERE voided=0`,
            [monthStart, monthStart],
            (allTimeErr, allTimeRow) => {
              if (allTimeErr) return res.json({ ok: false, error: String(allTimeErr) });
              res.json({
                ok: true,
                start,
                end,
                total,
                sessionTotal,
                todayQuantity,
                allTimeTotal: Number(allTimeRow && allTimeRow.total) || 0,
                allTimeQuantity: Number(allTimeRow && allTimeRow.quantity) || 0,
                directTotal,
                everyCafeDirectTotal,
                everyCafeMemberTotal,
                monthDirectTotal: Number(allTimeRow && allTimeRow.month_direct_total) || 0,
                allTimeDirectTotal: Number(allTimeRow && allTimeRow.all_time_direct_total) || 0,
                monthEveryCafeDirectTotal: Number(allTimeRow && allTimeRow.month_everycafe_direct_total) || 0,
                allTimeEveryCafeDirectTotal: Number(allTimeRow && allTimeRow.all_time_everycafe_direct_total) || 0,
                tableTotals,
                openSessionTotal,
                openSessionDetails,
                categoryTotals,
                list: list.slice(0, 100)
              });
            }
          );
            }
          );
        }
      );
        }
      );
    }
  );
});

app.get("/admin/product-sales/list", (req, res) => {
  setNoStore(res);
  const now = Date.now();
  const todayStart = dayStartTs(now);
  const period = String(req.query.period || "today").toLowerCase();
  const rawDate = String(req.query.date || "");
  const rawMonth = String(req.query.month || "");
  // Satış geçmişi kullanıcıya takvim günüyle gösterilir; 20:00 kafe günü
  // sadece gelir raporlarında kullanılır. Böylece 12 Ağustos seçilince
  // 13 Ağustos öğleden sonraki satış yanlışlıkla listeye gelmez.
  const todayCalendarStart = new Date(now);
  todayCalendarStart.setHours(0, 0, 0, 0);
  let start = period === "yesterday"
    ? todayCalendarStart.getTime() - (24 * 60 * 60 * 1000)
    : todayCalendarStart.getTime();
  if (/^\d{4}-\d{2}-\d{2}$/.test(rawDate)) {
    const [year, month, day] = rawDate.split("-").map(Number);
    const selected = new Date(year, month - 1, day, 0, 0, 0, 0).getTime();
    if (Number.isFinite(selected)) start = selected;
  }
  const end = start + (24 * 60 * 60 * 1000);
  let monthStart = new Date(new Date(now).getFullYear(), new Date(now).getMonth(), 1, 0, 0, 0, 0).getTime();
  if (/^\d{4}-\d{2}$/.test(rawMonth)) {
    const [year, month] = rawMonth.split("-").map(Number);
    monthStart = new Date(year, month - 1, 1, 0, 0, 0, 0).getTime();
  }
  const monthEndDate = new Date(monthStart);
  monthEndDate.setMonth(monthEndDate.getMonth() + 1);
  const monthEnd = monthEndDate.getTime();
  // Karşılaştırmanın EveryCafe tarafını kendi kaynak verisinden hesapla.
  // PaymentAmount oturum + sipariş toplamıdır; üye bakiye tahsilatları ise
  // MemberPaymentHistory'dedir. İkisini birleştirince EveryCafe'nin toplam
  // geliri ile KafePin'in masa/ürün/üye geliri aynı mantıkla karşılaştırılır.
  readEveryCafeClosedSessions(0, 200, (sourceErr, sourceSessions) => {
    if (sourceErr) return res.json({ ok: false, error: `EveryCafe okunamadı: ${sourceErr.message || sourceErr}` });
    readEveryCafeMemberPayments(0, 500, (memberSourceErr, memberPayments) => {
      if (memberSourceErr) return res.json({ ok: false, error: `EveryCafe üye geliri okunamadı: ${memberSourceErr.message || memberSourceErr}` });
    const sourceSessionTotalFor = (rangeStart, rangeEnd) => Math.round((sourceSessions || [])
      .filter((row) => {
        const sourceEnd = Number(row.EndDate) * 1000;
        return sourceEnd >= rangeStart && sourceEnd < rangeEnd &&
          !(!isEveryCafeDirectSaleClient(row.ClientName) && isEveryCafeFreeSession(row));
      })
      .reduce((sum, row) => sum + (Number(row.PaymentAmount) || 0), 0) * 100) / 100;
    const sourceMemberTotalFor = (rangeStart, rangeEnd) => Math.round((memberPayments || [])
      .filter((row) => {
        const sourceTime = Number(row.PaymentDate) * 1000;
        return sourceTime >= rangeStart && sourceTime < rangeEnd;
      })
      .reduce((sum, row) => sum + (Number(row.PaymentAmount) || 0), 0) * 100) / 100;
    const sourceTotalFor = (rangeStart, rangeEnd) => Math.round((sourceSessionTotalFor(rangeStart, rangeEnd) + sourceMemberTotalFor(rangeStart, rangeEnd)) * 100) / 100;
  db.all(
    `SELECT id,time,masa,product_name,quantity,total,sale_type,payment_method,external_source
     FROM product_sales
     WHERE time>=? AND time<? AND voided=0
     ORDER BY time DESC,id DESC`,
    [start, end],
    (err, rows) => {
      if (err) return res.json({ ok: false, error: String(err) });
      db.get(
        `SELECT COALESCE(SUM(total_amount),0) AS total
         FROM payments
         WHERE voided=0
           AND ((source='EVERYCAFE' AND external_source='EVERYCAFE')
             OR (source='EVERYCAFE_DIRECT' AND external_source='EVERYCAFE_DIRECT'))
           AND created_at>=? AND created_at<?`,
        [start, end],
        (everyErr, everyRow) => {
          if (everyErr) return res.json({ ok: false, error: String(everyErr) });
          db.get(
            `SELECT
              COALESCE((SELECT SUM(fee) FROM session_history WHERE end_time>=? AND end_time<?),0)
              + COALESCE((SELECT SUM(total) FROM product_sales WHERE voided=0 AND sale_type='TABLE' AND status='FINALIZED' AND time>=? AND time<?),0)
              + COALESCE((SELECT SUM(total) FROM product_sales
                          WHERE voided=0 AND sale_type='DIRECT'
                            AND (external_source='EVERYCAFE_MEMBER' OR external_source='EVERYCAFE_DIRECT' OR category='EveryCafe Geçmiş Aktarım')
                            AND time>=? AND time<?),0)
              AS total`,
            [start, end, start, end, start, end],
            (kafePinErr, kafePinRow) => {
              if (kafePinErr) return res.json({ ok: false, error: String(kafePinErr) });
              const queryEveryCafeTotal = (rangeStart, rangeEnd, cb) => cb(null, { total: sourceTotalFor(rangeStart, rangeEnd) });
              const queryKafePinTotal = (rangeStart, rangeEnd, cb) => db.get(
                `SELECT COALESCE((SELECT SUM(fee) FROM session_history WHERE end_time>=? AND end_time<?),0)
                    + COALESCE((SELECT SUM(total) FROM product_sales WHERE voided=0 AND sale_type='TABLE' AND status='FINALIZED' AND time>=? AND time<?),0)
                    + COALESCE((SELECT SUM(total) FROM product_sales
                                WHERE voided=0 AND sale_type='DIRECT'
                                  AND (external_source='EVERYCAFE_MEMBER' OR external_source='EVERYCAFE_DIRECT' OR category='EveryCafe Geçmiş Aktarım')
                                  AND time>=? AND time<?),0) AS total`,
                [rangeStart, rangeEnd, rangeStart, rangeEnd, rangeStart, rangeEnd], cb);
              queryEveryCafeTotal(monthStart, monthEnd, (monthEveryErr, monthEveryRow) => {
                if (monthEveryErr) return res.json({ ok:false, error:String(monthEveryErr) });
                queryKafePinTotal(monthStart, monthEnd, (monthKafeErr, monthKafeRow) => {
                  if (monthKafeErr) return res.json({ ok:false, error:String(monthKafeErr) });
                  queryEveryCafeTotal(0, Number.MAX_SAFE_INTEGER, (allEveryErr, allEveryRow) => {
                    if (allEveryErr) return res.json({ ok:false, error:String(allEveryErr) });
                    queryKafePinTotal(0, Number.MAX_SAFE_INTEGER, (allKafeErr, allKafeRow) => {
                      if (allKafeErr) return res.json({ ok:false, error:String(allKafeErr) });
                      res.json({
                        ok: true, period, date: rawDate, month: rawMonth, start, end, list: rows || [],
                        everyCafeTotal: sourceTotalFor(start, end),
                        everyCafeSessionTotal: sourceSessionTotalFor(start, end),
                        everyCafeMemberTotal: sourceMemberTotalFor(start, end),
                        kafePinTableTotal: Number(kafePinRow && kafePinRow.total) || 0,
                        monthEveryCafeTotal: Number(monthEveryRow && monthEveryRow.total) || 0,
                        monthKafePinTableTotal: Number(monthKafeRow && monthKafeRow.total) || 0,
                        allTimeEveryCafeTotal: Number(allEveryRow && allEveryRow.total) || 0,
                        allTimeKafePinTableTotal: Number(allKafeRow && allKafeRow.total) || 0
                      });
                    });
                  });
                });
              });
            }
          );
        }
      );
    }
  );
    });
  });
});

app.get("/admin/payment-preview", (req, res) => {
  setNoStore(res);
  const masa = parseInt(req.query.masa, 10) || 0;
  if (masa < 1 || masa > MASA_SAYISI) {
    return res.json({ ok: false, error: "Geçersiz masa" });
  }

  db.get(
    "SELECT * FROM sessions WHERE masa=? AND (end_time=0 OR end_time IS NULL)",
    [masa],
    (sessionErr, session) => {
      if (sessionErr) return res.json({ ok: false, error: String(sessionErr) });
      const now = Date.now();
      const sessionStart = Number(session && session.start_time) || 0;
      const sessionLastSeen = Number(session && session.last_seen) || now;
      const previewEnd = Math.min(now, sessionLastSeen + 15000);
      const baseFee = sessionStart && !isFreeMasa(masa)
        ? Math.max(feeAtTime(masa, sessionStart, previewEnd), 0)
        : 0;

      const loadProducts = (computerAmount) => {
        db.get(
          `SELECT COALESCE(SUM(total),0) AS total
           FROM product_sales
           WHERE masa=? AND sale_type='TABLE' AND status='OPEN' AND voided=0`,
          [masa],
          (productErr, productRow) => {
            if (productErr) return res.json({ ok: false, error: String(productErr) });
            const productAmount = Number(productRow && productRow.total) || 0;
            res.json({
              ok: true,
              masa,
              computerAmount,
              productAmount,
              total: Math.max(computerAmount + productAmount, 0)
            });
          }
        );
      };

      if (!sessionStart || isFreeMasa(masa)) return loadProducts(0);
      db.get(
        `SELECT COALESCE(SUM(amount),0) AS adj
         FROM real_adjustments
         WHERE masa=? AND session_start=?
           AND kind IN ('MANUAL_FEE_ADJUST','ZERO_FEE')`,
        [masa, sessionStart],
        (adjustErr, adjustRow) => {
          if (adjustErr) return res.json({ ok: false, error: String(adjustErr) });
          loadProducts(Math.max(baseFee + (Number(adjustRow && adjustRow.adj) || 0), 0));
        }
      );
    }
  );
});

app.get("/admin/payments/summary", (req, res) => {
  setNoStore(res);
  // Kasa/tahsilat, kullanıcının bankada gördüğü takvim gününü izler.
  // Gelir ve gün sonu raporları ayrı olarak 20:00 kafe günüyle devam eder.
  const currentDate = new Date();
  const start = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()).getTime();
  const end = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + 1).getTime();
  db.all(
    `SELECT * FROM payments
     WHERE voided=0
     ORDER BY id DESC`,
    (err, rows) => {
      if (err) return res.json({ ok: false, error: String(err) });
      const list = rows || [];
      getCardSettlementGroupsFromDb(list, Date.now(), (settlementErr, cardSettlements) => {
        if (settlementErr) return res.json({ ok: false, error: String(settlementErr) });
      const sumMethod = (source, method) => source
        .filter(row => row.method === method)
        .reduce((sum, row) => sum + (Number(row.total_amount) || 0), 0);
      const todayPaid = list.filter(row => {
        const paidTs = Number(row.paid_at) || Number(row.created_at) || 0;
        return row.method !== "PENDING" && paidTs >= start && paidTs < end;
      });
      const todayPendingRows = list.filter(row => {
        const createdTs = Number(row.created_at) || 0;
        return row.method === "PENDING" && createdTs >= start && createdTs < end;
      });
      const pending = list.filter(row => row.method === "PENDING");
      const todayCash = sumMethod(todayPaid, "CASH");
      const todayCard = sumMethod(todayPaid, "CARD");
      const todayPending = sumMethod(todayPendingRows, "PENDING");
      const todayCardCommission = Math.round(
        actualCardCommissionForRange(list, cardSettlements, start, end) * 100
      ) / 100;

      res.json({
        ok: true,
        start,
        end,
        todayCash,
        todayCard,
        todayPending,
        todayCardCommission,
        todayTotal: todayCash + todayCard + todayPending,
        allTimeCash: sumMethod(list, "CASH"),
        allTimeCard: sumMethod(list, "CARD"),
        allTimePending: sumMethod(list, "PENDING"),
        allTimeTotal: list.reduce((sum,row) => sum + (Number(row.total_amount) || 0), 0),
        pendingCount: pending.length,
        pending: pending.slice(0,100),
        recent: list.slice(0,100)
      });
      });
    }
  );
});

app.get("/admin/payments/reconciliation", (req, res) => {
  setNoStore(res);
  const auditStart = dayStartTs(Date.now()) - (6 * 24 * 60 * 60 * 1000);

  db.all(
    `SELECT * FROM payments
     WHERE voided=0 AND created_at>=?
     ORDER BY id DESC`,
    [auditStart],
    (paymentErr, paymentRows) => {
      if (paymentErr) return res.json({ ok: false, error: String(paymentErr) });
      db.all(
        `SELECT * FROM product_sales
         WHERE voided=0 AND time>=?
         ORDER BY id DESC`,
        [auditStart],
        (productErr, productRows) => {
          if (productErr) return res.json({ ok: false, error: String(productErr) });

          const payments = paymentRows || [];
          const sales = productRows || [];
          const issues = [];
          const moneyText = (value) => `${(Number(value) || 0).toFixed(2)} ₺`;
          const directPayments = new Map();
          const everyCafeDirectPayments = new Map();
          const sessionPayments = new Map();
          const everyCafePaymentsBySession = new Map();
          const everyCafePaymentsByEnd = new Map();

          payments.forEach((payment) => {
            const expected = (Number(payment.computer_amount) || 0) + (Number(payment.product_amount) || 0);
            const actual = Number(payment.total_amount) || 0;
            if (Math.abs(expected - actual) > 0.01) {
              issues.push({
                code: "PAYMENT_TOTAL",
                time: Number(payment.created_at) || 0,
                text: `Ödeme #${payment.id} toplamı uyuşmuyor: beklenen ${moneyText(expected)}, kayıt ${moneyText(actual)}`
              });
            }
            if (payment.source === "DIRECT_PRODUCT" && payment.product_sale_id) {
              directPayments.set(Number(payment.product_sale_id), payment);
            }
            if (payment.source === "EVERYCAFE_DIRECT" && payment.external_source === "EVERYCAFE_DIRECT") {
              everyCafeDirectPayments.set(String(payment.external_id || ""), payment);
            }
            if (payment.source === "SESSION") {
              sessionPayments.set(`${Number(payment.masa)}:${Number(payment.session_end)}`, payment);
            }
            if (payment.source === "EVERYCAFE" && Number(payment.masa) > 0) {
              everyCafePaymentsBySession.set(`${Number(payment.masa)}:${Number(payment.session_start)}:${Number(payment.session_end)}`, payment);
              everyCafePaymentsByEnd.set(`${Number(payment.masa)}:${Number(payment.session_end)}`, payment);
            }
          });

          sales.filter((sale) => sale.sale_type === "DIRECT").forEach((sale) => {
            const isEveryCafeDirect = sale.external_source === "EVERYCAFE_DIRECT" ||
              String(sale.category || "").toLocaleLowerCase("tr-TR").includes("everycafe doğrudan") ||
              String(sale.note || "").toLocaleLowerCase("tr-TR").includes("everycafe doğrudan");
            if (isEveryCafeDirect) {
              // EveryCafe doğrudan satışında tek tahsilat birden fazla ürün
              // satırını kapsayabilir. Buradaki ürün bazlı kasa denetimi yerine,
              // payment-audit SessionID üzerinden kaynak tahsilatını denetler.
              // Böylece doğru kayıt için sahte "ödeme yok" uyarısı oluşmaz.
              return;
            }
            const payment = directPayments.get(Number(sale.id));
            if (!payment) {
              const importedEveryCafePayment = payments.find((row) =>
                row.source === "EVERYCAFE_DIRECT" &&
                row.external_source === "EVERYCAFE_DIRECT" &&
                String(row.method) === String(sale.payment_method) &&
                Math.abs((Number(row.product_amount) || 0) - (Number(sale.total) || 0)) <= 0.01 &&
                Math.abs((Number(row.created_at) || 0) - (Number(sale.time) || 0)) <= 10 * 60 * 1000
              );
              if (importedEveryCafePayment) return;
              issues.push({ code: "DIRECT_MISSING", time: Number(sale.time) || 0, text: `${sale.product_name} doğrudan satışı için ödeme kaydı yok` });
              return;
            }
            if (Math.abs((Number(payment.product_amount) || 0) - (Number(sale.total) || 0)) > 0.01) {
              issues.push({ code: "DIRECT_AMOUNT", time: Number(sale.time) || 0, text: `${sale.product_name} satış tutarı ile ödeme tutarı uyuşmuyor` });
            }
            if (String(payment.method) !== String(sale.payment_method)) {
              issues.push({ code: "DIRECT_METHOD", time: Number(sale.time) || 0, text: `${sale.product_name} satışında nakit/kart kaydı uyuşmuyor` });
            }
          });

          const finalizedGroups = new Map();
          sales
            .filter((sale) => sale.sale_type === "TABLE" && sale.status === "FINALIZED" && Number(sale.finalized_at) > 0)
            .forEach((sale) => {
              const key = `${Number(sale.masa)}:${Number(sale.finalized_at)}`;
              const group = finalizedGroups.get(key) || { masa: Number(sale.masa), finalizedAt: Number(sale.finalized_at), total: 0, methods: new Set() };
              group.total += Number(sale.total) || 0;
              group.methods.add(String(sale.payment_method || "PENDING"));
              finalizedGroups.set(key, group);
            });

          finalizedGroups.forEach((group, key) => {
            const payment = sessionPayments.get(key) || everyCafePaymentsByEnd.get(key);
            if (!payment) {
              const everyCafePayment = everyCafePaymentsByEnd.get(key);
              issues.push({
                code: "SESSION_MISSING",
                time: group.finalizedAt,
                text: `Masa ${group.masa} kapanan ürün hesabı için ödeme kaydı yok`,
                everyCafePaymentId: everyCafePayment ? Number(everyCafePayment.id) : 0
              });
              return;
            }
            if (Math.abs((Number(payment.product_amount) || 0) - group.total) > 0.01) {
              issues.push({ code: "SESSION_PRODUCT_AMOUNT", time: group.finalizedAt, text: `Masa ${group.masa} ürün toplamı ile ödeme kaydı uyuşmuyor` });
            }
            if (group.methods.size !== 1 || !group.methods.has(String(payment.method))) {
              issues.push({ code: "SESSION_METHOD", time: group.finalizedAt, text: `Masa ${group.masa} ürünlerinde nakit/kart kaydı uyuşmuyor` });
            }
          });

          db.all(
            `SELECT sh.masa,sh.start_time,sh.end_time,sh.fee
             FROM session_history sh
             WHERE sh.end_time>=? AND sh.fee>0
               -- EveryCafe'in son kapanış kaydı ücretsiz/0 ise, eski yerel
               -- history satırı uyarı üretmez: kaynak sistem kesin doğrudur.
               AND NOT EXISTS (
                 SELECT 1 FROM everycafe_imports ei
                 WHERE ei.masa=sh.masa AND COALESCE(ei.total,0)=0
                   AND ABS(COALESCE(ei.source_end,0)-sh.end_time)<=120000
               )`,
            [auditStart],
            (historyErr, historyRows) => {
              if (historyErr) return res.json({ ok: false, error: String(historyErr) });
              const histories = historyRows || [];
              const sessionPaymentByExactKey = new Map();
              payments.filter(row => row.source === "SESSION").forEach(row => {
                sessionPaymentByExactKey.set(
                  `${Number(row.masa)}:${Number(row.session_start)}:${Number(row.session_end)}`,
                  row
                );
              });

              histories.forEach(history => {
                const key = `${Number(history.masa)}:${Number(history.start_time)}:${Number(history.end_time)}`;
                const payment = sessionPaymentByExactKey.get(key) || everyCafePaymentsBySession.get(key);
                const expected = Math.max(Number(history.fee) || 0, 0);
                if (!payment) {
                  const everyCafePayment = everyCafePaymentsBySession.get(key);
                  issues.push({
                    code: "SESSION_REVENUE_MISSING_PAYMENT",
                    time: Number(history.end_time) || 0,
                    text: `Masa ${history.masa} kapanış geliri ${moneyText(expected)} fakat buna ait ödeme kaydı yok`,
                    everyCafePaymentId: everyCafePayment ? Number(everyCafePayment.id) : 0
                  });
                  return;
                }
                const paidComputer = Number(payment.computer_amount) || 0;
                if (Math.abs(expected - paidComputer) > 0.01) {
                  issues.push({
                    code: "SESSION_REVENUE_AMOUNT",
                    time: Number(history.end_time) || 0,
                    text: `Masa ${history.masa} kapanış geliri ${moneyText(expected)}, ödeme kaydındaki masa geliri ${moneyText(paidComputer)}`
                  });
                }
              });

              const historyKeys = new Set(histories.map(row => `${Number(row.masa)}:${Number(row.start_time)}:${Number(row.end_time)}`));
              payments.filter(row => row.source === "SESSION" && (Number(row.computer_amount) || 0) > 0).forEach(payment => {
                const key = `${Number(payment.masa)}:${Number(payment.session_start)}:${Number(payment.session_end)}`;
                if (!historyKeys.has(key)) {
                  issues.push({
                    code: "PAYMENT_MISSING_SESSION_REVENUE",
                    time: Number(payment.created_at) || 0,
                    text: `Masa ${payment.masa} ödeme kaydında ${moneyText(payment.computer_amount)} masa geliri var fakat eşleşen kapanış kaydı yok`
                  });
                }
              });

              issues.sort((a, b) => b.time - a.time);
              res.json({
                ok: true,
                auditStart,
                checkedPayments: payments.length,
                checkedSales: sales.length,
                checkedSessions: histories.length,
                issueCount: issues.length,
                status: issues.length ? "PROBLEM" : "OK",
                issues: issues.slice(0, 50)
              });
            }
          );
        }
      );
    }
  );
});

// EveryCafe kendi raporunda görünmeyen istisnai bir kapanışı admin onayıyla
// KafePin'den kaldırır. Kaynak EveryCafe veritabanına hiçbir şey yazılmaz.
app.post("/admin/everycafe/void-import", (req, res) => {
  setNoStore(res);
  const paymentId = parseInt((req.body || {}).paymentId, 10) || 0;
  if (!paymentId) return res.json({ ok: false, error: "Geçersiz EveryCafe ödeme kaydı" });
  db.get(
    "SELECT * FROM payments WHERE id=? AND voided=0 AND source='EVERYCAFE' AND external_source='EVERYCAFE'",
    [paymentId],
    (selectErr, payment) => {
      if (selectErr) return res.json({ ok: false, error: String(selectErr) });
      if (!payment) return res.json({ ok: false, error: "EveryCafe aktarım kaydı bulunamadı veya zaten silinmiş" });
      const masa = Number(payment.masa) || 0;
      const sessionStart = Number(payment.session_start) || 0;
      const now = Date.now();
      db.serialize(() => {
        db.run("BEGIN IMMEDIATE");
        const fail = (err) => db.run("ROLLBACK", () => res.json({ ok: false, error: String(err) }));
        db.run("UPDATE payments SET voided=1,voided_at=? WHERE id=? AND voided=0", [now, paymentId], (paymentErr) => {
          if (paymentErr) return fail(paymentErr);
          db.run("UPDATE product_sales SET voided=1,voided_at=? WHERE external_source='EVERYCAFE' AND masa=? AND session_start=? AND voided=0", [now, masa, sessionStart], (productErr) => {
            if (productErr) return fail(productErr);
            db.run("DELETE FROM real_adjustments WHERE masa=? AND session_start=? AND kind='SESSION_FINALIZE'", [masa, sessionStart], (adjustErr) => {
              if (adjustErr) return fail(adjustErr);
              db.run("DELETE FROM session_history WHERE masa=? AND start_time=?", [masa, sessionStart], (historyErr) => {
                if (historyErr) return fail(historyErr);
                db.run("COMMIT", (commitErr) => {
                  if (commitErr) return fail(commitErr);
                  addLiveLog("everycafe_void", `↩️ EveryCafe uyumsuz aktarım silindi • Masa ${masa} • ${Number(payment.total_amount || 0).toFixed(2)} ₺`);
                  res.json({ ok: true, masa, removed: Number(payment.total_amount) || 0 });
                });
              });
            });
          });
        });
      });
    }
  );
});

app.get("/admin/payments/daily-comparison", (req, res) => {
  setNoStore(res);
  const requestedDays = parseInt(req.query.days, 10) || 7;
  const days = Math.max(1, Math.min(requestedDays, 31));
  const dayMs = 24 * 60 * 60 * 1000;
  const currentStart = dayStartTs(Date.now());
  const rangeStart = currentStart - ((days - 1) * dayMs);
  const rangeEnd = currentStart + dayMs;
  const rowsByStart = new Map();

  for (let index = 0; index < days; index += 1) {
    const start = rangeStart + (index * dayMs);
    rowsByStart.set(start, {
      start,
      end: start + dayMs,
      dateLabel: new Date(start).toLocaleDateString("tr-TR", {
        timeZone: "Europe/Istanbul",
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
      }),
      productRevenue: 0,
      productQuantity: 0,
      cash: 0,
      card: 0,
      pending: 0,
      pendingCount: 0,
      collected: 0,
      totalPayments: 0
    });
  }

  db.all(
    `SELECT time, quantity, total
     FROM product_sales
     WHERE voided=0 AND time>=? AND time<?`,
    [rangeStart, rangeEnd],
    (productErr, productRows) => {
      if (productErr) return res.json({ ok: false, error: String(productErr) });
      (productRows || []).forEach((sale) => {
        const row = rowsByStart.get(dayStartTs(Number(sale.time) || 0));
        if (!row) return;
        row.productRevenue += Number(sale.total) || 0;
        row.productQuantity += Number(sale.quantity) || 0;
      });

      db.all(
        `SELECT created_at, paid_at, total_amount, method
         FROM payments
         WHERE voided=0 AND created_at>=? AND created_at<?`,
        [rangeStart, rangeEnd],
        (paymentErr, paymentRows) => {
          if (paymentErr) return res.json({ ok: false, error: String(paymentErr) });
          (paymentRows || []).forEach((payment) => {
            const accountingTs = payment.method === "PENDING"
              ? (Number(payment.created_at) || 0)
              : (Number(payment.paid_at) || Number(payment.created_at) || 0);
            const row = rowsByStart.get(dayStartTs(accountingTs));
            if (!row) return;
            const amount = Number(payment.total_amount) || 0;
            row.totalPayments += amount;
            if (payment.method === "CASH") row.cash += amount;
            else if (payment.method === "CARD") row.card += amount;
            else {
              row.pending += amount;
              row.pendingCount += 1;
            }
          });

          const rows = Array.from(rowsByStart.values())
            .map((row) => ({ ...row, collected: row.cash + row.card }))
            .sort((a, b) => b.start - a.start);
          res.json({ ok: true, days, rows });
        }
      );
    }
  );
});

app.post("/admin/accounting/add", (req, res) => {
  setNoStore(res);
  const body = req.body || {};
  const type = String(body.type || "").trim().toUpperCase();
  const account = String(body.account || "").trim().toUpperCase();
  const method = account === "CASH" ? "CASH" : "CARD";
  const category = String(body.category || "").trim().slice(0, 60);
  const note = String(body.note || "").trim().slice(0, 180);
  const amount = Math.round((Number(body.amount) || 0) * 100) / 100;
  if (!['EXPENSE', 'CAPITAL_IN', 'CAPITAL_OUT'].includes(type)) {
    return res.json({ ok: false, error: "Geçersiz muhasebe kayıt türü" });
  }
  if (!['CASH', 'MAIN_BANK', 'POS_BANK', 'PERSONAL_CARD'].includes(account)) {
    return res.json({ ok: false, error: "Nakit Kasa, Ana Banka veya POS Bankası seç" });
  }
  if (account === 'PERSONAL_CARD' && type !== 'EXPENSE') {
    return res.json({ ok: false, error: "Kişisel Kart Borcu yalnızca gider kaydında kullanılır" });
  }
  if (amount <= 0) return res.json({ ok: false, error: "Tutar 0'dan büyük olmalı" });
  if (!category) return res.json({ ok: false, error: "Kategori yaz" });

  const now = Date.now();
  db.run(
    `INSERT INTO accounting_entries(time,type,category,amount,method,account,note,voided,voided_at)
     VALUES(?,?,?,?,?,?,?,0,0)`,
    [now, type, category, amount, method, account, note],
    function (err) {
      if (err) return res.json({ ok: false, error: String(err) });
      addLiveLog(
        "accounting_entry",
        `${type === 'EXPENSE' ? '🧾 Gider' : type === 'CAPITAL_IN' ? '💼 Sermaye girişi' : '🏦 Sermaye çekişi'} • ${category} • ${amount.toFixed(2)} ₺ • ${account === 'CASH' ? 'Nakit Kasa' : account === 'MAIN_BANK' ? 'Ana Banka' : account === 'POS_BANK' ? 'POS Bankası' : 'Kişisel Kart Borcu'}`
      );
      res.json({ ok: true, id: this.lastID, time: now });
    }
  );
});

app.post("/admin/accounting/void", (req, res) => {
  setNoStore(res);
  const id = parseInt((req.body || {}).id, 10) || 0;
  if (!id) return res.json({ ok: false, error: "Geçersiz kayıt" });
  db.run(
    "UPDATE accounting_entries SET voided=1,voided_at=? WHERE id=? AND voided=0",
    [Date.now(), id],
    function (err) {
      if (err) return res.json({ ok: false, error: String(err) });
      res.json({ ok: this.changes > 0 });
    }
  );
});

app.post("/admin/accounting/update", (req, res) => {
  setNoStore(res);
  const body = req.body || {};
  const id = parseInt(body.id, 10) || 0;
  const type = String(body.type || "").trim().toUpperCase();
  const account = String(body.account || "").trim().toUpperCase();
  const method = account === "CASH" ? "CASH" : "CARD";
  const category = String(body.category || "").trim().slice(0, 60);
  const note = String(body.note || "").trim().slice(0, 180);
  const amount = Math.round((Number(body.amount) || 0) * 100) / 100;
  if (!id) return res.json({ ok: false, error: "Geçersiz kayıt" });
  if (!['EXPENSE', 'CAPITAL_IN', 'CAPITAL_OUT'].includes(type)) {
    return res.json({ ok: false, error: "Geçersiz muhasebe kayıt türü" });
  }
  if (!['CASH', 'MAIN_BANK', 'POS_BANK', 'PERSONAL_CARD'].includes(account)) {
    return res.json({ ok: false, error: "Geçersiz hesap" });
  }
  if (account === 'PERSONAL_CARD' && type !== 'EXPENSE') {
    return res.json({ ok: false, error: "Kişisel Kart Borcu yalnızca gider kaydında kullanılır" });
  }
  if (amount <= 0 || !category) return res.json({ ok: false, error: "Kategori ve geçerli tutar gir" });
  db.run(
    `UPDATE accounting_entries
     SET type=?,category=?,amount=?,method=?,account=?,note=?
     WHERE id=? AND voided=0`,
    [type, category, amount, method, account, note, id],
    function (err) {
      if (err) return res.json({ ok: false, error: String(err) });
      if (!this.changes) return res.json({ ok: false, error: "Kayıt bulunamadı" });
      addLiveLog("accounting_update", `✏️ Muhasebe kaydı #${id} düzenlendi • ${amount.toFixed(2)} ₺`);
      res.json({ ok: true, id });
    }
  );
});

app.get("/admin/accounting/summary", (req, res) => {
  setNoStore(res);
  const now = Date.now();
  const todayStart = dayStartTs(now);
  const todayEnd = todayStart + 24 * 60 * 60 * 1000;
  const monthDate = new Date(now);
  monthDate.setDate(1);
  monthDate.setHours(20, 0, 0, 0);
  const monthStart = monthDate.getTime() > now
    ? new Date(monthDate.getFullYear(), monthDate.getMonth() - 1, 1, 20, 0, 0, 0).getTime()
    : monthDate.getTime();

  db.all(
    "SELECT * FROM accounting_entries WHERE voided=0 ORDER BY id DESC",
    (entryErr, entryRows) => {
      if (entryErr) return res.json({ ok: false, error: String(entryErr) });
      db.all(
        "SELECT * FROM payments WHERE voided=0 ORDER BY id DESC",
        (paymentErr, paymentRows) => {
          if (paymentErr) return res.json({ ok: false, error: String(paymentErr) });
          getCardSettlementGroupsFromDb(paymentRows || [], now, (settlementErr, cardSettlements) => {
            if (settlementErr) return res.json({ ok: false, error: String(settlementErr) });
          db.all(
            "SELECT * FROM account_transfers WHERE voided=0 ORDER BY id DESC",
            (transferErr, transferRows) => {
          if (transferErr) return res.json({ ok: false, error: String(transferErr) });
          const entries = entryRows || [];
          const payments = paymentRows || [];
          const transfers = transferRows || [];
          const entryAccount = row => String(row.account || "").trim() || (row.method === "CASH" ? "CASH" : "MAIN_BANK");
          const sumEntries = (type, account, start = 0, end = Infinity) => entries
            .filter(row => row.type === type && (!account || entryAccount(row) === account) && Number(row.time) >= start && Number(row.time) < end)
            .reduce((sum, row) => sum + (Number(row.amount) || 0), 0);

          let cashReceipts = 0;
          let settledCardGross = 0;
          let settledCardNet = 0;
          let unsettledCardGross = 0;
          let unsettledCardNet = 0;
          let totalCardCommission = 0;
          let nextSettlementAt = 0;
          payments.forEach(payment => {
            const amount = Number(payment.total_amount) || 0;
            if (payment.method === "CASH") cashReceipts += amount;
          });
          cardSettlements.forEach(group => {
            totalCardCommission += Number(group.commission) || 0;
            if (group.settled) {
              settledCardGross += Number(group.gross) || 0;
              settledCardNet += group.confirmed
                ? (Number(group.actualNet) || 0)
                : (Number(group.expectedNet) || 0);
            } else {
              unsettledCardGross += Number(group.gross) || 0;
              unsettledCardNet += Number(group.expectedNet) || 0;
              if (!nextSettlementAt || group.settlementAt < nextSettlementAt) nextSettlementAt = group.settlementAt;
            }
          });

          const capitalCash = sumEntries("CAPITAL_IN", "CASH") - sumEntries("CAPITAL_OUT", "CASH");
          const capitalMainBank = sumEntries("CAPITAL_IN", "MAIN_BANK") - sumEntries("CAPITAL_OUT", "MAIN_BANK");
          const capitalPosBank = sumEntries("CAPITAL_IN", "POS_BANK") - sumEntries("CAPITAL_OUT", "POS_BANK");
          const cashExpenses = sumEntries("EXPENSE", "CASH");
          const mainBankExpenses = sumEntries("EXPENSE", "MAIN_BANK");
          const posBankExpenses = sumEntries("EXPENSE", "POS_BANK");
          const personalCardExpenses = sumEntries("EXPENSE", "PERSONAL_CARD");
          const transferBalance = account => transfers.reduce((sum, row) => {
            const amount = Number(row.amount) || 0;
            if (row.to_account === account) sum += amount;
            if (row.from_account === account) sum -= amount;
            return sum;
          }, 0);
          const cashTransfers = transferBalance("CASH");
          const mainBankTransfers = transferBalance("MAIN_BANK");
          const posBankTransfers = transferBalance("POS_BANK");
          const personalCardRepayments = transferBalance("PERSONAL_CARD");
          const personalCardDebt = Math.max(personalCardExpenses - personalCardRepayments, 0);

          const loadPeriods = () => {
            getRangeStats(todayStart, todayEnd, (todayErr, today) => {
              if (todayErr) return res.json({ ok: false, error: String(todayErr) });
              getRangeStats(monthStart, now + 1, (monthErr, month) => {
                if (monthErr) return res.json({ ok: false, error: String(monthErr) });
                getRangeStats(0, now + 1, (allErr, allTime) => {
                  if (allErr) return res.json({ ok: false, error: String(allErr) });
                  const applyActualCardCommission = (stats, start, end) => {
                    const commission = Math.round(
                      actualCardCommissionForRange(payments, cardSettlements, start, end) * 100
                    ) / 100;
                    stats.kartKomisyonu = commission;
                    stats.netIsletmeSonucu =
                      (Number(stats.gercekGelir) || 0) +
                      (Number(stats.productGeliri) || 0) -
                      (Number(stats.giderler) || 0) - commission;
                  };
                  applyActualCardCommission(today, todayStart, todayEnd);
                  applyActualCardCommission(month, monthStart, now + 1);
                  applyActualCardCommission(allTime, 0, now + 1);
                  res.json({
                    ok: true,
                    cardCommissionRate: CARD_COMMISSION_RATE,
                    cardSettlementDelayHours: CARD_SETTLEMENT_DELAY_MS / 3600000,
                    today,
                    month,
                    allTime,
                    balances: {
                      cash: capitalCash + cashReceipts - cashExpenses + cashTransfers,
                      mainBank: capitalMainBank - mainBankExpenses + mainBankTransfers,
                      posBank: capitalPosBank + settledCardNet - posBankExpenses + posBankTransfers,
                      personalCardDebt,
                      totalAssets:
                        capitalCash + cashReceipts - cashExpenses + cashTransfers +
                        capitalMainBank - mainBankExpenses + mainBankTransfers +
                        capitalPosBank + settledCardNet - posBankExpenses + posBankTransfers +
                        unsettledCardNet,
                      card: capitalMainBank + capitalPosBank + settledCardNet - mainBankExpenses - posBankExpenses,
                      capitalCash,
                      capitalMainBank,
                      capitalPosBank,
                      capitalCard: capitalMainBank + capitalPosBank,
                      cashReceipts,
                      settledCardGross,
                      settledCardNet,
                      unsettledCardGross,
                      unsettledCardNet,
                      totalCardCommission,
                      cashExpenses,
                      mainBankExpenses,
                      posBankExpenses,
                      personalCardExpenses,
                      personalCardRepayments,
                      cashTransfers,
                      mainBankTransfers,
                      posBankTransfers,
                      cardExpenses: mainBankExpenses + posBankExpenses,
                      nextSettlementAt
                    },
                    recent: entries.slice(0, 100),
                    recentTransfers: transfers.slice(0, 100),
                    cardSettlements
                  });
                });
              });
            });
          };
          loadPeriods();
            }
          );
          });
        }
      );
    }
  );
});

app.post("/admin/card-settlements/confirm", (req, res) => {
  setNoStore(res);
  const body = req.body || {};
  const key = String(body.settlementKey || "").trim();
  const actualNet = Math.round((Number(body.actualNet) || 0) * 100) / 100;
  const note = String(body.note || "").trim().slice(0, 160);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(key)) {
    return res.json({ ok: false, error: "Geçersiz kart grubu" });
  }
  if (actualNet <= 0) return res.json({ ok: false, error: "Bankaya geçen net tutarı gir" });

  db.all("SELECT * FROM payments WHERE voided=0 AND method='CARD'", (paymentErr, paymentRows) => {
    if (paymentErr) return res.json({ ok: false, error: String(paymentErr) });
    getCardSettlementGroupsFromDb(paymentRows || [], Date.now(), (groupErr, groups) => {
      if (groupErr) return res.json({ ok: false, error: String(groupErr) });
      const group = (groups || []).find((item) => item.key === key);
      if (!group) return res.json({ ok: false, error: "Kart grubu bulunamadı" });
      if (actualNet > Number(group.gross) + 0.001) {
        return res.json({ ok: false, error: "Net tutar kart toplamından büyük olamaz" });
      }
      const confirmedAt = Date.now();
      db.run(
        `INSERT INTO card_settlements(settlement_key,actual_net,confirmed_at,note)
         VALUES(?,?,?,?)
         ON CONFLICT(settlement_key) DO UPDATE SET
           actual_net=excluded.actual_net, confirmed_at=excluded.confirmed_at, note=excluded.note`,
        [key, actualNet, confirmedAt, note],
        (saveErr) => {
          if (saveErr) return res.json({ ok: false, error: String(saveErr) });
          const commission = Math.max(Number(group.gross) - actualNet, 0);
          addLiveLog("card_settlement_confirmed", `🏦 Kart yatırımı doğrulandı • ${key} • Net ${actualNet.toFixed(2)} ₺ • Komisyon ${commission.toFixed(2)} ₺`);
          res.json({ ok: true, key, gross: group.gross, actualNet, commission, confirmedAt });
        }
      );
    });
  });
});

app.post("/admin/card-settlements/clear", (req, res) => {
  setNoStore(res);
  const key = String((req.body || {}).settlementKey || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(key)) return res.json({ ok: false, error: "Geçersiz kart grubu" });
  db.run("DELETE FROM card_settlements WHERE settlement_key=?", [key], (err) => {
    if (err) return res.json({ ok: false, error: String(err) });
    addLiveLog("card_settlement_cleared", `🏦 Kart yatırımı doğrulaması kaldırıldı • ${key}`);
    res.json({ ok: true });
  });
});

function getLiquidAccountBalances(cb) {
  db.all("SELECT * FROM accounting_entries WHERE voided=0", (entryErr, entryRows) => {
    if (entryErr) return cb(entryErr);
    db.all("SELECT * FROM payments WHERE voided=0", (paymentErr, paymentRows) => {
      if (paymentErr) return cb(paymentErr);
      getCardSettlementGroupsFromDb(paymentRows || [], Date.now(), (settlementErr, cardSettlements) => {
        if (settlementErr) return cb(settlementErr);
      db.all("SELECT * FROM account_transfers WHERE voided=0", (transferErr, transferRows) => {
        if (transferErr) return cb(transferErr);
        const entries = entryRows || [];
        const payments = paymentRows || [];
        const transfers = transferRows || [];
        const entryAccount = row => String(row.account || "").trim() || (row.method === "CASH" ? "CASH" : "MAIN_BANK");
        const entryEffect = account => entries.reduce((sum, row) => {
          if (entryAccount(row) !== account) return sum;
          const value = Number(row.amount) || 0;
          if (row.type === "CAPITAL_IN") return sum + value;
          if (row.type === "CAPITAL_OUT" || row.type === "EXPENSE") return sum - value;
          return sum;
        }, 0);
        const transferEffect = account => transfers.reduce((sum, row) => {
          const value = Number(row.amount) || 0;
          if (row.to_account === account) sum += value;
          if (row.from_account === account) sum -= value;
          return sum;
        }, 0);
        let cashReceipts = 0;
        let settledCardNet = 0;
        const now = Date.now();
        payments.forEach(row => {
          const value = Number(row.total_amount) || 0;
          if (row.method === "CASH") cashReceipts += value;
        });
        cardSettlements.forEach(group => {
          if (group.settled) {
            settledCardNet += group.confirmed
              ? (Number(group.actualNet) || 0)
              : (Number(group.expectedNet) || 0);
          }
        });
        cb(null, {
          CASH: entryEffect("CASH") + transferEffect("CASH") + cashReceipts,
          MAIN_BANK: entryEffect("MAIN_BANK") + transferEffect("MAIN_BANK"),
          POS_BANK: entryEffect("POS_BANK") + transferEffect("POS_BANK") + settledCardNet,
          PERSONAL_CARD: Math.max(-(entryEffect("PERSONAL_CARD") + transferEffect("PERSONAL_CARD")), 0)
        });
      });
      });
    });
  });
}

app.post("/admin/accounting/transfer", (req, res) => {
  setNoStore(res);
  const body = req.body || {};
  const fromAccount = String(body.fromAccount || "").trim().toUpperCase();
  const toAccount = String(body.toAccount || "").trim().toUpperCase();
  const amount = Math.round((Number(body.amount) || 0) * 100) / 100;
  const note = String(body.note || "").trim().slice(0, 180);
  const liquidAccounts = ["CASH", "MAIN_BANK", "POS_BANK"];
  const targetAccounts = [...liquidAccounts, "PERSONAL_CARD"];
  if (!liquidAccounts.includes(fromAccount) || !targetAccounts.includes(toAccount)) return res.json({ ok: false, error: "Geçerli kaynak ve hedef hesap seç" });
  if (fromAccount === toAccount) return res.json({ ok: false, error: "Kaynak ve hedef hesap aynı olamaz" });
  if (amount <= 0) return res.json({ ok: false, error: "Tutar 0'dan büyük olmalı" });
  getLiquidAccountBalances((balanceErr, balances) => {
    if (balanceErr) return res.json({ ok: false, error: String(balanceErr) });
    const available = Math.round((Number(balances[fromAccount]) || 0) * 100) / 100;
    if (amount > available + 0.001) {
      const accountName = fromAccount === "CASH" ? "Nakit Kasa" : fromAccount === "MAIN_BANK" ? "Ana Banka" : "POS Bankası";
      return res.json({ ok: false, code: "INSUFFICIENT_BALANCE", available, error: `${accountName} bakiyesi yetersiz. Kullanılabilir: ${available.toFixed(2)} ₺` });
    }
    if (toAccount === "PERSONAL_CARD" && amount > (Number(balances.PERSONAL_CARD) || 0) + 0.001) {
      return res.json({ ok: false, error: `Kişisel kart borcu yetersiz. Kapatılabilecek: ${(Number(balances.PERSONAL_CARD) || 0).toFixed(2)} ₺` });
    }
    const now = Date.now();
    db.run(
      `INSERT INTO account_transfers(time,from_account,to_account,amount,note,voided,voided_at) VALUES(?,?,?,?,?,0,0)`,
      [now, fromAccount, toAccount, amount, note],
      function (err) {
        if (err) return res.json({ ok: false, error: String(err) });
        addLiveLog("account_transfer", `🔁 Virman • ${amount.toFixed(2)} ₺ • ${fromAccount} → ${toAccount}`);
        res.json({ ok: true, id: this.lastID, time: now, remaining: available - amount });
      }
    );
  });
});

app.post("/admin/accounting/transfer-void", (req, res) => {
  setNoStore(res);
  const id = parseInt((req.body || {}).id, 10) || 0;
  if (!id) return res.json({ ok: false, error: "Geçersiz virman kaydı" });
  db.run(
    "UPDATE account_transfers SET voided=1,voided_at=? WHERE id=? AND voided=0",
    [Date.now(), id],
    function (err) {
      if (err) return res.json({ ok: false, error: String(err) });
      res.json({ ok: true, changed: this.changes || 0 });
    }
  );
});

app.get("/admin/preferences/collapsed-sections", (req, res) => {
  setNoStore(res);
  db.get(
    "SELECT pref_value FROM admin_preferences WHERE pref_key='collapsed_sections'",
    (err, row) => {
      if (err) return res.json({ ok: false, error: String(err) });
      let sections = [];
      try {
        const parsed = JSON.parse((row && row.pref_value) || "[]");
        if (Array.isArray(parsed)) sections = parsed.map(String).slice(0, 100);
      } catch (_err) {}
      res.json({ ok: true, saved: Boolean(row), sections });
    }
  );
});

function backupFileStamp(now = new Date()) {
  const pad = value => String(value).padStart(2, "0");
  return `${pad(now.getDate())}.${pad(now.getMonth() + 1)}.${now.getFullYear()}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`;
}

function cleanupOldFullBackups(keep = 30) {
  const resolvedDir = path.resolve(FULL_BACKUP_DIR);
  const expectedDir = path.resolve("D:\\KAFEPIN_YEDEK\\FULL\\ZIP");
  if (resolvedDir.toUpperCase() !== expectedDir.toUpperCase()) {
    throw new Error("Yedek temizleme klasörü güvenlik kontrolünden geçmedi");
  }
  const files = fs.readdirSync(resolvedDir, { withFileTypes: true })
    .filter(entry => entry.isFile() && /^KafePin_.*\.zip$/i.test(entry.name))
    .map(entry => {
      const fullPath = path.join(resolvedDir, entry.name);
      return { fullPath, mtimeMs: fs.statSync(fullPath).mtimeMs };
    })
    .sort((a, b) => b.mtimeMs - a.mtimeMs);
  const remove = files.slice(Math.max(1, Number(keep) || 30));
  remove.forEach(item => fs.unlinkSync(item.fullPath));
  return remove.length;
}

function snapshotEveryCafeDatabase(destination, cb) {
  const source = new sqlite3.Database(EVERYCAFE_DB_PATH, sqlite3.OPEN_READONLY, (openErr) => {
    if (openErr) return cb(openErr);
    // SQLite'ın kendi yedek mekanizması açık EveryCafe veritabanında da
    // tutarlı bir anlık görüntü oluşturur.
    source.backup(destination, (backupErr) => {
      source.close(() => cb(backupErr || null));
    });
  });
}

function createFullProjectBackup(cb) {
  if (fullBackupRunning) return cb(new Error("Yedekleme zaten devam ediyor"));
  fullBackupRunning = true;
  const startedAt = Date.now();
  let tempDir = "";
  let finished = false;
  const finish = (err, result) => {
    if (finished) return;
    finished = true;
    if (tempDir) {
      try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (_err) {}
    }
    fullBackupRunning = false;
    if (err) {
      lastFullBackup = { ok: false, time: Date.now(), error: String(err.message || err) };
      return cb(err);
    }
    lastFullBackup = { ok: true, ...result };
    cb(null, result);
  };

  try {
    fs.mkdirSync(FULL_BACKUP_DIR, { recursive: true });
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "kafepin-full-backup-"));
  } catch (err) {
    return finish(err);
  }

  const snapshotDb = path.join(tempDir, "database.db");
  db.backup(snapshotDb, (snapshotErr) => {
    if (snapshotErr) return finish(snapshotErr);
    const everyCafeSnapshot = path.join(tempDir, "everycafe.ecm");
    snapshotEveryCafeDatabase(everyCafeSnapshot, (everyCafeErr) => {
      if (everyCafeErr) return finish(new Error(`EveryCafe yedeği alınamadı: ${everyCafeErr.message || everyCafeErr}`));
    const fileName = `KafePin_${backupFileStamp()}.zip`;
    const zipPath = path.join(FULL_BACKUP_DIR, fileName);
    // '.' ile arsivlemek, Edge'in calisan uygulama profilindeki kilitli
    // Sessions dosyalarini da taramaya calisiyordu. Exclude kalibi Windows
    // tar.exe'de her zaman uygulanmadigi icin arsive alinacak kok ogeyi
    // acikca listeliyoruz; profil klasoru hic taranmiyor.
    const excludedRootEntries = new Set([
      "database.db", "database.db-wal", "database.db-shm", ".kafepin-pro-window"
    ]);
    let projectEntries;
    try {
      projectEntries = fs.readdirSync(path.resolve(__dirname), { withFileTypes: true })
        .filter((entry) => !excludedRootEntries.has(entry.name))
        .map((entry) => `./${entry.name}`);
    } catch (readErr) {
      return finish(readErr);
    }
    const args = ["-a", "-cf", zipPath, ...projectEntries, "-C", tempDir, "database.db", "everycafe.ecm"];
    const archive = spawn("tar.exe", args, {
      cwd: path.resolve(__dirname),
      windowsHide: true,
      stdio: ["ignore", "ignore", "pipe"]
    });
    let stderr = "";
    archive.stderr.on("data", chunk => { stderr += String(chunk || "").slice(0, 2000); });
    archive.on("error", finish);
    archive.on("close", code => {
      if (code !== 0) return finish(new Error(stderr.trim() || `ZIP oluşturulamadı (kod ${code})`));
      try {
        const stat = fs.statSync(zipPath);
        let cleanedCount = 0;
        try { cleanedCount = cleanupOldFullBackups(30); } catch (cleanupErr) { logErr("full backup cleanup", cleanupErr); }
        addLiveLog("full_backup", `💾 Tam yedek alındı • KafePin + EveryCafe • ${fileName} • ${(stat.size / 1048576).toFixed(2)} MB`);
        finish(null, {
          time: Date.now(),
          startedAt,
          fileName,
          path: zipPath,
          size: stat.size,
          everyCafeIncluded: true,
          cleanedCount,
          durationMs: Date.now() - startedAt
        });
      } catch (err) {
        finish(err);
      }
    });
    });
  });
}

app.get("/admin/backup/status", (req, res) => {
  setNoStore(res);
  let last = lastFullBackup;
  if (!last && !fullBackupRunning) {
    try {
      const latest = fs.readdirSync(FULL_BACKUP_DIR, { withFileTypes: true })
        .filter(entry => entry.isFile() && entry.name.toLowerCase().endsWith(".zip"))
        .map(entry => {
          const fullPath = path.join(FULL_BACKUP_DIR, entry.name);
          const stat = fs.statSync(fullPath);
          return { ok: true, time: stat.mtimeMs, fileName: entry.name, path: fullPath, size: stat.size, existing: true };
        })
        .sort((a, b) => b.time - a.time)[0];
      if (latest) last = latest;
    } catch (_err) {}
  }
  res.json({ ok: true, running: fullBackupRunning, destination: FULL_BACKUP_DIR, last });
});

app.post("/admin/backup/full", (req, res) => {
  setNoStore(res);
  if (fullBackupRunning) return res.status(409).json({ ok: false, running: true, error: "Yedekleme zaten devam ediyor" });
  addLiveLog("full_backup", "💾 Tam yedekleme baslatildi • KafePin + EveryCafe");
  createFullProjectBackup((err, result) => {
    if (err) {
      addLiveLog("full_backup", `⚠️ Tam yedekleme basarisiz: ${String(err.message || err).slice(0, 180)}`);
      return res.status(500).json({ ok: false, error: String(err.message || err) });
    }
    res.json({ ok: true, ...result });
  });
});

app.post("/admin/preferences/collapsed-sections", (req, res) => {
  setNoStore(res);
  const raw = Array.isArray((req.body || {}).sections) ? req.body.sections : [];
  const sections = [...new Set(raw.map(value => String(value || "").trim()).filter(Boolean))].slice(0, 100);
  const value = JSON.stringify(sections);
  db.run(
    `INSERT INTO admin_preferences(pref_key,pref_value,updated_at) VALUES('collapsed_sections',?,?)
     ON CONFLICT(pref_key) DO UPDATE SET pref_value=excluded.pref_value,updated_at=excluded.updated_at`,
    [value, Date.now()],
    function (err) {
      if (err) return res.json({ ok: false, error: String(err) });
      res.json({ ok: true, sections });
    }
  );
});

app.post("/admin/payments/set-method", (req, res) => {
  setNoStore(res);
  const id = parseInt((req.body || {}).id, 10) || 0;
  const method = normalizePaymentMethod((req.body || {}).method, "");
  if (!id || !["CASH", "CARD"].includes(method)) {
    return res.json({ ok: false, error: "Nakit veya Kart seç" });
  }

  db.get("SELECT * FROM payments WHERE id=? AND voided=0", [id], (selectErr, payment) => {
    if (selectErr) return res.json({ ok: false, error: String(selectErr) });
    if (!payment) return res.json({ ok: false, error: "Ödeme bulunamadı" });
    db.run(
      "UPDATE payments SET method=?,paid_at=? WHERE id=? AND voided=0",
      [method, Date.now(), id],
      (err) => {
        if (err) return res.json({ ok: false, error: String(err) });
        if (payment.source === "SESSION") {
          db.run(
            `UPDATE product_sales SET payment_method=?
             WHERE masa=? AND finalized_at=? AND voided=0`,
            [method, payment.masa, payment.session_end],
            (productErr) => logErr("set payment method product_sales", productErr)
          );
        } else if (payment.source === "DIRECT_PRODUCT" && payment.product_sale_id) {
          db.run(
            `UPDATE product_sales SET payment_method=?
             WHERE id=? AND voided=0`,
            [method, payment.product_sale_id],
            (productErr) => logErr("set direct payment method product_sales", productErr)
          );
        }
        addLiveLog(
          "payment_method",
          `💳 Masa ${payment.masa || "-"} ödeme ${method === "CASH" ? "NAKİT" : "KART"} yapıldı • ${Number(payment.total_amount).toFixed(2)} ₺`
        );
        res.json({ ok: true, id, method });
      }
    );
  });
});

app.get("/admin/free-masalar", (req, res) => {
  setNoStore(res);
  res.json({ ok: true, list: Array.from(freeMasalar) });
});

app.post("/admin/free-masa", (req, res) => {
  setNoStore(res);

  const masa = parseInt((req.body || {}).masa, 10);
  const enabled = (req.body || {}).enabled ? 1 : 0;

  if (!masa || masa < 1 || masa > MASA_SAYISI) {
    return res.json({ ok: false, error: "Geçersiz masa" });
  }

  const now = Date.now();

  const saveFreeState = () => {
    db.run(
      "INSERT INTO free_masalar(masa,enabled,set_time) VALUES(?,?,?) ON CONFLICT(masa) DO UPDATE SET enabled=excluded.enabled, set_time=excluded.set_time",
      [masa, enabled, now],
      (err) => {
        if (err) return res.json({ ok: false, error: String(err) });

        if (enabled === 1) {
          freeMasalar.add(masa);
          addLiveLog("free_on", `🟢 Masa ${masa} ücretsiz yapıldı`);
        } else {
          freeMasalar.delete(masa);
          addLiveLog("free_off", `🟠 Masa ${masa} ücretsiz kaldırıldı`);
        }

        return res.json({ ok: true, masa, enabled: enabled === 1 });
      }
    );
  };

  // Ücretli aktif oturumu, masa FREE olarak işaretlenmeden önce kapat.
  if (enabled === 1 && !isFreeMasa(masa)) {
    return db.get("SELECT * FROM sessions WHERE masa=?", [masa], (selectErr, row) => {
      if (selectErr) {
        return res.json({ ok: false, error: String(selectErr) });
      }

      if (row && (!row.end_time || row.end_time === 0)) {
        return finalizeEndedSessionToAdjustments(
          { ...row, end_time: now },
          now,
          (finalizeErr) => {
            if (finalizeErr) {
              return res.json({ ok: false, error: String(finalizeErr) });
            }
            return saveFreeState();
          }
        );
      }

      return saveFreeState();
    });
  }

  return saveFreeState();
});

app.post("/admin/fee-zero", (req, res) => {
  setNoStore(res);

  const masa = parseInt((req.body || {}).masa, 10);
  if (!masa || masa < 1 || masa > MASA_SAYISI) {
    return res.json({ ok: false, error: "Geçersiz masa" });
  }

  if (isFreeMasa(masa)) {
    return res.json({ ok: true, masa, amount: 0, msg: "Masa FREE, zaten 0₺." });
  }

  const now = Date.now();
  const dk = dayKey(now);

  db.get("SELECT * FROM sessions WHERE masa=?", [masa], (eS, s) => {
    let fee = 0;

    if (s) {
      const end = s.end_time && s.end_time > 0 ? s.end_time : s.last_seen || now;
fee =
  s.end_time && s.end_time > 0
    ? Number(s.final_fee) || feeAtTime(masa, s.start_time || end, end)
    : feeAtTime(masa, s.start_time || end, end);
    }

    const sessStart = s && s.start_time ? s.start_time : 0;

    db.get(
      "SELECT COALESCE(SUM(amount),0) AS adj FROM real_adjustments WHERE day_key=? AND masa=? AND session_start=? AND kind IN ('MANUAL_FEE_ADJUST','ZERO_FEE')",
      [dk, masa, sessStart],
      (eA, rA) => {
        const adj = Number((rA || {}).adj) || 0;
        const feeAdj = Math.max(fee + adj, 0);

        if (feeAdj <= 0) {
          return res.json({ ok: true, masa, amount: 0, msg: "Zaten 0₺." });
        }

        const amount = -feeAdj;
        const note = `Masa ${masa} ücret 0 yapıldı`;

        db.run(
          "INSERT INTO real_adjustments(time, day_key, masa, amount, kind, note, session_start) VALUES(?,?,?,?,?,?,?)",
          [now, dk, masa, amount, "ZERO_FEE", note, sessStart],
          function (err) {
            if (err) return res.json({ ok: false, error: String(err) });
            return res.json({ ok: true, masa, amount });
          }
        );
      }
    );
  });
});

app.post("/admin/session-reset", (req, res) => {
  setNoStore(res);
  return requireEveryCafeMaintenance(res, () => {

  const masa = parseInt((req.body || {}).masa, 10);
  if (!masa || masa < 1 || masa > MASA_SAYISI) {
    return res.json({ ok: false, error: "Geçersiz masa" });
  }

  autoApprovePendingRewardsForMasa(masa, "session reseti", (approveErr) => {
    if (approveErr) {
      return res.json({
        ok: false,
        error: "Bekleyen ödül otomatik onaylanamadı: " + String(approveErr)
      });
    }

    const now = Date.now();

    db.get("SELECT * FROM sessions WHERE masa=?", [masa], (e1, row) => {
      if (e1) return res.json({ ok: false, error: String(e1) });

const nextStep = () => {
  clearForceNewSession(masa, () => {
    db.run("DELETE FROM masalar WHERE masa=?", [masa], (err) => {

      logErr("/admin/reset-masa delete masalar", err);

      if (!err) {
        addLiveLog(
          "reset",
          `🔄 Masa ${masa} sıfırlandı`
        );
      }

      return res.json({ ok: true, masa });
    });
  });
};

      if (row && (!row.end_time || row.end_time === 0)) {
        return finalizeEndedSessionToAdjustments({ ...row, end_time: now }, now, (err) => {
          if (err) return res.json({ ok: false, error: String(err) });
          nextStep();
        });
      }

      return nextStep();
    });
  });
  });
});

app.post("/admin/hard-reset-masa", (req, res) => {
  setNoStore(res);
  return requireEveryCafeMaintenance(res, () => {

  const masa = parseInt((req.body || {}).masa, 10);
  if (!masa || masa < 1 || masa > MASA_SAYISI) {
    return res.json({ ok: false, error: "Geçersiz masa" });
  }

  autoApprovePendingRewardsForMasa(
    masa,
    "tam temizleme",
    (approveErr, approvedRewards) => {
      if (approveErr) {
        return res.json({
          ok: false,
          error:
            "Bekleyen ödül otomatik onaylanamadığı için tam temizleme durduruldu: " +
            String(approveErr)
        });
      }

  db.serialize(() => {
    db.run("BEGIN IMMEDIATE TRANSACTION", (e0) => {
      if (e0) return res.json({ ok: false, error: String(e0) });

      db.run("DELETE FROM masalar WHERE masa=?", [masa], (e1) => {
        if (e1) {
          db.run("ROLLBACK");
          return res.json({ ok: false, error: String(e1) });
        }

        db.run("DELETE FROM sessions WHERE masa=?", [masa], (e2) => {
          if (e2) {
            db.run("ROLLBACK");
            return res.json({ ok: false, error: String(e2) });
          }

          db.run("DELETE FROM session_locks WHERE masa=?", [masa], (e3) => {
            if (e3) {
              db.run("ROLLBACK");
              return res.json({ ok: false, error: String(e3) });
            }

            db.run("DELETE FROM force_new_sessions WHERE masa=?", [masa], (e4) => {
              if (e4) {
                db.run("ROLLBACK");
                return res.json({ ok: false, error: String(e4) });
              }

              db.run("DELETE FROM spins WHERE masa=?", [masa], (e5) => {
                if (e5) {
                  db.run("ROLLBACK");
                  return res.json({ ok: false, error: String(e5) });
                }

                db.run(
                  `UPDATE product_sales
                   SET voided=1, voided_at=?
                   WHERE masa=? AND sale_type='TABLE' AND status='OPEN' AND voided=0`,
                  [Date.now(), masa],
                  (productVoidErr) => {
                    if (productVoidErr) {
                      db.run("ROLLBACK");
                      return res.json({ ok: false, error: String(productVoidErr) });
                    }

                    // RAM temizliği
                    delete aktifMasalar[masa];
                    delete masaPingStats[masa];
                    delete latestRewardMap[masa];
                    offlineCount[masa] = 0;
                    lastOfflineState[masa] = false;
                    delete masaCloseLocks[masa];
                    sessionLocks.delete(masa);
                    blockedMasalar.delete(masa);
                    delete tokenTracker[masa];

                    db.run("DELETE FROM blocked_masalar WHERE masa=?", [masa], (e6) => {
                      if (e6) {
                        db.run("ROLLBACK");
                        return res.json({ ok: false, error: String(e6) });
                      }

                      db.run("COMMIT", (e7) => {
                        if (e7) {
                          db.run("ROLLBACK");
                          return res.json({ ok: false, error: String(e7) });
                        }

                        return res.json({
                          ok: true,
                          masa,
                          msg: "Masa tamamen temizlendi; açık ürün hesabı iptal edildi",
                          autoApprovedRewards: (approvedRewards || []).map((x) => ({
                            reward: x.reward,
                            costApplied: x.costApplied
                          }))
                        });
                      });
                    });
                  }
                );
              });
            });
          });
        });
      });
    });
  });
    }
  );
  });
});

function closePrepare(masa, res, paymentMethod) {
  autoApprovePendingRewardsForMasa(masa, "masa kapanışı", (approveErr, approvedRewards) => {
    if (approveErr) {
      return res.json({
        ok: false,
        error: "Bekleyen ödül otomatik onaylanamadı: " + String(approveErr)
      });
    }

    const now = Date.now();

    setLock(masa, now + LOCK_MS);

    finalizeAndPrepareSession(masa, now, (err, _closed, paymentInfo) => {
      if (err) {
        return res.json({ ok: false, error: String(err) });
      }

      const sendSuccess = () => res.json({
          ok: true,
          masa,
          lockedMs: LOCK_MS,
          freeModeRemoved: !isFreeMasa(masa),
          payment: paymentInfo || null,
          autoApprovedRewards: (approvedRewards || []).map((x) => ({
            reward: x.reward,
            costApplied: x.costApplied
          }))
        });

      // Ücretsiz test masasında YENİ MÜŞTERİ denirse ayrıca Kapat'a basmak
      // gerekmesin: temizlik tamamlandıktan sonra ücretsiz işaretini de kaldır.
      if (!isFreeMasa(masa)) return sendSuccess();

      db.run(
        "UPDATE free_masalar SET enabled=0, set_time=? WHERE masa=?",
        [Date.now(), masa],
        (disableErr) => {
          if (disableErr) {
            logErr("new customer disable free masa", disableErr);
            return res.json({ ok: false, error: String(disableErr) });
          }

          freeMasalar.delete(masa);
          addLiveLog(
            "free_new_customer_close",
            `🔵 Masa ${masa} yeni müşteri işlemiyle ücretsiz moddan çıkarıldı`
          );
          return sendSuccess();
        }
      );
    }, {
      paymentMethod: normalizePaymentMethod(paymentMethod, "PENDING"),
      closeReason: "NEW_CUSTOMER"
    });
  });
}


app.post("/admin/new-customer", (req, res) => {
  setNoStore(res);
  return requireEveryCafeMaintenance(res, () => {
  const masa = parseInt((req.body || {}).masa, 10);
  if (!masa || masa < 1 || masa > MASA_SAYISI) return res.json({ ok: false, error: "Geçersiz masa" });
  const paymentMethod = normalizePaymentMethod((req.body || {}).paymentMethod, "PENDING");
  closePrepare(masa, res, paymentMethod);
  });
});

app.get("/admin/sessions", (req, res) => {
  setNoStore(res);

  const now = Date.now();
  const dk = dayKey(now);

  db.all("SELECT * FROM sessions", (err, rows) => {
    if (err) {
      logErr("/admin/sessions select sessions", err);
      return res.json([]);
    }

    const map = {};
    (rows || []).forEach((r) => (map[r.masa] = r));

    db.all(
      `
      SELECT masa, session_start, COALESCE(SUM(amount),0) as adj
      FROM real_adjustments
      WHERE day_key=?
        AND kind IN ('MANUAL_FEE_ADJUST','ZERO_FEE')
      GROUP BY masa, session_start
      `,
      [dk],
      (eAdj, adjRows) => {
        if (eAdj) {
          logErr("/admin/sessions select adjustments", eAdj);
          return res.json([]);
        }

const adjMap = {};

(adjRows || []).forEach((r) => {
  adjMap[`${r.masa}:${r.session_start}`] = Number(r.adj) || 0;
});

        const out = [];

        for (let masa = 1; masa <= MASA_SAYISI; masa++) {
          if (isFreeMasa(masa)) {
            const lastSeen = aktifMasalar[masa] || 0;
            const online = !isActuallyOffline(masa, lastSeen, now);

            out.push({
              masa,
              online,
              started: false,
              minutes: 0,
              fee: 0,
              free: 1,
              adj: 0,
              feeAdj: 0,
              zeroed: 0,
              start_time: 0,
              last_seen: lastSeen || 0,
              end_time: 0,
              final_fee: 0
            });
            continue;
          }

          const s = map[masa];

          if (!s) {
            const lastSeen = aktifMasalar[masa] || 0;
            const online = !isActuallyOffline(masa, lastSeen, now);

            out.push({
              masa,
              online,
              started: online ? 1 : 0,
              minutes: 0,
              fee: 0,
              free: 0,
              adj: 0,
              feeAdj: 0,
              zeroed: 0,
              start_time: online ? lastSeen : 0,
              last_seen: lastSeen || 0,
              end_time: 0,
              final_fee: 0
            });
            continue;
          }

          let online = false;
          if (!s.end_time || s.end_time === 0) {
const ls = aktifMasalar[masa] || 0;
online = !isActuallyOffline(masa, ls, now);
          }

          const end =
            s.end_time && s.end_time > 0
              ? s.end_time
              : s.last_seen || now;

          let minutes = Math.floor((end - (s.start_time || end)) / 60000);
          if (minutes < 0) minutes = 0;

        const fee =
  s.end_time && s.end_time > 0
    ? Number(s.final_fee) || feeAtTime(masa, s.start_time || end, end)
    : feeAtTime(masa, s.start_time || end, end);

          const sessStart = s && s.start_time ? s.start_time : 0;
          const adj = adjMap[`${masa}:${sessStart}`] || 0;
          const feeAdj = Math.max(fee + adj, 0);

          const zeroed = feeAdj === 0 && adj < 0 ? 1 : 0;

          out.push({
            masa,
            online,
            started: true,
            start_time: s.start_time || aktifMasalar[masa] || 0,
            last_seen: s.last_seen || aktifMasalar[masa] || 0,
            end_time: s.end_time || 0,
            minutes,
            fee,
            free: 0,
            adj,
            feeAdj,
            zeroed,
            final_fee: Number(s.final_fee) || 0
          });
        }

        return res.json(out);
      }
    );
  });
});

app.get("/admin/stats", (req, res) => {
  setNoStore(res);

  const now = Date.now();
  const todayKeyStr = dayKey(now);
  const todayStart = dayStartTs(now);
  const yesterdayStart = todayStart - 24 * 60 * 60 * 1000;
  const weekStart = todayStart - 6 * 24 * 60 * 60 * 1000;
const d = new Date(now);

const monthStart = new Date(
  d.getFullYear(),
  d.getMonth(),
  1
).getTime();

  db.all("SELECT * FROM spins_log", (err, rows) => {
    if (err) {
      logErr("/admin/stats spins_log", err);
      return res.status(500).json({ ok: false });
    }
    if (!rows) rows = [];

    let toplam = rows.length;
    let bugunToplam = 0;
    let bugunOnaylananOdul = 0;
    let icecek = 0;
    let dakika = 0;
    let vipSpin = 0;
    let normalSpin = 0;
    let toplamMaliyet = 0;
    let bugunMaliyet = 0;
    let gelir = 0;
    let bugunGelir = 0;

    rows.forEach((s) => {
      const reward = (s.reward || "").toLowerCase();
      const isToday = dayKey(s.time) === todayKeyStr;
      const pricing = getPricingForTs(s.masa, s.time || now);

      if (isToday) bugunToplam++;
      if (
        isToday &&
        Number(s.used) === 1 &&
        !BOS_ODULLER.includes(String(s.reward || "").trim().toLocaleLowerCase("tr-TR"))
      ) {
        bugunOnaylananOdul++;
      }

      if (pricing.isVip) vipSpin++;
      else normalSpin++;

      gelir += pricing.opening;
if (isToday) bugunGelir += pricing.opening;


if (reward.includes("dakika")) {
  dakika++;

  const m = reward.match(/(\d+)\s*dakika/);
  const dkVal = m ? parseInt(m[1], 10) : 0;

  let maliyet = 0;

  if (pricing.weekend) {
    if (pricing.isVip) {
      if (dkVal === 30) maliyet = 35;
      else if (dkVal === 60) maliyet = 70;
    } else {
      if (dkVal === 30) maliyet = 25;
      else if (dkVal === 60) maliyet = 50;
    }
  } else {
    if (pricing.isVip) {
      if (dkVal === 30) maliyet = 30;
      else if (dkVal === 60) maliyet = 60;
    } else {
      if (dkVal === 30) maliyet = 20;
      else if (dkVal === 60) maliyet = 40;
    }
  }

  toplamMaliyet += maliyet;
  if (isToday) bugunMaliyet += maliyet;
}


      if (
        reward.includes("kola") ||
        reward.includes("çay") ||
        reward.includes("soda") ||
        reward.includes("crax") ||
        reward.includes("gofret") ||
        reward.includes("enerji")
      ) {
        icecek++;
        toplamMaliyet += ICECEK_MALIYET;
        if (isToday) bugunMaliyet += ICECEK_MALIYET;
      }
    });

    const kar = gelir - toplamMaliyet;
    const bugunKar = bugunGelir - bugunMaliyet;

    db.all("SELECT * FROM sessions", (err2, sessions) => {
      if (err2) {
        logErr("/admin/stats sessions", err2);
        return res.status(500).json({ ok: false });
      }
      if (!sessions) sessions = [];

      const activeSessions = (sessions || []).filter((s) => !s.end_time || s.end_time === 0);

      const liveRealBrutGelir = sumRealRevenueInRangeFromSessions(activeSessions, 0, now, now);
      const liveBugunRealBrutGelir = sumRealRevenueInRangeFromSessions(activeSessions, todayStart, now, now);
      const liveDunRealBrutGelir = sumRealRevenueInRangeFromSessions(activeSessions, yesterdayStart, todayStart, now);
      const liveHaftaRealBrutGelir = sumRealRevenueInRangeFromSessions(activeSessions, weekStart, now, now);
      const liveAyRealBrutGelir = sumRealRevenueInRangeFromSessions(activeSessions, monthStart, now, now);

      db.all("SELECT time, amount, kind, masa, session_start FROM real_adjustments", (eAdj, adjRows) => {
        if (eAdj) {
          logErr("/admin/stats real_adjustments", eAdj);
          return res.status(500).json({ ok: false });
        }

        adjRows = adjRows || [];

        const finalizedSessionTotal = sumFinalizedRevenueInRange(adjRows, 0, Infinity);
        const finalizedSessionToday = sumFinalizedRevenueInRange(adjRows, todayStart, now);
        const finalizedSessionYesterday = sumFinalizedRevenueInRange(adjRows, yesterdayStart, todayStart);
        const finalizedSessionWeek = sumFinalizedRevenueInRange(adjRows, weekStart, now);
        const finalizedSessionMonth = sumFinalizedRevenueInRange(adjRows, monthStart, now);

        let feeAdjustTotal = 0;
        let feeAdjustToday = 0;
        let feeAdjustYesterday = 0;
        let feeAdjustWeek = 0;
        let feeAdjustMonth = 0;

        let spinCostTotal = 0;
        let spinCostToday = 0;
        let spinCostYesterday = 0;
        let spinCostWeek = 0;
        let spinCostMonth = 0;

        (adjRows || []).forEach((a) => {
          const t =
  a.time ||
  a.session_start ||
  0;

const tt = Number(t) || 0;
          const amt = Number(a.amount) || 0;
          const kind = String(a.kind || "");

if (kind === "SESSION_FINALIZE") {
  return;
}

 if (kind === "MANUAL_FEE_ADJUST" || kind === "ZERO_FEE") {

  feeAdjustTotal += amt;

  if (tt >= todayStart)
    feeAdjustToday += amt;

  if (tt >= yesterdayStart && tt < todayStart)
    feeAdjustYesterday += amt;

  if (tt >= weekStart && tt < now)
    feeAdjustWeek += amt;

  if (tt >= monthStart && tt < now)
    feeAdjustMonth += amt;

  return;
}

if (
  String(kind).trim() === "SPIN_TIME_COST" ||
  String(kind).trim() === "SPIN_ITEM_COST"
) {

  const shownCost = Math.max(-amt, 0);

  spinCostTotal += shownCost;

  if (tt >= todayStart)
    spinCostToday += shownCost;

  if (tt >= yesterdayStart && tt < todayStart)
    spinCostYesterday += shownCost;

  if (tt >= weekStart && tt < now)
    spinCostWeek += shownCost;

  if (tt >= monthStart && tt < now)
    spinCostMonth += shownCost;

  return;
}
        });

        const brutGelir = liveRealBrutGelir + finalizedSessionTotal;
        const bugunBrutGelir = liveBugunRealBrutGelir + finalizedSessionToday;
        const dunBrutGelir = liveDunRealBrutGelir + finalizedSessionYesterday;
        const haftaBrutGelir = liveHaftaRealBrutGelir + finalizedSessionWeek;
        const ayBrutGelir = liveAyRealBrutGelir + finalizedSessionMonth;

        const adminDuzeltmeleri = feeAdjustTotal;
        const bugunAdminDuzeltmeleri = feeAdjustToday;
        const dunAdminDuzeltmeleri = feeAdjustYesterday;
        const haftaAdminDuzeltmeleri = feeAdjustWeek;
        const ayAdminDuzeltmeleri = feeAdjustMonth;

        const spinMaliyeti = spinCostTotal;
        const bugunSpinMaliyeti = spinCostToday;
        const dunSpinMaliyeti = spinCostYesterday;
        const haftaSpinMaliyeti = spinCostWeek;
        const aySpinMaliyeti = spinCostMonth;

const gercekGelir =
  brutGelir +
  adminDuzeltmeleri -
  spinMaliyeti;

const bugunGercekGelir =
  bugunBrutGelir +
  bugunAdminDuzeltmeleri -
  bugunSpinMaliyeti;

const dunGercekGelir =
  dunBrutGelir +
  dunAdminDuzeltmeleri -
  dunSpinMaliyeti;

const haftaGercekGelir =
  haftaBrutGelir +
  haftaAdminDuzeltmeleri -
  haftaSpinMaliyeti;

const ayGercekGelir =
  ayBrutGelir +
  ayAdminDuzeltmeleri -
  aySpinMaliyeti;

        return res.json({
          toplam,
          bugunToplam,
          bugunOnaylananOdul,
          icecek,
          dakika,
          vipSpin,
          normalSpin,
          toplamMaliyet,
          bugunMaliyet,
          gelir,
          bugunGelir,
          kar,
          bugunKar,

          brutGelir,
          bugunBrutGelir,
          dunBrutGelir,
          haftaBrutGelir,
          ayBrutGelir,

          adminDuzeltmeleri,
          bugunAdminDuzeltmeleri,
          dunAdminDuzeltmeleri,
          haftaAdminDuzeltmeleri,
          ayAdminDuzeltmeleri,

          spinMaliyeti,
          bugunSpinMaliyeti,
          dunSpinMaliyeti,
          haftaSpinMaliyeti,
          aySpinMaliyeti,

          gercekGelir,
          bugunGercekGelir,
          dunGercekGelir,
          haftaGercekGelir,
          ayGercekGelir,

          realBrutGelir: brutGelir,
          bugunRealBrutGelir: bugunBrutGelir,
          dunRealBrutGelir: dunBrutGelir,
          haftaRealBrutGelir: haftaBrutGelir,
          ayRealBrutGelir: ayBrutGelir,

          realGelir: gercekGelir,
          bugunRealGelir: bugunGercekGelir,
          dunRealGelir: dunGercekGelir,
          haftaRealGelir: haftaGercekGelir,
          ayRealGelir: ayGercekGelir,

          spinCostTotal: spinMaliyeti,
          spinCostToday: bugunSpinMaliyeti,
          spinCostYesterday: dunSpinMaliyeti,
          spinCostWeek: haftaSpinMaliyeti,
          spinCostMonth: aySpinMaliyeti,

          cafeDayStart: todayStart,
          spinSure: TEST_MODE === 1 ? TEST_SPIN_SURE_DK : parseInt(SPIN_SURE_DK, 10) || 45,
          testMode: TEST_MODE === 1,

          globalSpinCount,
          buyukOdulHedefNormal: BUYUK_ODUL_HEDEF,
          buyukOdulHedefVip: BUYUK_ODUL_HEDEF_VIP,
          buyukOdulHedefMin: Math.min(BUYUK_ODUL_HEDEF, BUYUK_ODUL_HEDEF_VIP),
          ucretBlokToleransDakika: 2,
          manualFeeAdjustment: true
        });
      });
    });
  });
});
app.get("/admin/monthly-report", (req, res) => {
  setNoStore(res);
  const rawMonth = String(req.query.month || "").trim();
  const match = rawMonth.match(/^(\d{4})-(\d{2})$/);
  const now = Date.now();
  const current = new Date(now);
  const year = match ? Number(match[1]) : current.getFullYear();
  const monthIndex = match ? Number(match[2]) - 1 : current.getMonth();
  if (!Number.isInteger(year) || monthIndex < 0 || monthIndex > 11) {
    return res.status(400).json({ ok: false, error: "Geçerli ay seç" });
  }

  // Kafe günü 20:00-20:00 çalıştığı için aylık aralık da aynı sınırla hesaplanır.
  const startTs = new Date(year, monthIndex, 1, 20, 0, 0, 0).getTime();
  const nextMonthStartTs = new Date(year, monthIndex + 1, 1, 20, 0, 0, 0).getTime();
  const endTs = Math.min(nextMonthStartTs, now + 1);
  if (startTs > now) {
    return res.json({ ok: true, month: rawMonth, startTs, endTs: startTs, stats: null, future: true });
  }

  getRangeStats(startTs, endTs, (statsErr, stats) => {
    if (statsErr) return res.status(500).json({ ok: false, error: String(statsErr) });
    db.all("SELECT * FROM payments WHERE voided=0 ORDER BY id DESC", (paymentErr, payments) => {
      if (paymentErr) return res.status(500).json({ ok: false, error: String(paymentErr) });
      getCardSettlementGroupsFromDb(payments || [], now, (settlementErr, groups) => {
        if (settlementErr) return res.status(500).json({ ok: false, error: String(settlementErr) });
        const actualCommission = Math.round(
          actualCardCommissionForRange(payments || [], groups || [], startTs, endTs) * 100
        ) / 100;
        const normalized = {
          ...stats,
          kartKomisyonu: actualCommission,
          netIsletmeSonucu:
            (Number(stats.gercekGelir) || 0) +
            (Number(stats.productGeliri) || 0) -
            (Number(stats.giderler) || 0) - actualCommission
        };
        res.json({
          ok: true,
          month: `${year}-${String(monthIndex + 1).padStart(2, "0")}`,
          startTs,
          endTs,
          partial: endTs < nextMonthStartTs,
          stats: normalized
        });
      });
    });
  });
});

app.get("/admin/yearly-report", (req, res) => {
  setNoStore(res);
  const rawYear = String(req.query.year || "").trim();
  const year = Number(rawYear || new Date().getFullYear());
  const now = Date.now();
  const currentYear = new Date(now).getFullYear();
  if (!Number.isInteger(year) || year < 2020 || year > 2100) {
    return res.status(400).json({ ok: false, error: "Geçerli yıl seç" });
  }
  const startTs = new Date(year, 0, 1, 20, 0, 0, 0).getTime();
  const nextYearStartTs = new Date(year + 1, 0, 1, 20, 0, 0, 0).getTime();
  const endTs = Math.min(nextYearStartTs, now + 1);
  if (startTs > now) {
    return res.json({ ok: true, year, startTs, endTs: startTs, stats: null, future: true });
  }

  getRangeStats(startTs, endTs, (statsErr, stats) => {
    if (statsErr) return res.status(500).json({ ok: false, error: String(statsErr) });
    db.all("SELECT * FROM payments WHERE voided=0 ORDER BY id DESC", (paymentErr, payments) => {
      if (paymentErr) return res.status(500).json({ ok: false, error: String(paymentErr) });
      getCardSettlementGroupsFromDb(payments || [], now, (settlementErr, groups) => {
        if (settlementErr) return res.status(500).json({ ok: false, error: String(settlementErr) });
        const actualCommission = Math.round(
          actualCardCommissionForRange(payments || [], groups || [], startTs, endTs) * 100
        ) / 100;
        res.json({
          ok: true,
          year,
          startTs,
          endTs,
          partial: year === currentYear && endTs < nextYearStartTs,
          stats: {
            ...stats,
            kartKomisyonu: actualCommission,
            netIsletmeSonucu:
              (Number(stats.gercekGelir) || 0) +
              (Number(stats.productGeliri) || 0) -
              (Number(stats.giderler) || 0) - actualCommission
          }
        });
      });
    });
  });
});

app.get("/admin/financial-range-report", (req, res) => {
  setNoStore(res);
  const parseDate = (value) => {
    const match = String(value || "").trim().match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) return null;
    const year = Number(match[1]);
    const month = Number(match[2]) - 1;
    const day = Number(match[3]);
    const date = new Date(year, month, day, 0, 0, 0, 0);
    return date.getFullYear() === year && date.getMonth() === month && date.getDate() === day ? date : null;
  };
  const startDate = parseDate(req.query.start);
  const endDate = parseDate(req.query.end || req.query.start);
  if (!startDate || !endDate || endDate.getTime() < startDate.getTime()) {
    return res.status(400).json({ ok: false, error: "Geçerli başlangıç ve bitiş tarihi seç" });
  }
  const startTs = startDate.getTime();
  // Mali rapor takvim gününe göre 00:00 - sonraki gün 00:00 hesaplanır.
  const endTs = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate() + 1, 0, 0, 0, 0).getTime();
  const now = Date.now();
  const effectiveEndTs = Math.min(endTs, now + 1);
  if (startTs > now) return res.json({ ok: true, startTs, endTs: startTs, stats: null, future: true });

  getRangeStats(startTs, effectiveEndTs, (statsErr, stats) => {
    if (statsErr) return res.status(500).json({ ok: false, error: String(statsErr) });
    db.all("SELECT * FROM payments WHERE voided=0 ORDER BY id DESC", (paymentErr, payments) => {
      if (paymentErr) return res.status(500).json({ ok: false, error: String(paymentErr) });
      getCardSettlementGroupsFromDb(payments || [], now, (settlementErr, groups) => {
        if (settlementErr) return res.status(500).json({ ok: false, error: String(settlementErr) });
        const actualCommission = Math.round(
          actualCardCommissionForRange(payments || [], groups || [], startTs, effectiveEndTs) * 100
        ) / 100;
        db.get(
          `SELECT
             COALESCE(SUM(CASE WHEN LOWER(COALESCE(category,'')) LIKE '%teknik%' THEN total ELSE 0 END),0) AS technical_total,
             COALESCE(SUM(CASE WHEN LOWER(COALESCE(category,'')) LIKE '%teknik%' THEN 0 ELSE total END),0) AS food_drink_total
           FROM product_sales
           WHERE voided=0 AND time>=? AND time<?`,
          [startTs, effectiveEndTs],
          (vatErr, vatRow) => {
            if (vatErr) return res.status(500).json({ ok: false, error: String(vatErr) });
            const gross20 = (Number(stats.gercekGelir) || 0) + (Number(vatRow && vatRow.technical_total) || 0);
            const gross10 = Number(vatRow && vatRow.food_drink_total) || 0;
            const splitVat = (gross, rate) => {
              const base = Math.round((gross / (1 + rate)) * 100) / 100;
              return { matrah: base, kdv: Math.round((gross - base) * 100) / 100, toplam: Math.round(gross * 100) / 100 };
            };
            const vat20 = splitVat(gross20, 0.20);
            const vat10 = splitVat(gross10, 0.10);
            res.json({
              ok: true,
              startTs,
              endTs: effectiveEndTs,
              partial: effectiveEndTs < endTs,
              startLabel: String(req.query.start),
              endLabel: String(req.query.end || req.query.start),
              vat: {
                rate20: vat20,
                rate10: vat10,
                toplamKdv: Math.round((vat20.kdv + vat10.kdv) * 100) / 100,
                toplamMatrah: Math.round((vat20.matrah + vat10.matrah) * 100) / 100
              },
              stats: {
                ...stats,
                kartKomisyonu: actualCommission,
                netIsletmeSonucu:
                  (Number(stats.gercekGelir) || 0) +
                  (Number(stats.productGeliri) || 0) -
                  (Number(stats.giderler) || 0) - actualCommission
              }
            });
          }
        );
      });
    });
  });
});

app.get("/admin/daily-report", (req, res) => {
  setNoStore(res);

  db.get(
    `
    SELECT *
    FROM daily_reports
    ORDER BY report_ts DESC
    LIMIT 1
    `,
    (err, row) => {

      if (err) {
        logErr("/admin/daily-report", err);
        return res.status(500).json({ error: "db" });
      }

      return res.json(row || {});
    }
  );
});
app.get("/admin/live-log", (req, res) => {
  res.json({
    ok: true,
    list: liveLogs
  });
});
app.get("/admin/diagnostics", (req, res) => {

  db.get(
    "SELECT COUNT(*) AS count FROM sessions WHERE end_time=0",
    (err, row) => {

      if (err) {
        return res.status(500).json({ ok: false, error: err.message });
      }

      res.json({
        ok: true,

        ramSessions: Object.keys(aktifMasalar).length,
        ramPingStats: Object.keys(masaPingStats).length,

        dbSessions: row.count,

        cleanupCount: diagnostics.cleanupCount,
        finalizeCount: diagnostics.finalizeCount,
        offlineCloseCount: diagnostics.offlineCloseCount,

        lastCleanup: diagnostics.lastCleanup,
        lastFinalize: diagnostics.lastFinalize,
        lastPing: diagnostics.lastPing,

        lastCleanupMasa: diagnostics.lastCleanupMasa,
        lastFinalizeMasa: diagnostics.lastFinalizeMasa
      });

    }
  );

});

app.post("/admin/reset-masa", (req, res) => {
  setNoStore(res);

  const masa = parseInt((req.body || {}).masa, 10);
  if (!masa || masa < 1 || masa > MASA_SAYISI) {
    return res.json({ ok: false, error: "Geçersiz masa" });
  }

  autoApprovePendingRewardsForMasa(masa, "masa sıfırlama", (approveErr) => {
    if (approveErr) {
      return res.json({
        ok: false,
        error: "Bekleyen ödül otomatik onaylanamadı: " + String(approveErr)
      });
    }

    const now = Date.now();

    db.get("SELECT * FROM sessions WHERE masa=?", [masa], (e0, row) => {
      const continueReset = () => {
        db.run("DELETE FROM masalar WHERE masa=?", [masa], (e1) => {
          logErr("/admin/reset-masa delete masalar", e1);

          const todayStart = dayStartTs(Date.now());
          db.run("DELETE FROM spins WHERE masa=? AND time>=?", [masa, todayStart], (e2) => {
            logErr("/admin/reset-masa delete spins", e2);
            res.json({ ok: true, masa });
          });
        });
      };

      if (!e0 && row && (!row.end_time || row.end_time === 0)) {
        return finalizeEndedSessionToAdjustments({ ...row, end_time: now }, now, (err) => {
          if (err) return res.json({ ok: false, error: String(err) });
          continueReset();
        });
      }

      continueReset();
    });
  });
});
app.post("/admin/transfer-session", async (req, res) => {
  setNoStore(res);

  const from = parseInt(req.body?.from, 10);
  const to = parseInt(req.body?.to, 10);

  if (
    !from || !to ||
    from < 1 || from > MASA_SAYISI ||
    to < 1 || to > MASA_SAYISI
  ) {
    return res.json({ ok: false, error: "Geçersiz masa" });
  }

  if (from === to) {
    return res.json({ ok: false, error: "Aynı masa olamaz" });
  }

  if (isFreeMasa(from) || isFreeMasa(to)) {
    return res.json({
      ok: false,
      error: "FREE masa ile oturum transferi yapılamaz"
    });
  }

  const dbRunAsync = (sql, params = []) =>
    new Promise((resolve, reject) => {
      db.run(sql, params, function (err) {
        if (err) return reject(err);
        resolve({ changes: this.changes || 0, lastID: this.lastID });
      });
    });

  const dbGetAsync = (sql, params = []) =>
    new Promise((resolve, reject) => {
      db.get(sql, params, (err, row) => {
        if (err) return reject(err);
        resolve(row || null);
      });
    });

  const unlockTransfer = () => {
    sessionLocks.delete(from);
    sessionLocks.delete(to);
    db.run(
      "DELETE FROM session_locks WHERE masa IN (?,?)",
      [from, to],
      (err) => logErr("transfer unlock", err)
    );
  };

  // Transfer sırasında iki bilgisayardan gelebilecek ping/spin isteklerini durdur.
  setLock(from, Date.now() + LOCK_MS);
  setLock(to, Date.now() + LOCK_MS);

  let transactionStarted = false;

  try {
    await dbRunAsync("BEGIN IMMEDIATE TRANSACTION");
    transactionStarted = true;

    // Kontroller transaction içinde tekrar yapılıyor; böylece kontrol ile
    // taşıma arasında hedefte yeni session açılması engelleniyor.
    const source = await dbGetAsync(
      "SELECT * FROM sessions WHERE masa=? AND (end_time=0 OR end_time IS NULL)",
      [from]
    );

    if (!source) {
      throw new Error("Kaynak masada aktif oturum bulunamadı");
    }

    const target = await dbGetAsync(
      "SELECT masa FROM sessions WHERE masa=?",
      [to]
    );

    if (target) {
      throw new Error("Hedef masada oturum var; önce hedef masayı sıfırlayın");
    }

    const sessionUpdate = await dbRunAsync(
      "UPDATE sessions SET masa=? WHERE masa=? AND start_time=?",
      [to, from, source.start_time]
    );

    if (sessionUpdate.changes !== 1) {
      throw new Error("Oturum taşınamadı");
    }

    // Hedefte kalmış eski sayaç satırını temizle, kaynağın sayacını taşı.
    await dbRunAsync("DELETE FROM masalar WHERE masa=?", [to]);
    await dbRunAsync(
      "UPDATE masalar SET masa=? WHERE masa=?",
      [to, from]
    );

    // Yalnızca henüz onaylanmamış ödüller müşteriyi takip eder.
    // Kullanılmış ve geçmiş spin kayıtlarının masa numarası değiştirilmez.
    await dbRunAsync(
      "UPDATE spins SET masa=? WHERE masa=? AND used=0",
      [to, from]
    );
    await dbRunAsync(
      "UPDATE spins_log SET masa=? WHERE masa=? AND used=0 AND time>=?",
      [to, from, dayStartTs(Date.now())]
    );

    // Aktif session'a ait manuel ücret hareketlerini de yeni masaya taşı.
    await dbRunAsync(
      "UPDATE real_adjustments SET masa=? WHERE masa=? AND session_start=?",
      [to, from, source.start_time]
    );

    // Açık ürün hesabı da müşteriyle birlikte hedef masaya taşınır.
    await dbRunAsync(
      `UPDATE product_sales
       SET masa=?, session_start=?
       WHERE masa=? AND status='OPEN' AND voided=0`,
      [to, source.start_time, from]
    );

    await dbRunAsync("COMMIT");
    transactionStarted = false;

    const sourceLastSeen = aktifMasalar[from] || source.last_seen || Date.now();
    aktifMasalar[to] = sourceLastSeen;
    delete aktifMasalar[from];

    masaPingStats[to] = masaPingStats[from] || {
      last: 0,
      avg: PING_INTERVAL_MS,
      lastSeen: 0,
      netSpeed: 0
    };
    masaPingStats[from] = {
      last: 0,
      avg: PING_INTERVAL_MS,
      lastSeen: 0,
      netSpeed: 0
    };

    latestRewardMap[to] = latestRewardMap[from] || null;
    delete latestRewardMap[from];

    offlineCount[to] = offlineCount[from] || 0;
    offlineCount[from] = 0;
    lastOfflineState[to] = lastOfflineState[from] || false;
    lastOfflineState[from] = false;

    unlockTransfer();
    masaCloseLocks[from] = Date.now() + 30000;
    masaCloseLocks[to] = Date.now() + 10000;

    addLiveLog("transfer", `🔄 Masa transferi: ${from} → ${to}`);
    console.log(`🔄 Masa transfer: ${from} → ${to}`);

    return res.json({ ok: true, from, to });
  } catch (err) {
    if (transactionStarted) {
      try {
        await dbRunAsync("ROLLBACK");
      } catch (rollbackErr) {
        logErr("transfer rollback", rollbackErr);
      }
    }

    unlockTransfer();
    logErr("/admin/transfer-session", err);

    return res.json({
      ok: false,
      error: err.message || "Transfer başarısız"
    });
  }
});
app.post("/admin/reset", (req, res) => {
  setNoStore(res);

  blockIfAnyPendingReward(res, () => {
    const now = Date.now();

    db.all("SELECT * FROM sessions WHERE end_time=0 OR end_time IS NULL", (e0, rows) => {
      if (e0) return res.json({ ok: false, error: String(e0) });
      rows = rows || [];

      const finalizeNext = (i) => {
if (i >= rows.length) {

  sendEndOfDayTelegramReport((err) => {
    if (err) {
      logErr("daily telegram report", err);
    } else {
      console.log("📊 Gün sonu raporu gönderildi");
    }

    db.run("DELETE FROM masalar", (err2) => {
      if (err2) {
        logErr("cron delete masalar", err2);
        return res.status(500).json({ ok: false, error: String(err2) });
      }
      console.log("🧹 Günlük reset tamamlandı");
      return res.json({ ok: true });
    });
  });

  return;
}
        const r = rows[i];
        finalizeEndedSessionToAdjustments({ ...r, end_time: now }, now, () => {
          finalizeNext(i + 1);
        });
      };

      finalizeNext(0);
    });
  });
});

app.post("/admin/reset-spins-today", (req, res) => {
  setNoStore(res);

  blockIfAnyPendingReward(res, () => {

    db.run("DELETE FROM spins", (e1) => {

      logErr("/admin/reset-spins-today spins", e1);

      db.run("DELETE FROM spins_log", (e2) => {

        logErr("/admin/reset-spins-today spins_log", e2);

        res.json({ ok: true });

      });

    });

  });
});

app.post("/admin/reset-all", (req, res) => {
  setNoStore(res);

  blockIfAnyPendingReward(res, () => {
    db.serialize(() => {
      db.run("DELETE FROM masalar", (e1) => {
        if (e1) return res.status(500).json({ ok: false, error: String(e1) });
        db.run("DELETE FROM spins", (e2) => {
          if (e2) return res.status(500).json({ ok: false, error: String(e2) });
          db.run("DELETE FROM sessions", (e3) => {
            if (e3) return res.status(500).json({ ok: false, error: String(e3) });
            db.run("DELETE FROM spins_log", (e4) => {
              if (e4) return res.status(500).json({ ok: false, error: String(e4) });

              db.run("DELETE FROM product_sales", (productErr) => {
                if (productErr) return res.status(500).json({ ok: false, error: String(productErr) });
                db.run("DELETE FROM payments", (paymentErr) => {
                  if (paymentErr) return res.status(500).json({ ok: false, error: String(paymentErr) });
                  db.run("DELETE FROM accounting_entries", (accountingErr) => {
                    if (accountingErr) return res.status(500).json({ ok: false, error: String(accountingErr) });
                    db.run("DELETE FROM account_transfers", (transferErr) => {
                      if (transferErr) return res.status(500).json({ ok: false, error: String(transferErr) });
                    db.run("DELETE FROM daily_reports", (reportErr) => {
                      if (reportErr) return res.status(500).json({ ok: false, error: String(reportErr) });

              db.run("DELETE FROM real_adjustments", (e5) => logErr("/admin/reset-all delete adjustments", e5));
              db.run("DELETE FROM session_locks", (e6) => logErr("/admin/reset-all delete locks", e6));
              db.run("DELETE FROM force_new_sessions", (e7) => logErr("/admin/reset-all delete force_new_sessions", e7));
              db.run("DELETE FROM blocked_masalar", (e8) => logErr("/admin/reset-all delete blocked_masalar", e8));
              db.run("DELETE FROM session_history", (e9) => logErr("/admin/reset-all delete session_history", e9));
              sessionLocks = new Map();
              blockedMasalar = new Set();
              aktifMasalar = {};
              tokenTracker = {};
              globalSpinCount = 0;

              db.run(
                "INSERT INTO settings(key,value) VALUES('global_spin_count','0') ON CONFLICT(key) DO UPDATE SET value='0'",
                (e9) => logErr("/admin/reset-all reset global_spin_count", e9)
              );

              return res.json({ ok: true });
                    });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
});

app.post("/admin/force-ready", (req, res) => {
  setNoStore(res);

  const masa = parseInt((req.body || {}).masa, 10);
  if (!masa || masa < 1 || masa > MASA_SAYISI) {
    return res.json({ ok: false, error: "Geçersiz masa" });
  }

  const now = Date.now();
  const SURE = getSpinSureMs();

  const newStart = now - SURE - 1000;

  db.run(
    "INSERT INTO masalar (masa, start_time) VALUES (?,?) ON CONFLICT(masa) DO UPDATE SET start_time=excluded.start_time",
    [masa, newStart],
    (e) => {
      if (e) return res.json({ ok: false, error: String(e) });
      return res.json({ ok: true, masa });
    }
  );
});

app.get("/admin/token-status", (req, res) => {
  setNoStore(res);

  const now = Date.now();
  const list = [];
  const ipMap = {};

  for (let masa = 1; masa <= MASA_SAYISI; masa++) {
    const rows = (tokenTracker[masa] || []).filter((x) => now - x.time <= 24 * 60 * 60 * 1000);
    const ips = [...new Set(rows.map((x) => x.ip))];

    let status = "OFFLINE";
    if (rows.length > 0 && ips.length === 1) status = "OK";
    if (ips.length > 1) status = "MULTI";

    list.push({
      masa,
      status,
      ipCount: ips.length,
      ips,
      lastIP: rows.length ? rows[rows.length - 1].ip : "-",
      lastSeen: rows.length ? rows[rows.length - 1].time : 0,
      blocked: blockedMasalar.has(masa),
      expectedIp: MASA_IPS[masa] || "-"
    });

    ips.forEach((ip) => {
      if (!ipMap[ip]) ipMap[ip] = [];
      ipMap[ip].push(masa);
    });
  }

  const conflicts = Object.entries(ipMap)
    .filter(([ip, masalar]) => ip !== "-" && masalar.length > 1)
    .map(([ip, masalar]) => ({
      ip,
      masalar
    }));

  return res.json({ ok: true, list, conflicts });
});

app.post("/admin/block-masa", (req, res) => {
  setNoStore(res);

  const masa = parseInt((req.body || {}).masa, 10);
  const minutes = parseInt((req.body || {}).minutes, 10) || 30;

  if (!masa || masa < 1 || masa > MASA_SAYISI) {
    return res.json({ ok: false, error: "Geçersiz masa" });
  }

  const untilTime = Date.now() + minutes * 60 * 1000;

  setBlockedMasa(masa, untilTime, "Admin block", (err) => {
    if (err) return res.json({ ok: false, error: String(err) });
    return res.json({ ok: true, masa, untilTime });
  });
});

app.post("/admin/unblock-masa", (req, res) => {
  setNoStore(res);

  const masa = parseInt((req.body || {}).masa, 10);

  if (!masa || masa < 1 || masa > MASA_SAYISI) {
    return res.json({ ok: false, error: "Geçersiz masa" });
  }

  clearBlockedMasa(masa, (err) => {
    if (err) return res.json({ ok: false, error: String(err) });
    return res.json({ ok: true, masa });
  });
});

app.get("/admin/send-daily-report", (req, res) => {
  setNoStore(res);

  sendEndOfDayTelegramReport((err, stats) => {
    if (err) {
      return res.json({ ok: false, error: String(err) });
    }

    return res.json({ ok: true, stats });
  });
});

function nextRolloverTimestamp(nowTs) {
  const now = Number(nowTs) || Date.now();
  const next = new Date(now);
  next.setHours(20, 0, 0, 0);
  if (next.getTime() <= now) next.setDate(next.getDate() + 1);
  return next.getTime();
}

function saveRolloverStatus(status, cb) {
  db.run(
    "INSERT INTO settings(key,value) VALUES('last_daily_rollover',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
    [JSON.stringify(status)],
    (err) => {
      if (err) logErr("saveRolloverStatus", err);
      if (cb) cb(err);
    }
  );
}

function recordClosedRolloverResult(masa, sessionStart, sessionEnd, totalFee) {
  db.get("SELECT value FROM settings WHERE key='last_daily_rollover'", (statusErr, row) => {
    if (statusErr || !row || !row.value) {
      if (statusErr) logErr("recordClosedRolloverResult status", statusErr);
      return;
    }

    let status;
    try {
      status = JSON.parse(row.value);
    } catch (parseErr) {
      logErr("recordClosedRolloverResult parse", parseErr);
      return;
    }

    const boundaryTs = Number(status.rolloverTs) || 0;
    const transferred = Array.isArray(status.onlineMasalar) ? status.onlineMasalar : [];
    if (
      status.status !== "success" ||
      !boundaryTs ||
      !transferred.map(Number).includes(Number(masa)) ||
      Number(sessionStart) >= boundaryTs ||
      Number(sessionEnd) <= boundaryTs
    ) return;

    db.all(
      `SELECT time, amount FROM real_adjustments
       WHERE masa=? AND session_start=?
       AND kind IN ('MANUAL_FEE_ADJUST','ZERO_FEE')`,
      [masa, sessionStart],
      (adjErr, adjustments) => {
        if (adjErr) {
          logErr("recordClosedRolloverResult adjustments", adjErr);
          return;
        }

        const beforeAdjustment = (adjustments || []).reduce((sum, item) => {
          return Number(item.time) < boundaryTs ? sum + (Number(item.amount) || 0) : sum;
        }, 0);
        const beforeFee = Math.max(
          feeAtTime(Number(masa), Number(sessionStart), boundaryTs) + beforeAdjustment,
          0
        );
        const finalTotal = Math.max(Number(totalFee) || 0, 0);
        const afterFee = finalTotal - beforeFee;

        // Devreden masanın ürünleri de satışın yazıldığı zamana göre iki
        // kafe gününe ayrılır; kapanış satırı yalnız bilgisayar ücretini göstermez.
        db.get(
          `SELECT
             COALESCE(SUM(CASE WHEN time < ? THEN total ELSE 0 END),0) AS before_product,
             COALESCE(SUM(CASE WHEN time >= ? THEN total ELSE 0 END),0) AS after_product
           FROM product_sales
           WHERE masa=? AND session_start=? AND sale_type='TABLE'
             AND voided=0 AND time<=?`,
          [boundaryTs, boundaryTs, masa, sessionStart, sessionEnd],
          (productErr, productRow) => {
            if (productErr) logErr("recordClosedRolloverResult products", productErr);
            const beforeProduct = Number(productRow && productRow.before_product) || 0;
            const afterProduct = Number(productRow && productRow.after_product) || 0;
            const beforeTotal = beforeFee + beforeProduct;
            const afterTotal = afterFee + afterProduct;

            const result = {
              masa: Number(masa),
              sessionStart: Number(sessionStart),
              closedAt: Number(sessionEnd),
              beforeFee,
              afterFee,
              totalFee: finalTotal,
              beforeProduct,
              afterProduct,
              beforeTotal,
              afterTotal,
              totalWithProducts: beforeTotal + afterTotal
            };

            const closedMasalar = Array.isArray(status.closedMasalar)
              ? status.closedMasalar.filter((x) =>
                  !(Number(x.masa) === Number(masa) && Number(x.sessionStart) === Number(sessionStart))
                )
              : [];
            closedMasalar.push(result);
            status.closedMasalar = closedMasalar;

            saveRolloverStatus(status, (saveErr) => {
              if (saveErr) return;
              addLiveLog(
                "rollover_session_closed",
                `♻️ Devreden Masa ${masa} kapandı • Eski gün ${beforeTotal.toFixed(2)} TL • Yeni gün ${afterTotal.toFixed(2)} TL • Toplam ${(beforeTotal + afterTotal).toFixed(2)} TL`
              );
            });
          }
        );
      }
    );
  });
}

app.get("/admin/rollover-status", (req, res) => {
  setNoStore(res);
  const serverNow = Date.now();
  db.get(
    "SELECT value FROM settings WHERE key='last_daily_rollover'",
    (err, row) => {
      if (err) {
        logErr("/admin/rollover-status", err);
        return res.json({ ok: false, error: String(err) });
      }
      let last = null;
      if (row && row.value) {
        try {
          last = JSON.parse(row.value);
        } catch (parseErr) {
          logErr("/admin/rollover-status parse", parseErr);
        }
      }
      const sendStatus = () => res.json({
        ok: true,
        serverNow,
        nextRolloverTs: nextRolloverTimestamp(serverNow),
        last
      });

      // Eski kayıtlar yalnızca masa gelirini saklamış olabilir. Şeritte her
      // zaman o kafe gününün masa + ürün/hizmet toplamını göster.
      const rolloverTs = Number(last && last.rolloverTs) || 0;
      if (!last || !rolloverTs) return sendStatus();
      return getRangeStats(dayStartTs(rolloverTs - 1), rolloverTs, (statsErr, stats) => {
        if (!statsErr && stats) {
          // Devir şeridindeki ciro, masa oturumu ile o gün satılan tüm
          // ürün/hizmetlerin toplamıdır. Ayrı alanlar da arayüzde doğrulanır.
          last.previousDayMasaRevenue = Number(stats.gercekGelir) || 0;
          last.previousDayProductRevenue = Number(stats.productGeliri) || 0;
          last.previousDayRevenue =
            last.previousDayMasaRevenue + last.previousDayProductRevenue;
          last.previousDayGrossRevenue = last.previousDayRevenue;
        }

        // Daha önce yalnız oturum ücretiyle kaydedilmiş kapanış satırlarını
        // da ürün/hizmet satışlarıyla zenginleştir; sayfa yenilenince güncel
        // toplam görülür.
        const closed = Array.isArray(last.closedMasalar) ? last.closedMasalar : [];
        if (!closed.length) return sendStatus();
        const pairs = closed.map(() => "(?,?)").join(",");
        const pairParams = closed.flatMap((item) => [Number(item.masa) || 0, Number(item.sessionStart) || 0]);
        return db.all(
          `SELECT masa, session_start,
             COALESCE(SUM(CASE WHEN time < ? THEN total ELSE 0 END),0) AS before_product,
             COALESCE(SUM(CASE WHEN time >= ? THEN total ELSE 0 END),0) AS after_product
           FROM product_sales
           WHERE sale_type='TABLE' AND voided=0
             AND (masa, session_start) IN (${pairs})
           GROUP BY masa, session_start`,
          [rolloverTs, rolloverTs, ...pairParams],
          (productErr, rows) => {
            if (productErr) {
              logErr("/admin/rollover-status closed products", productErr);
              return sendStatus();
            }
            const productMap = new Map(
              (rows || []).map((item) => [
                `${Number(item.masa)}:${Number(item.session_start)}`,
                item
              ])
            );
            last.closedMasalar = closed.map((item) => {
              const products = productMap.get(`${Number(item.masa)}:${Number(item.sessionStart)}`) || {};
              const beforeProduct = Number(products.before_product) || 0;
              const afterProduct = Number(products.after_product) || 0;
              const beforeFee = Number(item.beforeFee) || 0;
              const afterFee = Number(item.afterFee) || 0;
              return {
                ...item,
                beforeProduct,
                afterProduct,
                beforeTotal: beforeFee + beforeProduct,
                afterTotal: afterFee + afterProduct,
                totalWithProducts: beforeFee + afterFee + beforeProduct + afterProduct
              };
            });
            return sendStatus();
          }
        );
      });
    }
  );
});

let dailyRolloverInProgress = false;

// Gün sonunda yalnız EveryCafe'den gelen masa tahsilatlarını karşılaştırır.
// KafePin'in doğrudan satışları bu kontrole bilinçli olarak dahil edilmez.
function runEveryCafeDailyReconciliation(startTs, endTs, cb = () => {}) {
  getEveryCafeConfig((configErr, config) => {
    if (configErr) return cb(configErr);
    if (!config.enabled || !config.startAt) return cb(null, { skipped: true });
    const sourceStart = Math.max(Number(startTs) || 0, config.startAt);
    readEveryCafeClosedSessions(sourceStart, 200, (sourceErr, rows) => {
      if (sourceErr) return cb(sourceErr);
      const sourceRows = (rows || []).filter((row) => {
        const end = Number(row.EndDate) * 1000;
        return end >= startTs && end < endTs && Number(row.PaymentAmount) > 0 &&
          !(!isEveryCafeDirectSaleClient(row.ClientName) && isEveryCafeFreeSession(row));
      });
      const sourceTotal = Math.round(sourceRows.reduce((sum, row) => sum + (Number(row.PaymentAmount) || 0), 0) * 100) / 100;
      db.all(
        `SELECT total_amount FROM payments
         WHERE voided=0 AND (
           (source='EVERYCAFE' AND external_source='EVERYCAFE' AND session_end>=? AND session_end<?)
           OR
           (source='EVERYCAFE_DIRECT' AND external_source='EVERYCAFE_DIRECT' AND created_at>=? AND created_at<?)
         )`,
        [startTs, endTs, startTs, endTs],
        (paymentErr, paymentRows) => {
          if (paymentErr) return cb(paymentErr);
          const localTotal = Math.round((paymentRows || []).reduce((sum, row) => sum + (Number(row.total_amount) || 0), 0) * 100) / 100;
          const difference = Math.round((sourceTotal - localTotal) * 100) / 100;
          const result = {
            startTs, endTs,
            sourceCount: sourceRows.length,
            localCount: (paymentRows || []).length,
            sourceTotal, localTotal, difference,
            ok: Math.abs(difference) <= 0.01 && sourceRows.length === (paymentRows || []).length,
            checkedAt: Date.now()
          };
          lastEveryCafeDailyAudit = result;
          if (!result.ok) {
            const text = `🚨 EveryCafe gün sonu uyuşmazlığı • Kaynak: ${sourceTotal.toFixed(2)} ₺ (${sourceRows.length}) • KafePin: ${localTotal.toFixed(2)} ₺ (${(paymentRows || []).length})`;
            addLiveLog("everycafe_audit", text);
            const auditKey = `everycafe-daily-audit:${dayKey(Math.max(endTs - 1, 0))}`;
            if (TELEGRAM_ENABLED && shouldSendTelegramDedup(auditKey, 12 * 60 * 60 * 1000)) {
              sendTelegramMessage(text, () => {});
            }
          } else {
            addLiveLog("everycafe_audit", `✅ EveryCafe gün sonu uyumlu • ${sourceTotal.toFixed(2)} ₺ • ${sourceRows.length} oturum`);
          }
          cb(null, result);
        }
      );
    });
  });
}

function getRolloverBoundaryForNow(nowTs = Date.now()) {
  const now = Number(nowTs) || Date.now();
  const boundary = new Date(now);
  boundary.setHours(20, 0, 0, 0);
  return now >= boundary.getTime() ? boundary.getTime() : 0;
}

function sendRolloverTelegramWithRetry(msg, baseStatus, attempt = 1) {
  sendTelegramMessage(msg, (telegramErr) => {
    if (!telegramErr) {
      saveRolloverStatus({
        ...baseStatus,
        telegramSent: true,
        telegramStatus: "sent",
        telegramAttempts: attempt
      });
      addLiveLog("daily_report", "🌙 Gün sonu raporu Telegram'a gönderildi");
      moveLiveMonitorToBottomSoon();
      return;
    }

    logErr(`daily rollover telegram attempt ${attempt}`, telegramErr);
    if (attempt < 3) {
      saveRolloverStatus({
        ...baseStatus,
        telegramStatus: "pending",
        telegramAttempts: attempt,
        telegramError: String(telegramErr.message || telegramErr)
      });
      setTimeout(() => {
        sendRolloverTelegramWithRetry(msg, baseStatus, attempt + 1);
      }, attempt * 5000);
      return;
    }

    saveRolloverStatus({
      ...baseStatus,
      telegramStatus: "failed",
      telegramAttempts: attempt,
      telegramError: String(telegramErr.message || telegramErr)
    });
  });
}

function runReliableDailyRollover(boundaryTs, source = "cron") {
  if (dailyRolloverInProgress) return;
  dailyRolloverInProgress = true;

  const onlineMasalar = Object.entries(aktifMasalar)
    .filter(([masa, lastSeen]) => {
      return !isActuallyOffline(Number(masa), lastSeen, boundaryTs);
    })
    .map(([masa]) => Number(masa));

  console.log("🔥 GÜN SONU DEVİR SINIRI:", new Date(boundaryTs).toLocaleString("tr-TR"), source);
  console.log("♻️ Kesintisiz devredilen masalar:", onlineMasalar);

  const reportTs = Math.max(boundaryTs - 1, 0);
  const startTs = dayStartTs(reportTs);

  getRangeStats(startTs, boundaryTs, (err, stats) => {
    if (err) {
      dailyRolloverInProgress = false;
      logErr("daily rollover stats", err);
      saveRolloverStatus({
        status: "error",
        rolloverTs: boundaryTs,
        onlineMasalar,
        transferredCount: onlineMasalar.length,
        previousDayRevenue: 0,
        telegramSent: false,
        telegramStatus: "not_attempted",
        error: String(err.message || err),
        source
      });
      return;
    }

    saveDailyReport(reportTs, stats, (saveErr) => {
      if (saveErr) {
        dailyRolloverInProgress = false;
        saveRolloverStatus({
          status: "error",
          rolloverTs: boundaryTs,
          onlineMasalar,
          transferredCount: onlineMasalar.length,
          previousDayRevenue: Number(stats.genelGelir || stats.gercekGelir || stats.net) || 0,
          telegramSent: false,
          telegramStatus: "not_attempted",
          error: String(saveErr.message || saveErr),
          source
        });
        return;
      }

      const baseStatus = {
        status: "success",
        rolloverTs: boundaryTs,
        onlineMasalar,
        transferredCount: onlineMasalar.length,
        previousDayRevenue: Number(stats.genelGelir || stats.gercekGelir || stats.net) || 0,
        previousDayGrossRevenue: Number(stats.genelGelir || stats.brutGelir || stats.brut) || 0,
        telegramSent: false,
        telegramStatus: TELEGRAM_ENABLED ? "pending" : "disabled",
        source
      };

      // Devir önce kalıcı olarak kaydedilir; Telegram sonucu devri engellemez.
      saveRolloverStatus(baseStatus, () => {
        dailyRolloverInProgress = false;

        addLiveLog(
          "daily_rollover",
          onlineMasalar.length
            ? `♻️ Gün devri tamamlandı • Açık masalar kesintisiz devam ediyor: ${onlineMasalar.join(", ")}`
            : "♻️ Gün devri tamamlandı • Devreden açık masa yok"
        );
        console.log("✅ Kesintisiz gün sonu devri kaydedildi.");

        runEveryCafeDailyReconciliation(startTs, boundaryTs, (auditErr) => {
          if (auditErr) logErr("EveryCafe gün sonu karşılaştırması", auditErr);
        });

        if (!TELEGRAM_ENABLED) return;

        const msg = buildDailyTelegramReport(reportTs, stats);
        sendRolloverTelegramWithRetry(msg, baseStatus);
      });
    });
  });
}

function ensureTodayRollover() {
  const boundaryTs = getRolloverBoundaryForNow(Date.now());
  if (!boundaryTs || dailyRolloverInProgress) return;

  db.get("SELECT value FROM settings WHERE key='last_daily_rollover'", (err, row) => {
    if (err) {
      logErr("ensureTodayRollover", err);
      return;
    }

    let last = null;
    try {
      last = row && row.value ? JSON.parse(row.value) : null;
    } catch (parseErr) {
      logErr("ensureTodayRollover parse", parseErr);
    }

    if (last && last.status === "success" && Number(last.rolloverTs) >= boundaryTs) return;
    runReliableDailyRollover(boundaryTs, "catch_up");
  });
}

cron.schedule("0 20 * * *", () => {
  const boundaryTs = getRolloverBoundaryForNow(Date.now()) || Date.now();
  runReliableDailyRollover(boundaryTs, "cron");
}, { timezone: "Europe/Istanbul" });

// Server 20.00'den sonra açılırsa veya cron anı kaçarsa devri otomatik tamamlar.
setTimeout(ensureTodayRollover, 5000);
setInterval(ensureTodayRollover, 60 * 1000);

// EveryCafe açıkken yalnızca salt-okunur bağlantıyla yeni kapanışları kontrol eder.
setTimeout(() => {
  clearInvalidShortOfflinePendingSessions((cleanupErr, cleanupResult) => {
    if (cleanupErr) return logErr("EveryCafe bekleme ödeme temizliği", cleanupErr);
    if (cleanupResult && cleanupResult.cleared) {
      addLiveLog("everycafe_waiting", `EveryCafe bekleme kaynaklÄ± ${cleanupResult.cleared} hatalÄ± Ã¶deme temizlendi`);
    }
  });
}, 1000);

setTimeout(() => {
  syncEveryCafeActiveSessions((activeErr, activeResult) => {
    if (activeErr || (activeResult && activeResult.reason === "disabled")) return;
    syncEveryCafeClosedSessions((closeErr) => {
      if (closeErr) logErr("EveryCafe başlangıç senkronu", closeErr);
      else recordEveryCafeSyncSuccess();
    });
  });
}, 2000);

setTimeout(() => {
  reconcileEveryCafeClosedRewardApprovals((err, result) => {
    if (err) return logErr("EveryCafe reward approval recovery", err);
    if (result && result.approved) {
      addLiveLog("everycafe_reward_recovery", `EveryCafe kapanis odulleri otomatik onaylandi: ${result.approved}`);
    }
  });
}, 5000);

setInterval(() => {
  syncEveryCafeActiveSessions((activeErr, activeResult) => {
    if (activeErr) {
      recordEveryCafeSyncFailure("aktif masa", activeErr);
      return logErr("EveryCafe aktif masa sync", activeErr);
    }
    if (activeResult && activeResult.reason === "disabled") return;
    syncEveryCafeClosedSessions((err, result) => {
      if (err) {
        recordEveryCafeSyncFailure("kapanış", err);
        return logErr("EveryCafe live sync", err);
      }
      if (result && result.reason === "disabled") return;
      recordEveryCafeSyncSuccess();
      if (result && result.imported) console.log(`EveryCafe: ${result.imported} yeni oturum aktarıldı`);
    });
  });
}, EVERYCAFE_SYNC_MS);

if (process.env.DEBUG_QUEUE === "1") {
  setInterval(() => {
    for (const [masa] of finalizeQueues.entries()) {
      console.log(`Masa ${masa} queue aktif`);
    }
  }, 60000);
}


// ================= RESET RUNTIME =================
for (let i = 1; i <= MASA_SAYISI; i++) {

  delete aktifMasalar[i];

  masaPingStats[i] = {
    last: 0,
    avg: 0,
    netSpeed: 0
  };

  latestRewardMap[i] = null;

  offlineCount[i] = 0;
  lastOfflineState[i] = false;
}
console.log("✅ Runtime state temizlendi");


// ================= SERVER START =================

const server = app.listen(port, "0.0.0.0", () => {
  console.log("KafePin çalışıyor:");
  console.log("Local  : http://localhost:3000");
  console.log("Network: http://192.168.1.100:3000");

  addLiveLog("system", "🟢 Sunucu başlatıldı");
  setTimeout(() => ensureKafePinDesktopApp(false), 1500);
});

setTimeout(repairLatestStoredDailyReport, 4000);

if (TELEGRAM_ENABLED) {
    // Kayıtlı message_id korunur; server yeniden başlayınca yeni mesaj
    // oluşturmak yerine mevcut canlı durum mesajı güncellenir.
    setTimeout(sendLiveMonitor, 5000);
}

const TELEGRAM_LIVE_UPDATE_MS = 20 * 1000;
setInterval(() => {

    if (TELEGRAM_ENABLED) {
        sendLiveMonitor();
    }

}, TELEGRAM_LIVE_UPDATE_MS);

// server error
server.on("error", (err) => {
    console.error("SERVER ERROR:", err);
});

// 🔥 aktifMasalar temizlik
setInterval(() => {
  const now = Date.now();
  let cleaned = 0;

  for (const masa of Object.keys(aktifMasalar)) {
    if (now - aktifMasalar[masa] > CLEANUP_MS) {

      addLiveLog("disconnect", `🔌 Masa ${masa} bağlantısı koptu`);

      delete aktifMasalar[masa];
      cleaned++;
    }
  }

  if (cleaned > 0) {
    console.log(`🧹 aktifMasalar temizlendi: ${cleaned} kayıt`);
  }
}, 10000); // Her 10 saniyede bir kontrol et
