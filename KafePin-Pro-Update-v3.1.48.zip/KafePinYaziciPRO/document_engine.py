from __future__ import annotations

from pathlib import Path
from PIL import Image, ImageEnhance, ImageOps


A4_300 = (2480, 3508)


def _open_rgb(path: Path) -> Image.Image:
    with Image.open(path) as source:
        image = ImageOps.exif_transpose(source).convert("RGB")
    return image


def _fit(image: Image.Image, box: tuple[int, int]) -> Image.Image:
    copy = image.copy()
    copy.thumbnail(box, Image.Resampling.LANCZOS)
    return copy


def apply_adjustments(path: Path, *, rotate: int = 0, brightness: float = 1.0, contrast: float = 1.0, grayscale: bool = False) -> Path:
    image = _open_rgb(path)
    if rotate:
        image = image.rotate(-rotate, expand=True, fillcolor="white")
    if brightness != 1.0:
        image = ImageEnhance.Brightness(image).enhance(brightness)
    if contrast != 1.0:
        image = ImageEnhance.Contrast(image).enhance(contrast)
    if grayscale:
        image = ImageOps.grayscale(image).convert("RGB")
    image.save(path, "PNG", optimize=True)
    return path


def build_identity(front: Path, back: Path, layout: str, output_png: Path, output_pdf: Path) -> None:
    canvas = Image.new("RGB", A4_300, "white")
    margin = 160
    gap = 90
    label_h = 65
    images = [("KİMLİK ÖN YÜZ", _open_rgb(front)), ("KİMLİK ARKA YÜZ", _open_rgb(back))]
    if layout == "vertical":
        available_h = (A4_300[1] - 2 * margin - gap - 2 * label_h) // 2
        boxes = [(A4_300[0] - 2 * margin, available_h)] * 2
        top_positions = [margin + label_h, margin + label_h + available_h + gap + label_h]
        positions = []
        for top, (_, image), box in zip(top_positions, images, boxes):
            fitted = _fit(image, box)
            positions.append(((A4_300[0] - fitted.width) // 2, top, fitted))
    else:
        available_w = (A4_300[0] - 2 * margin - gap) // 2
        box = (available_w, A4_300[1] - 2 * margin - label_h)
        positions = []
        for index, (_, image) in enumerate(images):
            fitted = _fit(image, box)
            left = margin + index * (available_w + gap) + (available_w - fitted.width) // 2
            top = margin + label_h + (box[1] - fitted.height) // 2
            positions.append((left, top, fitted))
    for (title, _), (left, top, fitted) in zip(images, positions):
        canvas.paste(fitted, (left, top))
        # Pillow's default bitmap font avoids an external font dependency.
        from PIL import ImageDraw
        draw = ImageDraw.Draw(canvas)
        draw.text((left, max(margin, top - label_h + 12)), title, fill="black")
    output_png.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output_png, "PNG", optimize=True)
    canvas.save(output_pdf, "PDF", resolution=300.0)


def build_normal(pages: list[Path], preview_png: Path, output_pdf: Path) -> None:
    if not pages:
        raise ValueError("Yazdırılacak veya kaydedilecek tarama yok.")
    rendered: list[Image.Image] = []
    margin = 120
    for path in pages:
        source = _open_rgb(path)
        page = Image.new("RGB", A4_300, "white")
        fitted = _fit(source, (A4_300[0] - 2 * margin, A4_300[1] - 2 * margin))
        page.paste(fitted, ((A4_300[0] - fitted.width) // 2, (A4_300[1] - fitted.height) // 2))
        rendered.append(page)
    rendered[0].save(preview_png, "PNG", optimize=True)
    rendered[0].save(output_pdf, "PDF", resolution=300.0, save_all=True, append_images=rendered[1:])

