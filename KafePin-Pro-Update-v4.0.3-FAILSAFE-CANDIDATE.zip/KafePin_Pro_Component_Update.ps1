﻿param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$ProRoot = 'C:\KafePinPro'
)

$ErrorActionPreference = 'Stop'
$log = Join-Path $InstallRoot 'logs\pro-component-update.log'
$payloadRoot = Join-Path $InstallRoot 'pro-components'
$mp3Zip = Join-Path $payloadRoot 'mp3-bot-pro.zip'
$mp3Root = Join-Path $ProRoot 'MP3BotPRO'
$cvZip = Join-Path $payloadRoot 'cv-olustur-pro.zip'
$cvRoot = Join-Path $ProRoot 'CVOlusturPRO'
$performanceZip = Join-Path $payloadRoot 'client-performans-pro.zip'
$performanceRoot = Join-Path $ProRoot 'ClientPerformansPRO'
$flag = Join-Path (Join-Path $env:ProgramData 'KafePinPro') 'mp3-restart-after-update.flag'

function Log([string]$m) {
  try {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $log) | Out-Null
    Add-Content -LiteralPath $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $m) -Encoding UTF8
  } catch {}
}

function Stop-Mp3Runtime {
  try {
    foreach ($p in @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue)) {
      try {
        $name = ([string]$p.Name).ToLowerInvariant()
        if ($name -notin @('python.exe','pythonw.exe','py.exe','python3.exe')) { continue }
        $cmd = ([string]$p.CommandLine).Replace('/','\\').ToLowerInvariant()
        if ($cmd.Contains('web_service.py') -and ($cmd.Contains('kafepinpro\\mp3botpro') -or $cmd.Contains('kafepinmp3botpro'))) {
          Stop-Process -Id ([int]$p.ProcessId) -Force -ErrorAction SilentlyContinue
        }
      } catch {}
    }
  } catch {}
  try {
    foreach ($line in @(& netstat.exe -ano -p tcp 2>$null)) {
      $parts = @(([string]$line).Trim() -split '\s+')
      if ($parts.Count -ge 5 -and $parts[0].ToUpperInvariant() -eq 'TCP' -and $parts[1].EndsWith(':17890') -and $parts[3].ToUpperInvariant() -eq 'LISTENING') {
        $pidToStop = 0
        if ([int]::TryParse($parts[4],[ref]$pidToStop) -and $pidToStop -gt 0 -and $pidToStop -ne $PID) {
          Stop-Process -Id $pidToStop -Force -ErrorAction SilentlyContinue
        }
      }
    }
  } catch {}
  Start-Sleep -Milliseconds 150
}

try {
  if (-not (Test-Path -LiteralPath $mp3Zip -PathType Leaf)) {
    Log 'MP3 payload yok; component post-step atlandi.'
    exit 0
  }

  $probe = Join-Path $env:TEMP ('KafePin-MP3-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $probe | Out-Null
  try {
    Expand-Archive -LiteralPath $mp3Zip -DestinationPath $probe -Force
    $metaPath = Join-Path $probe 'mp3-web-version.json'
    if (-not (Test-Path -LiteralPath $metaPath -PathType Leaf)) { throw 'MP3 version metadata bulunamadi.' }
    $meta = Get-Content -LiteralPath $metaPath -Raw | ConvertFrom-Json
    $expected = [string]$meta.version
    if ([string]::IsNullOrWhiteSpace($expected)) { throw 'MP3 version bos.' }

    $installed = ''
    try {
      $installedMeta = Join-Path $mp3Root 'mp3-web-version.json'
      if (Test-Path -LiteralPath $installedMeta -PathType Leaf) {
        $installed = [string]((Get-Content -LiteralPath $installedMeta -Raw | ConvertFrom-Json).version)
      }
    } catch {}

    # LOCK: surum numarasi tek basina yeterli degil. Ayni surumde eski web/app.js
    # veya index.html kalirsa sol etiket eski gorunebilir. Paket her guncellemede
    # exact payload olarak yeniden eslenir; kullanici state/.venv/logs korunur.
    if ($installed -eq $expected) {
      Log ('MP3 surumu ayni; exact payload esitlemesi yine uygulanacak: ' + $expected)
    }

    Stop-Mp3Runtime
    New-Item -ItemType Directory -Force -Path $mp3Root | Out-Null

    $preserve = @('state.json','favorites.json','.env','.venv','logs')
    $incomingWeb = Join-Path $probe 'web'
    $targetWeb = Join-Path $mp3Root 'web'
    if (Test-Path -LiteralPath $incomingWeb -PathType Container) {
      Remove-Item -LiteralPath $targetWeb -Recurse -Force -ErrorAction SilentlyContinue
      Copy-Item -LiteralPath $incomingWeb -Destination $targetWeb -Recurse -Force
    }

    Get-ChildItem -LiteralPath $probe -Force | Where-Object {
      $_.Name -notin $preserve -and $_.Name -ne 'web'
    } | ForEach-Object {
      Copy-Item -LiteralPath $_.FullName -Destination $mp3Root -Recurse -Force
    }

    $actual = [string]((Get-Content -LiteralPath (Join-Path $mp3Root 'mp3-web-version.json') -Raw | ConvertFrom-Json).version)
    if ($actual -ne $expected) { throw ('MP3 dogrulama hatasi. Beklenen=' + $expected + ' Kurulu=' + $actual) }

    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $flag) | Out-Null
    [ordered]@{ version=$expected; createdAt=(Get-Date).ToString('o') } | ConvertTo-Json -Compress | Set-Content -LiteralPath $flag -Encoding UTF8
    Log ('MP3 payload esitlendi; sessiz restart isareti birakildi: ' + $expected)
  } finally {
    Remove-Item -LiteralPath $probe -Recurse -Force -ErrorAction SilentlyContinue
  }
} catch {
  Log ('MP3 component post-step uyarisi: ' + $_.Exception.Message)
}



# v3.1.87 TEST R3: CV Olustur PRO her update'te bagimsiz 5. PRO servis olarak
# C:\KafePinPro\CVOlusturPRO altina exact eslenir. Yalniz kullanici ayar/loglari korunur.
try {
  if (Test-Path -LiteralPath $cvZip -PathType Leaf) {
    $cvProbe = Join-Path $env:TEMP ('KafePin-CVPRO-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $cvProbe | Out-Null
    try {
      Expand-Archive -LiteralPath $cvZip -DestinationPath $cvProbe -Force
      if (-not (Test-Path -LiteralPath (Join-Path $cvProbe 'web_service.py') -PathType Leaf)) { throw 'CV PRO web_service.py bulunamadi.' }
      if (-not (Test-Path -LiteralPath (Join-Path $cvProbe 'web\index.html') -PathType Leaf)) { throw 'CV PRO web/index.html bulunamadi.' }
      # Eski CV servis prosesi varsa yalniz kendi kok/path veya portundan durdur.
      try {
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
          $name=([string]$_.Name).ToLowerInvariant(); $cmd=([string]$_.CommandLine).Replace('/','\').ToLowerInvariant()
          ($name -in @('python.exe','pythonw.exe','py.exe','python3.exe')) -and $cmd.Contains('c:\kafepinpro\cvolusturpro')
        } | ForEach-Object { Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue }
      } catch {}
      New-Item -ItemType Directory -Force -Path $cvRoot | Out-Null
      $preserve=@('config.json','settings.json','logs')
      foreach($item in @(Get-ChildItem -LiteralPath $cvProbe -Force)) {
        if($item.Name -in $preserve -and (Test-Path -LiteralPath (Join-Path $cvRoot $item.Name))) { continue }
        $dst=Join-Path $cvRoot $item.Name
        if($item.PSIsContainer) {
          if(Test-Path -LiteralPath $dst){ Remove-Item -LiteralPath $dst -Recurse -Force -ErrorAction SilentlyContinue }
          Copy-Item -LiteralPath $item.FullName -Destination $dst -Recurse -Force
        } else { Copy-Item -LiteralPath $item.FullName -Destination $dst -Force }
      }
      Log 'CV Olustur PRO bagimsiz payload C:\KafePinPro\CVOlusturPRO altina esitlendi.'
    } finally { Remove-Item -LiteralPath $cvProbe -Recurse -Force -ErrorAction SilentlyContinue }
  }
} catch { Log ('CV PRO component post-step uyarisi: ' + $_.Exception.Message) }

# Client Performans PRO yalnız mevcut Client Yönetim PRO bulunan kafelerde
# güvenli şekilde eklenir. Veriler EveryCafe'den yazılmaz; yalnız Client PRO
# salt-okunur listesi ve Libre Hardware Monitor JSON'u kullanılır.
try {
  if ((Test-Path -LiteralPath $performanceZip -PathType Leaf) -and (Test-Path -LiteralPath (Join-Path $ProRoot 'ClientYonetimPRO'))) {
    $performanceProbe = Join-Path $env:TEMP ('KafePin-ClientPerformance-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $performanceProbe | Out-Null
    try {
      Expand-Archive -LiteralPath $performanceZip -DestinationPath $performanceProbe -Force
      if (-not (Test-Path -LiteralPath (Join-Path $performanceProbe 'web_service.py') -PathType Leaf)) { throw 'Client Performans PRO web_service.py bulunamadi.' }
      try {
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
          $name=([string]$_.Name).ToLowerInvariant(); $cmd=([string]$_.CommandLine).Replace('/','\').ToLowerInvariant()
          ($name -in @('python.exe','pythonw.exe','py.exe','python3.exe')) -and $cmd.Contains('c:\kafepinpro\clientperformanspro')
        } | ForEach-Object { Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue }
      } catch {}
      # Eski/askida kalmis py.exe ebeveyni komut satirinda klasoru gostermeyebilir.
      # 17896 portunu dinleyen yalniz Client Performans PRO prosesini de durdur.
      try {
        foreach ($line in @(& netstat.exe -ano -p tcp 2>$null)) {
          $parts = @(([string]$line).Trim() -split '\s+')
          if ($parts.Count -ge 5 -and $parts[0].ToUpperInvariant() -eq 'TCP' -and $parts[1].EndsWith(':17896') -and $parts[3].ToUpperInvariant() -eq 'LISTENING') {
            $pidToStop = 0
            if ([int]::TryParse($parts[4],[ref]$pidToStop) -and $pidToStop -gt 0 -and $pidToStop -ne $PID) {
              Stop-Process -Id $pidToStop -Force -ErrorAction SilentlyContinue
            }
          }
        }
      } catch {}
      Start-Sleep -Milliseconds 200
      New-Item -ItemType Directory -Force -Path $performanceRoot | Out-Null
      foreach($item in @(Get-ChildItem -LiteralPath $performanceProbe -Force)) {
        $dst=Join-Path $performanceRoot $item.Name
        if($item.PSIsContainer) {
          if(Test-Path -LiteralPath $dst){ Remove-Item -LiteralPath $dst -Recurse -Force -ErrorAction SilentlyContinue }
          Copy-Item -LiteralPath $item.FullName -Destination $dst -Recurse -Force
        } else { Copy-Item -LiteralPath $item.FullName -Destination $dst -Force }
      }
      Log 'Client Performans PRO payload C:\KafePinPro\ClientPerformansPRO altina esitlendi.'
    } finally { Remove-Item -LiteralPath $performanceProbe -Recurse -Force -ErrorAction SilentlyContinue }
  }
} catch { Log ('Client Performans PRO component post-step uyarisi: ' + $_.Exception.Message) }

# Bu post-step ana KafePin guncellemesini ASLA bloke etmez.
exit 0
