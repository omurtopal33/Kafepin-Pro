param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$NodePath = ''
)

$ErrorActionPreference = 'SilentlyContinue'

# v3.1.85 TEST compatibility shim.
# IMPORTANT: Older KafePin updater builds call this script synchronously and
# abort the whole update when it returns a non-zero exit code. Server Manager
# health is no longer an update prerequisite, so this script must be best-effort
# only and must never block an otherwise valid update.
try {
  $programData = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
  $systemRoot = Join-Path $programData 'KafePinPro'
  if (-not (Test-Path -LiteralPath $systemRoot)) {
    New-Item -ItemType Directory -Path $systemRoot -Force | Out-Null
  }

  $managerSource = Join-Path $InstallRoot 'KafePin_System_Manager.ps1'
  $managerLive = Join-Path $systemRoot 'KafePin_System_Manager.ps1'
  if (Test-Path -LiteralPath $managerSource -PathType Leaf) {
    Copy-Item -LiteralPath $managerSource -Destination $managerLive -Force -ErrorAction SilentlyContinue
  }

  # If the historical scheduled task exists, nudge it silently. Missing task,
  # access issues, or a slow control port are deliberately non-fatal here.
  $schtasks = Join-Path $env:SystemRoot 'System32\schtasks.exe'
  if (Test-Path -LiteralPath $schtasks -PathType Leaf) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $schtasks
    $psi.Arguments = '/Run /TN "KafePin Pro Server Manager"'
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
    $p = [System.Diagnostics.Process]::Start($psi)
    if ($p) { $p.WaitForExit(2500) | Out-Null }
  }
} catch {
  # Best effort only. Never surface a PowerShell error and never fail update.
}

exit 0
