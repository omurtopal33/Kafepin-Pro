﻿param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$ProRoot = 'C:\KafePinPro',
  [switch]$RunNow
)

$ErrorActionPreference = 'Stop'
$TaskName = 'KafePin PRO Runtime Refresh'
$RefreshScript = Join-Path $InstallRoot 'KafePin_Pro_Runtime_Refresh.ps1'
$ProgramDataRoot = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
$StateRoot = Join-Path $ProgramDataRoot 'KafePinPro'
$LogPath = Join-Path $StateRoot 'pro-runtime-ensure.log'

function Log([string]$Text) {
  try {
    New-Item -ItemType Directory -Force -Path $StateRoot | Out-Null
    Add-Content -LiteralPath $LogPath -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Text) -Encoding UTF8
  } catch {}
}

function Get-InteractiveUser {
  try {
    $u = [string](Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).UserName
    if ($u) { return $u }
  } catch {}
  try {
    $items = Get-CimInstance Win32_Process -Filter "Name='explorer.exe'" -ErrorAction Stop | Sort-Object SessionId -Descending
    foreach ($p in $items) {
      if ([int]$p.SessionId -le 0) { continue }
      try {
        $owner = Invoke-CimMethod -InputObject $p -MethodName GetOwner -ErrorAction Stop
        if ($owner.User) {
          if ($owner.Domain) { return ([string]$owner.Domain + '\' + [string]$owner.User) }
          return [string]$owner.User
        }
      } catch {}
    }
  } catch {}
  return ''
}

function Remove-ObsoleteProTasks {
  $keep = @('KafePin PRO Runtime Refresh','KafePin Pro Server Manager','KafePin Pro Restore Worker','KafePin Pro Desktop Action')
  $tokens = @(
    'c:\kafepinpro\mp3botpro','c:\kafepinpro\mp3bot\','c:\kafepinmp3botpro',
    'c:\kafepinpro\yazicipro','c:\kafepinyazicipro',
    'c:\kafepinpro\teknikservispro','c:\kafepinteknikservispro',
    'c:\kafepinpro\clientyonetimpro','c:\kafepinclientyonetimpro'
  )
  try {
    $service = New-Object -ComObject 'Schedule.Service'
    $service.Connect()
    $root = $service.GetFolder('\')
    foreach ($task in @($root.GetTasks(0))) {
      try {
        $name = [string]$task.Name
        if ($name -in $keep) { continue }
        $hit = $false
        foreach ($action in @($task.Definition.Actions)) {
          $text = (([string]$action.Path) + ' ' + ([string]$action.Arguments) + ' ' + ([string]$action.WorkingDirectory)).Replace('/','\').ToLowerInvariant()
          foreach ($token in $tokens) { if ($text.Contains($token)) { $hit = $true; break } }
          if ($hit) { break }
        }
        if ($hit) { $root.DeleteTask($name,0); Log ('Eski/ayri PRO gorevi kaldirildi: ' + $name) }
      } catch {}
    }
  } catch { Log ('Eski PRO gorev temizleme uyarisi: ' + $_.Exception.Message) }
}

if (-not (Test-Path -LiteralPath $RefreshScript -PathType Leaf)) {
  throw ('PRO runtime yenileme dosyasi bulunamadi: ' + $RefreshScript)
}

$user = Get-InteractiveUser
if (-not $user) { throw 'Aktif Windows masaustu kullanicisi bulunamadi.' }
New-Item -ItemType Directory -Force -Path $StateRoot | Out-Null
Remove-ObsoleteProTasks

$service = New-Object -ComObject 'Schedule.Service'
$service.Connect()
$root = $service.GetFolder('\')
$definition = $service.NewTask(0)
$definition.RegistrationInfo.Description = 'KafePin PRO servislerini C:\KafePinPro altindan sessiz ve temiz sekilde yeniden baslatir.'
$definition.Settings.Enabled = $true
$definition.Settings.AllowDemandStart = $true
$definition.Settings.StartWhenAvailable = $true
$definition.Settings.Hidden = $true
$definition.Settings.ExecutionTimeLimit = 'PT2M'
$definition.Settings.MultipleInstances = 2
$definition.Principal.UserId = $user
$definition.Principal.LogonType = 3
$definition.Principal.RunLevel = 1

$trigger = $definition.Triggers.Create(9)
$trigger.UserId = $user
$trigger.Enabled = $true

$action = $definition.Actions.Create(0)
$action.Path = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$action.Arguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $RefreshScript + '" -InstallRoot "' + $InstallRoot + '" -ProRoot "' + $ProRoot + '"'
$action.WorkingDirectory = $InstallRoot

$null = $root.RegisterTaskDefinition($TaskName, $definition, 6, $user, $null, 3, $null)
Log ('Runtime gorevi hazirlandi. user=' + $user)

if ($RunNow) {
  try {
    $registered = $root.GetTask($TaskName)
    if (-not $registered) { throw 'Runtime gorevi bulunamadi.' }
    $null = $registered.Run($null)
    Log 'Runtime gorevi tetiklendi.'
  } catch { throw ('Runtime gorevi baslatilamadi: ' + $_.Exception.Message) }
}

Write-Output ('READY|' + $user + '|' + $TaskName)
