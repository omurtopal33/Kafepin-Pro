param(
  [string]$InstallRoot = 'C:\KafePin',
  [switch]$WaitForDownFirst,
  [switch]$LaunchDesktop,
  [string]$Reason = 'automatic'
)

$ErrorActionPreference = 'Continue'
$Root = $InstallRoot
$ServerJs = Join-Path $Root 'server.js'
$LogDir = Join-Path $Root 'logs'
$RecoveryLog = Join-Path $LogDir 'recovery-engine.log'
$ServerOut = Join-Path $LogDir 'recovery-server.out.log'
$ServerErr = Join-Path $LogDir 'recovery-server.err.log'
$DesktopExe = Join-Path $Root 'desktop-app\KafePin Pro.exe'
$DesktopSetup = Join-Path $Root 'KafePin_Desktop_App_Setup.ps1'
$HealthUrl = 'http://127.0.0.1:3000/api/health'
$SystemRoot = Join-Path $env:ProgramData 'KafePinPro'
$ResultFile = Join-Path $SystemRoot 'recovery-result.json'

New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
New-Item -ItemType Directory -Path $SystemRoot -Force | Out-Null

function Log([string]$Text){
  $line = ('[{0}] [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Reason, $Text)
  Add-Content -LiteralPath $RecoveryLog -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue
}

function Write-Result([bool]$Ok,[string]$Message){
  try {
    [ordered]@{ ok=$Ok; reason=$Reason; message=$Message; time=(Get-Date).ToString('o') } |
      ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $ResultFile -Encoding UTF8
  } catch {}
}

function Health {
  try {
    $r = Invoke-WebRequest -UseBasicParsing -Uri ($HealthUrl + '?recovery=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 2 -Headers @{ 'Cache-Control'='no-cache' }
    return ($r.StatusCode -ge 200 -and $r.StatusCode -lt 300)
  } catch { return $false }
}

function Wait-Health([int]$Seconds){
  for($i=0; $i -lt $Seconds; $i++){
    if(Health){ return $true }
    Start-Sleep -Seconds 1
  }
  return $false
}

function Find-Node {
  $candidates = New-Object System.Collections.Generic.List[string]
  try {
    $cmd = Get-Command node.exe -ErrorAction SilentlyContinue
    if($cmd -and $cmd.Source){ $candidates.Add($cmd.Source) }
  } catch {}

  foreach($p in @(
    (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
    ($(if(${env:ProgramFiles(x86)}){Join-Path ${env:ProgramFiles(x86)} 'nodejs\node.exe'}else{$null})),
    (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe'),
    'C:\nodejs\node.exe',
    (Join-Path $Root 'node.exe'),
    (Join-Path $Root 'node\node.exe')
  )){ if($p){ $candidates.Add([string]$p) } }

  foreach($rk in @('HKLM:\SOFTWARE\Node.js','HKLM:\SOFTWARE\WOW6432Node\Node.js','HKCU:\SOFTWARE\Node.js')){
    try {
      $v = Get-ItemProperty -Path $rk -ErrorAction Stop
      foreach($name in @('InstallPath','Path')){
        $base = [string]$v.$name
        if($base){ $candidates.Add((Join-Path $base 'node.exe')) }
      }
    } catch {}
  }

  try {
    Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue | ForEach-Object {
      if($_.ExecutablePath){ $candidates.Add([string]$_.ExecutablePath) }
    }
  } catch {}

  foreach($c in ($candidates | Select-Object -Unique)){
    if($c -and (Test-Path -LiteralPath $c)){ return $c }
  }
  return $null
}

function Start-Desktop {
  if(-not $LaunchDesktop){ return }
  try {
    $running = @(Get-Process -Name 'KafePin Pro' -ErrorAction SilentlyContinue)
    if($running.Count -gt 0){ Log 'Masaustu uygulamasi zaten acik.'; return }
  } catch {}

  if(Test-Path -LiteralPath $DesktopExe){
    try {
      Start-Process -FilePath $DesktopExe -WorkingDirectory (Split-Path -Parent $DesktopExe) | Out-Null
      Log 'KafePin Pro masaustu uygulamasi acildi.'
      return
    } catch { Log ('Masaustu uygulamasi acilamadi: ' + $_.Exception.Message) }
  }

  if(Test-Path -LiteralPath $DesktopSetup){
    try {
      Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$DesktopSetup,'-Launch') -WindowStyle Hidden | Out-Null
      Log 'Masaustu setup -Launch baslatildi.'
    } catch { Log ('Masaustu setup baslatilamadi: ' + $_.Exception.Message) }
  }
}

Log 'Kurtarma motoru basladi.'

if($WaitForDownFirst){
  Log 'Sunucunun yeniden baslama icin kapanmasi bekleniyor.'
  for($i=0; $i -lt 15; $i++){
    if(-not (Health)){ break }
    Start-Sleep -Seconds 1
  }
  Start-Sleep -Milliseconds 800
}

if(Health){
  Log 'Sunucu zaten saglikli.'
  Write-Result $true 'Sunucu zaten saglikli'
  Start-Desktop
  exit 0
}

if(-not (Test-Path -LiteralPath $ServerJs)){
  Log ('HATA: server.js bulunamadi: ' + $ServerJs)
  Write-Result $false 'server.js bulunamadi'
  exit 2
}

# Acil kurtarmada kilitler bilerek temizlenir.
foreach($lock in @(
  (Join-Path $SystemRoot 'maintenance.lock'),
  (Join-Path $SystemRoot 'server.manual-stop')
)){
  try {
    if(Test-Path -LiteralPath $lock){ Remove-Item -LiteralPath $lock -Force -ErrorAction Stop; Log ((Split-Path -Leaf $lock) + ' temizlendi.') }
  } catch { Log ((Split-Path -Leaf $lock) + ' temizlenemedi: ' + $_.Exception.Message) }
}

# 1) Resmi Server Manager.
try {
  $task = Get-ScheduledTask -TaskName 'KafePin Pro Server Manager' -ErrorAction Stop
  Log ('Server Manager bulundu. Durum: ' + $task.State)
  Start-ScheduledTask -TaskName 'KafePin Pro Server Manager' -ErrorAction Stop
  Log 'Server Manager calistirildi.'
} catch {
  Log ('Server Manager kullanilamadi: ' + $_.Exception.Message)
  try { & schtasks.exe /Run /TN 'KafePin Pro Server Manager' | Out-Null } catch {}
}

if(Wait-Health 12){
  Log 'BASARILI: Server Manager ile sunucu acildi.'
  Write-Result $true 'Server Manager ile sunucu acildi'
  Start-Desktop
  exit 0
}

# 2) ACIL KURTARMA v2 ile ayni dogrudan Node fallback.
Log 'Server Manager sonrasi sunucu gelmedi; dogrudan Node baslatma deneniyor.'
try {
  Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue | Where-Object {
    $_.CommandLine -and $_.CommandLine.IndexOf($ServerJs,[StringComparison]::OrdinalIgnoreCase) -ge 0
  } | ForEach-Object {
    Log ('Eski KafePin node sureci kapatiliyor PID=' + $_.ProcessId)
    Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
  }
} catch {}
Start-Sleep -Seconds 1

$node = Find-Node
if(-not $node){
  Log 'HATA: node.exe bulunamadi.'
  Write-Result $false 'node.exe bulunamadi'
  exit 3
}

Log ('Node bulundu: ' + $node)
Remove-Item -LiteralPath $ServerOut,$ServerErr -Force -ErrorAction SilentlyContinue
try {
  Start-Process -FilePath $node -ArgumentList @('server.js') -WorkingDirectory $Root -WindowStyle Hidden -RedirectStandardOutput $ServerOut -RedirectStandardError $ServerErr | Out-Null
  Log 'server.js dogrudan baslatildi.'
} catch {
  Log ('Node baslatma HATASI: ' + $_.Exception.Message)
}

if(Wait-Health 35){
  Log 'BASARILI: KafePin sunucusu saglikli.'
  Write-Result $true 'Node fallback ile sunucu acildi'
  Start-Desktop
  exit 0
}

$detail = 'Sunucu saglik kontrolunden gecemedi'
try {
  if(Test-Path -LiteralPath $ServerErr){
    $tail = (Get-Content -LiteralPath $ServerErr -Tail 15 -ErrorAction SilentlyContinue) -join ' | '
    if($tail){ $detail += ': ' + $tail }
  }
} catch {}
Log ('BASARISIZ: ' + $detail)
Write-Result $false $detail
exit 1
