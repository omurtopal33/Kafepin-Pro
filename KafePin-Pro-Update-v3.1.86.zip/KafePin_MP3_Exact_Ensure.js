'use strict';
const fs = require('fs');
const path = require('path');
const http = require('http');
const { spawnSync } = require('child_process');

function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }
function readJson(p){ try{return JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));}catch(_){return null;} }
function run(exe,args,timeout=10000){
  const r=spawnSync(exe,args,{encoding:'utf8',windowsHide:true,timeout});
  return {code:Number.isInteger(r.status)?r.status:-1,stdout:String(r.stdout||''),stderr:String(r.stderr||'')};
}
function health(){
  return new Promise(resolve=>{
    const req=http.get({host:'127.0.0.1',port:17890,path:'/api/health?_exact='+Date.now(),timeout:1200,headers:{'Cache-Control':'no-cache'}},res=>{
      let b=''; res.on('data',c=>b+=String(c)); res.on('end',()=>{try{resolve({ok:res.statusCode>=200&&res.statusCode<300,json:JSON.parse(b)});}catch(_){resolve({ok:false,json:null});}});
    });
    req.on('timeout',()=>req.destroy()); req.on('error',()=>resolve({ok:false,json:null}));
  });
}
function sameRoot(a,b){
  const norm=s=>String(s||'').replace(/\//g,'\\').replace(/\\+$/,'').toLowerCase();
  return !!norm(a) && norm(a)===norm(b);
}
async function main(){
  if(process.platform!=='win32') return 0;
  const mp3Root=process.env.KAFEPIN_MP3_ROOT||'C:\\KafePinPro\\MP3BotPRO';
  const meta=readJson(path.join(mp3Root,'mp3-web-version.json'));
  const expected=String(meta&&meta.version||'').trim();
  if(!expected) throw new Error('MP3 beklenen surum okunamadi');

  const h0=await health();
  if(h0.ok && h0.json && String(h0.json.version||'')===expected && sameRoot(h0.json.programRoot,mp3Root)) return 0;

  const programData=process.env.ProgramData||'C:\\ProgramData';
  const bridge=path.join(programData,'KafePinPro','DesktopBridge');
  const requestFile=path.join(bridge,'request.json');
  const resultFile=path.join(bridge,'result.json');
  const requestId=`mp3-exact-${process.pid}-${Date.now()}`;
  fs.mkdirSync(bridge,{recursive:true});
  fs.writeFileSync(requestFile,JSON.stringify({requestId,action:'restart-mp3-only',expectedVersion:expected,createdAt:Date.now()}),'utf8');
  try{fs.unlinkSync(resultFile);}catch(_){}

  let task=run('schtasks.exe',['/Run','/TN','KafePin Pro Desktop Action'],5000);
  if(task.code!==0){
    const ensure=path.join(__dirname,'KafePin_Desktop_Helper_Ensure.ps1');
    if(!fs.existsSync(ensure)) throw new Error('Desktop Action gorevi yok ve ensure bulunamadi');
    const er=run('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',ensure,'-InstallRoot',__dirname],12000);
    if(er.code!==0) throw new Error('Desktop Action hazirlanamadi: '+(er.stderr||er.stdout).trim());
    task=run('schtasks.exe',['/Run','/TN','KafePin Pro Desktop Action'],5000);
    if(task.code!==0) throw new Error('Desktop Action tetiklenemedi');
  }

  const end=Date.now()+45000;
  while(Date.now()<end){
    const result=readJson(resultFile);
    if(result && String(result.requestId||'')===requestId && result.ok===false) throw new Error(String(result.error||'MP3 restart basarisiz'));
    const h=await health();
    if(h.ok && h.json && String(h.json.version||'')===expected && sameRoot(h.json.programRoot,mp3Root)) return 0;
    await sleep(250);
  }
  throw new Error(`MP3 exact health-check gecmedi: ${expected}`);
}

main().then(()=>process.exit(0)).catch(err=>{try{console.error(err&&err.message||err);}catch(_){} process.exit(2);});
