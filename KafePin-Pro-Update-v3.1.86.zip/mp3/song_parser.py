from __future__ import annotations
import re
from pathlib import Path
from typing import Iterable
from openpyxl import load_workbook

NUM_RE = re.compile(r"^\s*(?:\d+[\.\-\)\:]|[-•*])\s*")
SPACE_RE = re.compile(r"\s+")

def normalize_line(s: str) -> str:
    s = (s.replace("\u2013", "-").replace("\u2014", "-")
           .replace("\u2212", "-").replace("\t", " "))
    s = NUM_RE.sub("", s)
    s = SPACE_RE.sub(" ", s).strip(" -\r\n\t")
    return s

def clean_song_lines(lines: Iterable[str]) -> list[str]:
    out = []
    seen = set()
    blocked = {
        "şarkı", "şarkılar", "liste", "mp3 listesi",
        "sanatçı", "şarkı adı", "sanatçı - şarkı",
        "müzik listesi", "müzikler"
    }

    for raw in lines:
        s = normalize_line(str(raw))
        if not s:
            continue

        # Aşırı uzun veya bariz OCR çöpü satırlarını ele.
        if len(s) < 3 or len(s) > 100:
            continue

        letters = sum(ch.isalpha() for ch in s)
        if letters < 3:
            continue

        tokens = [t for t in re.split(r"\s+", s) if t]
        if tokens:
            one_char = sum(1 for t in tokens if len(t) == 1)
            if len(tokens) >= 5 and one_char / len(tokens) > 0.5:
                continue

        low = s.casefold()
        if low in blocked or low in seen:
            continue

        seen.add(low)
        out.append(s)

    return out

def parse_text(text: str) -> list[str]:
    return clean_song_lines(text.splitlines())

def parse_txt(path: str | Path) -> list[str]:
    return parse_text(Path(path).read_text(encoding="utf-8-sig", errors="replace"))

def parse_xlsx(path: str | Path) -> list[str]:
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = []
    for row in ws.iter_rows(values_only=True):
        vals = [str(v).strip() for v in row if v is not None and str(v).strip()]
        if len(vals) >= 2:
            rows.append(f"{vals[0]} - {vals[1]}")
        elif len(vals) == 1:
            rows.append(vals[0])
    wb.close()
    return clean_song_lines(rows)
