from __future__ import annotations
import os
import re
import shutil
import time
from pathlib import Path
from audio_normalizer import normalize_to_temp_mp3
from duplicate_guard import car_artist_title, find_duplicate_mp3

AUDIO_EXTS = {".mp3"}
TEMP_EXTS = {".part", ".tmp", ".temp", ".download", ".crdownload"}

INVALID = re.compile(r'[<>:"/\\|?*]')

def safe_customer_name(name: str) -> str:
    name = INVALID.sub("_", name.strip()).strip(" .")
    return name[:120]

def ensure_customer_folder(root: str | Path, customer: str) -> Path:
    name = safe_customer_name(customer)
    if not name:
        raise ValueError("Müşteri adı boş.")
    out = Path(root).expanduser() / name
    out.mkdir(parents=True, exist_ok=True)
    return out

def snapshot_audio(folder: str | Path) -> dict[str, tuple[int, float]]:
    p = Path(folder).expanduser()
    if not p.exists():
        return {}
    result = {}
    for f in p.iterdir():
        try:
            if f.is_file() and f.suffix.casefold() in AUDIO_EXTS:
                st = f.stat()
                result[str(f.resolve())] = (st.st_size, st.st_mtime)
        except Exception:
            pass
    return result

def _unique_target(target_dir: Path, filename: str) -> Path:
    base = target_dir / filename
    if not base.exists():
        return base
    stem = base.stem
    suffix = base.suffix
    n = 2
    while True:
        candidate = target_dir / f"{stem} ({n}){suffix}"
        if not candidate.exists():
            return candidate
        n += 1

def find_new_audio(
    folder: str | Path,
    baseline: dict[str, tuple[int, float]],
    since_ts: float
) -> list[Path]:
    p = Path(folder).expanduser()
    if not p.exists():
        return []

    out = []
    for f in p.iterdir():
        try:
            if not f.is_file() or f.suffix.casefold() not in AUDIO_EXTS:
                continue
            rp = str(f.resolve())
            st = f.stat()
            if rp not in baseline and st.st_mtime >= since_ts - 3:
                out.append(f)
        except Exception:
            pass
    return out

def wait_until_stable(
    path: Path,
    stable_seconds: int = 5,
    timeout: int = 180
) -> bool:
    """
    MP3 boyutu belirli süre değişmezse ve aynı taban adda geçici indirme
    uzantısı yoksa tamamlanmış kabul eder.
    """
    start = time.time()
    last_size = -1
    stable_since = None

    while time.time() - start < timeout:
        try:
            if not path.exists():
                return False

            size = path.stat().st_size

            if size > 0 and size == last_size:
                if stable_since is None:
                    stable_since = time.time()

                if time.time() - stable_since >= stable_seconds:
                    siblings = list(path.parent.glob(path.stem + ".*"))
                    if not any(s.suffix.casefold() in TEMP_EXTS for s in siblings):
                        return True
            else:
                stable_since = None
                last_size = size

        except Exception:
            stable_since = None

        time.sleep(1)

    return False

def move_completed_audio(
    src: Path,
    target_dir: Path,
    bitrate_kbps: int = 320,
    eq_preset: str = "Araba Dengeli",
) -> Path:
    """
    Dış kaynaktan tamamlanan MP3:

    1) Kaynağı TEMP altında 2-pass EBU R128 ile normalize eder.
    2) Hedef müşteri klasörüne yalnız normalize edilmiş MP3'ü .moving olarak kopyalar.
    3) Boyutu doğrular.
    4) Final .mp3 adına çevirir.
    5) Ancak final doğrulandıktan sonra kaynak MP3'ünü siler.

    Hedef:
      -14 LUFS
      -2.0 dBTP
      LRA 9
    """
    target_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    if not src.exists():
        raise FileNotFoundError(
            str(src)
        )

    if src.stat().st_size <= 0:
        raise IOError(
            f"Kaynak MP3 boş görünüyor: {src.name}"
        )

    if bitrate_kbps not in (128, 320):
        bitrate_kbps = 320

    artist, title = car_artist_title(src.stem)
    duplicate = find_duplicate_mp3(target_dir, artist, title)
    if duplicate is not None:
        # Kaynak dosya tekrar tekrar watcher'a takilmasin diye sil.
        try:
            src.unlink()
        except Exception:
            pass
        raise FileExistsError(f"Zaten var, tekrar alinmadi: {duplicate.name}")

    clean_name = f"{artist} - {title}.mp3" if artist and title else src.name
    clean_name = INVALID.sub("_", clean_name).strip(" .")
    final_dst = target_dir / clean_name

    temp_dst = final_dst.with_name(
        final_dst.name + ".moving"
    )

    if temp_dst.exists():
        temp_dst.unlink()

    norm_dir = None

    try:
        normalized, norm_dir = normalize_to_temp_mp3(
            source=src,
            bitrate_kbps=bitrate_kbps,
            target_i=-14.0,
            target_tp=-2.0,
            target_lra=9.0,
            eq_preset=eq_preset,
            metadata_artist=artist,
            metadata_title=title,
        )

        normalized_size = normalized.stat().st_size

        if normalized_size <= 0:
            raise IOError(
                "Normalize edilmiş MP3 boş."
            )

        shutil.copy2(
            str(normalized),
            str(temp_dst),
        )

        if not temp_dst.exists():
            raise IOError(
                "Hedef geçici kopya oluşturulamadı."
            )

        dst_size = temp_dst.stat().st_size

        if dst_size != normalized_size:
            try:
                temp_dst.unlink()
            except Exception:
                pass

            raise IOError(
                "Normalize MP3 kopya doğrulaması başarısız: "
                f"kaynak={normalized_size}, hedef={dst_size}"
            )

        os.replace(
            str(temp_dst),
            str(final_dst),
        )

        if (
            not final_dst.exists()
            or final_dst.stat().st_size
            != normalized_size
        ):
            raise IOError(
                "Normalize edilmiş hedef MP3 son doğrulamadan geçemedi."
            )

        # Yalnız final normalize MP3 doğrulandıktan sonra kaynak dosyayı sil.
        try:
            src.unlink()
        except PermissionError:
            time.sleep(2)
            src.unlink()

        return final_dst

    finally:
        if temp_dst.exists():
            try:
                temp_dst.unlink()
            except Exception:
                pass

        if norm_dir is not None:
            shutil.rmtree(
                norm_dir,
                ignore_errors=True,
            )
