from __future__ import annotations

import io
import os
import socket
import tempfile
import threading
import uuid
from pathlib import Path
from typing import Callable

from flask import Flask, request, render_template_string
import qrcode

HTML = r"""
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MP3 Müşteri Asistanı</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f4f6;margin:0;padding:20px}
.card{max-width:520px;margin:30px auto;background:white;padding:24px;border-radius:16px;
box-shadow:0 4px 18px rgba(0,0,0,.12)}
h2{margin-top:0}
input[type=file]{width:100%;padding:12px;border:1px solid #ccc;border-radius:8px}
button{width:100%;margin-top:16px;padding:14px;border:0;border-radius:10px;background:#16a34a;
color:white;font-weight:bold;font-size:18px}
.note{font-size:14px;color:#555;line-height:1.45}
.ok{background:#ecfdf5;border:1px solid #86efac;padding:14px;border-radius:10px}
</style>
</head>
<body>
<div class="card">
{% if done %}
<div class="ok"><b>Fotoğraf gönderildi.</b><br>Fotoğraf bilgisayara ulaştı. Şimdi ChatGPT açılıyor.</div>
{% else %}
<h2>📱 Müşteri Liste Fotoğrafını Gönder</h2>
<p class="note">Müşterinin şarkı listesinin fotoğrafını seç veya kamerayla çek.</p>
<form method="post" enctype="multipart/form-data">
<input type="file" name="photo" accept="image/*" capture="environment" required>
<button type="submit">FOTOĞRAFI GÖNDER</button>
</form>
<p class="note">Bu sayfa yalnızca aynı yerel ağdaki bilgisayara fotoğraf yükler.</p>
{% endif %}
</div>
</body>
</html>
"""

def get_local_ip() -> str:
    """
    Aktif LAN IP'sini bulmaya çalışır.
    Ağ yoksa hostname üzerinden fallback yapar.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        if ip and not ip.startswith("127."):
            return ip
    except Exception:
        pass
    finally:
        s.close()

    try:
        ip = socket.gethostbyname(socket.gethostname())
        if ip and not ip.startswith("127."):
            return ip
    except Exception:
        pass

    return "127.0.0.1"

def find_free_port(start=8765, end=8795) -> int:
    for port in range(start, end + 1):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(("0.0.0.0", port))
            return port
        except OSError:
            continue
        finally:
            s.close()
    raise RuntimeError("Telefon yükleme servisi için boş port bulunamadı.")

class PhoneUploadServer:
    def __init__(self, on_photo: Callable[[str], None]):
        self.on_photo = on_photo
        self.token = uuid.uuid4().hex
        self.port = find_free_port()
        self.ip = get_local_ip()
        self.url = f"http://{self.ip}:{self.port}/{self.token}"
        self._thread = None
        self._started = False
        self._app = Flask(f"mp3_phone_upload_{self.token}")

        @self._app.route(f"/{self.token}", methods=["GET", "POST"])
        def upload():
            if request.method == "GET":
                return render_template_string(HTML, done=False)

            file = request.files.get("photo")
            if not file or not file.filename:
                return "Fotoğraf seçilmedi.", 400

            suffix = Path(file.filename).suffix.lower()
            if suffix not in {".jpg", ".jpeg", ".png", ".webp"}:
                suffix = ".jpg"

            out = Path(tempfile.gettempdir()) / f"mp3_phone_{uuid.uuid4().hex}{suffix}"
            file.save(str(out))

            try:
                self.on_photo(str(out))
            except Exception:
                pass

            return render_template_string(HTML, done=True)

    def start(self):
        if self._started:
            return
        self._started = True

        def run():
            import logging
            logging.getLogger("werkzeug").setLevel(logging.ERROR)
            self._app.run(
                host="0.0.0.0",
                port=self.port,
                debug=False,
                use_reloader=False,
                threaded=True,
            )

        self._thread = threading.Thread(target=run, daemon=True)
        self._thread.start()

    def qr_image(self):
        qr = qrcode.QRCode(box_size=8, border=3)
        qr.add_data(self.url)
        qr.make(fit=True)
        return qr.make_image(fill_color="black", back_color="white")
