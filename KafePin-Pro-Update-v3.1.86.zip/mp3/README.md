KafePin MP3 Bot PRO v2.34.56

- Winamp hizli filtre kalici SQLite indeksinden arar; arama disk taramasi yapmaz.
- Ilk ARSIV YENILE/SENKRONLA tam indeks, sonraki calismalar delta senkron yapar.
- Winamp SIL/Del KafePin oynaticisini otomatik birakir, sonra gercek kaynak dosyayi siler.
- Senkron, dosya silme, USB aktarim/donusum/satis gibi anlamli islemler Canli Sistem Gunlugu'ne best-effort yazilir.
- MP3 Bot KafePin cekirdeginden teknik olarak bagimsizdir; aktif program koku C:\KafePinPro\MP3BotPRO'dur.
