from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path
from typing import Callable


APP_DIR = Path(__file__).resolve().parent


EQ_PRESETS = {
    "Orijinal / Düz": "",
    "Normal Dengeli": (
        "highpass=f=25,"
        "equalizer=f=90:t=q:w=0.9:g=0.7,"
        "equalizer=f=250:t=q:w=1.0:g=-0.4,"
        "equalizer=f=3000:t=q:w=1.0:g=0.4,"
        "equalizer=f=10000:t=q:w=0.8:g=0.4"
    ),
    "Araba Dengeli": (
        "highpass=f=30,"
        "equalizer=f=70:t=q:w=0.9:g=1.5,"
        "equalizer=f=220:t=q:w=1.0:g=-0.8,"
        "equalizer=f=2500:t=q:w=1.0:g=0.8,"
        "equalizer=f=8500:t=q:w=0.8:g=0.7"
    ),
    "Araba Baslı": (
        "highpass=f=28,"
        "equalizer=f=60:t=q:w=0.85:g=2.4,"
        "equalizer=f=120:t=q:w=0.9:g=1.4,"
        "equalizer=f=260:t=q:w=1.0:g=-1.0,"
        "equalizer=f=2800:t=q:w=1.0:g=0.5,"
        "equalizer=f=8500:t=q:w=0.8:g=0.5"
    ),
}


def get_eq_presets() -> tuple[str, ...]:
    return tuple(EQ_PRESETS.keys())


def eq_filter_for(preset: str) -> str:
    return EQ_PRESETS.get(
        preset,
        EQ_PRESETS["Araba Dengeli"],
    )


def _find_exe(name: str) -> str | None:
    found = shutil.which(name)
    if found and Path(found).is_file():
        return str(Path(found))

    local = Path(os.environ.get("LOCALAPPDATA", ""))
    program_files = Path(
        os.environ.get("PROGRAMFILES", r"C:\Program Files")
    )

    candidates = []

    if local:
        candidates += [
            local / "Microsoft" / "WinGet" / "Links" / name,
            local / "Programs" / "ffmpeg" / "bin" / name,
        ]

        packages = (
            local
            / "Microsoft"
            / "WinGet"
            / "Packages"
        )

        if packages.exists():
            try:
                candidates.extend(
                    packages.glob(
                        f"Gyan.FFmpeg_*/**/{name}"
                    )
                )
            except Exception:
                pass

    candidates += [
        program_files / "ffmpeg" / "bin" / name,
        Path(r"C:\ffmpeg\bin") / name,
    ]

    for candidate in candidates:
        try:
            if Path(candidate).is_file():
                return str(Path(candidate))
        except Exception:
            pass

    return None


def find_ffmpeg() -> str | None:
    marker = APP_DIR / "ffmpeg_path.txt"

    if marker.exists():
        try:
            saved = marker.read_text(
                encoding="utf-8-sig"
            ).strip()

            if saved and Path(saved).is_file():
                return saved
        except Exception:
            pass

    return _find_exe("ffmpeg.exe") or _find_exe("ffmpeg")


def find_ffprobe() -> str | None:
    ffmpeg = find_ffmpeg()

    if ffmpeg:
        sibling = Path(ffmpeg).with_name("ffprobe.exe")
        if sibling.is_file():
            return str(sibling)

    return _find_exe("ffprobe.exe") or _find_exe("ffprobe")


def find_ffplay() -> str | None:
    ffmpeg = find_ffmpeg()

    if ffmpeg:
        sibling = Path(ffmpeg).with_name("ffplay.exe")
        if sibling.is_file():
            return str(sibling)

    return _find_exe("ffplay.exe") or _find_exe("ffplay")


def _creationflags() -> int:
    if os.name == "nt":
        return getattr(
            subprocess,
            "CREATE_NO_WINDOW",
            0,
        )
    return 0


def _run(command: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=_creationflags(),
    )


def _join_filters(*filters: str) -> str:
    return ",".join(
        value
        for value in filters
        if value and value.strip()
    )


def _extract_loudnorm_json(stderr: str) -> dict:
    blocks = re.findall(
        r"\{\s*\"input_i\".*?\}",
        stderr,
        flags=re.S,
    )

    if not blocks:
        raise RuntimeError(
            "FFmpeg ses ölçüm verisini döndürmedi."
        )

    data = json.loads(blocks[-1])

    for key in (
        "input_i",
        "input_tp",
        "input_lra",
        "input_thresh",
        "target_offset",
    ):
        value = str(data.get(key, "")).strip()

        if (
            not value
            or value.casefold()
            in {
                "inf",
                "+inf",
                "-inf",
                "nan",
            }
        ):
            raise RuntimeError(
                f"Ses ölçüm değeri geçersiz: {key}={value}"
            )

    return data


def _first_pass(
    ffmpeg: str,
    source: Path,
    target_i: float,
    target_tp: float,
    target_lra: float,
    eq_filter: str,
) -> dict:
    loudnorm = (
        "loudnorm="
        f"I={target_i}:"
        f"TP={target_tp}:"
        f"LRA={target_lra}:"
        "print_format=json"
    )

    command = [
        ffmpeg,
        "-hide_banner",
        "-nostats",
        "-y",
        # İki geçişli ölçüm korunur; FFmpeg yalnızca uygun tüm işlemci
        # çekirdeklerini kullanarak aynı işlemi daha kısa sürede tamamlar.
        "-threads",
        "0",
        "-filter_threads",
        "0",
        "-i",
        str(source),
        "-vn",
        "-af",
        _join_filters(
            eq_filter,
            loudnorm,
        ),
        "-f",
        "null",
        os.devnull,
    ]

    result = _run(command)

    if result.returncode != 0:
        raise RuntimeError(
            "Ses ölçümü başarısız: "
            + (
                result.stderr[-1200:]
                or "FFmpeg hata verdi."
            )
        )

    return _extract_loudnorm_json(
        result.stderr
    )


def _second_pass_filter(
    measured: dict,
    target_i: float,
    target_tp: float,
    target_lra: float,
) -> str:
    return (
        "loudnorm="
        f"I={target_i}:"
        f"TP={target_tp}:"
        f"LRA={target_lra}:"
        f"measured_I={measured['input_i']}:"
        f"measured_TP={measured['input_tp']}:"
        f"measured_LRA={measured['input_lra']}:"
        f"measured_thresh={measured['input_thresh']}:"
        f"offset={measured['target_offset']}:"
        "linear=true:"
        "print_format=summary"
    )


def _dynamic_filter(
    target_i: float,
    target_tp: float,
    target_lra: float,
) -> str:
    return (
        "loudnorm="
        f"I={target_i}:"
        f"TP={target_tp}:"
        f"LRA={target_lra}:"
        "linear=false:"
        "print_format=summary"
    )


def preview_filter(
    eq_preset: str,
) -> str:
    """
    Kaydetmeden dinleme için:
    Seçili EQ + tek-pass loudnorm.
    """
    eq_filter = eq_filter_for(
        eq_preset
    )

    live_loudnorm = (
        "loudnorm="
        "I=-14:"
        "TP=-2.0:"
        "LRA=9:"
        "linear=false"
    )

    return _join_filters(
        eq_filter,
        live_loudnorm,
    )


def normalize_mp3(
    source: str | Path,
    output: str | Path,
    bitrate_kbps: int,
    *,
    target_i: float = -14.0,
    target_tp: float = -2.0,
    target_lra: float = 9.0,
    eq_preset: str = "Araba Dengeli",
    progress_cb: Callable[[str], None] | None = None,
    metadata_artist: str = "",
    metadata_title: str = "",
) -> Path:
    if bitrate_kbps not in (128, 320):
        raise ValueError(
            "Çıkış yalnızca 128 veya 320 kbps olabilir."
        )

    ffmpeg = find_ffmpeg()
    ffprobe = find_ffprobe()

    if not ffmpeg or not ffprobe:
        raise RuntimeError(
            "EQ/ses dengeleme için FFmpeg/FFprobe bulunamadı."
        )

    source = Path(source)
    output = Path(output)

    if (
        not source.exists()
        or source.stat().st_size <= 0
    ):
        raise RuntimeError(
            "İşlenecek ses dosyası bulunamadı."
        )

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    if output.exists():
        output.unlink()

    eq_filter = eq_filter_for(
        eq_preset
    )

    if progress_cb:
        progress_cb(
            "EQ / ses ölçümü (1/2)"
        )

    measured = None
    first_error = None

    try:
        measured = _first_pass(
            ffmpeg=ffmpeg,
            source=source,
            target_i=target_i,
            target_tp=target_tp,
            target_lra=target_lra,
            eq_filter=eq_filter,
        )
    except Exception as exc:
        first_error = exc

    if progress_cb:
        progress_cb(
            "EQ / ses dengeleme (2/2)"
        )

    if measured is not None:
        loudnorm = _second_pass_filter(
            measured=measured,
            target_i=target_i,
            target_tp=target_tp,
            target_lra=target_lra,
        )
    else:
        loudnorm = _dynamic_filter(
            target_i=target_i,
            target_tp=target_tp,
            target_lra=target_lra,
        )

    audio_filter = _join_filters(
        eq_filter,
        loudnorm,
    )

    command = [
        ffmpeg,
        "-hide_banner",
        "-nostats",
        "-y",
        "-threads",
        "0",
        "-filter_threads",
        "0",
        "-i",
        str(source),
        "-map_metadata",
        "-1",
        "-vn",
        "-af",
        audio_filter,
        "-ar",
        "44100",
        "-c:a",
        "libmp3lame",
        "-b:a",
        f"{bitrate_kbps}k",
    ]

    if metadata_artist:
        command += ["-metadata", f"artist={metadata_artist}"]
    if metadata_title:
        command += ["-metadata", f"title={metadata_title}"]

    command += [
        "-id3v2_version",
        "3",
        str(output),
    ]

    result = _run(command)

    if (
        result.returncode != 0
        or not output.exists()
        or output.stat().st_size <= 0
    ):
        detail = (
            result.stderr[-1400:]
            or "FFmpeg çıktı üretmedi."
        )

        if first_error is not None:
            detail = (
                f"İlk ölçüm: {first_error}\n\n"
                + detail
            )

        raise RuntimeError(
            "EQ/ses dengeleme başarısız: "
            + detail
        )

    return output


def normalize_to_temp_mp3(
    source: str | Path,
    bitrate_kbps: int,
    *,
    target_i: float = -14.0,
    target_tp: float = -2.0,
    target_lra: float = 9.0,
    eq_preset: str = "Araba Dengeli",
    progress_cb: Callable[[str], None] | None = None,
    metadata_artist: str = "",
    metadata_title: str = "",
) -> tuple[Path, Path]:
    root = (
        Path(tempfile.gettempdir())
        / "KafePinMp3BotPRO"
        / "normalize"
    )

    root.mkdir(
        parents=True,
        exist_ok=True,
    )

    job_dir = root / (
        "norm_" + uuid.uuid4().hex
    )

    job_dir.mkdir(
        parents=True,
        exist_ok=False,
    )

    output = job_dir / "normalized.mp3"

    normalize_mp3(
        source=source,
        output=output,
        bitrate_kbps=bitrate_kbps,
        target_i=target_i,
        target_tp=target_tp,
        target_lra=target_lra,
        eq_preset=eq_preset,
        progress_cb=progress_cb,
        metadata_artist=metadata_artist,
        metadata_title=metadata_title,
    )

    return output, job_dir
