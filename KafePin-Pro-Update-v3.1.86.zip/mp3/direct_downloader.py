from __future__ import annotations

import os
import re
import shutil
import tempfile
import uuid
from pathlib import Path
from typing import Callable

from yt_dlp import YoutubeDL
from audio_normalizer import normalize_mp3
from duplicate_guard import car_artist_title, clean_artist_name, clean_song_title, find_duplicate_mp3


INVALID_FILENAME = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
APP_DIR = Path(__file__).resolve().parent


def _find_exe(name: str) -> str | None:
    found = shutil.which(name)
    if found and Path(found).is_file():
        return str(Path(found))

    local = Path(os.environ.get("LOCALAPPDATA", ""))
    program_files = Path(os.environ.get("PROGRAMFILES", r"C:\Program Files"))

    candidates = []

    if local:
        candidates += [
            local / "Microsoft" / "WinGet" / "Links" / name,
            local / "Programs" / "ffmpeg" / "bin" / name,
        ]

        packages = local / "Microsoft" / "WinGet" / "Packages"

        if packages.exists():
            try:
                candidates.extend(
                    packages.glob(f"Gyan.FFmpeg_*/**/{name}")
                )
            except Exception:
                pass

    candidates += [
        program_files / "ffmpeg" / "bin" / name,
        Path(r"C:\ffmpeg\bin") / name,
    ]

    for candidate in candidates:
        try:
            if Path(candidate).is_file():
                return str(Path(candidate))
        except Exception:
            pass

    return None


def find_ffmpeg() -> str | None:
    marker = APP_DIR / "ffmpeg_path.txt"

    if marker.exists():
        try:
            saved = marker.read_text(
                encoding="utf-8-sig"
            ).strip()

            if saved and Path(saved).is_file():
                return saved
        except Exception:
            pass

    return _find_exe("ffmpeg.exe") or _find_exe("ffmpeg")


def find_ffprobe() -> str | None:
    ffmpeg = find_ffmpeg()

    if ffmpeg:
        sibling = Path(ffmpeg).with_name("ffprobe.exe")

        if sibling.is_file():
            return str(sibling)

    return _find_exe("ffprobe.exe") or _find_exe("ffprobe")


def _ensure_deno_path() -> None:
    candidates = [
        shutil.which("deno"),
        str(
            Path(os.environ.get("LOCALAPPDATA", ""))
            / "Microsoft"
            / "WinGet"
            / "Links"
            / "deno.exe"
        ),
        str(
            Path(os.environ.get("USERPROFILE", ""))
            / ".deno"
            / "bin"
            / "deno.exe"
        ),
    ]

    for raw in candidates:
        if raw and Path(raw).is_file():
            folder = str(Path(raw).parent)
            current = os.environ.get("PATH", "")

            if folder.casefold() not in current.casefold():
                os.environ["PATH"] = folder + os.pathsep + current

            return


def direct_engine_status() -> tuple[bool, str]:
    ffmpeg = find_ffmpeg()
    ffprobe = find_ffprobe()

    if not ffmpeg or not ffprobe:
        return (
            False,
            "FFmpeg/FFprobe bulunamadı. "
            "KURULUM.cmd dosyasını tekrar çalıştır.",
        )

    return (
        True,
        f"FFmpeg hazır: {Path(ffmpeg).parent}",
    )


def safe_filename(value: str) -> str:
    value = INVALID_FILENAME.sub(
        "_",
        (value or "").strip(),
    )

    value = re.sub(
        r"\s+",
        " ",
        value,
    ).strip(" .")

    return (value or "muzik")[:170]


def _metadata_from_info(info: dict, filename_hint: str) -> tuple[str, str]:
    req_artist, req_title = car_artist_title(filename_hint)
    info_artist = clean_artist_name(str(info.get("artist") or info.get("creator") or info.get("uploader") or ""))
    info_title = clean_song_title(str(info.get("track") or info.get("title") or ""))
    title_artist, title_name = car_artist_title(str(info.get("title") or ""), info_artist, info_title)

    # A user-supplied SANATCI - SARKI query is the strongest source.
    if req_artist and req_title:
        return req_artist, req_title
    artist = info_artist or title_artist
    title = info_title or title_name or req_title
    return clean_artist_name(artist), clean_song_title(title)


def _target_name(artist: str, title: str, fallback: str) -> str:
    if artist and title:
        return safe_filename(f"{artist} - {title}")
    return safe_filename(title or fallback)


def _unique_target(
    folder: Path,
    base_name: str,
) -> Path:
    first = folder / f"{base_name}.mp3"

    if not first.exists():
        return first

    n = 2

    while True:
        candidate = folder / f"{base_name} ({n}).mp3"

        if not candidate.exists():
            return candidate

        n += 1


def _find_downloaded_audio(
    work_dir: Path,
) -> Path | None:
    """
    yt-dlp'nin indirdiği gerçek kaynak sesi bulur.
    .part / geçici / json gibi dosyalar alınmaz.
    """
    ignored_suffixes = {
        ".part",
        ".tmp",
        ".temp",
        ".json",
        ".jpg",
        ".jpeg",
        ".png",
        ".webp",
        ".description",
    }

    files = []

    for p in work_dir.iterdir():
        try:
            if not p.is_file():
                continue

            if p.suffix.casefold() in ignored_suffixes:
                continue

            if p.stat().st_size <= 0:
                continue

            files.append(p)
        except Exception:
            pass

    if not files:
        return None

    files.sort(
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    return files[0]

def _is_403(exc: Exception) -> bool:
    text = str(exc).casefold()

    return (
        "403" in text
        or "forbidden" in text
        or "po token" in text
        or "pot" in text
    )


def _clean_attempt_dir(path: Path) -> None:
    shutil.rmtree(
        path,
        ignore_errors=True,
    )

    path.mkdir(
        parents=True,
        exist_ok=False,
    )


def _profiles() -> list[dict]:
    """
    YouTube 403 durumunda farklı istemci/ağ yollarını otomatik dener.

    source_address=0.0.0.0 -> IPv4 kullanımı.
    android_vr ve web_embedded -> PO Token gerektirmeyen alternatif istemciler.
    Son yöntem curl_cffi kuruluysa Chrome benzetimini dener.
    """
    return [
        {
            "name": "Normal + IPv4",
            "source_address": "0.0.0.0",
        },
        {
            "name": "Android VR istemcisi",
            "source_address": "0.0.0.0",
            "extractor_args": {
                "youtube": {
                    "player_client": ["android_vr"],
                }
            },
        },
        {
            "name": "Web Embedded istemcisi",
            "source_address": "0.0.0.0",
            "extractor_args": {
                "youtube": {
                    "player_client": ["web_embedded"],
                }
            },
        },
        {
            "name": "Chrome benzetimi",
            "source_address": "0.0.0.0",
            "impersonate": "chrome",
        },
    ]


def _make_options(
    *,
    work_dir: Path,
    base_name: str,
    ffmpeg: str,
    bitrate_kbps: int,
    profile: dict,
    progress_cb,
) -> dict:
    def hook(data):
        if progress_cb is None:
            return

        status = data.get("status")

        if status == "downloading":
            total = (
                data.get("total_bytes")
                or data.get("total_bytes_estimate")
            )

            done = data.get("downloaded_bytes") or 0
            percent = None

            if total:
                try:
                    percent = max(
                        0,
                        min(
                            99,
                            int(done * 100 / total),
                        ),
                    )
                except Exception:
                    percent = None

            progress_cb(
                percent,
                "İndiriliyor",
            )

        elif status == "finished":
            progress_cb(
                100,
                "Kaynak ses indirildi",
            )

    options = {
        "format": "bestaudio/best",
        "outtmpl": str(
            work_dir / f"{base_name}.%(ext)s"
        ),
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "windowsfilenames": True,
        "continuedl": True,
        "overwrites": True,
        "socket_timeout": 15,
        "retries": 2,
        "fragment_retries": 2,
        "file_access_retries": 2,
        # DASH/HLS seslerinde dört parçaya kadar paralel aktarım. Normal tek
        # dosyalı akışlarda etkisizdir; modem ve YouTube tarafı zorlanmaz.
        "concurrent_fragment_downloads": 4,
        # Yarım kalan aktarım .part dosyasından devam eder; kısa bağlantı
        # kopmalarında baştan indirme ve gereksiz hata engellenir.
        "nopart": False,
        "ffmpeg_location": str(
            Path(ffmpeg).parent
        ),
        "progress_hooks": [hook],
    }

    if profile.get("source_address"):
        options["source_address"] = profile["source_address"]

    if profile.get("extractor_args"):
        options["extractor_args"] = profile["extractor_args"]

    if profile.get("impersonate"):
        options["impersonate"] = profile["impersonate"]

    return options


def download_mp3(
    url: str,
    target_folder: str | Path,
    filename_hint: str,
    bitrate_kbps: int,
    eq_preset: str = "Araba Dengeli",
    progress_cb: Callable[
        [int | None, str],
        None,
    ] | None = None,
) -> Path:
    """
    Müşteri klasörüne yalnız final MP3 bırakır.

    YouTube 403 verirse otomatik olarak farklı indirme profilleri denenir.
    Kullanıcının yöntem seçmesine gerek yoktur.
    """
    if bitrate_kbps not in (128, 320):
        raise ValueError(
            "Kalite yalnızca 128 veya 320 kbps olabilir."
        )

    ffmpeg = find_ffmpeg()
    ffprobe = find_ffprobe()

    if not ffmpeg or not ffprobe:
        raise RuntimeError(
            "Doğrudan MP3 için FFmpeg ve FFprobe bulunamadı. "
            "KURULUM.cmd dosyasını tekrar çalıştır."
        )

    _ensure_deno_path()

    target = Path(
        target_folder
    ).expanduser()

    target.mkdir(
        parents=True,
        exist_ok=True,
    )

    base_name = safe_filename(filename_hint)
    requested_artist, requested_title = car_artist_title(filename_hint)
    duplicate = find_duplicate_mp3(target, requested_artist, requested_title)
    if duplicate is not None:
        raise FileExistsError(f"Zaten var, tekrar indirilmedi: {duplicate.name}")

    temp_root = (
        Path(tempfile.gettempdir())
        / "KafePinMp3BotPRO"
    )

    temp_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    job_dir = temp_root / (
        "job_" + uuid.uuid4().hex
    )

    job_dir.mkdir(
        parents=True,
        exist_ok=False,
    )

    errors = []

    try:
        profiles = _profiles()

        for attempt_no, profile in enumerate(
            profiles,
            start=1,
        ):
            attempt_dir = job_dir / (
                f"attempt_{attempt_no}"
            )

            attempt_dir.mkdir(
                parents=True,
                exist_ok=False,
            )

            if progress_cb is not None:
                progress_cb(
                    None,
                    f"Yöntem {attempt_no}/{len(profiles)}: "
                    f"{profile['name']}",
                )

            options = _make_options(
                work_dir=attempt_dir,
                base_name=base_name,
                ffmpeg=ffmpeg,
                bitrate_kbps=bitrate_kbps,
                profile=profile,
                progress_cb=progress_cb,
            )

            try:
                with YoutubeDL(options) as ydl:
                    info = ydl.extract_info(
                        url,
                        download=True,
                    ) or {}

                artist, title = _metadata_from_info(info, filename_hint)
                duplicate = find_duplicate_mp3(target, artist, title)
                if duplicate is not None:
                    raise FileExistsError(f"Zaten var, tekrar indirilmedi: {duplicate.name}")
                final_target = _unique_target(target, _target_name(artist, title, filename_hint))

                downloaded_audio = _find_downloaded_audio(
                    attempt_dir
                )

                if downloaded_audio is None:
                    raise RuntimeError(
                        "İndirme tamamlandı fakat kaynak ses dosyası oluşmadı."
                    )

                normalized_mp3 = attempt_dir / "normalized_final.mp3"

                def norm_progress(stage):
                    if progress_cb is not None:
                        progress_cb(
                            100,
                            stage,
                        )

                normalize_mp3(
                    source=downloaded_audio,
                    output=normalized_mp3,
                    bitrate_kbps=bitrate_kbps,
                    target_i=-14.0,
                    target_tp=-2.0,
                    target_lra=9.0,
                    eq_preset=eq_preset,
                    progress_cb=norm_progress,
                    metadata_artist=artist,
                    metadata_title=title,
                )

                if progress_cb is not None:
                    progress_cb(
                        100,
                        "Dengelenmiş MP3 müşteri klasörüne alınıyor",
                    )

                moving = final_target.with_suffix(
                    ".mp3.moving"
                )

                if moving.exists():
                    moving.unlink()

                shutil.copy2(
                    normalized_mp3,
                    moving,
                )

                if (
                    not moving.exists()
                    or moving.stat().st_size
                    != normalized_mp3.stat().st_size
                ):
                    raise RuntimeError(
                        "Dengelenmiş MP3 kopyalama boyut doğrulaması başarısız."
                    )

                moving.replace(
                    final_target
                )

                if (
                    not final_target.exists()
                    or final_target.stat().st_size <= 0
                ):
                    raise RuntimeError(
                        "Son MP3 dosyası doğrulanamadı."
                    )

                return final_target

            except FileExistsError:
                raise

            except Exception as exc:
                error_text = str(exc)

                errors.append(
                    f"{profile['name']}: {error_text}"
                )

                if progress_cb is not None:
                    if _is_403(exc):
                        progress_cb(
                            None,
                            f"403 alındı — otomatik diğer yöntem deneniyor",
                        )
                    else:
                        progress_cb(
                            None,
                            "Bu yöntem başarısız — sıradaki deneniyor",
                        )

                # Deneme kalıntıları başka profile karışmasın.
                shutil.rmtree(
                    attempt_dir,
                    ignore_errors=True,
                )

                continue

        short_errors = []

        for item in errors:
            item = item.replace(
                "\n",
                " ",
            )

            if len(item) > 260:
                item = item[:260] + "..."

            short_errors.append(item)

        raise RuntimeError(
            "Tüm doğrudan YouTube indirme yöntemleri başarısız oldu.\n\n"
            + "\n\n".join(short_errors)
            + "\n\n"
            "Bu durumda YouTube bu bağlantıyı/IP'yi 403 ile engelliyor olabilir. "
            "Bir süre sonra yeniden dene."
        )

    finally:
        shutil.rmtree(
            job_dir,
            ignore_errors=True,
        )
