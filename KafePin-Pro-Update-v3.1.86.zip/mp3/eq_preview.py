from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
from pathlib import Path

from yt_dlp import YoutubeDL

try:
    import psutil
except Exception:
    psutil = None

from audio_normalizer import (
    find_ffplay,
    find_ffprobe,
    preview_filter,
)


def _windows_args():
    creationflags = 0
    startupinfo = None

    if os.name == "nt":
        creationflags = (
            getattr(
                subprocess,
                "CREATE_NO_WINDOW",
                0,
            )
            | getattr(
                subprocess,
                "DETACHED_PROCESS",
                0,
            )
        )

        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= getattr(
            subprocess,
            "STARTF_USESHOWWINDOW",
            0,
        )
        startupinfo.wShowWindow = 0

    return creationflags, startupinfo


def _profiles():
    return [
        {
            "name": "Normal + IPv4",
            "source_address": "0.0.0.0",
        },
        {
            "name": "Android VR",
            "source_address": "0.0.0.0",
            "extractor_args": {
                "youtube": {
                    "player_client": ["android_vr"],
                }
            },
        },
        {
            "name": "Web Embedded",
            "source_address": "0.0.0.0",
            "extractor_args": {
                "youtube": {
                    "player_client": ["web_embedded"],
                }
            },
        },
        {
            "name": "Chrome",
            "source_address": "0.0.0.0",
            "impersonate": "chrome",
        },
    ]


def _find_audio(folder: Path) -> Path | None:
    ignored = {
        ".part",
        ".tmp",
        ".json",
        ".jpg",
        ".jpeg",
        ".png",
        ".webp",
    }

    files = []

    for path in folder.iterdir():
        if not path.is_file():
            continue

        if path.suffix.casefold() in ignored:
            continue

        try:
            if path.stat().st_size <= 0:
                continue
        except Exception:
            continue

        files.append(path)

    if not files:
        return None

    files.sort(
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    return files[0]


class EqPreviewEngine:
    """
    Kaydetmeden EQ önizleme.

    YouTube kaynak sesi yalnız TEMP'e alınır.

    Canlı EQ değişiminde:
    - o anki saniye hesaplanır
    - ffplay yeni EQ filtresiyle
    - AYNI SANİYEDEN yeniden başlatılır

    Müşteri klasörüne dosya yazılmaz.
    """

    def __init__(self):
        self.root = (
            Path(tempfile.gettempdir())
            / "KafePinMp3BotPRO"
            / "eq_preview"
        )

        self.root.mkdir(
            parents=True,
            exist_ok=True,
        )

        self.current_url = ""
        self.current_audio = None
        self.job_dir = None
        self.process = None

        self.current_eq = "Araba Dengeli"
        self.current_volume = 85

        self.duration = 0.0
        self.offset = 0.0
        self.started_at = None
        self.cancel_event = threading.Event()

    def _duration_of(
        self,
        source: Path,
    ) -> float:
        ffprobe = find_ffprobe()

        if not ffprobe:
            return 0.0

        creationflags, startupinfo = (
            _windows_args()
        )

        try:
            result = subprocess.run(
                [
                    ffprobe,
                    "-v",
                    "error",
                    "-show_entries",
                    "format=duration",
                    "-of",
                    "default=noprint_wrappers=1:nokey=1",
                    str(source),
                ],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=12,
                creationflags=creationflags,
                startupinfo=startupinfo,
            )

            if result.returncode != 0:
                return 0.0

            return max(
                0.0,
                float(
                    result.stdout.strip()
                ),
            )

        except Exception:
            return 0.0

    def has_source(self) -> bool:
        return (
            self.current_audio is not None
            and self.current_audio.exists()
            and bool(self.current_url)
        )

    def is_active(self) -> bool:
        return (
            self.process is not None
            and self.process.poll() is None
        )

    def position(self) -> float:
        if not self.has_source():
            return 0.0

        position = self.offset

        if (
            self.started_at is not None
            and self.is_active()
        ):
            position += (
                time.monotonic()
                - self.started_at
            )

        if self.duration > 0:
            position = min(
                position,
                self.duration,
            )

        return max(
            0.0,
            position,
        )

    def _terminate(
        self,
        keep_position: bool,
    ):
        position = (
            self.position()
            if keep_position
            else 0.0
        )

        process = self.process
        self.process = None

        if process is not None:
            pid = getattr(process, "pid", None)
            if pid and psutil is not None:
                try:
                    parent = psutil.Process(int(pid))
                    children = parent.children(recursive=True)
                    for child in children:
                        try: child.terminate()
                        except Exception: pass
                    try: parent.terminate()
                    except Exception: pass
                    _, alive = psutil.wait_procs(children + [parent], timeout=1.0)
                    for item in alive:
                        try: item.kill()
                        except Exception: pass
                except Exception:
                    pass
            try:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=0.8)
                    except Exception:
                        process.kill()
            except Exception:
                pass
            if os.name == "nt" and pid:
                try:
                    subprocess.run(
                        ["taskkill", "/PID", str(int(pid)), "/T", "/F"],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                        timeout=3,
                        check=False,
                    )
                except Exception:
                    pass

        self.offset = position
        self.started_at = None

    def stop(self):
        self.cancel_event.set()
        self._terminate(
            keep_position=True
        )

    def clear(self):
        self._terminate(
            keep_position=False
        )

        if self.job_dir is not None:
            shutil.rmtree(
                self.job_dir,
                ignore_errors=True,
            )

        self.current_url = ""
        self.current_audio = None
        self.job_dir = None
        self.current_eq = "Araba Dengeli"
        self.duration = 0.0
        self.offset = 0.0
        self.started_at = None

    def ensure_source(
        self,
        url: str,
        status_cb=None,
    ) -> Path:
        url = (url or "").strip()

        if (
            self.current_url == url
            and self.current_audio is not None
            and self.current_audio.exists()
        ):
            return self.current_audio

        self.clear()

        job_dir = self.root / (
            "job_" + uuid.uuid4().hex
        )

        job_dir.mkdir(
            parents=True,
            exist_ok=False,
        )

        errors = []

        for number, profile in enumerate(
            _profiles(),
            start=1,
        ):
            attempt = job_dir / (
                f"attempt_{number}"
            )
            attempt.mkdir()

            if status_cb:
                status_cb(
                    f"Önizleme kaynağı hazırlanıyor "
                    f"{number}/4 — {profile['name']}"
                )

            def _progress_hook(_status):
                if self.cancel_event.is_set():
                    raise RuntimeError("EQ önizleme kullanıcı tarafından durduruldu.")

            options = {
                "format": "bestaudio/best",
                "outtmpl": str(
                    attempt
                    / "preview.%(ext)s"
                ),
                "noplaylist": True,
                "quiet": True,
                "no_warnings": True,
                "windowsfilenames": True,
                "continuedl": True,
                "overwrites": True,
                "socket_timeout": 15,
                "retries": 2,
                "fragment_retries": 2,
                "progress_hooks": [_progress_hook],
            }

            if profile.get(
                "source_address"
            ):
                options[
                    "source_address"
                ] = profile[
                    "source_address"
                ]

            if profile.get(
                "extractor_args"
            ):
                options[
                    "extractor_args"
                ] = profile[
                    "extractor_args"
                ]

            if profile.get(
                "impersonate"
            ):
                options[
                    "impersonate"
                ] = profile[
                    "impersonate"
                ]

            try:
                if self.cancel_event.is_set():
                    raise RuntimeError("EQ önizleme kullanıcı tarafından durduruldu.")

                with YoutubeDL(
                    options
                ) as ydl:
                    ydl.extract_info(
                        url,
                        download=True,
                    )

                if self.cancel_event.is_set():
                    raise RuntimeError("EQ önizleme kullanıcı tarafından durduruldu.")

                audio = _find_audio(
                    attempt
                )

                if audio is None:
                    raise RuntimeError(
                        "Kaynak ses oluşmadı."
                    )

                self.current_url = url
                self.current_audio = audio
                self.job_dir = job_dir
                self.duration = (
                    self._duration_of(
                        audio
                    )
                )
                self.offset = 0.0
                self.started_at = None

                return audio

            except Exception as exc:
                errors.append(
                    f"{profile['name']}: {exc}"
                )

                shutil.rmtree(
                    attempt,
                    ignore_errors=True,
                )

        shutil.rmtree(
            job_dir,
            ignore_errors=True,
        )

        raise RuntimeError(
            "EQ önizleme kaynağı indirilemedi.\n\n"
            + "\n\n".join(
                errors
            )
        )

    def _launch(
        self,
        eq_preset: str,
        volume: int,
        start_seconds: float,
    ):
        if self.cancel_event.is_set():
            raise RuntimeError("EQ önizleme kullanıcı tarafından durduruldu.")
        if not self.has_source():
            raise RuntimeError(
                "EQ önizleme kaynağı hazır değil."
            )

        ffplay = find_ffplay()

        if not ffplay:
            raise RuntimeError(
                "ffplay bulunamadı."
            )

        volume = max(
            0,
            min(
                100,
                int(volume),
            ),
        )

        start_seconds = max(
            0.0,
            float(start_seconds),
        )

        if self.duration > 0:
            start_seconds = min(
                start_seconds,
                max(
                    0.0,
                    self.duration - 0.05,
                ),
            )

        self._terminate(
            keep_position=False
        )

        audio_filter = preview_filter(
            eq_preset
        )

        command = [
            ffplay,
            "-nodisp",
            "-autoexit",
            "-loglevel",
            "quiet",
        ]

        if start_seconds > 0:
            command += [
                "-ss",
                f"{start_seconds:.3f}",
            ]

        if audio_filter:
            command += [
                "-af",
                audio_filter,
            ]

        command += [
            "-volume",
            str(volume),
            str(self.current_audio),
        ]

        creationflags, startupinfo = (
            _windows_args()
        )

        self.process = subprocess.Popen(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags,
            startupinfo=startupinfo,
        )

        self.current_eq = eq_preset
        self.current_volume = volume
        self.offset = start_seconds
        self.started_at = (
            time.monotonic()
        )

    def play(
        self,
        url: str,
        eq_preset: str,
        volume: int = 85,
        status_cb=None,
    ):
        self.cancel_event.clear()
        self.ensure_source(
            url,
            status_cb=status_cb,
        )

        self._launch(
            eq_preset=eq_preset,
            volume=volume,
            start_seconds=0.0,
        )

    def switch_eq_live(
        self,
        eq_preset: str,
        volume: int | None = None,
    ):
        """
        Şarkı çalarken EQ değiştir.
        Aynı saniyeden devam eder.
        """
        if not self.has_source():
            raise RuntimeError(
                "Önce EQ ÖNİZLE ile bir şarkı başlat."
            )

        position = self.position()

        if volume is None:
            volume = self.current_volume

        self._launch(
            eq_preset=eq_preset,
            volume=volume,
            start_seconds=position,
        )

    def __del__(self):
        try:
            self.clear()
        except Exception:
            pass
