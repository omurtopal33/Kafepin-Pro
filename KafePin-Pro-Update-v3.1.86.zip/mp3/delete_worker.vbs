Option Explicit
Dim p, fso, parentPath, fileName, shellApp, folderObj, itemObj, i
If WScript.Arguments.Count < 1 Then WScript.Quit 2
p = WScript.Arguments(0)
Set fso = CreateObject("Scripting.FileSystemObject")
If Not fso.FileExists(p) Then WScript.Quit 0
parentPath = fso.GetParentFolderName(p)
fileName = fso.GetFileName(p)
Set shellApp = CreateObject("Shell.Application")
Set folderObj = shellApp.Namespace(parentPath)
If folderObj Is Nothing Then WScript.Quit 3
Set itemObj = folderObj.ParseName(fileName)
If itemObj Is Nothing Then WScript.Quit 4
On Error Resume Next
itemObj.InvokeVerb "delete"
If Err.Number <> 0 Then WScript.Quit 5
On Error GoTo 0
For i = 1 To 60
  If Not fso.FileExists(p) Then WScript.Quit 0
  WScript.Sleep 100
Next
WScript.Quit 6
