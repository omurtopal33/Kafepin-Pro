from __future__ import annotations

import json
import difflib
import os
import re
import subprocess
import sys
import unicodedata
from dataclasses import dataclass
from functools import partial

import requests
from ytmusicapi import YTMusic


BAD_TERMS = {
    "remix": 28, "live": 24, "concert": 24, "karaoke": 36, "cover": 32,
    "sped up": 34, "slowed": 34, "nightcore": 38, "8d": 26,
    "reaction": 35, "instrumental": 28, "lyrics": 8, "lyric": 8,
}
GOOD_TERMS = {
    "official audio": 18,
    "official": 8,
    "topic": 8,
    "audio": 5,
}
YOUTUBE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")


@dataclass
class Candidate:
    title: str
    channel: str
    url: str
    duration: int | None
    score: int
    artist_id: str = ""
    channel_id: str = ""
    channel_url: str = ""
    match_score: int = 0
    strict_match: bool = True
    match_reason: str = ""


def norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.casefold()
    s = re.sub(r"[^a-z0-9çğıöşü\s]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def split_song(query: str) -> tuple[str, str]:
    if " - " in query:
        a, b = query.split(" - ", 1)
        return a.strip(), b.strip()
    if "-" in query:
        a, b = query.split("-", 1)
        return a.strip(), b.strip()
    return "", query.strip()


def score_candidate(query: str, title: str, channel: str) -> int:
    artist, song = split_song(query)
    nq, nt, nc = norm(query), norm(title), norm(channel)
    na, ns = norm(artist), norm(song)

    score = 0
    if ns and ns in nt:
        score += 45
    if na and (na in nt or na in nc):
        score += 35
    if nq and nq in nt:
        score += 25

    q_tokens = set(nq.split())
    t_tokens = set((nt + " " + nc).split())
    score += min(25, 4 * len(q_tokens & t_tokens))

    for term, penalty in BAD_TERMS.items():
        if term in nt and term not in nq:
            score -= penalty
    for term, bonus in GOOD_TERMS.items():
        if term in nt or term in nc:
            score += bonus

    return score



STRICT_BAD_VARIANTS = ("remix", "live", "concert", "karaoke", "cover", "sped up", "slowed", "nightcore", "8d", "instrumental")
MATCH_NOISE = ("official video", "official audio", "official music video", "lyrics", "lyric video", "visualizer", "video", "audio", "hd", "4k", "8k", "remastered", "remaster", "topic", "vevo")


def _music_norm(value: str) -> str:
    text = norm(value)
    for term in MATCH_NOISE:
        text = re.sub(r"\b" + re.escape(norm(term)) + r"\b", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _similarity(a: str, b: str) -> float:
    a, b = _music_norm(a), _music_norm(b)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    if a in b or b in a:
        shorter = min(len(a), len(b))
        longer = max(len(a), len(b))
        if shorter >= 4:
            return max(0.88, shorter / max(1, longer))
    ratio = difflib.SequenceMatcher(None, a, b).ratio()
    at, bt = set(a.split()), set(b.split())
    if at and bt:
        inter = len(at & bt)
        union = len(at | bt)
        jaccard = inter / union if union else 0.0
        coverage = inter / min(len(at), len(bt)) if min(len(at), len(bt)) else 0.0
        ratio = max(ratio, 0.55 * jaccard + 0.45 * coverage)
    return ratio


def _has_unrequested_variant(query: str, title: str) -> bool:
    nq, nt = norm(query), norm(title)
    for term in STRICT_BAD_VARIANTS:
        nterm = norm(term)
        if nterm in nt and nterm not in nq:
            return True
    return False


def candidate_match_details(query: str, title: str, channel: str) -> tuple[bool, int, str]:
    """Artist + song must match together when the request is in ARTIST - SONG form.

    The important rule is fail-closed: if artist/title cannot be matched with high
    confidence, the resolver does NOT silently choose another song.
    """
    req_artist, req_song = split_song(query)
    req_artist = req_artist.strip()
    req_song = req_song.strip()
    if not req_artist or not req_song:
        # Free-form discovery remains available; strict enforcement applies once
        # the request has a separate artist and song name.
        return True, max(0, min(100, score_candidate(query, title, channel))), "Serbest arama"

    title_artist, title_song = split_song(title)
    artist_sources = [channel]
    if title_artist and title_song:
        artist_sources.append(title_artist)
        candidate_song = title_song
    else:
        candidate_song = title

    artist_score = max((_similarity(req_artist, value) for value in artist_sources if value), default=0.0)
    song_score = _similarity(req_song, candidate_song)
    variant_bad = _has_unrequested_variant(query, title)

    artist_ok = artist_score >= 0.82
    song_ok = song_score >= 0.84
    strict = artist_ok and song_ok and not variant_bad
    combined = int(round((artist_score * 45.0) + (song_score * 55.0)))
    if variant_bad:
        combined = max(0, combined - 35)
    reason = f"sanatçı %{artist_score*100:.0f} • şarkı %{song_score*100:.0f}"
    if variant_bad:
        reason += " • farklı versiyon"
    return strict, max(0, min(100, combined)), reason


def _artist_matches(wanted_artist: str, actual_artist: str) -> bool:
    if not wanted_artist:
        return True
    if not actual_artist:
        return False
    # Artist fields can contain multiple performers separated with commas, &, x, feat.
    pieces = re.split(r"\s*(?:,|&|\bx\b|\bfeat\.?\b|\bft\.?\b)\s*", actual_artist, flags=re.I)
    scores = [_similarity(wanted_artist, p) for p in pieces if p.strip()]
    scores.append(_similarity(wanted_artist, actual_artist))
    return max(scores or [0.0]) >= 0.82


def canonical_url(video_id: str) -> str:
    video_id = str(video_id or "").strip()
    if YOUTUBE_ID_RE.fullmatch(video_id):
        return f"https://www.youtube.com/watch?v={video_id}"
    return ""


def _artist_text(item: dict) -> str:
    artists = item.get("artists")
    if not isinstance(artists, list):
        return ""

    names = []
    for artist in artists:
        if isinstance(artist, dict):
            name = str(artist.get("name") or "").strip()
            if name:
                names.append(name)
    return ", ".join(names)


def _first_artist_id(item: dict) -> str:
    artists = item.get("artists")
    if isinstance(artists, list):
        for artist in artists:
            if not isinstance(artist, dict):
                continue
            value = str(artist.get("id") or artist.get("browseId") or "").strip()
            if value:
                return value
    return str(item.get("artistId") or item.get("channelId") or "").strip()


def _duration_seconds(item: dict) -> int | None:
    value = item.get("duration_seconds")
    if value is not None:
        try:
            return int(value)
        except Exception:
            pass

    text = str(item.get("duration") or "").strip()
    if not text:
        return None

    if re.fullmatch(r"\d{1,3}(?::\d{1,2}){1,2}", text):
        parts = [int(x) for x in text.split(":")]
        if len(parts) == 2:
            return parts[0] * 60 + parts[1]
        if len(parts) == 3:
            return parts[0] * 3600 + parts[1] * 60 + parts[2]

    return None


def _new_ytmusic() -> YTMusic:
    # ytmusicapi kendi oturumunda varsayılan 30 saniye bekleyebilir.
    # Biz 9 saniyeye indiriyoruz ki pencere uzun süre takılmasın.
    session = requests.Session()
    session.request = partial(session.request, timeout=9)
    return YTMusic(requests_session=session)


def _parse_ytmusic_rows(rows: list[dict], query: str) -> list[Candidate]:
    out = []

    for item in rows or []:
        if not isinstance(item, dict):
            continue

        video_id = str(item.get("videoId") or "").strip()
        url = canonical_url(video_id)
        if not url:
            continue

        title = str(item.get("title") or "").strip()
        if not title:
            continue

        channel = _artist_text(item)
        if not channel:
            channel = str(item.get("author") or item.get("channel") or "").strip()

        strict, match_score, match_reason = candidate_match_details(query, title, channel)
        out.append(
            Candidate(
                title=title,
                channel=channel,
                url=url,
                duration=_duration_seconds(item),
                score=score_candidate(query, title, channel),
                artist_id=_first_artist_id(item),
                channel_id=_first_artist_id(item),
                channel_url=(f"https://www.youtube.com/channel/{_first_artist_id(item)}" if _first_artist_id(item).startswith("UC") else ""),
                match_score=match_score,
                strict_match=strict,
                match_reason=match_reason,
            )
        )

    return out


def _ytmusic_search(query: str, max_results: int) -> list[Candidate]:
    """
    API anahtarı / login gerektirmeyen YouTube Music araması.
    Müzik programı olduğu için önce şarkılar, sonra videolar alınır.
    """
    merged: list[Candidate] = []
    seen: set[str] = set()
    errors = []

    # YouTube Music bazen bir A/B cevapta az sonuç verebildiği için
    # iki yeni istemciyle iki tur deniyoruz.
    for attempt in range(2):
        try:
            ytm = _new_ytmusic()

            song_limit = max(10, max_results)
            video_limit = max(10, max_results // 2)

            groups = []

            try:
                groups.append(
                    ytm.search(query, filter="songs", limit=song_limit)
                )
            except Exception as exc:
                errors.append(f"şarkı araması: {exc}")

            try:
                groups.append(
                    ytm.search(query, filter="videos", limit=video_limit)
                )
            except Exception as exc:
                errors.append(f"video araması: {exc}")

            # Filtreli arama hiç sonuç vermezse genel aramayı da dene.
            if not any(groups):
                try:
                    groups.append(ytm.search(query, limit=max_results))
                except Exception as exc:
                    errors.append(f"genel arama: {exc}")

            for rows in groups:
                for candidate in _parse_ytmusic_rows(rows, query):
                    vid = candidate.url.rsplit("=", 1)[-1]
                    if vid in seen:
                        continue
                    seen.add(vid)
                    merged.append(candidate)

                    if len(merged) >= max_results:
                        return merged

            # İlk denemede yeterli sonuç çıktıysa tekrar istemci açma.
            if len(merged) >= min(8, max_results):
                return merged

        except Exception as exc:
            errors.append(f"YTMusic deneme {attempt + 1}: {exc}")

    if merged:
        return merged

    detail = " | ".join(errors[-4:]) if errors else "sonuç yok"
    raise RuntimeError("YouTube Music araması sonuç vermedi: " + detail)


def _legacy_ytdlp_search(query: str, max_results: int) -> list[Candidate]:
    """
    İlk çalışan sürümlerdeki:
        ytsearchN:SORGU
    motorunun yedek sürümü.

    Ayrı işlemde çalışır; 18 saniyede dönmezse öldürülür.
    """
    cmd = [
        sys.executable,
        "-m",
        "yt_dlp",
        f"ytsearch{max_results}:{query}",
        "--flat-playlist",
        "--dump-single-json",
        "--skip-download",
        "--ignore-config",
        "--quiet",
        "--no-warnings",
        "--socket-timeout", "8",
        "--retries", "1",
    ]

    creationflags = 0
    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=18,
            creationflags=creationflags,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("Eski YouTube araması 18 saniyede cevap vermedi.") from exc

    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip()
        if len(detail) > 700:
            detail = detail[-700:]
        raise RuntimeError(detail or "Eski YouTube araması hata verdi.")

    try:
        info = json.loads(proc.stdout)
    except Exception as exc:
        raise RuntimeError("Eski YouTube arama cevabı çözümlenemedi.") from exc

    out = []
    seen = set()

    for item in (info or {}).get("entries") or []:
        if not isinstance(item, dict):
            continue

        video_id = str(item.get("id") or "").strip()
        url = canonical_url(video_id)
        if not url or video_id in seen:
            continue
        seen.add(video_id)

        title = str(item.get("title") or "")
        channel = str(item.get("channel") or item.get("uploader") or "")

        duration = item.get("duration")
        try:
            duration = int(duration) if duration is not None else None
        except Exception:
            duration = None

        strict, match_score, match_reason = candidate_match_details(query, title, channel)
        out.append(
            Candidate(
                title=title,
                channel=channel,
                url=url,
                duration=duration,
                score=score_candidate(query, title, channel),
                channel_id=str(item.get("channel_id") or item.get("uploader_id") or "").strip(),
                channel_url=str(item.get("channel_url") or item.get("uploader_url") or "").strip(),
                match_score=match_score,
                strict_match=strict,
                match_reason=match_reason,
            )
        )

    if not out:
        raise RuntimeError("Eski arama da sonuç vermedi.")

    return out


def discover_youtube(query: str, max_results: int = 30) -> list[Candidate]:
    """Search like the user typed the exact text into YouTube.

    The literal query is sent first to yt-dlp's ``ytsearchN:`` extractor, which
    represents normal YouTube search rather than a songs-only music catalogue.
    YouTube Music remains a fallback when the normal YouTube search is
    temporarily unavailable.  Result ordering from the primary YouTube search
    is preserved for the UI.
    """
    query = (query or "").strip()
    if not query:
        return []

    youtube_error = None
    try:
        return _legacy_ytdlp_search(query, max_results)
    except Exception as exc:
        youtube_error = str(exc)

    try:
        return _ytmusic_search(query, max_results)
    except Exception as exc:
        music_error = str(exc)

    raise RuntimeError(
        "YouTube araması yapılamadı.\n\n"
        f"YouTube araması: {youtube_error}\n\n"
        f"YouTube Music yedeği: {music_error}"
    )


def search_youtube(query: str, max_results: int = 5) -> list[Candidate]:
    rows = discover_youtube(query, max(max_results * 3, 18))
    req_artist, req_song = split_song(query)
    if req_artist and req_song:
        strict_rows = [c for c in rows if c.strict_match]
        strict_rows.sort(key=lambda c: (c.match_score, c.score), reverse=True)
        return strict_rows[:max_results]
    rows.sort(key=lambda c: (c.match_score, c.score), reverse=True)
    return rows[:max_results]



def _channel_base_url(channel_url: str = "", channel_id: str = "") -> str:
    url = str(channel_url or "").strip()
    cid = str(channel_id or "").strip()
    if not url and cid.startswith("UC"):
        url = f"https://www.youtube.com/channel/{cid}"
    if not url:
        return ""
    url = re.sub(r"/(?:featured|videos|shorts|streams|releases|playlists)/?$", "", url.rstrip("/"), flags=re.I)
    return url


def _run_ytdlp_json(target: str, *, timeout: int = 24, playlist_end: int | None = None) -> dict:
    cmd = [
        sys.executable, "-m", "yt_dlp", target,
        "--flat-playlist", "--dump-single-json", "--skip-download",
        "--ignore-config", "--quiet", "--no-warnings",
        "--socket-timeout", "8", "--retries", "1",
    ]
    if playlist_end:
        cmd += ["--playlist-end", str(int(playlist_end))]
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
    proc = subprocess.run(
        cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=timeout, creationflags=creationflags,
    )
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip()
        raise RuntimeError((detail[-900:] if len(detail) > 900 else detail) or "YouTube kanal bilgisi alınamadı.")
    try:
        data = json.loads(proc.stdout or "{}")
    except Exception as exc:
        raise RuntimeError("YouTube kanal cevabı çözümlenemedi.") from exc
    return data if isinstance(data, dict) else {}


def _playlist_url_from_item(item: dict) -> tuple[str, str]:
    pid = str(item.get("id") or item.get("playlist_id") or "").strip()
    raw_url = str(item.get("webpage_url") or item.get("url") or "").strip()
    m = re.search(r"[?&]list=([A-Za-z0-9_-]+)", raw_url)
    if m:
        pid = m.group(1)
    if raw_url.startswith("http") and ("playlist?list=" in raw_url or "/playlist/" in raw_url):
        return pid, raw_url
    if pid and not YOUTUBE_ID_RE.fullmatch(pid):
        return pid, f"https://www.youtube.com/playlist?list={pid}"
    return "", ""


def find_channel_playlists(channel_url: str = "", channel_id: str = "", max_collections: int = 40) -> list[dict]:
    """Read the selected artist's actual YouTube channel /playlists tab.

    This is deliberately separate from fuzzy playlist search. If the artist has
    playlists on their own YouTube channel, those are surfaced first.
    """
    base = _channel_base_url(channel_url, channel_id)
    if not base:
        return []
    try:
        data = _run_ytdlp_json(base + "/playlists", timeout=26, playlist_end=max(1, min(80, max_collections)))
    except Exception:
        return []
    rows = data.get("entries") or []
    out: list[dict] = []
    seen: set[str] = set()
    for item in rows:
        if not isinstance(item, dict):
            continue
        pid, playlist_url = _playlist_url_from_item(item)
        title = str(item.get("title") or "").strip()
        if not pid or not playlist_url or not title or pid in seen:
            continue
        seen.add(pid)
        count = item.get("playlist_count") or item.get("item_count") or item.get("n_entries")
        subtitle = "Sanatçının YouTube kanalındaki oynatma listesi"
        if count not in (None, ""):
            subtitle += f" • {count} öğe"
        out.append({
            "kind": "channel_playlist",
            "title": title,
            "id": pid,
            "url": playlist_url,
            "subtitle": subtitle,
            "params": "",
            "source": "YouTube • Sanatçı Kanalı",
        })
        if len(out) >= max_collections:
            break
    return out


def load_channel_playlist(collection_id: str, artist_name: str = "", limit: int = 150) -> list[Candidate]:
    pid = str(collection_id or "").strip()
    if not pid:
        raise ValueError("Oynatma listesi kimliği boş.")
    target = pid if pid.startswith("http") else f"https://www.youtube.com/playlist?list={pid}"
    data = _run_ytdlp_json(target, timeout=30, playlist_end=max(1, min(200, int(limit or 150))))
    out: list[Candidate] = []
    seen: set[str] = set()
    for item in data.get("entries") or []:
        if not isinstance(item, dict):
            continue
        vid = str(item.get("id") or "").strip()
        url = canonical_url(vid)
        if not url or vid in seen:
            continue
        seen.add(vid)
        title = str(item.get("title") or "").strip()
        if not title:
            continue
        channel = str(item.get("channel") or item.get("uploader") or artist_name or "").strip()
        duration = item.get("duration")
        try:
            duration = int(duration) if duration is not None else None
        except Exception:
            duration = None
        strict, match_score, match_reason = candidate_match_details(
            f"{artist_name} - {title}" if artist_name else title, title, channel
        )
        out.append(Candidate(
            title=title,
            channel=channel,
            url=url,
            duration=duration,
            score=100,
            channel_id=str(item.get("channel_id") or item.get("uploader_id") or "").strip(),
            channel_url=str(item.get("channel_url") or item.get("uploader_url") or "").strip(),
            match_score=match_score,
            strict_match=strict,
            match_reason=match_reason,
        ))
    return out


# ---------- Artist releases / playlists ----------
def _best_artist_result(rows: list[dict], artist_name: str) -> dict | None:
    wanted = norm(artist_name)
    best = None
    best_score = -1
    for item in rows or []:
        if not isinstance(item, dict):
            continue
        name = str(item.get("artist") or item.get("name") or item.get("title") or "").strip()
        browse_id = str(item.get("browseId") or item.get("channelId") or "").strip()
        if not name or not browse_id:
            continue
        nn = norm(name)
        score = 0
        if wanted and nn == wanted:
            score += 100
        elif wanted and (wanted in nn or nn in wanted):
            score += 70
        score += 5 * len(set(wanted.split()) & set(nn.split()))
        if score > best_score:
            best_score = score
            best = {**item, "_name": name, "_browse_id": browse_id}
    return best


def _collection_id(item: dict) -> str:
    return str(item.get("browseId") or item.get("playlistId") or item.get("id") or "").strip()


def _collection_title(item: dict, fallback: str = "Liste") -> str:
    return str(item.get("title") or item.get("name") or fallback).strip() or fallback


def _collection_subtitle(item: dict) -> str:
    parts: list[str] = []
    year = str(item.get("year") or "").strip()
    if year:
        parts.append(year)
    count = item.get("trackCount") or item.get("count")
    if count not in (None, ""):
        parts.append(f"{count} şarkı")
    author = str(item.get("author") or "").strip()
    if author:
        parts.append(author)
    return " • ".join(parts)


def _add_collection(out: list[dict], seen: set[str], *, kind: str, title: str, browse_id: str,
                    subtitle: str = "", params: str = "", source: str = "") -> None:
    browse_id = str(browse_id or "").strip()
    title = str(title or "").strip()
    if not browse_id or not title:
        return
    key = f"{kind}|{browse_id}"
    if key in seen:
        return
    seen.add(key)
    out.append({
        "kind": kind,
        "title": title,
        "id": browse_id,
        "subtitle": str(subtitle or "").strip(),
        "params": str(params or "").strip(),
        "source": str(source or "").strip(),
    })


def find_artist_collections(artist_name: str, artist_browse_id: str = "", max_collections: int = 30, selected_channel_url: str = "", selected_channel_id: str = "", selected_channel_name: str = "") -> dict:
    """Return an artist's songs/albums/singles and relevant public playlists.

    This uses only unauthenticated YouTube Music browsing. The selected song's
    artist browse id is preferred; otherwise the artist is resolved by name.
    """
    artist_name = str(artist_name or "").strip()
    artist_browse_id = str(artist_browse_id or "").strip()
    if not artist_name and not artist_browse_id:
        raise ValueError("Sanatçı bilgisi bulunamadı.")

    ytm = _new_ytmusic()
    resolved_name = artist_name
    if not artist_browse_id:
        rows = ytm.search(artist_name, filter="artists", limit=8) or []
        best = _best_artist_result(rows, artist_name)
        if not best:
            raise RuntimeError(f"Sanatçı bulunamadı: {artist_name}")
        artist_browse_id = best["_browse_id"]
        resolved_name = best["_name"]

    profile = ytm.get_artist(artist_browse_id) or {}
    resolved_name = str(profile.get("name") or resolved_name or artist_name).strip()
    collections: list[dict] = []
    seen: set[str] = set()

    # First open the resolved artist's real YouTube channel and read its
    # /playlists tab. This matches the UI expectation: song -> artist homepage
    # -> playlists. A label/uploader channel from the selected video is used
    # only when its name itself matches the resolved artist.
    direct_channel_id = artist_browse_id if str(artist_browse_id).startswith("UC") else ""
    direct_channel_url = f"https://www.youtube.com/channel/{direct_channel_id}" if direct_channel_id else ""
    if not direct_channel_url and selected_channel_url and _artist_matches(resolved_name, selected_channel_name):
        direct_channel_url = selected_channel_url
        direct_channel_id = selected_channel_id
    for item in find_channel_playlists(direct_channel_url, direct_channel_id, max_collections=max_collections):
        _add_collection(
            collections, seen, kind="channel_playlist", title=item.get("title", "Oynatma Listesi"),
            browse_id=item.get("id", ""), subtitle=item.get("subtitle", ""),
            source=item.get("source", "YouTube • Sanatçı Kanalı"),
        )

    songs = profile.get("songs") if isinstance(profile.get("songs"), dict) else {}
    if songs:
        sid = str(songs.get("browseId") or "").strip()
        if sid:
            _add_collection(
                collections, seen, kind="songs",
                title=f"{resolved_name} • Popüler Şarkılar", browse_id=sid,
                subtitle="Sanatçı şarkıları",
            )

    for key, kind, label in (("albums", "album", "Albüm"), ("singles", "single", "Single")):
        section = profile.get(key) if isinstance(profile.get(key), dict) else {}
        rows = list(section.get("results") or []) if section else []
        # Expand when the artist page supplies the browseId+params pointers.
        section_browse = str(section.get("browseId") or "").strip() if section else ""
        params = str(section.get("params") or "").strip() if section else ""
        if section_browse and params:
            try:
                expanded = ytm.get_artist_albums(section_browse, params, limit=50) or []
                if isinstance(expanded, list):
                    rows.extend(expanded)
            except Exception:
                # Top releases are still usable if the full list endpoint changes.
                pass
        for item in rows:
            if not isinstance(item, dict):
                continue
            cid = _collection_id(item)
            title = _collection_title(item, label)
            _add_collection(
                collections, seen, kind=kind, title=title, browse_id=cid,
                subtitle=_collection_subtitle(item) or label,
            )

    # Prefer playlists published by the artist/channel itself. Some YouTube
    # Music responses expose them directly on the artist page; get_user is a
    # second source and can also provide params for the full playlist list.
    profile_playlists = profile.get("playlists") if isinstance(profile.get("playlists"), dict) else {}
    official_rows = list(profile_playlists.get("results") or []) if profile_playlists else []
    official_params = str(profile_playlists.get("params") or "").strip() if profile_playlists else ""
    try:
        user_page = ytm.get_user(artist_browse_id) or {}
    except Exception:
        user_page = {}
    user_playlists = user_page.get("playlists") if isinstance(user_page.get("playlists"), dict) else {}
    if user_playlists:
        official_rows.extend(list(user_playlists.get("results") or []))
        official_params = str(user_playlists.get("params") or official_params).strip()
    if official_params:
        try:
            expanded = ytm.get_user_playlists(artist_browse_id, official_params) or []
            if isinstance(expanded, list):
                official_rows.extend(expanded)
        except Exception:
            pass
    for item in official_rows:
        if not isinstance(item, dict):
            continue
        cid = _collection_id(item)
        title = _collection_title(item, "Oynatma Listesi")
        _add_collection(
            collections, seen, kind="official_playlist", title=title, browse_id=cid,
            subtitle=_collection_subtitle(item) or "Sanatçının oynatma listesi",
            source="Sanatçı kanalı",
        )

    # Also surface public YouTube Music playlists related to this artist.
    # This is useful for artist/"best of" playlists that are not albums.
    if resolved_name:
        playlist_rows = []
        for playlist_filter in ("playlists", "community_playlists"):
            try:
                playlist_rows.extend(ytm.search(resolved_name, filter=playlist_filter, limit=16) or [])
            except Exception:
                pass
        wanted = norm(resolved_name)
        for item in playlist_rows:
            if not isinstance(item, dict):
                continue
            cid = _collection_id(item)
            title = _collection_title(item, "Oynatma Listesi")
            author_value = item.get("author")
            if isinstance(author_value, list):
                author = ", ".join(str(x.get("name") or "") for x in author_value if isinstance(x, dict))
            elif isinstance(author_value, dict):
                author = str(author_value.get("name") or "")
            else:
                author = str(author_value or "").strip()
            title_match = _similarity(resolved_name, title)
            author_match = _similarity(resolved_name, author)
            searchable = norm(title + " " + author)
            # Fail closed: a generic playlist is shown only when the artist name
            # is clearly present in title/author or fuzzy match is very strong.
            if wanted and wanted not in searchable and max(title_match, author_match) < 0.84:
                continue
            _add_collection(
                collections, seen, kind="playlist", title=title, browse_id=cid,
                subtitle=_collection_subtitle(item) or "YouTube Music oynatma listesi",
                source="YouTube Music",
            )

    order = {"channel_playlist": 0, "official_playlist": 1, "songs": 2, "album": 3, "single": 4, "playlist": 5}
    collections.sort(key=lambda c: (order.get(str(c.get("kind") or ""), 9), str(c.get("title") or "").casefold()))
    limit = max(1, min(80, int(max_collections or 30)))
    return {
        "artist": resolved_name or artist_name,
        "artist_id": artist_browse_id,
        "collections": collections[:limit],
    }


def _playlist_payload(ytm: YTMusic, browse_id: str, limit: int) -> dict:
    last_exc = None
    ids = [browse_id]
    if browse_id.startswith("VL") and len(browse_id) > 2:
        ids.append(browse_id[2:])
    for value in ids:
        try:
            data = ytm.get_playlist(value, limit=limit) or {}
            if isinstance(data, dict):
                return data
        except TypeError:
            try:
                data = ytm.get_playlist(value) or {}
                if isinstance(data, dict):
                    return data
            except Exception as exc:
                last_exc = exc
        except Exception as exc:
            last_exc = exc
    if last_exc:
        raise last_exc
    return {}


def load_artist_collection(collection_id: str, kind: str, artist_name: str = "", limit: int = 100) -> list[Candidate]:
    collection_id = str(collection_id or "").strip()
    kind = str(kind or "").strip().casefold()
    artist_name = str(artist_name or "").strip()
    if not collection_id:
        raise ValueError("Liste kimliği boş.")
    limit = max(1, min(200, int(limit or 100)))
    ytm = _new_ytmusic()

    if kind in {"album", "single"}:
        data = ytm.get_album(collection_id) or {}
        rows = data.get("tracks") or [] if isinstance(data, dict) else []
    elif kind == "channel_playlist":
        return load_channel_playlist(collection_id, artist_name, limit=limit)
    elif kind in {"songs", "playlist", "official_playlist"}:
        data = _playlist_payload(ytm, collection_id, limit)
        rows = data.get("tracks") or data.get("contents") or []
    else:
        raise ValueError("Geçersiz sanatçı liste türü.")

    out: list[Candidate] = []
    seen: set[str] = set()
    for item in rows or []:
        if not isinstance(item, dict):
            continue
        video_id = str(item.get("videoId") or item.get("id") or "").strip()
        url = canonical_url(video_id)
        if not url or video_id in seen:
            continue
        seen.add(video_id)
        title = str(item.get("title") or "").strip()
        if not title:
            continue
        structured_artist = _artist_text(item)
        channel = structured_artist or str(item.get("author") or item.get("channel") or artist_name).strip()
        # Artist lists must never silently turn into another artist's songs.
        # For public/official playlists we require the track's own artist metadata
        # to match the selected artist. Artist albums/songs may fall back to the
        # selected artist only when YouTube Music omitted per-track artist data.
        if artist_name:
            if structured_artist:
                if not _artist_matches(artist_name, structured_artist):
                    continue
            elif kind in {"playlist", "official_playlist"}:
                continue
        strict, match_score, match_reason = candidate_match_details(
            f"{artist_name} - {title}" if artist_name else title, title, channel
        )
        if artist_name and not strict:
            continue
        out.append(Candidate(
            title=title,
            channel=channel or artist_name,
            url=url,
            duration=_duration_seconds(item),
            score=100,
            artist_id=_first_artist_id(item),
            match_score=match_score,
            strict_match=strict,
            match_reason=match_reason,
        ))
        if len(out) >= limit:
            break
    return out
