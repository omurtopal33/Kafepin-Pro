from __future__ import annotations

import os
import sqlite3
import threading
import time
import unicodedata
from pathlib import Path
from typing import Callable, Iterable


class ArchiveIndex:
    """Persistent, per-user media archive index.

    The first explicit sync builds a complete index. Later syncs walk the selected
    roots only to compare path/size/mtime and update new, changed or deleted rows;
    unchanged rows keep their existing metadata. Searches never walk the disk.
    """

    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.data_dir / "archive-index.sqlite3"
        self.lock = threading.RLock()
        self._ensure_schema()

    @staticmethod
    def _key_path(value: str | Path) -> str:
        # normpath/normcase work for local drive paths and UNC shares without
        # resolving remote reparse points.
        return os.path.normcase(os.path.normpath(str(value)))

    @staticmethod
    def normalize_text(value: str) -> str:
        text = unicodedata.normalize("NFKD", str(value or "")).replace("ı", "i")
        text = "".join(ch for ch in text if not unicodedata.combining(ch))
        return "".join(ch for ch in text.casefold() if ch.isalnum())

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA temp_store=MEMORY")
        return conn

    def _ensure_schema(self) -> None:
        with self.lock, self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS archive_items (
                  media_type TEXT NOT NULL,
                  root_key TEXT NOT NULL,
                  root_path TEXT NOT NULL,
                  path_key TEXT NOT NULL,
                  path TEXT NOT NULL,
                  kind TEXT NOT NULL,
                  name TEXT NOT NULL,
                  display_name TEXT NOT NULL,
                  parent_name TEXT NOT NULL,
                  extension TEXT NOT NULL,
                  size_bytes INTEGER NOT NULL DEFAULT 0,
                  mtime_ns INTEGER NOT NULL DEFAULT 0,
                  duration_seconds INTEGER NOT NULL DEFAULT 0,
                  search_text TEXT NOT NULL,
                  PRIMARY KEY (media_type, root_key, path_key)
                );
                CREATE INDEX IF NOT EXISTS idx_archive_items_root
                  ON archive_items(media_type, root_key);
                CREATE INDEX IF NOT EXISTS idx_archive_items_name
                  ON archive_items(media_type, root_key, name);
                CREATE TABLE IF NOT EXISTS archive_roots (
                  media_type TEXT NOT NULL,
                  root_key TEXT NOT NULL,
                  root_path TEXT NOT NULL,
                  item_count INTEGER NOT NULL DEFAULT 0,
                  first_indexed_at INTEGER NOT NULL DEFAULT 0,
                  last_synced_at INTEGER NOT NULL DEFAULT 0,
                  PRIMARY KEY (media_type, root_key)
                );
                """
            )

    def has_index(self, media_type: str, root: str | Path) -> bool:
        root_key = self._key_path(root)
        with self.lock, self._connect() as conn:
            row = conn.execute(
                "SELECT 1 FROM archive_roots WHERE media_type=? AND root_key=? LIMIT 1",
                (str(media_type), root_key),
            ).fetchone()
            return row is not None

    def sync(
        self,
        media_type: str,
        root: str | Path,
        extensions: Iterable[str],
        *,
        include_dirs: bool = False,
        dir_allowed: Callable[[Path], bool] | None = None,
        display_name: Callable[[Path], str] | None = None,
        duration_seconds: Callable[[Path], int] | None = None,
        progress: Callable[[dict], None] | None = None,
        recursive: bool = True,
        folder_search_name_only: bool = False,
    ) -> dict:
        media_type = str(media_type or "").strip() or "media"
        root_path = Path(str(root or "")).expanduser()
        if not root_path.is_dir():
            raise ValueError(f"Arşiv klasörü bulunamadı: {root_path}")
        root_text = os.path.normpath(str(root_path))
        root_key = self._key_path(root_text)
        ext_set = {str(ext).casefold() for ext in extensions}
        started = time.monotonic()

        with self.lock, self._connect() as conn:
            root_row = conn.execute(
                "SELECT first_indexed_at FROM archive_roots WHERE media_type=? AND root_key=?",
                (media_type, root_key),
            ).fetchone()
            initial = root_row is None
            existing_rows = conn.execute(
                "SELECT path_key,kind,size_bytes,mtime_ns FROM archive_items WHERE media_type=? AND root_key=?",
                (media_type, root_key),
            ).fetchall()
            existing = {
                str(row["path_key"]): (str(row["kind"]), int(row["size_bytes"]), int(row["mtime_ns"]))
                for row in existing_rows
            }

            seen: set[str] = set()
            added = updated = unchanged = 0
            scanned = 0
            upserts: list[tuple] = []

            def report(current_path: str = "") -> None:
                if progress is None:
                    return
                try:
                    progress({
                        "media": media_type, "root": root_text, "current": str(current_path or root_text),
                        "scanned": scanned, "added": added, "updated": updated, "unchanged": unchanged,
                        "elapsed_ms": int((time.monotonic() - started) * 1000),
                    })
                except Exception:
                    pass

            report(root_text)
            try:
                for directory, folders, files in os.walk(root_text):
                    base = Path(directory)
                    report(str(base))
                    allowed_folders: list[str] = []
                    for folder_name in folders:
                        folder_path = base / folder_name
                        try:
                            allowed = True if dir_allowed is None else bool(dir_allowed(folder_path))
                        except Exception:
                            allowed = False
                        if allowed:
                            allowed_folders.append(folder_name)
                    folders[:] = allowed_folders

                    if include_dirs:
                        for folder_name in allowed_folders:
                            item = base / folder_name
                            try:
                                stat = item.stat()
                            except OSError:
                                continue
                            path_text = os.path.normpath(str(item))
                            path_key = self._key_path(path_text)
                            seen.add(path_key)
                            scanned += 1
                            if scanned % 200 == 0:
                                report(str(item))
                            current = ("folder", 0, int(getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1e9))))
                            before = existing.get(path_key)
                            if before == current:
                                unchanged += 1
                                continue
                            label = item.name
                            search_source = item.name if folder_search_name_only else f"{item.name} {item.parent.name} {path_text}"
                            search_text = self.normalize_text(search_source)
                            upserts.append((
                                media_type, root_key, root_text, path_key, path_text, "folder",
                                item.name, label, item.parent.name, "", 0, current[2], 0, search_text,
                            ))
                            if before is None:
                                added += 1
                            else:
                                updated += 1

                    if not recursive:
                        folders[:] = []

                    for filename in files:
                        item = base / filename
                        if item.suffix.casefold() not in ext_set:
                            continue
                        try:
                            stat = item.stat()
                        except OSError:
                            continue
                        path_text = os.path.normpath(str(item))
                        path_key = self._key_path(path_text)
                        seen.add(path_key)
                        scanned += 1
                        if scanned % 200 == 0:
                            report(str(item))
                        size = int(stat.st_size)
                        mtime = int(getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1e9)))
                        current = ("file", size, mtime)
                        before = existing.get(path_key)
                        if before == current:
                            unchanged += 1
                            continue
                        try:
                            label = str(display_name(item) if display_name else item.name)
                        except Exception:
                            label = item.name
                        try:
                            seconds = max(0, int(duration_seconds(item))) if duration_seconds else 0
                        except Exception:
                            seconds = 0
                        search_text = self.normalize_text(
                            f"{label} {item.name} {item.parent.name} {path_text}"
                        )
                        upserts.append((
                            media_type, root_key, root_text, path_key, path_text, "file",
                            item.name, label, item.parent.name, item.suffix.casefold(),
                            size, mtime, seconds, search_text,
                        ))
                        if before is None:
                            added += 1
                        else:
                            updated += 1
            except (OSError, PermissionError) as exc:
                raise RuntimeError(f"Arşiv taranamadı: {root_text}") from exc

            if upserts:
                conn.executemany(
                    """
                    INSERT INTO archive_items(
                      media_type,root_key,root_path,path_key,path,kind,name,display_name,
                      parent_name,extension,size_bytes,mtime_ns,duration_seconds,search_text
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(media_type,root_key,path_key) DO UPDATE SET
                      root_path=excluded.root_path,path=excluded.path,kind=excluded.kind,
                      name=excluded.name,display_name=excluded.display_name,
                      parent_name=excluded.parent_name,extension=excluded.extension,
                      size_bytes=excluded.size_bytes,mtime_ns=excluded.mtime_ns,
                      duration_seconds=excluded.duration_seconds,search_text=excluded.search_text
                    """,
                    upserts,
                )

            stale = [path_key for path_key in existing if path_key not in seen]
            if stale:
                conn.executemany(
                    "DELETE FROM archive_items WHERE media_type=? AND root_key=? AND path_key=?",
                    [(media_type, root_key, key) for key in stale],
                )
            deleted = len(stale)
            count = int(conn.execute(
                "SELECT COUNT(*) FROM archive_items WHERE media_type=? AND root_key=?",
                (media_type, root_key),
            ).fetchone()[0])
            now_ms = int(time.time() * 1000)
            first_ms = now_ms if initial else int(root_row["first_indexed_at"] or now_ms)
            conn.execute(
                """
                INSERT INTO archive_roots(media_type,root_key,root_path,item_count,first_indexed_at,last_synced_at)
                VALUES(?,?,?,?,?,?)
                ON CONFLICT(media_type,root_key) DO UPDATE SET
                  root_path=excluded.root_path,item_count=excluded.item_count,last_synced_at=excluded.last_synced_at
                """,
                (media_type, root_key, root_text, count, first_ms, now_ms),
            )

        report(root_text)
        return {
            "media": media_type,
            "folder": root_text,
            "mode": "initial" if initial else "sync",
            "count": count,
            "added": added,
            "updated": updated,
            "deleted": deleted,
            "unchanged": unchanged,
            "elapsed_ms": int((time.monotonic() - started) * 1000),
        }

    def search(self, media_type: str, root: str | Path, query: str, limit: int = 250, kind: str | None = None) -> dict:
        media_type = str(media_type or "").strip() or "media"
        root_text = os.path.normpath(str(Path(str(root or "")).expanduser()))
        root_key = self._key_path(root_text)
        needle = self.normalize_text(query)
        requested_kind = str(kind or "").strip().casefold()
        if requested_kind not in {"", "folder", "file"}:
            raise ValueError("Geçersiz indeks kayıt türü.")
        if len(needle) < 2:
            raise ValueError("Arama için en az 2 harf yaz.")
        with self.lock, self._connect() as conn:
            root_row = conn.execute(
                "SELECT item_count,last_synced_at FROM archive_roots WHERE media_type=? AND root_key=?",
                (media_type, root_key),
            ).fetchone()
            if root_row is None:
                raise RuntimeError("Bu arşiv henüz indekslenmedi. Önce ARŞİV YENİLE / SENKRONLA düğmesine basın.")
            kind_sql = " AND kind=?" if requested_kind else ""
            params = [media_type, root_key, needle]
            if requested_kind:
                params.append(requested_kind)
            rows = conn.execute(
                f"""
                SELECT path,kind,name,display_name,parent_name,extension,size_bytes,duration_seconds
                FROM archive_items
                WHERE media_type=? AND root_key=? AND instr(search_text, ?) > 0{kind_sql}
                ORDER BY kind DESC, display_name COLLATE NOCASE
                LIMIT ?
                """,
                (*params, max(1, int(limit))),
            ).fetchall()
            total = int(conn.execute(
                f"SELECT COUNT(*) FROM archive_items WHERE media_type=? AND root_key=? AND instr(search_text, ?) > 0{kind_sql}",
                tuple(params),
            ).fetchone()[0])
        return {
            "folder": root_text,
            "search": needle,
            "search_total": total,
            "indexed_total": int(root_row["item_count"]),
            "last_synced_at": int(root_row["last_synced_at"]),
            "items": [dict(row) for row in rows],
        }

    def remove_path(self, media_type: str, root: str | Path, path: str | Path) -> bool:
        """Remove one known item immediately after a user deletes it from disk."""
        media_type = str(media_type or "").strip() or "media"
        root_key = self._key_path(root)
        path_key = self._key_path(path)
        with self.lock, self._connect() as conn:
            cursor = conn.execute(
                "DELETE FROM archive_items WHERE media_type=? AND root_key=? AND path_key=?",
                (media_type, root_key, path_key),
            )
            changed = int(cursor.rowcount or 0) > 0
            if changed:
                count = int(conn.execute(
                    "SELECT COUNT(*) FROM archive_items WHERE media_type=? AND root_key=?",
                    (media_type, root_key),
                ).fetchone()[0])
                conn.execute(
                    "UPDATE archive_roots SET item_count=?, last_synced_at=? WHERE media_type=? AND root_key=?",
                    (count, int(time.time() * 1000), media_type, root_key),
                )
            return changed

    def remove_root(self, media_type: str, root: str | Path) -> None:
        media_type = str(media_type or "").strip() or "media"
        root_key = self._key_path(root)
        with self.lock, self._connect() as conn:
            conn.execute("DELETE FROM archive_items WHERE media_type=? AND root_key=?", (media_type, root_key))
            conn.execute("DELETE FROM archive_roots WHERE media_type=? AND root_key=?", (media_type, root_key))
