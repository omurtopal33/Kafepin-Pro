from __future__ import annotations

import re
import unicodedata
from pathlib import Path


def _norm(value: str) -> str:
    value = unicodedata.normalize("NFKD", value or "")
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = value.casefold()
    value = re.sub(r"\([^)]*\)", " ", value)
    value = re.sub(r"\[[^\]]*\]", " ", value)
    value = re.sub(
        r"\b(official|audio|video|lyrics?|lyric|hd|4k|remaster(?:ed)?)\b",
        " ",
        value,
        flags=re.I,
    )
    value = re.sub(r"[^a-z0-9çğıöşü]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def split_artist_song(text: str) -> tuple[str, str]:
    text = (text or "").strip()
    if " - " in text:
        artist, song = text.split(" - ", 1)
        return artist.strip(), song.strip()
    if "-" in text:
        artist, song = text.split("-", 1)
        return artist.strip(), song.strip()
    return "", text


def song_key(text: str) -> str:
    artist, song = split_artist_song(text)
    artist = _norm(artist)
    song = _norm(song)
    if not artist or not song:
        return ""
    return f"{artist}|||{song}"


def normalize_youtube_url(url: str) -> str:
    url = (url or "").strip()
    patterns = [
        r"(?:youtube\.com/watch\?[^#\s]*?v=)([A-Za-z0-9_-]{11})",
        r"(?:youtu\.be/)([A-Za-z0-9_-]{11})",
        r"(?:youtube\.com/shorts/)([A-Za-z0-9_-]{11})",
    ]
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return "https://www.youtube.com/watch?v=" + match.group(1)
    return url


def row_key(row: dict) -> str:
    """
    Sadece aynı liste içindeki tekrarları ayıklamak için.
    İndirme geçmişi değildir.
    """
    for field in ("query", "title"):
        key = song_key(str(row.get(field) or ""))
        if key:
            return key

    url = normalize_youtube_url(str(row.get("url") or ""))
    return f"url|||{url}" if url else ""


def dedupe_song_texts(items: list[str]) -> tuple[list[str], list[str]]:
    """
    Aynı SANATÇI + ŞARKI aynı listede yalnız 1 kez tutulur.
    Diskte veya oturumda indirme geçmişi tutulmaz.
    """
    kept = []
    dropped = []
    seen = set()

    for item in items:
        key = song_key(item)

        if not key:
            kept.append(item)
            continue

        if key in seen:
            dropped.append(item)
            continue

        seen.add(key)
        kept.append(item)

    return kept, dropped


CAR_ARTIST_MAX = 40
CAR_TITLE_MAX = 60
_NOISE_WORDS = (
    "official video", "official audio", "official music video", "lyrics", "lyric video",
    "audio", "video", "hd", "4k", "8k", "remastered", "remaster", "visualizer",
    "klip", "resmi video", "resmi klip", "full version", "music video"
)

def _smart_trim(value: str, limit: int) -> str:
    value = re.sub(r"\s+", " ", (value or "").strip(" -_|"))
    if len(value) <= limit:
        return value
    cut = value[:limit].rstrip()
    if " " in cut:
        word_cut = cut.rsplit(" ", 1)[0].rstrip()
        if len(word_cut) >= max(12, int(limit * 0.65)):
            cut = word_cut
    return cut.rstrip(" -_|.,")

def clean_youtube_text(value: str) -> str:
    value = (value or "").replace("–", "-").replace("—", "-").replace("−", "-")
    # Remove bracket groups only when they mostly contain YouTube/format noise.
    def repl(m):
        inner = m.group(1).casefold()
        return " " if any(word in inner for word in _NOISE_WORDS) else m.group(0)
    value = re.sub(r"\(([^)]*)\)", repl, value)
    value = re.sub(r"\[([^]]*)\]", repl, value)
    value = re.sub(r"\b(?:official\s+video|official\s+audio|official\s+music\s+video|lyric\s+video|lyrics?|visualizer|remaster(?:ed)?|full\s+version|music\s+video|resmi\s+(?:video|klip)|4k|8k|hd)\b", " ", value, flags=re.I)
    value = re.sub(r"\s+", " ", value).strip(" -_|.,")
    return value

def clean_artist_name(value: str) -> str:
    value = clean_youtube_text(value)
    value = re.sub(r"\s*[-–—]?\s*Topic$", "", value, flags=re.I)
    value = re.sub(r"\s*VEVO$", "", value, flags=re.I)
    return _smart_trim(value, CAR_ARTIST_MAX)

def clean_song_title(value: str) -> str:
    return _smart_trim(clean_youtube_text(value), CAR_TITLE_MAX)

def car_artist_title(text: str, fallback_artist: str = "", fallback_title: str = "") -> tuple[str, str]:
    raw = clean_youtube_text(text)
    artist, title = split_artist_song(raw)
    if not artist or not title:
        artist = artist or clean_artist_name(fallback_artist)
        title = title or clean_song_title(fallback_title or raw)
    else:
        artist = clean_artist_name(artist)
        title = clean_song_title(title)
    if not title:
        title = clean_song_title(raw or fallback_title or "Muzik")
    return clean_artist_name(artist), clean_song_title(title)

def car_song_key(artist: str, title: str) -> str:
    a, t = _norm(artist), _norm(title)
    if a and t:
        return f"{a}|||{t}"
    if t:
        return f"title|||{t}"
    return ""

def filename_song_key(filename: str) -> str:
    stem = re.sub(r"\s+\(\d+\)$", "", Path(filename).stem, flags=re.I)
    artist, title = car_artist_title(stem)
    return car_song_key(artist, title)

def find_duplicate_mp3(folder, artist: str, title: str):
    from pathlib import Path as _Path
    folder = _Path(folder)
    wanted = car_song_key(artist, title)
    if not wanted or not folder.exists():
        return None
    for p in folder.glob("*.mp3"):
        try:
            if p.is_file() and filename_song_key(p.name) == wanted:
                return p
        except Exception:
            pass
    return None
