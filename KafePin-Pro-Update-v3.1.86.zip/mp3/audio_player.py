from __future__ import annotations

import os
import subprocess
import threading
import time
from pathlib import Path

try:
    import psutil
except Exception:
    psutil = None

from audio_normalizer import (
    find_ffplay,
    find_ffprobe,
)


class Mp3Player:
    def __init__(self):
        self.process = None
        self.current = None
        self.duration = 0.0
        self.offset = 0.0
        self.started_at = None
        self.volume = 85
        self._lock = threading.RLock()

    def _windows_process_args(self):
        creationflags = 0
        startupinfo = None

        if os.name == "nt":
            creationflags = (
                getattr(
                    subprocess,
                    "CREATE_NO_WINDOW",
                    0,
                )
                | getattr(
                    subprocess,
                    "DETACHED_PROCESS",
                    0,
                )
            )

            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= getattr(
                subprocess,
                "STARTF_USESHOWWINDOW",
                0,
            )
            startupinfo.wShowWindow = 0

        return creationflags, startupinfo

    def get_duration(
        self,
        path: str | Path,
    ) -> float:
        source = Path(path)

        if not source.exists():
            return 0.0

        ffprobe = find_ffprobe()

        if not ffprobe:
            return 0.0

        creationflags, startupinfo = (
            self._windows_process_args()
        )

        try:
            result = subprocess.run(
                [
                    ffprobe,
                    "-v",
                    "error",
                    "-show_entries",
                    "format=duration",
                    "-of",
                    "default=noprint_wrappers=1:nokey=1",
                    str(source),
                ],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=12,
                creationflags=creationflags,
                startupinfo=startupinfo,
            )

            if result.returncode != 0:
                return 0.0

            return max(
                0.0,
                float(
                    result.stdout.strip()
                ),
            )

        except Exception:
            return 0.0

    def _terminate_process(self) -> None:
        """Stop only the ffplay process owned by this player, aggressively if needed."""
        process = self.process
        self.process = None

        if process is None:
            return

        pid = getattr(process, "pid", None)

        try:
            if process.poll() is not None:
                return
        except Exception:
            return

        # psutil first: terminate the exact child tree we started.
        if pid and psutil is not None:
            try:
                parent = psutil.Process(int(pid))
                children = parent.children(recursive=True)
                for child in children:
                    try:
                        child.terminate()
                    except Exception:
                        pass
                try:
                    parent.terminate()
                except Exception:
                    pass
                gone, alive = psutil.wait_procs(children + [parent], timeout=1.25)
                for item in alive:
                    try:
                        item.kill()
                    except Exception:
                        pass
                if alive:
                    psutil.wait_procs(alive, timeout=1.0)
            except Exception:
                pass

        try:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=0.9)
                except Exception:
                    process.kill()
                    try:
                        process.wait(timeout=0.9)
                    except Exception:
                        pass
        except Exception:
            pass

        # Last Windows fallback. This is restricted to the PID we launched.
        if os.name == "nt" and pid:
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(int(pid)), "/T", "/F"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    timeout=3,
                    check=False,
                )
            except Exception:
                pass

    def stop(self) -> None:
        with self._lock:
            self._terminate_process()
            self.current = None
            self.duration = 0.0
            self.offset = 0.0
            self.started_at = None

    def is_playing(self) -> bool:
        with self._lock:
            return (
                self.process is not None
                and self.process.poll() is None
            )

    def is_finished(self) -> bool:
        with self._lock:
            return (
                self.current is not None
                and self.process is not None
                and self.process.poll() is not None
            )

    def position(self) -> float:
        with self._lock:
            if self.current is None:
                return 0.0

            position = self.offset

            if (
                self.started_at is not None
                and self.is_playing()
            ):
                position += (
                    time.monotonic()
                    - self.started_at
                )

            if self.duration > 0:
                position = min(
                    position,
                    self.duration,
                )

            return max(
                0.0,
                position,
            )

    def _launch(
        self,
        source: Path,
        *,
        volume: int,
        start_seconds: float,
    ) -> None:
        ffplay = find_ffplay()

        if not ffplay:
            raise RuntimeError(
                "ffplay bulunamadı. "
                "KURULUM.cmd dosyasını yeniden çalıştır."
            )

        volume = max(
            0,
            min(
                100,
                int(volume),
            ),
        )

        duration = self.get_duration(
            source
        )

        start_seconds = max(
            0.0,
            float(start_seconds),
        )

        if duration > 0:
            start_seconds = min(
                start_seconds,
                max(
                    0.0,
                    duration - 0.05,
                ),
            )

        self._terminate_process()

        command = [
            ffplay,
            "-nodisp",
            "-autoexit",
            "-loglevel",
            "quiet",
        ]

        if start_seconds > 0:
            command += [
                "-ss",
                f"{start_seconds:.3f}",
            ]

        command += [
            "-volume",
            str(volume),
            str(source),
        ]

        creationflags, startupinfo = (
            self._windows_process_args()
        )

        self.process = subprocess.Popen(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags,
            startupinfo=startupinfo,
        )

        self.current = source
        self.duration = duration
        self.offset = start_seconds
        self.started_at = time.monotonic()
        self.volume = volume

    def play(
        self,
        path: str | Path,
        volume: int = 85,
        start_seconds: float = 0.0,
    ) -> None:
        source = Path(path)

        if (
            not source.exists()
            or not source.is_file()
        ):
            raise FileNotFoundError(
                str(source)
            )

        with self._lock:
            self._launch(
                source,
                volume=volume,
                start_seconds=start_seconds,
            )

    def seek_to(
        self,
        seconds: float,
    ) -> None:
        if self.current is None:
            return

        with self._lock:
            source = self.current
            volume = self.volume

            self._launch(
                source,
                volume=volume,
                start_seconds=seconds,
            )

    def seek(
        self,
        delta_seconds: float,
    ) -> None:
        if self.current is None:
            return

        self.seek_to(
            self.position()
            + float(delta_seconds)
        )

    def set_volume(
        self,
        volume: int,
    ) -> None:
        volume = max(
            0,
            min(
                100,
                int(volume),
            ),
        )

        with self._lock:
            if (
                self.current is None
                or not self.is_playing()
            ):
                self.volume = volume
                return

            source = self.current
            position = self.position()

            self._launch(
                source,
                volume=volume,
                start_seconds=position,
            )

