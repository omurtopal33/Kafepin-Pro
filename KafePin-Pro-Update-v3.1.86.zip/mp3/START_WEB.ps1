﻿param(
    [switch]$WaitReady,
    [int]$TimeoutSeconds = 25
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$PythonW = Join-Path $Root '.venv\Scripts\pythonw.exe'
$Ctl = Join-Path $Root 'service_control.py'
$Meta = Join-Path $Root 'mp3-web-version.json'
if (-not (Test-Path -LiteralPath $PythonW -PathType Leaf)) { throw 'MP3 Bot pythonw.exe not found' }
if (-not (Test-Path -LiteralPath $Ctl -PathType Leaf)) { throw 'MP3 Bot service controller not found' }
$Expected = ''
try { $Expected = [string]((Get-Content -LiteralPath $Meta -Raw | ConvertFrom-Json).version) } catch {}
if ([string]::IsNullOrWhiteSpace($Expected)) { throw 'MP3 Bot expected version metadata missing' }

$args = @($Ctl, 'start', '--timeout', [string]([Math]::Max(5,$TimeoutSeconds)), '--expected-version', $Expected, '--expected-root', $Root)
if ($WaitReady) { $args += '--wait' }
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $PythonW
$psi.WorkingDirectory = $Root
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
$quoted = foreach ($arg in $args) {
    $text = [string]$arg
    if ($text -match '[\s"]') { '"' + ($text -replace '"','\"') + '"' } else { $text }
}
$psi.Arguments = ($quoted -join ' ')
$p = [System.Diagnostics.Process]::Start($psi)
if (-not $p) { throw 'MP3 Bot service controller could not start' }
if ($WaitReady) {
    if (-not $p.WaitForExit(([Math]::Max(8,$TimeoutSeconds + 8)) * 1000)) {
        try { $p.Kill() } catch {}
        exit 5
    }
    exit [int]$p.ExitCode
}
exit 0
