﻿$ErrorActionPreference = "SilentlyContinue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$PythonW = Join-Path $Root ".venv\Scripts\pythonw.exe"
$Ctl = Join-Path $Root "service_control.py"
if ((Test-Path -LiteralPath $PythonW) -and (Test-Path -LiteralPath $Ctl)) {
    Start-Process -FilePath $PythonW -ArgumentList @($Ctl, "stop") -WorkingDirectory $Root -WindowStyle Hidden | Out-Null
}
exit 0
