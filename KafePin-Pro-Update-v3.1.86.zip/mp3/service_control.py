from __future__ import annotations

import argparse
import json
import os
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

try:
    import psutil
except Exception:
    psutil = None

ROOT = Path(__file__).resolve().parent
SERVICE = ROOT / "web_service.py"
DATA_DIR = Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / "KafePinMp3BotPRO"
PID_FILE = DATA_DIR / "web_service.pid"
LOG_DIR = ROOT / "logs"
OUT_LOG = LOG_DIR / "web-service.out.log"
ERR_LOG = LOG_DIR / "web-service.err.log"
HEALTH_URL = "http://127.0.0.1:17890/api/health"
EXPECTED_SERVICE = "KafePin MP3 Bot PRO"
EXPECTED_ISOLATION = "separate-loopback-service"
def _payload_version() -> str:
    try:
        meta = json.loads((ROOT / "mp3-web-version.json").read_text(encoding="utf-8-sig"))
        return str(meta.get("version") or "").strip()
    except Exception:
        return ""

EXPECTED_VERSION = _payload_version()
PYTHONW = Path(sys.executable).with_name("pythonw.exe")


def _windows_no_window_flags() -> int:
    if os.name != "nt":
        return 0
    return int(getattr(subprocess, "CREATE_NO_WINDOW", 0))


def _run_hidden(args, **kwargs):
    if os.name == "nt" and "creationflags" not in kwargs:
        kwargs["creationflags"] = _windows_no_window_flags()
    return subprocess.run(args, **kwargs)


def _emit(text: str, *, error: bool = False) -> None:
    stream = sys.stderr if error else sys.stdout
    if stream is None:
        return
    try:
        print(text, file=stream, flush=True)
    except Exception:
        pass


def health(expected_version: str | None = None, expected_root: str | None = None) -> bool:
    try:
        req = urllib.request.Request(HEALTH_URL + "?_=" + str(time.time_ns()))
        with urllib.request.urlopen(req, timeout=2.0) as r:
            if not (200 <= int(r.status) < 300):
                return False
            marker = str(r.headers.get("X-KafePin-MP3-Isolation") or "")
            if marker != EXPECTED_ISOLATION:
                return False
            data = json.loads(r.read().decode("utf-8"))
        if str(data.get("service") or "") != EXPECTED_SERVICE:
            return False
        if expected_version and str(data.get("version") or "") != expected_version:
            return False
        if expected_root:
            actual_root = os.path.normcase(os.path.normpath(str(data.get("programRoot") or "")))
            wanted_root = os.path.normcase(os.path.normpath(str(expected_root or "")))
            if not actual_root or actual_root != wanted_root:
                return False
        return True
    except Exception:
        return False


def port_is_open() -> bool:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.35)
    try:
        return s.connect_ex(("127.0.0.1", 17890)) == 0
    finally:
        s.close()


def _windows_port_owner_pids(port: int) -> set[int]:
    """Return LISTENING owner PIDs using netstat, across Windows sessions/users."""
    if os.name != "nt":
        return set()
    pids: set[int] = set()
    try:
        cp = _run_hidden(
            ["netstat", "-ano", "-p", "tcp"],
            capture_output=True,
            text=True,
            errors="replace",
            timeout=5,
            check=False,
        )
        for line in (cp.stdout or "").splitlines():
            parts = line.split()
            if len(parts) < 5 or parts[0].upper() != "TCP" or parts[3].upper() != "LISTENING":
                continue
            local = parts[1]
            if local.rsplit(":", 1)[-1] != str(int(port)):
                continue
            if parts[-1].isdigit():
                pids.add(int(parts[-1]))
    except Exception:
        pass
    return pids


def _windows_process_commandline(pid: int) -> str:
    """Best-effort command line lookup even when psutil cannot inspect another session."""
    if os.name != "nt" or int(pid) <= 0:
        return ""
    try:
        # Win32_Process is available on supported KafePin Windows installs and
        # works from the SYSTEM updater as well as the interactive desktop task.
        command = (
            "$p=Get-CimInstance Win32_Process -Filter \"ProcessId=" + str(int(pid)) + "\" "
            "-ErrorAction SilentlyContinue; if($p){[Console]::Out.Write([string]$p.CommandLine)}"
        )
        cp = _run_hidden(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command],
            capture_output=True,
            text=True,
            errors="replace",
            timeout=6,
            check=False,
        )
        return str(cp.stdout or "").strip()
    except Exception:
        return ""


def _windows_process_name(pid: int) -> str:
    if int(pid) <= 0:
        return ""
    if psutil is not None:
        try:
            return str(psutil.Process(int(pid)).name() or "").casefold()
        except Exception:
            pass
    if os.name == "nt":
        try:
            command = (
                "$p=Get-CimInstance Win32_Process -Filter \"ProcessId=" + str(int(pid)) + "\" "
                "-ErrorAction SilentlyContinue; if($p){[Console]::Out.Write([string]$p.Name)}"
            )
            cp = _run_hidden(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command],
                capture_output=True, text=True, errors="replace", timeout=6, check=False,
            )
            return str(cp.stdout or "").strip().casefold()
        except Exception:
            pass
    return ""


def _is_python_listener_name(name: str) -> bool:
    return str(name or "").casefold() in {"python.exe", "pythonw.exe", "py.exe", "python3.exe"}


def _looks_like_kafepin_mp3_command(command_line: str) -> bool:
    text = str(command_line or "").replace("/", "\\").casefold()
    if "web_service.py" not in text:
        return False
    return (
        "kafepinpro\\mp3botpro" in text
        or "kafepinmp3botpro" in text
        or "\\mp3botpro\\" in text
    )


def _is_our_process(proc) -> bool:
    try:
        cmd = " ".join(proc.cmdline() or [])
        if _looks_like_kafepin_mp3_command(cmd):
            return True
        # Current-root fallback for unusual quoting/path formatting.
        root = str(ROOT).replace("/", "\\").casefold()
        return "web_service.py" in cmd.casefold() and root in cmd.replace("/", "\\").casefold()
    except Exception:
        return False


def _pid_is_kafepin_mp3(pid: int) -> bool:
    if int(pid) <= 0 or int(pid) == os.getpid():
        return False
    if psutil is not None:
        try:
            if _is_our_process(psutil.Process(int(pid))):
                return True
        except Exception:
            pass
    return _looks_like_kafepin_mp3_command(_windows_process_commandline(int(pid)))


def _force_kill_pid_windows(pid: int) -> bool:
    if os.name != "nt" or int(pid) <= 0 or int(pid) == os.getpid():
        return False
    try:
        cp = _run_hidden(
            ["taskkill", "/PID", str(int(pid)), "/T", "/F"],
            capture_output=True,
            text=True,
            errors="replace",
            timeout=7,
            check=False,
        )
        return cp.returncode == 0
    except Exception:
        return False


def stop_service() -> int:
    """Stop the KafePin MP3 listener authoritatively by its reserved port.

    Older builds were often launched as ``pythonw.exe -B web_service.py`` with only
    a working directory. Win32_Process.CommandLine therefore did not contain the
    installation root, so root-string matching could never identify that listener.
    Port 17890 is reserved for KafePin MP3 Bot PRO; a Python listener on that port is
    therefore the authoritative stale service and may be replaced even when its
    command line has no absolute path.
    """
    stopped = False
    pid_file_pids: set[int] = set()
    try:
        if PID_FILE.exists():
            raw = PID_FILE.read_text(encoding="ascii", errors="ignore").strip()
            if raw.isdigit():
                pid_file_pids.add(int(raw))
    except Exception:
        pass

    port_pids: set[int] = set()
    if psutil is not None:
        try:
            for c in psutil.net_connections(kind="tcp"):
                if c.status == psutil.CONN_LISTEN and c.laddr and c.laddr.port == 17890 and c.pid:
                    port_pids.add(int(c.pid))
        except Exception:
            pass
    if os.name == "nt":
        port_pids.update(_windows_port_owner_pids(17890))

    # PID file is only trusted when command line still proves it is ours. A live
    # listener on the dedicated MP3 port is trusted when it is either proven by
    # command line OR is a Python runtime. This catches legacy working-directory
    # launches whose command line is simply 'pythonw.exe -B web_service.py'.
    candidates = sorted(pid_file_pids | port_pids)
    for pid in candidates:
        if pid == os.getpid():
            continue
        is_port_owner = pid in port_pids
        proven = _pid_is_kafepin_mp3(pid)
        python_listener = is_port_owner and _is_python_listener_name(_windows_process_name(pid))
        if not proven and not python_listener:
            continue
        killed = False
        if psutil is not None:
            try:
                proc = psutil.Process(pid)
                proc.terminate()
                try:
                    proc.wait(timeout=2.0)
                except psutil.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=2.0)
                killed = True
            except Exception:
                pass
        if os.name == "nt" and not killed:
            killed = _force_kill_pid_windows(pid)
        stopped = stopped or killed

    # The port itself is the final truth. Re-read it and forcibly terminate any
    # remaining Python owner. If a non-Python application owns 17890, leave it
    # untouched so start_service reports a real port collision instead of killing
    # an unrelated program.
    if os.name == "nt":
        deadline = time.monotonic() + 6.0
        while time.monotonic() < deadline:
            owners = _windows_port_owner_pids(17890)
            if not owners:
                break
            changed = False
            for pid in sorted(owners):
                if pid == os.getpid():
                    continue
                if _pid_is_kafepin_mp3(pid) or _is_python_listener_name(_windows_process_name(pid)):
                    changed = _force_kill_pid_windows(pid) or changed
                    stopped = changed or stopped
            if not changed:
                break
            time.sleep(0.18)

    try:
        PID_FILE.unlink(missing_ok=True)
    except Exception:
        pass
    if stopped:
        _emit("MP3 Bot service stopped.")
    else:
        _emit("No running KafePin MP3 Bot service found.")
    return 0

def _windows_session_id() -> int | None:
    if os.name != "nt":
        return None
    try:
        import ctypes
        sid = ctypes.c_uint(0)
        ok = ctypes.windll.kernel32.ProcessIdToSessionId(os.getpid(), ctypes.byref(sid))
        return int(sid.value) if ok else None
    except Exception:
        return None


def start_service(wait: bool = False, timeout: int = 25, expected_version: str | None = None, expected_root: str | None = None) -> int:
    session_id = _windows_session_id()
    if os.name == "nt" and session_id is not None and session_id <= 0:
        _emit(
            "ERROR: MP3 Bot PRO Session 0/SYSTEM altında başlatılmadı; "
            "KafePin masaüstündeki MP3 Bot PRO sekmesi kullanıcı oturumunda başlatmalıdır.",
            error=True,
        )
        return 6
    if health(expected_version, expected_root):
        if wait:
            _emit("MP3 Bot service already ready.")
        return 0
    if not SERVICE.exists():
        _emit("ERROR: web_service.py not found: " + str(SERVICE), error=True)
        return 2
    if port_is_open() and not health(expected_version, expected_root):
        # 17890 is reserved for KafePin MP3. A stale Python listener from an older
        # build must not block the new exact-version service forever.
        stop_service()
        until_free = time.monotonic() + 6.0
        while time.monotonic() < until_free and port_is_open():
            time.sleep(0.15)
        if port_is_open():
            _emit("ERROR: Port 17890 could not be released for KafePin MP3 Bot PRO.", error=True)
            return 3

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    out = open(OUT_LOG, "ab", buffering=0)
    err = open(ERR_LOG, "ab", buffering=0)
    kwargs = dict(
        cwd=str(ROOT),
        stdout=out,
        stderr=err,
        stdin=subprocess.DEVNULL,
        close_fds=True,
    )
    if os.name == "nt":
        kwargs["creationflags"] = (
            getattr(subprocess, "CREATE_NO_WINDOW", 0)
            | getattr(subprocess, "DETACHED_PROCESS", 0)
            | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        )
    runtime = PYTHONW if (os.name == "nt" and PYTHONW.exists()) else Path(sys.executable)
    proc = subprocess.Popen([str(runtime), str(SERVICE)], **kwargs)

    if not wait:
        return 0
    until = time.monotonic() + max(3, int(timeout))
    while time.monotonic() < until:
        if health(expected_version, expected_root):
            _emit("KafePin MP3 Bot PRO web service ready: http://127.0.0.1:17890/")
            return 0
        if proc.poll() is not None:
            _emit("ERROR: MP3 Bot service exited early. Log: " + str(ERR_LOG), error=True)
            return 4
        time.sleep(0.35)
    _emit("ERROR: MP3 Bot service did not become ready. Log: " + str(ERR_LOG), error=True)
    return 5


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sp = sub.add_parser("start")
    sp.add_argument("--wait", action="store_true")
    sp.add_argument("--timeout", type=int, default=25)
    sp.add_argument("--expected-version", default=None)
    sp.add_argument("--expected-root", default=None)
    sub.add_parser("stop")
    hp = sub.add_parser("health")
    hp.add_argument("--expected-version", default=None)
    hp.add_argument("--expected-root", default=None)
    args = ap.parse_args()
    if args.cmd == "start":
        return start_service(args.wait, args.timeout, args.expected_version, args.expected_root)
    if args.cmd == "stop":
        return stop_service()
    ok = health(args.expected_version, args.expected_root)
    _emit("OK" if ok else "NOT_READY")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
