@echo off
setlocal
cd /d "%~dp0"
set "SILENT=0"
if /I "%~1"=="/silent" set "SILENT=1"
py -3 -m venv .venv || exit /b 1
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade pip || exit /b 1
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt || exit /b 1
if not exist ".venv\Scripts\pythonw.exe" exit /b 1
if "%SILENT%"=="1" exit /b 0
echo.
echo MP3 Bot PRO kuruldu.
pause
