'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const { spawn, spawnSync } = require('child_process');

function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }
function log(root, text){
  try { const p=path.join(root,'logs','update-supervisor.log'); fs.mkdirSync(path.dirname(p),{recursive:true}); fs.appendFileSync(p,`${new Date().toISOString()} ${text}\n`,'utf8'); } catch(_){}
}
function hidden(exe,args,opts={}){
  return spawn(exe,args,{cwd:opts.cwd||undefined,detached:!!opts.detached,stdio:opts.stdio||'ignore',windowsHide:true});
}
function run(exe,args,opts={}){
  const r=spawnSync(exe,args,{cwd:opts.cwd||undefined,encoding:'utf8',windowsHide:true,timeout:opts.timeout||15000});
  return {code:Number.isInteger(r.status)?r.status:-1,stdout:String(r.stdout||''),stderr:String(r.stderr||''),error:r.error||null};
}
function portPid(port){
  if(process.platform!=='win32') return 0;
  const r=run('netstat.exe',['-ano','-p','tcp'],{timeout:5000});
  for(const raw of r.stdout.split(/\r?\n/)){
    const line=raw.trim(); if(!line || !/^TCP\s/i.test(line)) continue;
    const parts=line.split(/\s+/); if(parts.length<5) continue;
    if(!parts[1].endsWith(':'+port) || String(parts[3]).toUpperCase()!=='LISTENING') continue;
    const pid=Number(parts[4]); if(pid>0) return pid;
  }
  return 0;
}
function killPid(pid){ if(process.platform==='win32' && pid>0) run('taskkill.exe',['/PID',String(pid),'/F','/T'],{timeout:7000}); }
async function waitPortDown(port,timeoutMs){ const end=Date.now()+timeoutMs; while(Date.now()<end){ if(!portPid(port)) return true; await sleep(150); } return !portPid(port); }
function httpJson(port,urlPath,timeoutMs=1200){
  return new Promise(resolve=>{
    const req=http.get({host:'127.0.0.1',port,path:urlPath,timeout:timeoutMs,headers:{'Cache-Control':'no-cache'}},res=>{
      let body=''; res.on('data',c=>body+=String(c)); res.on('end',()=>{ try{resolve({ok:res.statusCode>=200&&res.statusCode<300,json:JSON.parse(body),headers:res.headers});}catch(_){resolve({ok:false,json:null,headers:res.headers});} });
    });
    req.on('timeout',()=>req.destroy()); req.on('error',()=>resolve({ok:false,json:null,headers:{}}));
  });
}
async function waitServerVersion(version,timeoutMs){ const end=Date.now()+timeoutMs; while(Date.now()<end){ const r=await httpJson(3000,'/api/health?_supervisor='+Date.now()); const h=String((r.headers||{})['x-kafepin-version']||''); if(r.ok && (!version || h===version)) return true; await sleep(250); } return false; }
function readJson(p){ try{return JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));}catch(_){return null;} }
function copyTree(src,dst,preserveTop){
  fs.mkdirSync(dst,{recursive:true});
  for(const ent of fs.readdirSync(src,{withFileTypes:true})){
    if(preserveTop && preserveTop.has(ent.name)) continue;
    const s=path.join(src,ent.name), d=path.join(dst,ent.name);
    if(ent.isDirectory()){ fs.rmSync(d,{recursive:true,force:true}); copyTree(s,d,null); }
    else if(ent.isFile()){ fs.mkdirSync(path.dirname(d),{recursive:true}); fs.copyFileSync(s,d); }
  }
}
function extractZip(zip,dst){
  fs.mkdirSync(dst,{recursive:true});
  const exe=process.platform==='win32'?'tar.exe':'unzip';
  const args=process.platform==='win32'?['-xf',zip,'-C',dst]:['-q','-o',zip,'-d',dst];
  const r=run(exe,args,{timeout:60000}); if(r.code!==0) throw new Error(`ZIP acilamadi: ${(r.stderr||r.stdout).trim()}`);
}
function syncMp3Payload(installRoot,proRoot){
  const zip=path.join(installRoot,'pro-components','mp3-bot-pro.zip');
  if(!fs.existsSync(zip)) return {required:false,version:''};
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'kafepin-mp3-activate-'));
  try{
    extractZip(zip,tmp);
    const meta=readJson(path.join(tmp,'mp3-web-version.json')); const expected=String(meta&&meta.version||'');
    if(!expected) throw new Error('MP3 payload surumu okunamadi');
    const root=path.join(proRoot,'MP3BotPRO');
    const installed=readJson(path.join(root,'mp3-web-version.json')); const current=String(installed&&installed.version||'');
    // LOCK: version ayni olsa bile stale web/index.html veya app.js kalmis olabilir.
    // Her update aktivasyonunda paket payloadini exact olarak yeniden esle; yalniz
    // kullanici state/.venv/logs gibi kalici verileri koru.
    const pid=portPid(17890); if(pid) killPid(pid);
    const preserve=new Set(['state.json','favorites.json','.env','.venv','logs']);
    fs.mkdirSync(root,{recursive:true});
    copyTree(tmp,root,preserve);
    const actual=readJson(path.join(root,'mp3-web-version.json'));
    if(String(actual&&actual.version||'')!==expected) throw new Error('MP3 payload dogrulama hatasi');
    return {required:true,version:expected,root};
  } finally { try{fs.rmSync(tmp,{recursive:true,force:true});}catch(_){} }
}
async function startAndVerifyMp3(info){
  if(!info.required) return true;
  const pid=portPid(17890); if(pid) killPid(pid);
  await waitPortDown(17890,5000);
  if(process.platform!=='win32') throw new Error('MP3 interaktif oturum baslatma yalniz Windows icin destekleniyor');

  // MP3'ü supervisor/SYSTEM oturumunda değil, kullanıcının gerçek interaktif
  // masaüstü tokenında başlat. Bu, kullanıcının elle PRO Servisleri demesiyle aynı
  // LOCALAPPDATA/profil/dosya erişim bağlamını kullanır ve pencere açmaz.
  // Desktop Action gorevini her MP3 aktivasyonunda sessizce CREATE_OR_UPDATE et.
  // Boylece onceki TEST'ten kalmis eski gorev tanimi yeni delete/restart aksiyonlarini engelleyemez.
  const helperEnsure=path.join(path.dirname(__filename),'KafePin_Desktop_Helper_Ensure.ps1');
  if(fs.existsSync(helperEnsure)){
    const ensure=run('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',helperEnsure,'-InstallRoot',path.dirname(__filename)],{timeout:12000});
    if(ensure.code!==0) throw new Error(`Desktop Action gorevi guncellenemedi: ${(ensure.stderr||ensure.stdout).trim()}`);
  }
  const pd=process.env.ProgramData||'C:\\ProgramData';
  const bridge=path.join(pd,'KafePinPro','DesktopBridge');
  const requestFile=path.join(bridge,'request.json'), resultFile=path.join(bridge,'result.json');
  const requestId=`mp3-${process.pid}-${Date.now()}`;
  fs.mkdirSync(bridge,{recursive:true});
  fs.writeFileSync(requestFile,JSON.stringify({requestId,action:'restart-mp3-only',expectedVersion:info.version,createdAt:Date.now()}),'utf8');
  try{fs.unlinkSync(resultFile);}catch(_err){}
  const task=run('schtasks.exe',['/Run','/TN','KafePin Pro Desktop Action'],{timeout:5000});
  if(task.code!==0) throw new Error('MP3 interaktif Desktop Bridge gorevi baslatilamadi');
  const bridgeEnd=Date.now()+45000;
  while(Date.now()<bridgeEnd){
    const d=readJson(resultFile);
    if(d&&String(d.requestId||'')===requestId){
      if(d.ok!==true) throw new Error(String(d.error||'MP3 interaktif baslatma basarisiz'));
      break;
    }
    await sleep(200);
  }
  const finalResult=readJson(resultFile);
  if(!finalResult||String(finalResult.requestId||'')!==requestId||finalResult.ok!==true) throw new Error('MP3 interaktif baslatma sonucu zaman asimi');

  const end=Date.now()+12000;
  while(Date.now()<end){ const r=await httpJson(17890,'/api/health?_supervisor='+Date.now()); if(r.ok&&r.json&&String(r.json.version||'')===info.version) return true; await sleep(250); }
  throw new Error(`MP3 health-check gecmedi: ${info.version}`);
}
function isDesktopRunning(){
  if(process.platform!=='win32') return true;
  const r=run('tasklist.exe',['/FI','IMAGENAME eq KafePin Pro.exe','/NH'],{timeout:5000});
  return r.code===0 && /KafePin Pro\.exe/i.test(r.stdout);
}
async function launchDesktop(installRoot){
  if(process.platform!=='win32') return true;
  const appPath=path.join(installRoot,'desktop-app','KafePin Pro.exe');
  if(!fs.existsSync(appPath)) throw new Error('KafePin Pro.exe bulunamadi');
  const pd=process.env.ProgramData||'C:\\ProgramData'; const bridge=path.join(pd,'KafePinPro','DesktopBridge');
  const requestFile=path.join(bridge,'request.json'), resultFile=path.join(bridge,'result.json');
  const requestId=`upd-${process.pid}-${Date.now()}`; fs.mkdirSync(bridge,{recursive:true});
  fs.writeFileSync(requestFile,JSON.stringify({requestId,action:'launch-kafepin',appPath,createdAt:Date.now()}),'utf8'); try{fs.unlinkSync(resultFile);}catch(_){}
  const r=run('schtasks.exe',['/Run','/TN','KafePin Pro Desktop Action'],{timeout:5000}); if(r.code!==0) throw new Error('Desktop Bridge gorevi baslatilamadi');
  const end=Date.now()+15000; while(Date.now()<end){ const d=readJson(resultFile); if(d&&String(d.requestId||'')===requestId){ if(d.ok===true&&Number(d.sessionId||0)>0) return true; throw new Error(String(d.error||'Masaustu acilamadi')); } await sleep(200); }
  throw new Error('Masaustu acilis health-check zaman asimi');
}
function activationPath(){ const pd=process.platform==='win32'?(process.env.ProgramData||'C:\\ProgramData'):process.cwd(); return path.join(pd,'KafePinPro','update-activation.json'); }
function desktopMarkerPath(){ const pd=process.platform==='win32'?(process.env.ProgramData||'C:\\ProgramData'):process.cwd(); return path.join(pd,'KafePinPro','desktop-reopen-after-update.json'); }
function supervisorLockPath(){ const pd=process.platform==='win32'?(process.env.ProgramData||'C:\\ProgramData'):process.cwd(); return path.join(pd,'KafePinPro','update-supervisor.lock'); }
function writeActivation(data){ const p=activationPath(); fs.mkdirSync(path.dirname(p),{recursive:true}); fs.writeFileSync(p,JSON.stringify(data,null,2),'utf8'); }
async function activateOnly(installRoot,targetVersion){
  const lockPath=supervisorLockPath();
  try{
    const prior=readJson(lockPath); if(prior && Date.now()-Number(prior.startedAt||0)<60000) { log(installRoot,'activate skipped: supervisor already running'); return false; }
    fs.mkdirSync(path.dirname(lockPath),{recursive:true}); fs.writeFileSync(lockPath,JSON.stringify({pid:process.pid,targetVersion,startedAt:Date.now()}),'utf8');
    const proRoot=process.env.KAFEPIN_PRO_ROOT||'C:\\KafePinPro';
    log(installRoot,`activate start target=${targetVersion}`);
    const desktopWasRunning=isDesktopRunning();
    const serverOk=await waitServerVersion(targetVersion,15000); if(!serverOk) throw new Error(`Yeni KafePin server health-check gecmedi: ${targetVersion}`);
    const mp3=syncMp3Payload(installRoot,proRoot); await startAndVerifyMp3(mp3);
    let desktopLaunched=false;
    if(!desktopWasRunning){ await launchDesktop(installRoot); desktopLaunched=true; }
    writeActivation({ok:true,targetVersion,serverVerified:true,mp3Required:mp3.required,mp3Version:mp3.version,mp3Verified:true,desktopPreserved:desktopWasRunning,desktopLaunched,completedAt:Date.now()});
    try{fs.unlinkSync(desktopMarkerPath());}catch(_){}
    log(installRoot,`activate success target=${targetVersion} mp3=${mp3.version||'n/a'}`);
    return true;
  } finally { try{fs.unlinkSync(lockPath);}catch(_){} }
}
async function fullRestart(installRoot,targetVersion){
  log(installRoot,`restart supervisor start target=${targetVersion}`);
  try{fs.unlinkSync(activationPath());}catch(_){}
  // Masaustu kabugunu OLDURME. Desktop kendi 1.5 sn watchdog'u ile server kesintisini
  // gorur ve yeni server gelince WebView'i cache-bust ile otomatik yeniler.
  // Boylece update sonrasi 'kapandi ama geri acilmadi' sinifi tamamen ortadan kalkar.
  const pid=portPid(3000); if(pid&&pid!==process.pid) killPid(pid);
  await waitPortDown(3000,7000);
  const server=path.join(installRoot,'server.js');
  const child=hidden(process.execPath,[server],{cwd:installRoot,detached:true}); child.unref();
  const serverOk=await waitServerVersion(targetVersion,15000); if(!serverOk) throw new Error(`Yeni KafePin server health-check gecmedi: ${targetVersion}`);
  const end=Date.now()+45000;
  while(Date.now()<end){ const a=readJson(activationPath()); if(a&&a.ok===true&&String(a.targetVersion||'')===targetVersion) return true; if(a&&a.ok===false&&String(a.targetVersion||'')===targetVersion) throw new Error(String(a.error||'Post-update activation failed')); await sleep(300); }
  throw new Error('Post-update aktivasyon health-check zaman asimi');
}
async function selfTest(){
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'kafepin-supervisor-selftest-'));
  try{
    const src=path.join(tmp,'src'),dst=path.join(tmp,'dst'); fs.mkdirSync(src,{recursive:true}); fs.mkdirSync(dst,{recursive:true});
    fs.writeFileSync(path.join(src,'a.txt'),'new'); fs.writeFileSync(path.join(dst,'state.json'),'keep'); fs.writeFileSync(path.join(dst,'a.txt'),'old');
    copyTree(src,dst,new Set(['state.json']));
    if(fs.readFileSync(path.join(dst,'a.txt'),'utf8')!=='new') throw new Error('copyTree overwrite');
    if(fs.readFileSync(path.join(dst,'state.json'),'utf8')!=='keep') throw new Error('preserve failed');
    process.stdout.write('SELFTEST_OK\n');
  } finally { fs.rmSync(tmp,{recursive:true,force:true}); }
}
(async()=>{
  const args=process.argv.slice(2); if(args.includes('--self-test')) return selfTest();
  const root=path.resolve(args[args.indexOf('--install-root')+1]||process.cwd());
  const target=String(args[args.indexOf('--target-version')+1]||'').trim(); if(!/^\d+(\.\d+){1,3}$/.test(target)) throw new Error('target-version gecersiz');
  const activate=args.includes('--activate-only');
  try{ if(activate) await activateOnly(root,target); else await fullRestart(root,target); }
  catch(err){ writeActivation({ok:false,targetVersion:target,error:String(err&&err.message||err),completedAt:Date.now()}); log(root,`FAILED ${String(err&&err.stack||err)}`); process.exitCode=1; }
})();
