param(
  [Parameter(Mandatory=$true)][string]$ManifestUrl,
  [Parameter(Mandatory=$true)][string]$ExpectedVersion
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$work = Join-Path $env:TEMP ('KafePinProUpdate_' + [guid]::NewGuid().ToString('N'))
$zip = Join-Path $work 'update.zip'
$expanded = Join-Path $work 'expanded'

try {
  Start-Sleep -Seconds 2
  New-Item -ItemType Directory -Path $work -Force | Out-Null
  $manifest = Invoke-RestMethod -Uri $ManifestUrl -UseBasicParsing
  if ([string]$manifest.version -ne $ExpectedVersion) { throw 'Surum bilgisi degisti; guncelleme iptal edildi.' }
  if (-not $manifest.downloadUrl -or $manifest.downloadUrl -notmatch '^https://') { throw 'Guncelleme indirme adresi gecersiz.' }
  Invoke-WebRequest -Uri $manifest.downloadUrl -OutFile $zip -UseBasicParsing
  if ($manifest.sha256) {
    $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($hash -ne ([string]$manifest.sha256).ToLowerInvariant()) { throw 'Indirilen paket dogrulanamadi.' }
  }
  Expand-Archive -LiteralPath $zip -DestinationPath $expanded -Force
  $updateInfoPath = Join-Path $expanded 'update.json'
  if (-not (Test-Path -LiteralPath $updateInfoPath)) { throw 'Paket tanim dosyasi bulunamadi.' }
  $update = Get-Content -LiteralPath $updateInfoPath -Raw | ConvertFrom-Json
  if ([string]$update.version -ne $ExpectedVersion -or -not $update.files) { throw 'Paket surumu gecersiz.' }

  & (Join-Path $root 'KafePin_Pro_Yedek_Al.bat') /AUTO
  if ($LASTEXITCODE -ne 0) { throw 'Emniyet yedegi alinamadi.' }
  & (Join-Path $root 'KafePin_Pro_Durdur.bat')
  foreach ($relative in $update.files) {
    $safe = [string]$relative
    if ([string]::IsNullOrWhiteSpace($safe) -or $safe -match '(^|[\\/])\.\.([\\/]|$)' -or [IO.Path]::IsPathRooted($safe)) { throw 'Paket dosya yolu gecersiz.' }
    $source = Join-Path $expanded $safe
    $target = Join-Path $root $safe
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Paket dosyasi eksik: $safe" }
    New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
    Copy-Item -LiteralPath $source -Destination $target -Force
  }
  @{ version=$ExpectedVersion; channel='stable'; installedAt=(Get-Date).ToString('o') } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $root 'kafepin-pro-version.json') -Encoding UTF8
  Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
  Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', ('call "' + (Join-Path $root 'KafePin_Pro_Baslat.bat') + '"') -WindowStyle Hidden
} catch {
  $log = Join-Path $root 'logs\kafepin-update-error.log'
  New-Item -ItemType Directory -Path (Split-Path -Parent $log) -Force | Out-Null
  ((Get-Date).ToString('s') + '  ' + $_.Exception.Message) | Add-Content -LiteralPath $log
  try { Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', ('call "' + (Join-Path $root 'KafePin_Pro_Baslat.bat') + '"') -WindowStyle Hidden } catch {}
}
