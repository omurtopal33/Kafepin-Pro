﻿param(
  [string]$ServerUrl='',
  [switch]$ConnectionTestOnly
)

$ErrorActionPreference='Stop'

try {
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  [Console]::InputEncoding = $utf8
  [Console]::OutputEncoding = $utf8
  $OutputEncoding = $utf8
} catch {}

function Set-ClientProgress([int]$Percent,[string]$Text) {
  Write-Output ('KAFEPIN_CLIENT_PROGRESS|'+$Percent+'|'+$Text)
}

function Test-Administrator {
  return ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator
  )
}

function Invoke-KafePinDirectJson([string]$Uri) {
  $request = [System.Net.HttpWebRequest]::Create($Uri)
  $request.Method = 'GET'
  $request.Proxy = $null
  $request.Timeout = 6000
  $request.ReadWriteTimeout = 6000
  $request.KeepAlive = $false
  $request.CachePolicy = New-Object System.Net.Cache.RequestCachePolicy(
    [System.Net.Cache.RequestCacheLevel]::NoCacheNoStore
  )
  $response = $null
  $reader = $null
  try {
    $response = [System.Net.HttpWebResponse]$request.GetResponse()
    $reader = New-Object System.IO.StreamReader($response.GetResponseStream(), [System.Text.Encoding]::UTF8)
    return ($reader.ReadToEnd() | ConvertFrom-Json)
  } finally {
    if ($reader) { $reader.Dispose() }
    if ($response) { $response.Dispose() }
  }
}

function Invoke-WebLimitAgentJson {
  param(
    [Parameter(Mandatory=$true)][string]$Uri,
    [Parameter(Mandatory=$true)][string]$ControlKey,
    [ValidateSet('GET','POST')][string]$Method='GET',
    [object]$Body=$null
  )
  $request = [System.Net.HttpWebRequest]::Create($Uri)
  $request.Method = $Method
  $request.Proxy = $null
  $request.Timeout = 6000
  $request.ReadWriteTimeout = 6000
  $request.KeepAlive = $false
  $request.Headers['X-KafePin-Token'] = $ControlKey
  if ($Method -eq 'POST') {
    $payload = [System.Text.Encoding]::UTF8.GetBytes(($Body | ConvertTo-Json -Compress))
    $request.ContentType = 'application/json; charset=utf-8'
    $request.ContentLength = $payload.Length
    $stream = $request.GetRequestStream()
    try { $stream.Write($payload, 0, $payload.Length) } finally { $stream.Dispose() }
  }
  $response = $null
  $reader = $null
  try {
    $response = [System.Net.HttpWebResponse]$request.GetResponse()
    $reader = New-Object System.IO.StreamReader($response.GetResponseStream(), [System.Text.Encoding]::UTF8)
    return ($reader.ReadToEnd() | ConvertFrom-Json)
  } finally {
    if ($reader) { $reader.Dispose() }
    if ($response) { $response.Dispose() }
  }
}

function Install-WebLimitAgent {
  param([string]$PayloadRoot)

  $answer = (Read-Host 'SuperWKS acik ve diskless ayari kaydedildi mi? (E/H)').Trim().ToUpperInvariant()
  if ($answer -ne 'E') { throw 'SuperWKS acik/kaydedilmis olmadan WinAgent kurulumu baslatilmaz.' }

  $agentZip = Join-Path $PayloadRoot 'WebLimitAgent\WebLimitAgent.zip'
  $expectedZipHash = 'f542f54c781f4fda7b229aa1da72665fc79d6045a980978a2789ac8c2437a677'
  $expectedExeHash = '7ae44bab4f0e8eda1aaf9fe906796afd01dbf5645712f0440a8a5529c4e7e3d2'
  if (-not (Test-Path -LiteralPath $agentZip -PathType Leaf)) { throw 'WebLimit Agent payload ZIP bulunamadi.' }
  if ((Get-FileHash -LiteralPath $agentZip -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedZipHash) {
    throw 'WebLimit Agent ZIP SHA-256 dogrulamasini gecemedi.'
  }

  $agentRoot = 'C:\KafePinPro\WebLimitAgent'
  $agentExe = Join-Path $agentRoot 'KafePin_WebLimit_Agent.exe'
  $agentKeyRoot = 'C:\ProgramData\KafePin\WebLimit'
  $agentKey = Join-Path $agentKeyRoot 'control.key'
  $taskName = 'KafePin Web Limit Agent'
  $oldTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  if ($oldTask) {
    Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction Stop
  }
  $oldAgents = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -ieq 'KafePin_WebLimit_Agent.exe' -and $_.CommandLine -like ('*' + $agentExe + '*')
  })
  foreach ($oldAgent in $oldAgents) { Stop-Process -Id $oldAgent.ProcessId -Force -ErrorAction SilentlyContinue }
  New-Item -ItemType Directory -Force -Path $agentRoot, $agentKeyRoot | Out-Null
  Expand-Archive -LiteralPath $agentZip -DestinationPath $agentRoot -Force
  $keyBytes = New-Object byte[] 32
  $keyRng = [Security.Cryptography.RandomNumberGenerator]::Create()
  try { $keyRng.GetBytes($keyBytes) } finally { $keyRng.Dispose() }
  $controlKey = ([BitConverter]::ToString($keyBytes)).Replace('-','').ToLowerInvariant()
  [IO.File]::WriteAllText($agentKey, $controlKey, (New-Object Text.UTF8Encoding($false)))
  & icacls.exe $agentKey '/inheritance:r' '/grant:r' '*S-1-5-18:(F)' '*S-1-5-32-544:(F)' | Out-Null
  if ($LASTEXITCODE -ne 0) { throw 'WebLimit Agent benzersiz control.key erişim izinleri güvenli biçimde ayarlanamadı.' }
  if (-not (Test-Path -LiteralPath $agentExe -PathType Leaf)) { throw 'WebLimit Agent EXE arsivden cikmadi.' }
  if ((Get-FileHash -LiteralPath $agentExe -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedExeHash) {
    throw 'WebLimit Agent EXE SHA-256 dogrulamasini gecemedi.'
  }

  Get-NetFirewallRule -DisplayName 'KafePin Web Limit Agent 17906' -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
  New-NetFirewallRule -DisplayName 'KafePin Web Limit Agent 17906' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 17906 -Profile Private -Program $agentExe -ErrorAction Stop | Out-Null
  $action = New-ScheduledTaskAction -Execute $agentExe
  $trigger = New-ScheduledTaskTrigger -AtStartup
  $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
  $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1)
  Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
  Start-ScheduledTask -TaskName $taskName -ErrorAction Stop

  $controlKey = (Get-Content -LiteralPath $agentKey -Raw -Encoding UTF8).Trim()
  if ([string]::IsNullOrWhiteSpace($controlKey)) { throw 'WebLimit Agent control.key bos.' }
  $health = $null
  for ($attempt = 1; $attempt -le 15; $attempt++) {
    try {
      $health = Invoke-WebLimitAgentJson -Uri 'http://127.0.0.1:17906/api/health' -ControlKey $controlKey
      if ($health.ok) { break }
    } catch {}
    Start-Sleep -Seconds 1
  }
  if (-not $health -or -not $health.ok) { throw 'WebLimit Agent 17906 saglik kontrolu basarisiz.' }
  if ([int]$health.controlPort -ne 17906 -or [string]$health.mode -ne 'browser-only-pac-proxy' -or -not [bool]$health.failOpen) {
    throw 'WebLimit Agent guvenli browser-only/fail-open modu dogrulanamadi.'
  }
  $enabled = Invoke-WebLimitAgentJson -Uri 'http://127.0.0.1:17906/api/control' -ControlKey $controlKey -Method POST -Body @{ action='enable'; downMbps=50; upMbps=10 }
  if (-not $enabled.ok) { throw 'WebLimit Agent 50/10 ayari uygulanamadi.' }
  $health = Invoke-WebLimitAgentJson -Uri 'http://127.0.0.1:17906/api/health' -ControlKey $controlKey
  if (-not $health.ok -or -not [bool]$health.enabled -or [double]$health.downMbps -ne 50 -or [double]$health.upMbps -ne 10) {
    throw 'WebLimit Agent 50/10 sonrasi saglik dogrulamasi basarisiz.'
  }
  $runningAgents = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -ieq 'KafePin_WebLimit_Agent.exe' -and $_.CommandLine -like ('*' + $agentExe + '*')
  })
  if ($runningAgents.Count -ne 1) { throw ('WebLimit Agent tek-instance dogrulamasi basarisiz. Islem sayisi: ' + $runningAgents.Count) }
  return $health
}

Set-ClientProgress 5 'Kurulum hazırlanıyor'
if (-not $ConnectionTestOnly) {
  if (-not (Test-Administrator)) { throw 'Kurulumu yönetici olarak çalıştırın.' }
  Set-ClientProgress 10 'Yönetici izni doğrulandı'
}

if (-not $ServerUrl) {
  $ServerUrl = Read-Host 'KafePin ana sunucu adresi (örnek: http://192.168.1.100:3000)'
}
$ServerUrl = $ServerUrl.Trim().TrimEnd('/')
if ($ServerUrl -notmatch '^http://(?:\d{1,3}\.){3}\d{1,3}:\d{1,5}$') {
  throw 'Sunucu adresi geçersiz. Örnek: http://192.168.1.100:3000'
}

Set-ClientProgress 20 'Ana sunucuya proxy kullanmadan bağlanılıyor'
try {
  $health = Invoke-KafePinDirectJson ($ServerUrl + '/api/health')
  if (-not $health.ok) { throw 'Sunucu sağlık kontrolü başarısız.' }
} catch {
  throw ('Ana sunucuya doğrudan ulaşılamadı: ' + $_.Exception.Message)
}
if ($ConnectionTestOnly) {
  Set-ClientProgress 100 'Doğrudan yerel ağ bağlantı testi başarılı'
  Write-Host '✓ Ana sunucuya Windows proxy kullanılmadan doğrudan bağlanıldı.' -ForegroundColor Green
  return
}

try {
  $clientConfig = Invoke-KafePinDirectJson ($ServerUrl + '/api/client-config')
} catch {
  throw ('Client masa ayarı okunamadı: ' + $_.Exception.Message)
}
if (-not $clientConfig.ok) {
  throw ('Bu bilgisayarın IP adresi ana sunucuda masa olarak tanımlı değil: ' + [string]$clientConfig.error)
}

$masa = [int]$clientConfig.masa
$spinEnabled = [bool]$clientConfig.spinEnabled
Set-ClientProgress 35 ('MASA-' + $masa + ' bulundu; sunucu ayarı okundu')

$source = Join-Path $PSScriptRoot 'KafePinClient.cs'
if (-not (Test-Path -LiteralPath $source)) { throw 'KafePinClient.cs eksik.' }

$root = Join-Path $env:ProgramData 'KafePinClient'
New-Item -ItemType Directory -Force -Path $root | Out-Null
$exe = Join-Path $root 'KafePinClient.exe'
$configPath = Join-Path $root 'config.json'
@{
  serverUrl = $ServerUrl
  masa = $masa
  spinEnabled = $spinEnabled
  directLanConnection = $true
} | ConvertTo-Json | Set-Content -LiteralPath $configPath -Encoding UTF8

$compiler = @(
  (Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'),
  (Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe')
) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $compiler) { throw '.NET Framework derleyicisi bulunamadı.' }

Get-Process -Name 'KafePinClient' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
& $compiler /nologo /target:winexe /platform:anycpu /optimize+ ('/out:' + $exe) /reference:System.dll /reference:System.Core.dll /reference:System.Web.Extensions.dll $source
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $exe)) {
  throw 'Client ping uygulaması derlenemedi.'
}
Set-ClientProgress 60 'Proxy kullanmayan ping uygulaması hazır'

$taskName = 'KafePin Client Ping'
$oldTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($oldTask) {
  Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction Stop
}
$action = New-ScheduledTaskAction -Execute $exe
$trigger = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1)
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
Start-ScheduledTask -TaskName $taskName -ErrorAction Stop
Set-ClientProgress 82 'Ping sistemi kuruldu ve başlatıldı'

Set-ClientProgress 86 'WebLimit WinAgent kuruluyor'
$agentHealth = Install-WebLimitAgent -PayloadRoot $PSScriptRoot
Set-ClientProgress 89 'WebLimit WinAgent 50/10 browser-only olarak hazır'

$publicDesktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
if (-not $publicDesktop) { $publicDesktop = Join-Path $env:PUBLIC 'Desktop' }
foreach ($name in @('KafePin Sans Carki.lnk','KafePin Şans Çarkı.lnk')) {
  Remove-Item -LiteralPath (Join-Path $publicDesktop $name) -Force -ErrorAction SilentlyContinue
}

Set-ClientProgress 90 'Çark politikası uygulanıyor'
if ($spinEnabled) {
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut((Join-Path $publicDesktop 'KafePin Şans Çarkı.lnk'))
  $shortcut.TargetPath = Join-Path $env:WINDIR 'explorer.exe'
  $shortcut.Arguments = $ServerUrl + '/wheel.html'
  $shortcut.Description = 'KafePin Şans Çarkı'
  $shortcut.Save()
}

Set-ClientProgress 100 'Client kurulumu tamamlandı'
Write-Host ''
Write-Host ('✓ KafePin Client kuruldu: MASA-' + $masa) -ForegroundColor Green
Write-Host '✓ Yerel ağ bağlantısı doğrudan; Windows proxy ayarları kullanılmaz.' -ForegroundColor Green
Write-Host '✓ Windows başlangıç ping görevi kuruldu ve çalıştırıldı.' -ForegroundColor Green
Write-Host '✓ WebLimit WinAgent kuruldu: 50/10 browser-only, fail-open, tek-instance.' -ForegroundColor Green
Write-Host ('✓ Çark: ' + $(if ($spinEnabled) { 'AKTİF; masaüstü kısayolu hazır.' } else { 'KAPALI; yalnız ping kuruldu.' })) -ForegroundColor Green
