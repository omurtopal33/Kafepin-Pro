@echo off
chcp 65001 >nul
title KafePin Client v3.1.65 Kurulumu
net session >nul 2>&1
if not "%errorlevel%"=="0" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath 'cmd.exe' -ArgumentList '/c ""%~f0""' -Verb RunAs"
  exit /b
)
echo.
echo KafePin Client kurulumu basliyor...
echo Ana sunucu adresini tam olarak girin. Ornek: http://192.168.1.100:3000
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0KafePin-Client-Kur.ps1"
set RC=%ERRORLEVEL%
echo.
if "%RC%"=="0" (
  echo KURULUM BASARILI.
) else (
  echo KURULUM TAMAMLANAMADI. Hata kodu: %RC%
)
pause
exit /b %RC%

