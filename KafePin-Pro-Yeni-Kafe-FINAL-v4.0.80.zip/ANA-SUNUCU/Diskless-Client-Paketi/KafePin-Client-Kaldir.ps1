﻿$ErrorActionPreference='SilentlyContinue'

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
  [Security.Principal.WindowsBuiltInRole]::Administrator
)) { throw 'Yönetici olarak çalıştırın.' }

$task = Get-ScheduledTask -TaskName 'KafePin Client Ping' -ErrorAction SilentlyContinue
if ($task) {
  Stop-ScheduledTask -TaskName 'KafePin Client Ping' -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName 'KafePin Client Ping' -Confirm:$false -ErrorAction SilentlyContinue
}
Get-Process -Name 'KafePinClient' -ErrorAction SilentlyContinue | Stop-Process -Force
$agentTask = Get-ScheduledTask -TaskName 'KafePin Web Limit Agent' -ErrorAction SilentlyContinue
if ($agentTask) {
  Stop-ScheduledTask -TaskName 'KafePin Web Limit Agent' -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName 'KafePin Web Limit Agent' -Confirm:$false -ErrorAction SilentlyContinue
}
$agentExe = 'C:\KafePinPro\WebLimitAgent\KafePin_WebLimit_Agent.exe'
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
  $_.Name -ieq 'KafePin_WebLimit_Agent.exe' -and $_.CommandLine -like ('*' + $agentExe + '*')
} | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Get-NetFirewallRule -DisplayName 'KafePin Web Limit Agent 17906' -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
Remove-Item -LiteralPath 'C:\KafePinPro\WebLimitAgent' -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $env:ProgramData 'KafePin\WebLimit') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $env:ProgramData 'KafePinClient') -Recurse -Force -ErrorAction SilentlyContinue
$desktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
foreach ($name in @('KafePin Sans Carki.lnk','KafePin Şans Çarkı.lnk')) {
  Remove-Item -LiteralPath (Join-Path $desktop $name) -Force -ErrorAction SilentlyContinue
}
Write-Host 'KafePin Client ve WebLimit WinAgent kaldırıldı.'

