using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

class KafePinClient {
    static readonly string ConfigDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "KafePinClient");
    static readonly string ConfigFile = Path.Combine(ConfigDir, "config.json");
    static readonly string LogFile = Path.Combine(ConfigDir, "client.log");
    static readonly JavaScriptSerializer Json = new JavaScriptSerializer();

    static void Log(string text) {
        try {
            Directory.CreateDirectory(ConfigDir);
            File.AppendAllText(LogFile, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + text + Environment.NewLine, Encoding.UTF8);
        } catch { }
    }

    static HttpWebRequest CreateRequest(string url, string method) {
        var request = (HttpWebRequest)WebRequest.Create(url);
        request.Method = method;
        request.Proxy = null;
        request.Timeout = 6000;
        request.ReadWriteTimeout = 6000;
        request.KeepAlive = false;
        request.CachePolicy = new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);
        return request;
    }

    static Dictionary<string, object> GetJson(string url) {
        var request = CreateRequest(url, "GET");
        using (var response = (HttpWebResponse)request.GetResponse())
        using (var reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
            return Json.Deserialize<Dictionary<string, object>>(reader.ReadToEnd());
    }

    static Dictionary<string, object> PostJson(string url, object body) {
        byte[] bytes = Encoding.UTF8.GetBytes(Json.Serialize(body));
        var request = CreateRequest(url, "POST");
        request.ContentType = "application/json";
        request.ContentLength = bytes.Length;
        using (var stream = request.GetRequestStream()) stream.Write(bytes, 0, bytes.Length);
        using (var response = (HttpWebResponse)request.GetResponse())
        using (var reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
            return Json.Deserialize<Dictionary<string, object>>(reader.ReadToEnd());
    }

    static string ReadBaseUrl() {
        Directory.CreateDirectory(ConfigDir);
        var data = Json.Deserialize<Dictionary<string, object>>(File.ReadAllText(ConfigFile, Encoding.UTF8));
        return Convert.ToString(data["serverUrl"]).TrimEnd('/');
    }

    static bool IsOk(Dictionary<string, object> data) {
        return data != null && data.ContainsKey("ok") && Convert.ToBoolean(data["ok"]);
    }

    static void Main() {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        ServicePointManager.Expect100Continue = false;
        string baseUrl;
        try { baseUrl = ReadBaseUrl(); }
        catch (Exception error) { Log("config error " + error.Message); return; }

        int lastMasa = 0;
        bool wasConnected = false;
        Log("client started direct-lan " + baseUrl);
        while (true) {
            try {
                var config = GetJson(baseUrl + "/api/client-config");
                if (!IsOk(config)) throw new Exception(config != null && config.ContainsKey("error") ? Convert.ToString(config["error"]) : "client-config failed");
                int masa = Convert.ToInt32(config["masa"]);
                string token = Convert.ToString(config["token"]);
                var ping = PostJson(baseUrl + "/api/ping", new { masa = masa, token = token });
                if (!IsOk(ping)) throw new Exception(ping != null && ping.ContainsKey("error") ? Convert.ToString(ping["error"]) : "ping failed");
                if (!wasConnected || masa != lastMasa) Log("connected masa=" + masa);
                lastMasa = masa;
                wasConnected = true;
            } catch (Exception error) {
                if (wasConnected) Log("connection lost " + error.Message);
                wasConnected = false;
            }
            Thread.Sleep(10000);
        }
    }
}

