"use strict";

const sqlite3 = require("sqlite3").verbose();
const { readSessionOrders } = require("./everycafe-session-charges");

const open = (file, mode) => new Promise((resolve, reject) => {
  const db = new sqlite3.Database(file, mode, (err) => err ? reject(err) : resolve(db));
});
const all = (db, sql, args = []) => new Promise((resolve, reject) =>
  db.all(sql, args, (err, rows) => err ? reject(err) : resolve(rows || [])));
const get = (db, sql, args = []) => new Promise((resolve, reject) =>
  db.get(sql, args, (err, row) => err ? reject(err) : resolve(row || null)));
const run = (db, sql, args = []) => new Promise((resolve, reject) =>
  db.run(sql, args, function done(err) { err ? reject(err) : resolve({ changes: this.changes, lastID: this.lastID }); }));
const close = (db) => new Promise((resolve) => db ? db.close(() => resolve()) : resolve());
const readOrders = (db, ids) => new Promise((resolve, reject) =>
  readSessionOrders(db, ids, (err, rows) => err ? reject(err) : resolve(rows || [])));
const round = (value) => Math.round((Number(value) || 0) * 100) / 100;

async function tableExists(db, name) {
  return Boolean(await get(db, "SELECT 1 AS ok FROM sqlite_master WHERE type='table' AND name=?", [name]));
}

async function backfillImportedSessionCharges(options = {}) {
  const localPath = String(options.localPath || "").trim();
  const sourcePath = String(options.sourcePath || "").trim();
  if (!localPath || !sourcePath) throw new Error("EveryCafe ayrıntı düzeltmesi için DB yolları eksik");
  let localDb = null;
  let sourceDb = null;
  const result = { ok: true, scanned: 0, repairedSessions: 0, insertedCharges: 0, reclassifiedTotal: 0, skipped: [] };
  try {
    localDb = await open(localPath, sqlite3.OPEN_READWRITE);
    sourceDb = await open(sourcePath, sqlite3.OPEN_READONLY);
    await run(localDb, "PRAGMA busy_timeout=5000");

    const imported = await all(localDb, `SELECT i.session_id,i.masa,i.source_end,i.total,
        p.id AS payment_id,p.masa AS payment_masa,p.session_start,p.session_end,
        p.computer_amount,p.product_amount,p.total_amount,p.method,p.close_reason
      FROM everycafe_imports i
      JOIN payments p ON p.voided=0 AND p.external_source='EVERYCAFE'
        AND p.external_id=('SESSION:' || i.session_id)
      WHERE p.close_reason='EVERYCAFE_SYNC'
      ORDER BY i.source_end ASC`);
    result.scanned = imported.length;
    if (!imported.length) return result;

    let splitIds = new Set();
    if (await tableExists(localDb, "everycafe_split_payments")) {
      splitIds = new Set((await all(localDb, "SELECT session_id FROM everycafe_split_payments"))
        .map((row) => String(row.session_id || "").trim()).filter(Boolean));
    }
    const sessionIds = imported.map((row) => String(row.session_id || "").trim()).filter(Boolean);
    const sourceRows = await readOrders(sourceDb, sessionIds);
    const syntheticBySession = new Map();
    for (const row of sourceRows) {
      const orderId = String(row.OrderID || "").trim();
      if (!/^(PRINT|ITEM|USB):/.test(orderId) || Number(row.OrderIsActive) === 0) continue;
      const sid = String(row.SessionID || "").trim();
      if (!syntheticBySession.has(sid)) syntheticBySession.set(sid, []);
      syntheticBySession.get(sid).push(row);
    }

    for (const item of imported) {
      const sessionId = String(item.session_id || "").trim();
      const candidates = syntheticBySession.get(sessionId) || [];
      if (!candidates.length) continue;
      if (splitIds.has(sessionId)) {
        result.skipped.push({ sessionId, reason: "parçalı ödeme dağılımı manuel korunuyor" });
        continue;
      }
      const externalIds = candidates.map((row) => `ORDER:${String(row.OrderID)}`);
      const existing = await all(localDb, `SELECT external_id,voided FROM product_sales
        WHERE external_source='EVERYCAFE' AND external_id IN (${externalIds.map(() => "?").join(",")})`, externalIds);
      const existingIds = new Set(existing.map((row) => String(row.external_id || "")));
      const missing = candidates.filter((row) => !existingIds.has(`ORDER:${String(row.OrderID)}`));
      if (!missing.length) continue;

      const missingTotal = round(missing.reduce((sum, row) =>
        sum + Math.max(1, Number(row.Quantity) || 1) * Math.max(0, Number(row.Price) || 0), 0));
      const computer = round(item.computer_amount);
      const product = round(item.product_amount);
      const total = round(item.total_amount);
      if (missingTotal <= 0 || Math.abs(round(computer + product) - total) > 0.01 || computer + 0.01 < missingTotal) {
        result.skipped.push({ sessionId, reason: "tahsilat dağılımı güvenli değil", missingTotal, computer, product, total });
        continue;
      }
      const adjustments = await all(localDb, `SELECT id,amount FROM real_adjustments
        WHERE masa=? AND session_start=? AND kind='SESSION_FINALIZE'`, [Number(item.payment_masa) || 0, Number(item.session_start) || 0]);
      const histories = await all(localDb, `SELECT id,fee FROM session_history
        WHERE masa=? AND start_time=? AND close_reason='EVERYCAFE'`, [Number(item.payment_masa) || 0, Number(item.session_start) || 0]);
      if (adjustments.length !== 1 || histories.length !== 1
          || Math.abs(round(adjustments[0].amount) - computer) > 0.01
          || Math.abs(round(histories[0].fee) - computer) > 0.01) {
        result.skipped.push({ sessionId, reason: "bilgisayar ücreti satırları birebir doğrulanamadı" });
        continue;
      }

      await run(localDb, "BEGIN IMMEDIATE");
      try {
        for (const charge of missing) {
          const quantity = Math.max(1, Number(charge.Quantity) || 1);
          const price = Math.max(0, Number(charge.Price) || 0);
          const lineTotal = round(quantity * price);
          const inserted = await run(localDb, `INSERT OR IGNORE INTO product_sales
            (time,masa,session_start,product_id,product_name,category,unit_price,quantity,total,sale_type,note,status,finalized_at,payment_method,voided,voided_at,external_source,external_id)
            VALUES (?,?,?,?,?,?,?,?,?,'TABLE',?,'FINALIZED',?,?,0,0,'EVERYCAFE',?)`,
          [(Number(charge.AddDate) || Math.floor(Number(item.session_end) / 1000)) * 1000,
            Number(item.payment_masa) || 0, Number(item.session_start) || 0, 0,
            String(charge.StockName || "EveryCafe ek hizmet").trim().slice(0, 100),
            String(charge.CategoryName || "Ek Hizmet").trim().slice(0, 100), price, quantity, lineTotal,
            `EveryCafe oturum ayrıntısı tamamlandı: ${sessionId}`,
            Number(item.session_end) || Number(item.source_end) || Date.now(), String(item.method || "PENDING"),
            `ORDER:${String(charge.OrderID)}`]);
          if (inserted.changes !== 1) throw new Error(`Ayrıntı satırı eklenemedi: ${charge.OrderID}`);
        }
        const paymentUpdate = await run(localDb, `UPDATE payments
          SET computer_amount=?,product_amount=?
          WHERE id=? AND voided=0 AND ABS(computer_amount-?)<0.011 AND ABS(product_amount-?)<0.011 AND ABS(total_amount-?)<0.011`,
        [round(computer - missingTotal), round(product + missingTotal), Number(item.payment_id), computer, product, total]);
        if (paymentUpdate.changes !== 1) throw new Error("Tahsilat satırı eşzamanlı değişti");
        const adjustmentUpdate = await run(localDb, "UPDATE real_adjustments SET amount=? WHERE id=? AND ABS(amount-?)<0.011",
          [round(computer - missingTotal), Number(adjustments[0].id), computer]);
        const historyUpdate = await run(localDb, "UPDATE session_history SET fee=? WHERE id=? AND ABS(fee-?)<0.011",
          [round(computer - missingTotal), Number(histories[0].id), computer]);
        if (adjustmentUpdate.changes !== 1 || historyUpdate.changes !== 1) throw new Error("Bilgisayar ücreti eşzamanlı değişti");
        await run(localDb, "COMMIT");
        result.repairedSessions += 1;
        result.insertedCharges += missing.length;
        result.reclassifiedTotal = round(result.reclassifiedTotal + missingTotal);
      } catch (err) {
        try { await run(localDb, "ROLLBACK"); } catch (_) {}
        throw err;
      }
    }
    return result;
  } finally {
    await close(sourceDb);
    await close(localDb);
  }
}

module.exports = { backfillImportedSessionCharges };

if (require.main === module) {
  backfillImportedSessionCharges({ localPath: process.argv[2], sourcePath: process.argv[3] })
    .then((result) => console.log(JSON.stringify(result, null, 2)))
    .catch((err) => { console.error(err && err.stack || err); process.exitCode = 1; });
}
