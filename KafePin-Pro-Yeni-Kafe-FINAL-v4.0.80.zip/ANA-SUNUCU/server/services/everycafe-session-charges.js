"use strict";

// These are details of the existing session bill, never extra cash receipts.
// Prepaid charges already settled separately must not be billed again.
const all = (db, sql, args=[]) => new Promise((resolve,reject) =>
  db.all(sql,args,(err,rows)=>err?reject(err):resolve(rows||[])));

async function readSessionCharges(db, sessionIds) {
  const ids=[...new Set(sessionIds.map(String).filter(Boolean))];
  if(!ids.length)return [];
  const tables=new Set((await all(db,"SELECT name FROM sqlite_master WHERE type='table'")).map(r=>r.name));
  const result=[];
  const schemas=new Map();
  for(const table of ['PrintHistory','SessionItems','Sessions']) {
    if(tables.has(table))schemas.set(table,new Set((await all(db,`PRAGMA table_info('${table}')`)).map(r=>r.name)));
  }
  const supports=(t,cols)=>cols.every(c=>schemas.get(t)?.has(c));
  for(let i=0;i<ids.length;i+=180){
    const batch=ids.slice(i,i+180), placeholders=batch.map(()=>'?').join(',');
    if(supports('PrintHistory',['PrintHistoryID','SessionID','PrintedPages','PrintoutPrice','PrintDate','Prepaid'])) {
      const rows=await all(db,`SELECT PrintHistoryID,SessionID,PrintedPages,PrintoutPrice,PrintDate
        FROM PrintHistory WHERE SessionID IN (${placeholders}) AND COALESCE(Prepaid,0)=0
        AND PrintedPages>0 AND PrintoutPrice>0`,batch);
      for(const r of rows)result.push({OrderID:`PRINT:${r.PrintHistoryID}`,SessionID:r.SessionID,
        StockID:0,StockName:'Yazıcı çıktısı',CategoryName:'Yazıcı',Quantity:r.PrintedPages,
        Price:r.PrintoutPrice,AddDate:r.PrintDate,OrderIsActive:1});
    }
    if(supports('SessionItems',['SessionItemID','SessionID','SessionItemText','Amount','Prepaid','AddDate'])) {
      const rows=await all(db,`SELECT SessionItemID,SessionID,SessionItemText,Amount,AddDate
        FROM SessionItems WHERE SessionID IN (${placeholders}) AND COALESCE(Prepaid,0)=0
        AND Amount>0 AND COALESCE(SessionItemID,'')<>''`,batch);
      for(const r of rows)result.push({OrderID:`ITEM:${r.SessionItemID}`,SessionID:r.SessionID,
        StockID:0,StockName:String(r.SessionItemText||'Ek hizmet'),CategoryName:'Ek Hizmet',
        Quantity:1,Price:r.Amount,AddDate:r.AddDate,OrderIsActive:1});
    }
    if(supports('Sessions',['SessionID','USBPrice','IsUSBPricesActive','StartDate'])) {
      const rows=await all(db,`SELECT SessionID,USBPrice,StartDate FROM Sessions
        WHERE SessionID IN (${placeholders}) AND IsUSBPricesActive=1 AND USBPrice>0`,batch);
      for(const r of rows)result.push({OrderID:`USB:${r.SessionID}`,SessionID:r.SessionID,
        StockID:0,StockName:'USB aktarımı',CategoryName:'USB',Quantity:1,
        Price:r.USBPrice,AddDate:r.StartDate,OrderIsActive:1});
    }
  }
  return result;
}

function readSessionOrders(db, ids, cb) {
  (async()=>{
    if(!ids.length)return [];
    const orderColumns=new Set((await all(db,"PRAGMA table_info('Orders')")).map(r=>String(r.name||'')));
    const paymentMethod=orderColumns.has('PaymentMethod')?'COALESCE(o.PaymentMethod,-1)':'-1';
    const prepaid=orderColumns.has('Prepaid')?'COALESCE(o.Prepaid,0)':'0';
    const rows=[];
    for(let i=0;i<ids.length;i+=180){
      const batch=ids.slice(i,i+180);
      rows.push(...await all(db,`SELECT o.OrderID,o.SessionID,o.StockID,o.StockName,o.Quantity,o.Price,o.AddDate,o.OrderIsActive,
        ${paymentMethod} AS PaymentMethod,${prepaid} AS Prepaid,
        COALESCE(c.LookupText1,'') AS CategoryName FROM Orders o
        LEFT JOIN Stocks st ON st.StockID=o.StockID
        LEFT JOIN LookupValues c ON c.LookupKey='ProductCategories' AND c.LookupValue1=st.CategoryID
        WHERE o.SessionID IN (${batch.map(()=>'?').join(',')})`,batch));
    }
    rows.push(...await readSessionCharges(db,ids));
    return rows.sort((a,b)=>(Number(a.AddDate)||0)-(Number(b.AddDate)||0)||String(a.OrderID).localeCompare(String(b.OrderID)));
  })().then(rows=>cb(null,rows),err=>cb(err));
}
module.exports={readSessionCharges,readSessionOrders};
