'use strict';

function decideInstallLifecycle(input = {}) {
  const targetInstalled = Boolean(input.targetInstalled);
  const serverHealthy = Boolean(input.serverHealthy);
  const ownerIsCurrentServer = Boolean(input.ownerIsCurrentServer);
  const supervisorAlive = Boolean(input.supervisorAlive);
  const activationFailed = Boolean(input.activationFailed);
  const stateStage = String(input.stateStage || '');
  const stateRunning = input.stateRunning !== false && !['success','error','idle'].includes(stateStage);
  const stateAgeMs = Math.max(0, Number(input.stateAgeMs || 0));
  const lockAgeMs = Math.max(0, Number(input.lockAgeMs || 0));
  const maxAgeMs = Math.max(1000, Number(input.maxAgeMs || 30 * 60 * 1000));
  const freshState = stateRunning && stateAgeMs <= maxAgeMs;
  const activeOwner = ownerIsCurrentServer || supervisorAlive;

  if (activationFailed) return { state: 'error', clearLock: true, reason: 'activation_failed' };
  if (targetInstalled && serverHealthy && !activeOwner) {
    return { state: 'installed', clearLock: true, reason: 'target_running_no_active_installer' };
  }
  if (stateStage === 'error' || input.stateRunning === false) {
    return { state: 'error', clearLock: true, reason: 'terminal_state' };
  }
  if (!activeOwner && lockAgeMs >= maxAgeMs) {
    return { state: 'stale', clearLock: true, reason: 'stale_without_owner' };
  }
  return {
    state: 'installing',
    clearLock: false,
    reason: activeOwner ? 'real_owner_active' : (freshState ? 'progress_only_grace' : 'waiting')
  };
}

// Backward-compatible adapter: older/newer server.js builds use the richer
// evaluateInstallLifecycle contract while the v4.0.62 regression test uses
// decideInstallLifecycle. Keep both exports so a TEST package cannot leave
// server.js and this helper on different revisions and crash at startup.
function evaluateInstallLifecycle(input = {}) {
  const stage = String(input.state && input.state.stage || '');
  const decision = decideInstallLifecycle({
    targetInstalled: input.targetInstalled === true,
    serverHealthy: input.serverHealthy === true,
    ownerIsCurrentServer: input.directInstallerActive === true,
    supervisorAlive: input.updaterActive === true,
    activationFailed: input.activationFailed === true,
    stateStage: stage,
    stateRunning: input.state ? input.state.running : undefined,
    stateAgeMs: input.stateAgeMs,
    lockAgeMs: input.lockAgeMs,
    maxAgeMs: input.maxAgeMs || input.orphanGraceMs || 30000
  });
  const status = decision.state === 'stale' ? 'error' : decision.state;
  return {
    status,
    cleanup: decision.clearLock === true,
    reason: decision.reason
  };
}

module.exports = { decideInstallLifecycle, evaluateInstallLifecycle };
