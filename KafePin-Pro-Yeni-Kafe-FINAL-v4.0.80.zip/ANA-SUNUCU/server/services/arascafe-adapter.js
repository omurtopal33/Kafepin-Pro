"use strict";

// Tek yönlü ArasKafe kaynak adaptörü. Kaynak SQLite bağlantısı her durumda
// OPEN_READONLY ile açılır; bu modül ArasKafe dosyasında hiçbir migration veya
// yazma sorgusu çalıştırmaz.
const path = require("path");

function textNorm(value) {
  return String(value == null ? "" : value).trim().normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("tr-TR")
    .replace(/ı/g, "i").replace(/ş/g, "s").replace(/ğ/g, "g")
    .replace(/ç/g, "c").replace(/ö/g, "o").replace(/ü/g, "u");
}

function normalizeArasPaymentMethod(value) {
  const valueNorm = textNorm(value).replace(/[^a-z0-9]+/g, " ").trim();
  if (/\b(nakit|cash|pesin)\b/.test(valueNorm)) return "CASH";
  if (/\b(kredi karti|kart|card|pos|kredi)\b/.test(valueNorm)) return "CARD";
  return "UNKNOWN";
}

function normalizeArasMovementType(value) {
  const valueNorm = textNorm(value).replace(/[^a-z0-9]+/g, " ").trim();
  if (/\b(gelir|income|tahsilat|odeme alindi)\b/.test(valueNorm)) return "INCOME";
  if (/\b(gider|expense|iade|iptal|cikis)\b/.test(valueNorm)) return "OUTGOING";
  return "UNKNOWN";
}

function isArasIncomeMovement(row) {
  return normalizeArasMovementType(row && row.GelirGider) === "INCOME" &&
    Number(row && row.Tutar) > 0 && normalizeArasPaymentMethod(row && row.OdemeSekli) !== "UNKNOWN";
}

function quoteIdent(name) {
  return `"${String(name).replace(/"/g, '""')}"`;
}

function openReadOnly(sqlite3, filePath) {
  return new Promise((resolve, reject) => {
    if (!filePath) return reject(new Error("ArasKafe database.db yolu ayarlanmamış"));
    const absolutePath = path.resolve(String(filePath));
    const source = new sqlite3.Database(absolutePath, sqlite3.OPEN_READONLY, (err) => {
      if (err) return reject(err);
      source.get("PRAGMA query_only=ON", (pragmaErr) => {
        if (pragmaErr) {
          source.close(() => reject(pragmaErr));
          return;
        }
        resolve(source);
      });
    });
  });
}

function all(db, sql, params = []) {
  return new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows || [])));
}

function close(db) {
  return new Promise((resolve) => db.close(() => resolve()));
}

async function readArasCafeSchema(sqlite3, filePath) {
  const source = await openReadOnly(sqlite3, filePath);
  try {
    const tables = await all(source, "SELECT name FROM sqlite_master WHERE type='table'");
    const schema = {};
    for (const row of tables) {
      const name = String(row.name || "");
      if (!name || name.startsWith("sqlite_")) continue;
      const columns = await all(source, `PRAGMA table_info(${quoteIdent(name)})`);
      schema[name] = columns.map((column) => String(column.name || ""));
    }
    return { path: path.resolve(String(filePath)), schema };
  } finally {
    await close(source);
  }
}

function safeSelect(schema, table, required, optional = []) {
  const columns = schema[table];
  if (!columns) return null;
  if (required.some((column) => !columns.includes(column))) return null;
  const chosen = [...required, ...optional.filter((column) => columns.includes(column))];
  return `SELECT ${chosen.map(quoteIdent).join(",")} FROM ${quoteIdent(table)}`;
}

async function readArasCafeSnapshot(sqlite3, filePath, options = {}) {
  const limit = Math.min(5000, Math.max(1, Number(options.limit) || 1000));
  const source = await openReadOnly(sqlite3, filePath);
  try {
    const schemaRows = await all(source, "SELECT name FROM sqlite_master WHERE type='table'");
    const schema = {};
    for (const row of schemaRows) {
      const name = String(row.name || "");
      if (!name || name.startsWith("sqlite_")) continue;
      schema[name] = (await all(source, `PRAGMA table_info(${quoteIdent(name)})`)).map((column) => String(column.name || ""));
    }

    const readTable = async (table, required, optional, cursorKey = "") => {
      const base = safeSelect(schema, table, required, optional);
      if (!base) return { available: Boolean(schema[table]), columns: schema[table] || [], rows: [] };
      const hasId = (schema[table] || []).includes("Id");
      const cursor = cursorKey ? Math.max(0, Number(options[cursorKey]) || 0) : 0;
      const where = hasId && cursorKey ? ` WHERE ${quoteIdent("Id")}>?` : "";
      const order = hasId ? ` ORDER BY ${quoteIdent("Id")} ${cursorKey ? "ASC" : "DESC"}` : "";
      const rows = await all(source, `${base}${where}${order} LIMIT ?`, hasId && cursorKey ? [cursor, limit] : [limit]);
      return { available: true, columns: schema[table] || [], rows };
    };

    const [tables, sessions, orders, movements, memberMovements, prints] = await Promise.all([
      readTable("Masalar", ["Id"], ["MasaNo", "MasaIsmi", "Durum", "IpAdresi", "RezerveMi"]),
      readTable("Oturumlar", ["Id"], ["MasaId", "UyeId", "MusteriAdi", "BaslangicTarihi", "BitisTarihi", "Ucret", "SuresizMi", "YoneticiMi", "UcretsizMi", "ToplamDakika", "OdemeSekli"], "lastSessionId"),
      readTable("Siparisler", ["Id"], ["MasaId", "UyeId", "Ad", "Aciklama", "Fiyat", "Adet", "Tarih", "OnaylandiMi"]),
      readTable("KasaHareketleri", ["Id"], ["Tarih", "GelirGider", "OdemeSekli", "IslemTuru", "Tutar", "Aciklama", "OturumId", "SiparisId", "UyeBakiyeIslemiId", "StokId", "Iskonto"], "lastCashId"),
      readTable("UyeBakiyeIslemleri", ["Id"], ["UyeId", "IslemTuru", "Tutar", "Tarih", "Aciklama"], "lastMemberId"),
      readTable("AnaMasaCiktilar", ["Id"], ["MasaId", "OturumId", "UyeId", "DosyaAdi", "SayfaSayisi", "RenkliMi", "KalemAdi", "BirimFiyat", "ToplamFiyat", "OnaylandiMi", "Tarih", "Kasiyer"])
    ]);
    let activeSessions = sessions.rows.filter((row) => row.BitisTarihi == null || String(row.BitisTarihi).trim() === "");
    if (schema.Oturumlar && schema.Oturumlar.includes("BitisTarihi")) {
      const activeSql = safeSelect(schema, "Oturumlar", ["Id"], ["MasaId", "UyeId", "MusteriAdi", "BaslangicTarihi", "BitisTarihi", "Ucret", "SuresizMi", "YoneticiMi", "UcretsizMi", "ToplamDakika", "OdemeSekli"]);
      activeSessions = await all(source, `${activeSql} WHERE ${quoteIdent("BitisTarihi")} IS NULL OR TRIM(CAST(${quoteIdent("BitisTarihi")} AS TEXT))='' ORDER BY ${quoteIdent("Id")} DESC LIMIT ?`, [limit]);
    }
    if (schema.Oturumlar && schema.Oturumlar.includes("BitisTarihi")) {
      const sessionSql = safeSelect(schema, "Oturumlar", ["Id"], ["MasaId", "UyeId", "MusteriAdi", "BaslangicTarihi", "BitisTarihi", "Ucret", "SuresizMi", "YoneticiMi", "UcretsizMi", "ToplamDakika", "OdemeSekli"]);
      const recentClosed = await all(source, `${sessionSql} WHERE ${quoteIdent("BitisTarihi")} IS NOT NULL AND TRIM(CAST(${quoteIdent("BitisTarihi")} AS TEXT))<>'' AND ${quoteIdent("BitisTarihi")}>=datetime('now','-2 days') ORDER BY ${quoteIdent("Id")} DESC LIMIT ?`, [limit]);
      const sessionRowsById = new Map((sessions.rows || []).map((row) => [String(row.Id), row]));
      recentClosed.forEach((row) => sessionRowsById.set(String(row.Id), row));
      sessions.rows = [...sessionRowsById.values()].sort((a,b)=>(Number(a.Id)||0)-(Number(b.Id)||0));
    }
    const incomeMovements = movements.rows.filter(isArasIncomeMovement).map((row) => ({
      ...row, normalizedMethod: normalizeArasPaymentMethod(row.OdemeSekli), normalizedType: "INCOME"
    }));
    const closedPaidSessions = sessions.rows.filter((row) => {
      const hasEnd = row.BitisTarihi != null && String(row.BitisTarihi).trim() !== "";
      return hasEnd && Number(row.UcretsizMi) !== 1 && Number(row.Ucret) > 0 &&
        normalizeArasPaymentMethod(row.OdemeSekli) !== "UNKNOWN";
    });
    // Kasa cursor sayfalıdır; eski kasa hareketleri son sayfada olmayabilir.
    // Fallback oturumlarını seçerken kaynak DB'de OturumId ile bağlı herhangi
    // bir hareket olup olmadığını ayrıca, salt okunur ve sınırlı IN sorgularıyla
    // kontrol ederiz.
    const movementSessionIds = new Set(incomeMovements.map((row) => String(row.OturumId || "")).filter(Boolean));
    if (closedPaidSessions.length && schema.KasaHareketleri && schema.KasaHareketleri.includes("OturumId")) {
      const ids = closedPaidSessions.map((row) => Number(row.Id)).filter((id) => Number.isFinite(id) && id > 0);
      for (let offset = 0; offset < ids.length; offset += 300) {
        const chunk = ids.slice(offset, offset + 300);
        if (!chunk.length) continue;
        const linked = await all(source,
          `SELECT DISTINCT ${quoteIdent("OturumId")} FROM ${quoteIdent("KasaHareketleri")} WHERE ${quoteIdent("OturumId")} IN (${chunk.map(() => "?").join(",")})`,
          chunk
        );
        linked.forEach((row) => { if (row.OturumId != null) movementSessionIds.add(String(row.OturumId)); });
      }
    }
    const fallbackSessions = closedPaidSessions.filter((row) => !movementSessionIds.has(String(row.Id)));
    return {
      sourcePath: path.resolve(String(filePath)), schema,
      tables, sessions, orders, movements, memberMovements, prints,
      activeSessions, incomeMovements, fallbackSessions,
      unknownMovementCount: movements.rows.filter((row) => normalizeArasMovementType(row.GelirGider) === "INCOME" && normalizeArasPaymentMethod(row.OdemeSekli) === "UNKNOWN").length
    };
  } finally {
    await close(source);
  }
}

module.exports = {
  normalizeArasPaymentMethod,
  normalizeArasMovementType,
  isArasIncomeMovement,
  openReadOnly,
  readArasCafeSchema,
  readArasCafeSnapshot
};
