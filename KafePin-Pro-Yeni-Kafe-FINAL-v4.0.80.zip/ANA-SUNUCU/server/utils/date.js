function createDateUtils(DAY_SHIFT_MS) {
  function dayKey(ts) {
    return new Date(ts - DAY_SHIFT_MS).toDateString();
  }

  function dayStartTs(ts) {
    const d = new Date(ts - DAY_SHIFT_MS);
    const startMidnight =
      new Date(
        d.getFullYear(),
        d.getMonth(),
        d.getDate()
      ).getTime();

    return startMidnight + DAY_SHIFT_MS;
  }

  return {
    dayKey,
    dayStartTs
  };
}

module.exports = createDateUtils;