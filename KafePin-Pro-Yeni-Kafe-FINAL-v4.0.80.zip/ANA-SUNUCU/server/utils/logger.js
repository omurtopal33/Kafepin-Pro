function logErr(where, err) {
  if (err) console.error(`[${where}]`, err);
}

function logInfo(where, data) {
  try {
    console.log(`[${where}]`, JSON.stringify(data));
  } catch {
    console.log(`[${where}]`, data);
  }
}

module.exports = {
  logErr,
  logInfo
};