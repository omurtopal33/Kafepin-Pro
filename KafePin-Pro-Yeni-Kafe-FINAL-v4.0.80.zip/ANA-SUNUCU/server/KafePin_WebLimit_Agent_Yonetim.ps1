param(
  [Parameter(Mandatory=$true)][string]$ClientIp,
  [ValidateSet('status','enable','disable')][string]$Action='status',
  [ValidateRange(1,10000)][double]$DownMbps=50,
  [ValidateRange(1,10000)][double]$UpMbps=10
)

$ErrorActionPreference='Stop'

function Invoke-WebLimitAgentJson {
  param([string]$Uri, [string]$ControlKey, [string]$Method='GET', [object]$Body=$null)
  $request = [System.Net.HttpWebRequest]::Create($Uri)
  $request.Method = $Method
  $request.Proxy = $null
  $request.Timeout = 6000
  $request.ReadWriteTimeout = 6000
  $request.KeepAlive = $false
  $request.Headers['X-KafePin-Token'] = $ControlKey
  if ($Method -eq 'POST') {
    $payload = [System.Text.Encoding]::UTF8.GetBytes(($Body | ConvertTo-Json -Compress))
    $request.ContentType = 'application/json; charset=utf-8'
    $request.ContentLength = $payload.Length
    $stream = $request.GetRequestStream()
    try { $stream.Write($payload, 0, $payload.Length) } finally { $stream.Dispose() }
  }
  $response = $null
  $reader = $null
  try {
    $response = [System.Net.HttpWebResponse]$request.GetResponse()
    $reader = New-Object System.IO.StreamReader($response.GetResponseStream(), [System.Text.Encoding]::UTF8)
    return ($reader.ReadToEnd() | ConvertFrom-Json)
  } finally {
    if ($reader) { $reader.Dispose() }
    if ($response) { $response.Dispose() }
  }
}

if ($ClientIp -notmatch '^(?:\d{1,3}\.){3}\d{1,3}$') { throw 'ClientIp gecersiz IPv4 adresi.' }
$keyPath = 'C:\ProgramData\KafePin\WebLimit\control.key'
if (-not (Test-Path -LiteralPath $keyPath -PathType Leaf)) { throw 'WebLimit control.key bulunamadi.' }
$controlKey = (Get-Content -LiteralPath $keyPath -Raw -Encoding UTF8).Trim()
if ([string]::IsNullOrWhiteSpace($controlKey)) { throw 'WebLimit control.key bos.' }

$base = 'http://' + $ClientIp + ':17906'
if ($Action -eq 'enable') {
  $result = Invoke-WebLimitAgentJson -Uri ($base + '/api/control') -ControlKey $controlKey -Method POST -Body @{ action='enable'; downMbps=$DownMbps; upMbps=$UpMbps }
  if (-not $result.ok) { throw 'WebLimit enable istegi basarisiz.' }
} elseif ($Action -eq 'disable') {
  $result = Invoke-WebLimitAgentJson -Uri ($base + '/api/control') -ControlKey $controlKey -Method POST -Body @{ action='disable' }
  if (-not $result.ok) { throw 'WebLimit disable istegi basarisiz.' }
}

$health = Invoke-WebLimitAgentJson -Uri ($base + '/api/health') -ControlKey $controlKey
if (-not $health.ok) { throw 'WebLimit Agent health basarisiz.' }
if ([int]$health.controlPort -ne 17906 -or [string]$health.mode -ne 'browser-only-pac-proxy' -or -not [bool]$health.failOpen) {
  throw 'WebLimit Agent browser-only/fail-open guvenlik durumu dogrulanamadi.'
}
$health | ConvertTo-Json -Depth 5
