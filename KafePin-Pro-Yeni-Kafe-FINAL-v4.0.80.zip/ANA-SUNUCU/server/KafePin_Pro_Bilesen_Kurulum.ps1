﻿param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$ProRoot = 'C:\KafePinPro',
  [switch]$InitialSetup,
  [switch]$EveryCafeEnabled,
  [switch]$ForceInitialSetup
)

$ErrorActionPreference = 'Stop'
try{$utf8=New-Object System.Text.UTF8Encoding($false);[Console]::OutputEncoding=$utf8;$OutputEncoding=$utf8}catch{}
$PayloadRoot = Join-Path $InstallRoot 'pro-components'
$StatePath = Join-Path $InstallRoot 'config\pro-components.json'
$InitialSetupMarker = Join-Path $InstallRoot 'config\new-cafe-initial-setup.pending'
$FreshInstall = -not (Test-Path -LiteralPath (Join-Path $InstallRoot 'database.db'))

# Çekirdek C:\KafePin altında kalır. İsteğe bağlı PRO modülleri kendi ortak
# köklerinde çalışır ve çekirdeğin dosyalarına/DB'sine erişmez.
$ComponentTargets = [ordered]@{
  mp3       = Join-Path $ProRoot 'MP3BotPRO'
  printer   = Join-Path $ProRoot 'YaziciPRO'
  technical = Join-Path $ProRoot 'TeknikServisPRO'
  cv        = Join-Path $ProRoot 'CVOlusturPRO'
  clientPerformance = Join-Path $ProRoot 'ClientPerformansPRO'
  mining    = Join-Path $ProRoot 'MiningPRO'
}
$PrinterSupervisorTaskName = 'KafePin Yazici PRO Supervisor'
$PrinterSupervisorRunName = 'KafePin Yazici PRO Supervisor'

function Write-ComponentLog([string]$Text) {
  $log = Join-Path $InstallRoot 'logs\pro-components-install.log'
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $log) | Out-Null
  Add-Content -LiteralPath $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Text) -Encoding UTF8
}

function Ask-Component([string]$Title, [string]$Text) {
  Write-Host ''
  Write-Host ('=== ' + $Title + ' ===') -ForegroundColor Cyan
  Write-Host $Text -ForegroundColor White
  while ($true) {
    $answer = (Read-Host 'Kurulsun mu? (E/H) [H]').Trim().ToUpperInvariant()
    if ([string]::IsNullOrWhiteSpace($answer) -or $answer -in @('H','HAYIR','N','NO')) { return $false }
    if ($answer -in @('E','EVET','Y','YES')) { return $true }
    Write-Host 'Lütfen E veya H girin.' -ForegroundColor Yellow
  }
}

function Get-ListeningPort([int]$Port) {
  try {
    $connections = @(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction Stop)
    if ($connections.Count -gt 0) { return $connections }
  } catch {}
  try { return @(netstat -ano | Select-String (':'+$Port+'\s+.*LISTENING')) } catch { return @() }
}

function Test-LocalServiceHealth([int]$Port, [string]$ExpectedHeader, [string]$ExpectedValue) {
  try {
    $response = Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:'+$Port+'/api/health?_='+[DateTime]::UtcNow.Ticks) -TimeoutSec 2
    if ($response.StatusCode -lt 200 -or $response.StatusCode -ge 300) { return $false }
    if ($ExpectedHeader -and $response.Headers[$ExpectedHeader] -ne $ExpectedValue) { return $false }
    $body = $response.Content | ConvertFrom-Json
    return ($null -ne $body -and [bool]$body.ok)
  } catch { return $false }
}

function Clear-ClientPerformanceDuplicateListeners {
  $connections = @()
  try { $connections = @(Get-NetTCPConnection -LocalPort 17896 -State Listen -ErrorAction Stop) } catch {}
  if ($connections.Count -le 1) { return }

  $owners = @($connections | ForEach-Object { [int]$_.OwningProcess } | Sort-Object -Unique)
  foreach ($owner in $owners) {
    $process = Get-Process -Id $owner -ErrorAction SilentlyContinue
    if (-not $process -or $process.ProcessName -notin @('python','pythonw')) {
      throw ('17896 portu Client Performans PRO disinda bir islem tarafindan kullaniliyor (PID: '+$owner+').')
    }
  }
  foreach ($owner in $owners) {
    Stop-Process -Id $owner -Force -ErrorAction Stop
  }
  $until = (Get-Date).AddSeconds(8)
  do { Start-Sleep -Milliseconds 250; $connections = @(Get-NetTCPConnection -LocalPort 17896 -State Listen -ErrorAction SilentlyContinue) } while ($connections.Count -gt 1 -and (Get-Date) -lt $until)
  if ($connections.Count -gt 1) { throw 'Eski Client Performans PRO dinleyicileri 17896 portundan güvenli biçimde tek örneğe indirilemedi.' }
}

function Stop-ComponentProcesses([string]$Root, [int[]]$Ports) {
  $rootText = [IO.Path]::GetFullPath($Root).TrimEnd('\')
  Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $commandLine = [string]$_.CommandLine
    $commandLine -and $commandLine.IndexOf($rootText, [StringComparison]::OrdinalIgnoreCase) -ge 0
  } | ForEach-Object {
    try { Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction Stop } catch {}
  }
  $deadline = (Get-Date).AddSeconds(12)
  do {
    $remaining = @($Ports | Where-Object { @(Get-ListeningPort $_).Count -gt 0 })
    if ($remaining.Count -eq 0) { return }
    Start-Sleep -Milliseconds 300
  } while ((Get-Date) -lt $deadline)
  throw ('Eski bileşen süreçleri portlardan ayrılamadı: ' + ($remaining -join ', '))
}

function Start-ClientPerformanceService([string]$Root) {
  $service = Join-Path $Root 'web_service.py'
  if (-not (Test-Path -LiteralPath $service -PathType Leaf)) { throw 'Client Performans PRO web servisi bulunamadı.' }
  $existing = @(Get-ListeningPort 17896)
  if ($existing.Count -gt 1) {
    Clear-ClientPerformanceDuplicateListeners
    $existing = @(Get-ListeningPort 17896)
  }
  if ($existing.Count -eq 0) {
    $py = Ensure-Python3
    $pythonArgs = if ([IO.Path]::GetFileName([string]$py.Source) -ieq 'py.exe') { @('-3','-B',$service) } else { @('-B',$service) }
    $started = Start-Process -FilePath $py.Source -ArgumentList $pythonArgs -WorkingDirectory $Root -WindowStyle Hidden -PassThru
    $until = (Get-Date).AddSeconds(20)
    do {
      Start-Sleep -Milliseconds 500
      if ($started.HasExited) { throw ('Client Performans PRO işlemi 17896 açılmadan kapandı. Çıkış kodu: '+$started.ExitCode) }
      $existing = @(Get-ListeningPort 17896)
    } while ($existing.Count -eq 0 -and (Get-Date) -lt $until)
  }
  $until = (Get-Date).AddSeconds(60)
  do {
    if (@(Get-ListeningPort 17896).Count -eq 1 -and (Test-LocalServiceHealth 17896 'X-KafePin-Performance-Isolation' 'separate-loopback-service')) { return }
    if ($started -and $started.HasExited) { throw ('Client Performans PRO işlemi sağlık vermeden kapandı. Çıkış kodu: '+$started.ExitCode) }
    Start-Sleep -Milliseconds 500
  } while ((Get-Date) -lt $until)
  throw 'Client Performans PRO 17896 portunda tek-instance sağlık doğrulamasını 60 saniye içinde geçemedi.'
}

function Start-MiningService([string]$Root) {
  $service = Join-Path $Root 'web_service.py'
  if (-not (Test-Path -LiteralPath $service -PathType Leaf)) { throw 'Mining PRO web servisi bulunamadı.' }
  $existing = @(Get-ListeningPort 17897)
  if ($existing.Count -eq 0) {
    $py = Ensure-Python3
    $pythonArgs = if ([IO.Path]::GetFileName([string]$py.Source) -ieq 'py.exe') { @('-3','-B',$service) } else { @('-B',$service) }
    $started = Start-Process -FilePath $py.Source -ArgumentList $pythonArgs -WorkingDirectory $Root -WindowStyle Hidden -PassThru
  }
  $until = (Get-Date).AddSeconds(60)
  do {
    try {
      $health = Invoke-RestMethod -Uri ('http://127.0.0.1:17897/api/v1/health?_='+[DateTime]::UtcNow.Ticks) -TimeoutSec 2
      if ($health.ok -and [string]$health.app -eq 'KafePin Mining Pro' -and [string]$health.version -eq '4.0.80') { return }
    } catch {}
    if ($started -and $started.HasExited) { throw ('Mining PRO işlemi sağlık vermeden kapandı. Çıkış kodu: '+$started.ExitCode) }
    Start-Sleep -Milliseconds 500
  } while ((Get-Date) -lt $until)
  throw 'Mining PRO 17897 portunda v4.0.80 sağlık doğrulamasını 60 saniye içinde geçemedi.'
}

function Copy-Component([string]$SourceName, [string]$TargetPath) {
  $source = Join-Path $PayloadRoot ($SourceName + '.zip')
  if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
    throw "Bileşen paketi bulunamadı: $SourceName"
  }
  $temp = Join-Path $env:TEMP ('KafePin-Pro-Component-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $temp | Out-Null
  try {
    Expand-Archive -LiteralPath $source -DestinationPath $temp -Force
    if (-not (Get-ChildItem -LiteralPath $temp -Force | Select-Object -First 1)) {
      throw "Bileşen paketi boş: $SourceName"
    }
    New-Item -ItemType Directory -Force -Path $TargetPath | Out-Null
    Get-ChildItem -LiteralPath $temp -Force | ForEach-Object {
      Copy-Item -LiteralPath $_.FullName -Destination $TargetPath -Recurse -Force
    }
  } finally {
    Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
  }
}

function Invoke-ComponentSetup([string]$ComponentName, [string]$FilePath, [string]$Arguments, [string]$WorkingDirectory, [int]$TimeoutSeconds = 600) {
  $safeName = ($ComponentName -replace '[^a-zA-Z0-9]+','-').Trim('-').ToLowerInvariant()
  $logDir = Join-Path $InstallRoot 'logs'
  New-Item -ItemType Directory -Force -Path $logDir | Out-Null
  $outLog = Join-Path $logDir ('pro-'+$safeName+'-setup.out.log')
  $errLog = Join-Path $logDir ('pro-'+$safeName+'-setup.err.log')
  Remove-Item -LiteralPath $outLog,$errLog -Force -ErrorAction SilentlyContinue
  $p = Start-Process -FilePath $FilePath -ArgumentList $Arguments -WorkingDirectory $WorkingDirectory -WindowStyle Hidden -RedirectStandardOutput $outLog -RedirectStandardError $errLog -PassThru
  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  $nextNotice = Get-Date
  while (-not $p.HasExited) {
    if ((Get-Date) -ge $deadline) {
      try { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue } catch {}
      throw ($ComponentName+' kurulumu '+$TimeoutSeconds+' saniye içinde tamamlanmadı. Günlük: '+$outLog)
    }
    if ((Get-Date) -ge $nextNotice) {
      $remaining = [math]::Max(0,[int](($deadline-(Get-Date)).TotalSeconds))
      Write-Host ('… '+$ComponentName+' hazırlanıyor; kalan en fazla '+$remaining+' sn. (günlük: '+$outLog+')') -ForegroundColor DarkCyan
      $nextNotice = (Get-Date).AddSeconds(5)
    }
    Start-Sleep -Milliseconds 500
    $p.Refresh()
  }
  try { $p.WaitForExit(); $exitCode = $p.ExitCode } catch { $exitCode = $null }
  # Bazı Windows/cmd.exe sürümleri çıkış kodunu Process nesnesine boş
  # döndürüyor; bağımlılıklar zaten başarıyla kurulduysa bunu sahte hata
  # sayma. Gerçek sıfır-dışı kodlar yine günlükle birlikte durdurulur.
  if ($null -ne $exitCode -and $exitCode -ne 0) {
    $detail = @()
    foreach($logFile in @($errLog,$outLog)) { if(Test-Path -LiteralPath $logFile){ $detail += @(Get-Content -LiteralPath $logFile -Tail 8 -ErrorAction SilentlyContinue) } }
    throw ($ComponentName+' kurulum çıkış kodu: '+$exitCode+$(if($detail.Count){' — '+(($detail -join ' ') -replace '\s+',' ').Trim()}else{''}))
  }
  Write-Host ('✓ '+$ComponentName+' bağımlılık kurulumu tamamlandı.') -ForegroundColor Green
}

function Prepare-Mp3Setup([string]$Root) {
  $setup = Join-Path $Root 'KURULUM.cmd'
  if (-not (Test-Path -LiteralPath $setup)) { throw 'MP3 Bot PRO KURULUM.cmd bulunamadı.' }
  $text = Get-Content -LiteralPath $setup -Raw
  $text = $text.Replace('--disable-pip-version-check --upgrade pip','--disable-pip-version-check --timeout 30 --retries 2 --upgrade pip')
  $text = $text.Replace('--disable-pip-version-check -r requirements.txt','--disable-pip-version-check --timeout 30 --retries 2 -r requirements.txt')
  Set-Content -LiteralPath $setup -Value $text -Encoding ASCII
}

function Start-Mp3Service([string]$Root) {
  # Do not depend on the local PowerShell script execution policy.  The virtual
  # environment is created by KURULUM.cmd immediately before this step.
  $python = Join-Path $Root '.venv\Scripts\python.exe'
  $controller = Join-Path $Root 'service_control.py'
  if (-not (Test-Path -LiteralPath $python)) { throw 'MP3 Bot PRO Python ortamı bulunamadı.' }
  if (-not (Test-Path -LiteralPath $controller)) { throw 'MP3 Bot PRO servis denetleyicisi bulunamadı.' }
  $args = '"'+$controller+'" start --wait --timeout 75'
  Invoke-ComponentSetup 'MP3 Bot PRO servis sağlık kontrolü' $python $args $Root 90
  if (-not (Test-LocalServiceHealth 17890 'X-KafePin-MP3-Isolation' 'separate-loopback-service')) { throw 'MP3 Bot PRO 17890 sağlık doğrulamasını geçemedi.' }
}

function Start-PrinterService([string]$Root) {
  $serviceHost = Join-Path $Root 'KafePin_YaziciPRO_ServiceHost.ps1'
  if (-not (Test-Path -LiteralPath $serviceHost)) { throw 'Yazıcı PRO servis başlatıcısı bulunamadı.' }
  $hostProcess = Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$serviceHost,'-InstallRoot',$Root) -WorkingDirectory $Root -WindowStyle Hidden -PassThru
  $expected = ''
  try { $expected = [string]((Get-Content -LiteralPath (Join-Path $Root 'yazici-pro-version.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version) } catch {}
  $deadline = (Get-Date).AddSeconds(90)
  do {
    try {
      $web = Invoke-RestMethod -UseBasicParsing -Uri ('http://127.0.0.1:17891/api/health?_=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 2
      $revenue = Invoke-RestMethod -UseBasicParsing -Uri ('http://127.0.0.1:17893/health?_=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 2
      $webVersion = [string]$web.version
      $revenueVersion = [string]$revenue.version
      if ([bool]$web.ok -and [bool]$revenue.ok -and $webVersion -and $webVersion -eq $revenueVersion -and (-not $expected -or $webVersion -eq $expected)) { return }
    } catch {}
    if ($hostProcess.HasExited -and $hostProcess.ExitCode -ne 0) { throw ('Yazıcı PRO başlatıcısı hata koduyla kapandı: ' + $hostProcess.ExitCode) }
    Start-Sleep -Milliseconds 500
  } while ((Get-Date) -lt $deadline)
  throw 'Yazıcı PRO 17891 ve 17893 sağlık doğrulamasını 90 saniye içinde geçemedi.'
}

function Stop-PrinterSupervisorTask {
  $task = Get-ScheduledTask -TaskName $PrinterSupervisorTaskName -ErrorAction SilentlyContinue
  if (-not $task) { return }
  Stop-ScheduledTask -TaskName $PrinterSupervisorTaskName -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $PrinterSupervisorTaskName -Confirm:$false -ErrorAction SilentlyContinue
}

function Install-PrinterSupervisorTask([string]$Root) {
  try {
    $serviceHost = Join-Path $Root 'KafePin_YaziciPRO_ServiceHost.ps1'
    if (-not (Test-Path -LiteralPath $serviceHost -PathType Leaf)) { throw 'Yazıcı PRO supervisor dosyası bulunamadı.' }
    $interactiveUser = ''
    try { $interactiveUser = [string](Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).UserName } catch {}
    if ([string]::IsNullOrWhiteSpace($interactiveUser)) { $interactiveUser = [Security.Principal.WindowsIdentity]::GetCurrent().Name }
    if ([string]::IsNullOrWhiteSpace($interactiveUser) -or $interactiveUser -match '\\SYSTEM$') { throw 'Yazıcı PRO supervisor için interaktif Windows kullanıcısı bulunamadı.' }
    $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $arguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $serviceHost + '" -InstallRoot "' + $Root + '"'
    $action = New-ScheduledTaskAction -Execute $powershell -Argument $arguments -WorkingDirectory $Root
    $trigger = New-ScheduledTaskTrigger -AtLogOn -User $interactiveUser
    $principal = New-ScheduledTaskPrincipal -UserId $interactiveUser -LogonType Interactive -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
    Register-ScheduledTask -TaskName $PrinterSupervisorTaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'KafePin Yazici PRO 17891 ve 17893 kalici supervisor' -Force | Out-Null
    Start-ScheduledTask -TaskName $PrinterSupervisorTaskName -ErrorAction Stop
    Write-ComponentLog 'Yazıcı PRO supervisor zamanlanmış görevi kuruldu.'
    return $true
  } catch {
    Write-ComponentLog ('Yazıcı PRO zamanlanmış görev kurulamadı; başlangıç kaydı kullanılacak: ' + $_.Exception.Message)
    return $false
  }
}

function Install-PrinterSupervisorRunFallback([string]$Root) {
  try {
    $serviceHost = Join-Path $Root 'KafePin_YaziciPRO_ServiceHost.ps1'
    if (-not (Test-Path -LiteralPath $serviceHost -PathType Leaf)) { throw 'Yazıcı PRO supervisor dosyası bulunamadı.' }
    $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $command = '"' + $powershell + '" -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $serviceHost + '" -InstallRoot "' + $Root + '"'
    $lastError = ''
    foreach ($runKey in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run')) {
      try {
        New-Item -Path $runKey -Force | Out-Null
        New-ItemProperty -Path $runKey -Name $PrinterSupervisorRunName -Value $command -PropertyType String -Force | Out-Null
        $saved = [string](Get-ItemPropertyValue -Path $runKey -Name $PrinterSupervisorRunName -ErrorAction Stop)
        if ($saved -ne $command) { throw 'başlangıç kaydı doğrulanamadı' }
        Write-ComponentLog ('Yazıcı PRO başlangıç kaydı kuruldu ve doğrulandı: ' + $runKey)
        return $true
      } catch { $lastError = $_.Exception.Message }
    }
    try {
      $startup = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Startup'
      New-Item -ItemType Directory -Path $startup -Force | Out-Null
      $startupFile = Join-Path $startup 'KafePin-Yazici-PRO-Supervisor.vbs'
      $vbsCommand = $command.Replace('"','""')
      $vbs = 'Set KafePinShell = CreateObject("WScript.Shell")' + [Environment]::NewLine + 'KafePinShell.Run "' + $vbsCommand + '", 0, False'
      Set-Content -LiteralPath $startupFile -Value $vbs -Encoding ASCII
      if (-not (Test-Path -LiteralPath $startupFile -PathType Leaf) -or (Get-Item -LiteralPath $startupFile).Length -lt 80) { throw 'ortak başlangıç dosyası doğrulanamadı' }
      Write-ComponentLog ('Yazıcı PRO ortak başlangıç fallback kuruldu: ' + $startupFile)
      return $true
    } catch { $lastError = $_.Exception.Message }
    throw ('Registry ve ortak başlangıç fallback kurulamadı: ' + $lastError)
  } catch {
    Write-ComponentLog ('Yazıcı PRO başlangıç fallback kurulamadı: ' + $_.Exception.Message)
    return $false
  }
}

function Start-TechnicalService([string]$Root) {
  $py = Ensure-Python3
  $args = if ([IO.Path]::GetFileName($py.Source) -ieq 'py.exe') { @('-3', '-B', 'web_service.py') } else { @('-B', 'web_service.py') }
  Start-Process -FilePath $py.Source -ArgumentList $args -WorkingDirectory $Root -WindowStyle Hidden | Out-Null
}

if (-not $InitialSetup) {
  exit 0
}
$isAuthorizedInitialSetup = $ForceInitialSetup -and (Test-Path -LiteralPath $InitialSetupMarker)
if (-not $isAuthorizedInitialSetup -or ((Test-Path -LiteralPath $StatePath) -and -not $ForceInitialSetup)) {
  exit 0
}
if (-not (Test-Path -LiteralPath (Join-Path $PayloadRoot 'mp3-bot-pro.zip') -PathType Leaf)) {
  Write-ComponentLog 'Bileşen seçimi atlandı: paket klasörü yok.'
  exit 0
}

$choices = [ordered]@{
  mp3 = Ask-Component 'KafePin MP3 Bot PRO' 'MP3 Bot PRO kurulsun mu?`n`nYouTube arama/indirme, Dinleme Modu, Winamp Modu ve Favori Listem bağımsız olarak kurulacaktır.'
  printer = Ask-Component 'KafePin Yazıcı PRO' 'Yazıcı PRO kurulsun mu?`n`nTarayıcı, kimlik fotokopisi, PDF/dosya dönüştürme ve Windows yazıcı seçimi kurulacaktır.'
  technical = Ask-Component 'KafePin Teknik Servis PRO' 'Teknik Servis PRO kurulsun mu?`n`nServis kaydı, A4 servis fişi ve Nakit/Kart tahsilat kaydı bağımsız olarak kurulacaktır.'
  cv = Ask-Component 'KafePin CV Oluştur PRO' 'CV Oluştur PRO kurulsun mu?`n`nCV şablonları, PDF/yazdırma ve KafePin gelir kaydı bağımsız PRO bileşeni olarak kurulacaktır.'
  clientPerformance = Ask-Component 'KafePin Client Performans PRO' 'Client Performans PRO kurulsun mu?`n`n17896 portunda tek-instance performans ve bağlantı göstergesi servisi kurulacaktır.'
  mining = Ask-Component 'KafePin Mining PRO' 'Mining PRO kurulsun mu?`n`n17897 portundaki bağımsız madencilik paneli ve iOS/Tailscale KafePin Admin sekmesi kurulacaktır. Tüm cüzdan ve API alanları boş gelir; işletme kendi bilgilerini girer.'
}


function Ensure-Python3 {
  $py = Get-Command py.exe -ErrorAction SilentlyContinue
  if ($py) { return $py }
  foreach($candidate in @((Join-Path $env:ProgramFiles 'Python313\python.exe'),(Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'))){
    if(Test-Path -LiteralPath $candidate){return [pscustomobject]@{ Source = $candidate; IsPythonExe = $true }}
  }
  $url='https://www.python.org/ftp/python/3.13.15/python-3.13.15-amd64.exe'
  $expected='edec09c4853aeae9ac36efb8c9f95b6b8e2fee65eee56d9767a8b7c69c574403'
  $temp=Join-Path $env:TEMP ('KafePin-Python-'+[guid]::NewGuid().ToString('N')+'.exe')
  try{
    Write-ComponentLog 'Python 3 bulunamadı; resmi Python kurucusu indiriliyor.'
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $temp
    if((Get-FileHash -Algorithm SHA256 -LiteralPath $temp).Hash.ToLowerInvariant() -ne $expected){throw 'Python indirilen dosya SHA-256 doğrulamasını geçemedi.'}
    $process=Start-Process -FilePath $temp -ArgumentList @('/quiet','InstallAllUsers=1','PrependPath=1','Include_test=0') -Wait -PassThru
    if($process.ExitCode -ne 0){throw ('Python 3 kurulum çıkış kodu: '+$process.ExitCode)}
  }finally{Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue}
  $py = Get-Command py.exe -ErrorAction SilentlyContinue
  if (-not $py) {
    foreach($candidate in @((Join-Path $env:ProgramFiles 'Python313\python.exe'),(Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'))){
      if (Test-Path -LiteralPath $candidate) { return [pscustomobject]@{ Source = $candidate; IsPythonExe = $true } }
    }
    throw 'Python 3 kurulumu tamamlandı ancak py.exe/python.exe bulunamadı.'
  }
  return $py
}

$version = '4.0.80'
$versionFile = Join-Path $InstallRoot 'kafepin-pro-version.json'
if (Test-Path -LiteralPath $versionFile) { try { $version = [string]((Get-Content -LiteralPath $versionFile -Raw -Encoding UTF8 | ConvertFrom-Json).version) } catch {} }
$result = [ordered]@{ version = $version; installedAt = (Get-Date).ToString('o'); choices = $choices; results = [ordered]@{} }

$selectedComponents=@('mp3','printer','technical','cv','clientPerformance','mining')|Where-Object{$choices[$_]}
$selectedIndex=0
foreach ($name in @('mp3', 'printer', 'technical', 'cv', 'clientPerformance', 'mining')) {
  if (-not $choices[$name]) { $result.results[$name] = 'skipped'; continue }
  $selectedIndex++
  $componentLabel=@{mp3='MP3 Bot PRO';printer='Yazıcı PRO';technical='Teknik Servis PRO';cv='CV Oluştur PRO';clientPerformance='Client Performans PRO';mining='Mining PRO'}[$name]
  $percent=[math]::Floor((($selectedIndex-1)*100)/[math]::Max(1,$selectedComponents.Count))
  Write-Progress -Activity 'PRO servisleri kuruluyor' -Status ($componentLabel+' kuruluyor ('+$selectedIndex+'/'+$selectedComponents.Count+')') -PercentComplete $percent
  Write-Host ('['+$selectedIndex+'/'+$selectedComponents.Count+'] '+$componentLabel+' kuruluyor...') -ForegroundColor Cyan
  try {
    if ($name -eq 'mp3') {
      $target = $ComponentTargets.mp3
      Copy-Component 'mp3-bot-pro' $target
      Prepare-Mp3Setup $target
      Invoke-ComponentSetup 'MP3 Bot PRO' 'cmd.exe' '/d /c KURULUM.cmd /silent' $target 600
      Start-Mp3Service $target
    } elseif ($name -eq 'printer') {
      $target = $ComponentTargets.printer
      Stop-PrinterSupervisorTask
      Stop-ComponentProcesses $target @(17891,17893)
      Copy-Component 'yazici-pro' $target
      $printerHost = Join-Path $target 'KafePin_YaziciPRO_ServiceHost.ps1'
      foreach ($requiredPrinterFile in @(
        'KafePin_YaziciPRO_ServiceHost.ps1',
        'KURULUM.cmd',
        'KafePin_YaziciGelir_Service.js',
        'web_service.py',
        'yazici-pro-version.json'
      )) {
        if (-not (Test-Path -LiteralPath (Join-Path $target $requiredPrinterFile))) {
          throw ('Yazıcı PRO gerekli dosyası eksik: ' + $requiredPrinterFile)
        }
      }
      Invoke-ComponentSetup 'Yazıcı PRO' 'cmd.exe' '/d /c KURULUM.cmd /silent' $target 600
      $printerTaskInstalled = Install-PrinterSupervisorTask $target
      $printerRunInstalled = Install-PrinterSupervisorRunFallback $target
      Start-PrinterService $target
      if (-not $printerTaskInstalled -and $printerRunInstalled) { Write-ComponentLog 'Yazıcı PRO görev yerine doğrulanmış başlangıç fallback ile çalışıyor.' }
      if (-not $printerTaskInstalled -and -not $printerRunInstalled) { Write-ComponentLog 'Yazıcı PRO kalıcı kayıt kurulamadı; canlı supervisor sağlık doğrulaması geçti.' }
    } else {
      $null = Ensure-Python3
      if ($name -eq 'cv') {
        $target = $ComponentTargets.cv
        Copy-Component 'cv-olustur-pro' $target
      } elseif ($name -eq 'clientPerformance') {
        $target = $ComponentTargets.clientPerformance
        Stop-ComponentProcesses $target @(17896)
        Copy-Component 'client-performans-pro' $target
        $clientService = Join-Path $target 'web_service.py'
        if (-not (Select-String -LiteralPath $clientService -SimpleMatch 'list_kafepin_config_clients' -Quiet)) { throw 'Client Performans EveryCafe bağımsız fallback kodu hedefe geçmedi.' }
        Start-ClientPerformanceService $target
      } elseif ($name -eq 'mining') {
        $target = $ComponentTargets.mining
        Stop-ComponentProcesses $target @(17897)
        Copy-Component 'mining-pro' $target
        Start-MiningService $target
        $integration = Join-Path $target 'Integrate-KafePinAdmin.ps1'
        if (Test-Path -LiteralPath $integration -PathType Leaf) {
          Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',$integration) -WorkingDirectory $target -WindowStyle Hidden | Out-Null
        }
      } else {
      $target = $ComponentTargets.technical
      Copy-Component 'teknik-servis-pro' $target
      Start-TechnicalService $target
      }
    }
    $result.results[$name] = 'installed'
    Write-ComponentLog "$name kuruldu: $target"
  } catch {
    $result.results[$name] = 'failed: ' + $_.Exception.Message
    Write-Host ('✗ '+$componentLabel+' kurulamadı: '+$_.Exception.Message) -ForegroundColor Red
    Write-ComponentLog "$name kurulamadı: $($_.Exception.Message)"
  }
}

Write-Progress -Activity 'PRO servisleri kuruluyor' -Completed
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $StatePath) | Out-Null
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $StatePath -Encoding UTF8
$failed = @($result.results.Values | Where-Object { $_ -like 'failed:*' })
Write-Host ''
if ($failed.Count -gt 0) {
  Write-Host 'Seçilen bazı PRO bileşenleri kurulamadı.' -ForegroundColor Yellow
  Write-Host 'Ayrıntı: C:\KafePin\logs\pro-components-install.log' -ForegroundColor Yellow
} else {
  Remove-Item -LiteralPath $InitialSetupMarker -Force -ErrorAction SilentlyContinue
  Write-Host 'PRO bileşen seçimleri tamamlandı. Seçilen paneller KafePin masaüstü uygulamasında hazırdır.' -ForegroundColor Green
}
