# Mining Pro v4.0.50 only: clean previously orphaned Mining Python on TCP 17897.
# Does not touch Tailscale, Node, KafePin Server, or other PRO ports.
$ErrorActionPreference = 'Stop'
$port = 17897
try {
    $listeners = @(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)
    $owners = @($listeners | Select-Object -ExpandProperty OwningProcess -Unique)
    foreach ($ownerPid in $owners) {
        if ($ownerPid -le 0) { continue }
        try {
            $ownerProcess = Get-Process -Id $ownerPid -ErrorAction Stop
            if ($ownerProcess.ProcessName -notin @('python', 'pythonw')) { continue }
            # Exact port owner + allowlisted Python only. No broad process-pattern matching.
            Stop-Process -Id $ownerPid -Force -ErrorAction Stop
        }
        catch { Write-Warning ('PID '+$ownerPid+': '+$_.Exception.Message) }
    }
    for ($attempt=0; $attempt -lt 32; $attempt++) {
        $remaining = @(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)
        if ($remaining.Count -eq 0) { exit 0 }
        Start-Sleep -Milliseconds 200
    }
    $remaining = @(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)
    if ($remaining.Count -gt 0) {
        Write-Error ('17897 still has '+$remaining.Count+' listener(s). Inspect their process identity before killing anything else.')
        exit 3
    }
    exit 0
}
catch { Write-Error $_.Exception.Message; exit 4 }
