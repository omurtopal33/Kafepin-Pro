from __future__ import print_function

import json
import base64
import hashlib
import hmac
import ipaddress
import os
import ctypes
from ctypes import wintypes
import re
import shutil
import socket
import subprocess
import threading
import time
import uuid
from datetime import datetime, timezone, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor

VERSION = "4.0.80"
ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web"
DATA = ROOT / "data"
LOGS = ROOT / "logs"
DATA.mkdir(parents=True, exist_ok=True)
LOGS.mkdir(parents=True, exist_ok=True)

CONFIG_FILE = DATA / "merkez-config.json"
CLIENTS_FILE = DATA / "clients.json"
COMMANDS_FILE = DATA / "commands.json"
POOL_CACHE_FILE = DATA / "pool-cache.json"
POOL_EARNINGS_FILE = DATA / "pool-earnings-history.json"
MARKET_CACHE_FILE = DATA / "market-cache.json"
FX_CACHE_FILE = DATA / "fx-cache.json"
TRANSFER_LOG_FILE = DATA / "bigone-transfer-log.json"
FINANCE_LOG_FILE = DATA / "finance-log.json"
SESSION_FILE = DATA / "mining-sessions.json"
HEALTH_FILE = DATA / "mining-health-30d.json"
REST_STATE_FILE = DATA / "mining-rest-state.json"
PROFILE_SCHEDULE_STATE_FILE = DATA / "profile-schedule-state.json"
BIGONE_CRED_FILE = DATA / "bigone-token.dpapi"
LOCAL_THERMAL_LOCK_FILE = DATA / "main-pc-thermal-lock.json"
SRB_CONSOLE_LOG = Path(os.environ.get("ProgramData") or r"C:\ProgramData") / "KafePinPro" / "srbminer-console.log"
SRB_BAT_BACKUP_SUFFIX = ".before-kafepin-cmd-telemetry.bak"
PEARL_OC_FILE = DATA / "pearl-oc-profile.json"
SRB_OC_BAT_BACKUP_SUFFIX = ".before-kafepin-pearl-oc.bak"
PEARL_OC_PRESETS = {
    "RTX 3060": {"cclock": 1500, "coffset": 200, "mclock": 5001, "plimit": 110},
    "RTX 3060 Ti": {"cclock": 1500, "coffset": 200, "mclock": 5001, "plimit": 140},
    "RTX 4060 Ti": {"cclock": 2450, "coffset": 200, "mclock": 5001, "plimit": 120},
}
TAILSCALE_STATE_FILE = DATA / "tailscale-remote.json"
PROGRAM_DATA_ROOT = Path(os.environ.get("ProgramData") or r"C:\ProgramData") / "KafePinPro"
MAIN_PC_START_REQUEST_FILE = PROGRAM_DATA_ROOT / "mainpc-mining-start.request"
MAIN_PC_START_RESULT_FILE = PROGRAM_DATA_ROOT / "mainpc-mining-start.result"
LOG_FILE = LOGS / "mining-pro.log"

DEFAULT_CONFIG = {
    "port": 17897,
    "wallet": "",
    "twoMinersBase": "https://prl.2miners.com/api",
    "coinUnits": 100000000,
    "bigoneTickerUrl": "https://api.big.one/api/v3/asset_pairs/PEARL-USDT/ticker",
    "bigoneTickerFallbackUrl": "https://api.big.one/api/v3/asset_pairs/tickers?pair_names=PEARL-USDT",
    "bigoneDepositAddress": "",
    "bigoneApiBase": "https://api.big.one/api/v3",
    "bigonePair": "PEARL-USDT",
    "binanceUsdtAddress": "",
    "binanceNetworkLabel": "BEP20 (BSC)",
    "binanceGatewayName": "BinanceSmartChain",
    "electricityTryKwh": 5.934056,
    "usdTryFallback": 0,
    "feeRatePrlPerKb": 0.00001,
    "hardStopTempC": 90,
    "warnTempC": 85,
    "resumeTempC": 80,
    "autoOnlyWhenCafeEmpty": False,
    "selectedClientIds": [],
    "includeMainPc": True,
    "mainPcClientId": "ANA-PC",
    "offlineSeconds": 900,
    "runtimeFreshSeconds": 15,
    "bridgeReadySeconds": 20,
    "kafepinMetricsUrl": "http://127.0.0.1:17896/api/metrics",
    "kafepinHardwareUrl": "http://127.0.0.1:17896/hardware.html",
    "kafepinActionUrl": "http://127.0.0.1:17896/api/action",
    "minerStartFile": r"C:\\SRBMiner-Multi-3-7-9-win64\\SRBMiner-Multi-3-7-9\\start-mining-pearl.bat",
    "tailscaleRemoteEnabled": True,
    "tailscaleHttpsPort": 18443,
    "profileScheduleEnabled": False,
    "profileDayStart": "08:00",
    "profileNightStart": "22:00",
    "restScheduleEnabled": True,
    "restStart": "05:00",
    "restDurationMinutes": 120,
}

lock = threading.RLock()
clients = {}
commands = {}
bridges = {}
mem_cache = {}
session_ledger = {}
session_last_save = 0.0
health_ledger = {}
health_last_save = 0.0


def now_iso():
    return datetime.now(timezone.utc).astimezone().isoformat()


def log(message):
    try:
        with LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " " + str(message) + "\n")
    except Exception:
        pass


def read_json(path, fallback):
    try:
        with Path(path).open("r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:
        return fallback


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(str(tmp), str(path))


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    old = read_json(CONFIG_FILE, {})
    if isinstance(old, dict):
        cfg.update(old)
    cfg.pop("apiKey", None)
    cfg.pop("fallbackPrlTry", None)
    cfg.pop("fallbackPrlPerDay", None)
    # v4.0.28: 8787 Windows tarafinda WSAEACCES/WinError 10013 ile rezerve olabiliyor.
    # Eski test ayarini kalici olarak PRO servis araligindaki 17897'ye tasiyoruz.
    try:
        old_port = int(cfg.get("port", 0) or 0)
    except Exception:
        old_port = 0
    if old_port in (0, 8787):
        cfg["port"] = 17897
    cfg["coinUnits"] = 100000000
    selected = cfg.get("selectedClientIds")
    if not isinstance(selected, list):
        selected = []
    clean_selected = []
    seen_selected = set()
    for item in selected:
        cid = str(item or "").strip()
        if cid and cid not in seen_selected:
            seen_selected.add(cid); clean_selected.append(cid)
    cfg["selectedClientIds"] = clean_selected[:500]
    try:
        fixed_w = float(cfg.get("defaultDevicePowerW", 200) or 200)
    except Exception:
        fixed_w = 200.0
    cfg["defaultDevicePowerW"] = min(1000.0, max(1.0, fixed_w))
    if "/PRL-USDT/" in str(cfg.get("bigoneTickerUrl", "")):
        cfg["bigoneTickerUrl"] = DEFAULT_CONFIG["bigoneTickerUrl"]
    try:
        cfg["offlineSeconds"] = min(3600, max(60, int(float(cfg.get("offlineSeconds", 900) or 900))))
    except Exception:
        cfg["offlineSeconds"] = 900
    cfg["runtimeFreshSeconds"] = 15
    cfg["bridgeReadySeconds"] = 20
    # v4.0.51: Tailscale HTTPS asla backend 17897 ile ayni portu kullanmaz.
    try:
        old_ts_https = int(cfg.get("tailscaleHttpsPort", 0) or 0)
    except Exception:
        old_ts_https = 0
    if old_ts_https in (0, 17897):
        cfg["tailscaleHttpsPort"] = 18443
    if not re.match(r"^0x[0-9a-fA-F]{40}$", str(cfg.get("binanceUsdtAddress") or "")):
        cfg["binanceUsdtAddress"] = DEFAULT_CONFIG["binanceUsdtAddress"]
    cfg["binanceNetworkLabel"] = "BEP20 (BSC)"
    cfg["binanceGatewayName"] = "BinanceSmartChain"
    save_json(CONFIG_FILE, cfg)
    return cfg


config = load_config()
clients.update(read_json(CLIENTS_FILE, {}) if isinstance(read_json(CLIENTS_FILE, {}), dict) else {})
commands.update(read_json(COMMANDS_FILE, {}) if isinstance(read_json(COMMANDS_FILE, {}), dict) else {})
session_ledger.update(read_json(SESSION_FILE, {}) if isinstance(read_json(SESSION_FILE, {}), dict) else {})
health_ledger.update(read_json(HEALTH_FILE, {}) if isinstance(read_json(HEALTH_FILE, {}), dict) else {})


def to_num(value, default=0.0):
    try:
        if value is None:
            return default
        if isinstance(value, (int, float)):
            return float(value)
        text = str(value).strip().replace(",", ".")
        m = re.search(r"[-+]?\d+(?:\.\d+)?", text)
        return float(m.group(0)) if m else default
    except Exception:
        return default


def normalize(value):
    return re.sub(r"[^a-z0-9_-]", "", str(value or "").strip().lower())


def parse_iso(value):
    try:
        s = str(value).replace("Z", "+00:00")
        return datetime.fromisoformat(s).timestamp()
    except Exception:
        return 0.0


def fresh(row, seconds=35):
    return bool(row) and (time.time() - parse_iso(row.get("updatedAt"))) < seconds


def row_age(row):
    if not row:
        return 10 ** 9
    ts = parse_iso(row.get("updatedAt"))
    return max(0.0, time.time() - ts) if ts else 10 ** 9


def valid_evm_address(addr):
    return bool(re.match(r"^0x[0-9a-fA-F]{40}$", str(addr or "").strip()))


def mem_cached(name, ttl, loader):
    now = time.time()
    with lock:
        hit = mem_cache.get(name)
        if hit and now - hit[0] < ttl:
            return hit[1]
    data = loader()
    with lock:
        mem_cache[name] = (now, data)
    return data


def find_tailscale_exe():
    candidates = []
    for name in ("tailscale.exe", "tailscale"):
        p = shutil.which(name)
        if p: candidates.append(p)
    for env_name in ("ProgramFiles", "ProgramFiles(x86)"):
        root = os.environ.get(env_name)
        if root:
            candidates.append(os.path.join(root, "Tailscale", "tailscale.exe"))
    for p in candidates:
        if p and os.path.isfile(p): return p
    return None


def _tailscale_live_status():
    exe = find_tailscale_exe()
    if not exe:
        return {"installed": False, "running": False, "serveConfigured": False,
                "error": "Tailscale bulunamadi. Ana KafePin PC'ye Tailscale kurup ayni tailnet'e giris yap."}
    try:
        cp = subprocess.run([exe, "status", "--json"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, timeout=8, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        raw = (cp.stdout or "").strip()
        if cp.returncode != 0:
            return {"installed": True, "running": False, "serveConfigured": False, "exe": exe, "error": raw or "Tailscale status alinamadi."}
        data = json.loads(raw or "{}")
        self_row = data.get("Self") or {}
        state = str(data.get("BackendState") or "")
        dns = str(self_row.get("DNSName") or "").strip().rstrip(".")
        ips = self_row.get("TailscaleIPs") or data.get("TailscaleIPs") or []
        remote_port = int(config.get("tailscaleHttpsPort", 17897) or 17897)
        url = ("https://%s:%d/" % (dns, remote_port)) if dns else ""
        saved = read_json(TAILSCALE_STATE_FILE, {})
        configured = bool(saved.get("ok")) and str(saved.get("remoteUrl") or "") == url
        return {"installed": True, "running": state.lower() == "running", "backendState": state,
                "serveConfigured": configured, "dnsName": dns, "tailscaleIps": ips, "remoteUrl": url,
                "httpsPort": remote_port, "exe": exe, "lastSetup": saved.get("updatedAt"),
                "setupError": saved.get("error")}
    except Exception as exc:
        return {"installed": True, "running": False, "serveConfigured": False, "exe": exe, "error": str(exc)}


def tailscale_remote_state():
    try:
        return mem_cached("tailscale_state", 8, _tailscale_live_status)
    except Exception as exc:
        return {"installed": False, "running": False, "serveConfigured": False, "error": str(exc)}


def ensure_tailscale_serve():
    if not bool(config.get("tailscaleRemoteEnabled", True)):
        row = {"ok": False, "disabled": True, "error": "Tailscale uzaktan erisim ayarlardan kapali.", "updatedAt": now_iso()}
        save_json(TAILSCALE_STATE_FILE, row); return row
    live = _tailscale_live_status()
    exe = live.get("exe")
    if not exe or not live.get("running"):
        row = {"ok": False, "error": live.get("error") or "Tailscale kurulu ama bagli degil.", "updatedAt": now_iso()}
        save_json(TAILSCALE_STATE_FILE, row)
        with lock: mem_cache.pop("tailscale_state", None)
        return row
    dns = str(live.get("dnsName") or "")
    if not dns:
        row = {"ok": False, "error": "Tailscale MagicDNS/DNSName bulunamadi.", "updatedAt": now_iso()}
        save_json(TAILSCALE_STATE_FILE, row)
        with lock: mem_cache.pop("tailscale_state", None)
        return row
    local_port = int(config.get("port", 17897) or 17897)
    https_port = int(config.get("tailscaleHttpsPort", 17897) or 17897)
    target = "http://127.0.0.1:%d" % local_port
    remote_url = "https://%s:%d/" % (dns, https_port)
    args = [exe, "serve", "--bg", "--yes", "--https=%d" % https_port, target]
    try:
        cp = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=25,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        output = (cp.stdout or "").strip()
        ok = cp.returncode == 0
        row = {"ok": ok, "remoteUrl": remote_url, "dnsName": dns, "httpsPort": https_port,
               "target": target, "output": output[-3000:], "updatedAt": now_iso()}
        if not ok:
            row["error"] = output or "tailscale serve basarisiz. Tailnet HTTPS/Serve iznini Tailscale yonetiminden bir kez etkinlestir."
        save_json(TAILSCALE_STATE_FILE, row)
        with lock: mem_cache.pop("tailscale_state", None)
        log("Tailscale Serve %s -> %s rc=%s" % (remote_url, target, cp.returncode))
        return row
    except Exception as exc:
        row = {"ok": False, "remoteUrl": remote_url, "error": str(exc), "updatedAt": now_iso()}
        save_json(TAILSCALE_STATE_FILE, row)
        with lock: mem_cache.pop("tailscale_state", None)
        log("Tailscale Serve setup error: %s" % exc)
        return row


class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _dpapi(data, protect):
    if os.name != "nt":
        raise RuntimeError("BigONE API token sifreleme Windows DPAPI gerektirir.")
    raw = data if isinstance(data, (bytes, bytearray)) else str(data).encode("utf-8")
    buf = ctypes.create_string_buffer(bytes(raw))
    in_blob = DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
    out_blob = DATA_BLOB()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    crypt32.CryptProtectData.restype = wintypes.BOOL
    crypt32.CryptUnprotectData.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    flags = 0x1  # CRYPTPROTECT_UI_FORBIDDEN
    if protect:
        ok = crypt32.CryptProtectData(ctypes.byref(in_blob), None, None, None, None, flags, ctypes.byref(out_blob))
    else:
        ok = crypt32.CryptUnprotectData(ctypes.byref(in_blob), None, None, None, None, flags, ctypes.byref(out_blob))
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        if out_blob.pbData:
            kernel32.LocalFree(out_blob.pbData)


def _b64url(data):
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def save_bigone_credentials(api_key, api_secret):
    api_key = str(api_key or "").strip()
    api_secret = str(api_secret or "").strip()
    if not api_key and not api_secret:
        try:
            BIGONE_CRED_FILE.unlink()
        except Exception:
            pass
        return
    payload = json.dumps({"apiKey": api_key, "apiSecret": api_secret}, ensure_ascii=False).encode("utf-8")
    BIGONE_CRED_FILE.write_bytes(_dpapi(payload, True))


def save_bigone_token(token):
    token = str(token or "").strip()
    if not token:
        save_bigone_credentials("", "")
        return
    BIGONE_CRED_FILE.write_bytes(_dpapi(token.encode("utf-8"), True))


def load_bigone_credentials():
    api_key = str(os.environ.get("KAFEPIN_BIGONE_API_KEY") or "").strip()
    api_secret = str(os.environ.get("KAFEPIN_BIGONE_API_SECRET") or "").strip()
    if api_key and api_secret:
        return {"apiKey": api_key, "apiSecret": api_secret}
    if not BIGONE_CRED_FILE.is_file():
        return {}
    try:
        raw = _dpapi(BIGONE_CRED_FILE.read_bytes(), False).decode("utf-8").strip()
        if raw.startswith("{"):
            row = json.loads(raw)
            if str(row.get("apiKey") or "").strip() and str(row.get("apiSecret") or "").strip():
                return {"apiKey": str(row.get("apiKey")).strip(), "apiSecret": str(row.get("apiSecret")).strip()}
    except Exception:
        pass
    return {}


def load_bigone_token():
    env = str(os.environ.get("KAFEPIN_BIGONE_TOKEN") or "").strip()
    if env:
        return env
    creds = load_bigone_credentials()
    if creds:
        header = _b64url(json.dumps({"alg":"HS256","typ":"JWT"}, separators=(",", ":")).encode("utf-8"))
        payload = _b64url(json.dumps({"type":"OpenAPIV2","sub":creds["apiKey"],"nonce":str(time.time_ns())}, separators=(",", ":")).encode("utf-8"))
        signing = (header + "." + payload).encode("ascii")
        signature = _b64url(hmac.new(creds["apiSecret"].encode("utf-8"), signing, hashlib.sha256).digest())
        return header + "." + payload + "." + signature
    if not BIGONE_CRED_FILE.is_file():
        return ""
    try:
        return _dpapi(BIGONE_CRED_FILE.read_bytes(), False).decode("utf-8").strip()
    except Exception:
        return ""


def bigone_auth_json(path, timeout=8, method="GET", body=None):
    token = load_bigone_token()
    if not token:
        raise RuntimeError("BigONE API token tanimli degil.")
    base = str(config.get("bigoneApiBase") or "https://api.big.one/api/v3").rstrip("/")
    data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
    headers = {"Accept": "application/json", "User-Agent": "KafePin-MiningPro/%s" % VERSION,
               "Authorization": "Bearer " + token}
    if data is not None:
        headers["Content-Type"] = "application/json"
    req = Request(base + path, data=data, headers=headers, method=method)
    try:
        with urlopen(req, timeout=timeout) as res:
            raw = res.read().decode("utf-8-sig")
            return json.loads(raw or "{}")
    except HTTPError as exc:
        try:
            detail = exc.read().decode("utf-8-sig")
        except Exception:
            detail = str(exc)
        raise RuntimeError("BigONE API %s: %s" % (exc.code, detail[:600]))


def http_json(url, timeout=8, method="GET", body=None):
    data = None
    headers = {"Accept": "application/json", "User-Agent": "KafePin-MiningPro/%s" % VERSION}
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = Request(url, data=data, headers=headers, method=method)
    with urlopen(req, timeout=timeout) as res:
        raw = res.read().decode("utf-8-sig")
        return json.loads(raw or "{}")



def http_text(url, timeout=5):
    req = Request(url, headers={
        "Accept": "text/html,application/javascript,*/*",
        "User-Agent": "KafePin-MiningPro/%s" % VERSION
    })
    with urlopen(req, timeout=timeout) as res:
        raw = res.read()
        ctype = str(res.headers.get("Content-Type") or "").lower()
        enc = "utf-8"
        if "charset=" in ctype:
            enc = ctype.split("charset=", 1)[1].split(";", 1)[0].strip() or "utf-8"
        try:
            return raw.decode(enc, errors="replace")
        except Exception:
            return raw.decode("utf-8", errors="replace")


def _hardware_candidate_urls():
    base = "http://127.0.0.1:17896"
    fixed = [
        "/api/hardware", "/api/hardware/clients", "/api/clients/hardware",
        "/api/client-hardware", "/api/devices", "/api/clients",
        "/api/systems", "/api/system", "/api/metrics"
    ]
    found = []
    html_text = ""
    try:
        html_text = http_text(
            str(config.get("kafepinHardwareUrl") or (base + "/hardware.html")),
            timeout=2.5
        )
        for path in re.findall(r'["\'](/api/[A-Za-z0-9_./?=&%:-]+)["\']', html_text, re.I):
            if path not in found:
                found.append(path)
    except Exception:
        pass

    def priority(path):
        low = path.lower()
        score = 0
        if "hardware" in low: score -= 50
        if "gpu" in low or "device" in low: score -= 30
        if "client" in low or "machine" in low or "system" in low: score -= 10
        if "action" in low or "command" in low or "wake" in low: score += 100
        return (score, len(path))

    paths = []
    for p in sorted(found + fixed, key=priority):
        if p not in paths and not any(x in p.lower() for x in ("action","command","wake","stop","start")):
            paths.append(p)
    return base, paths[:30], html_text


def _walk_dicts(value, out, depth=0):
    if depth > 8 or value is None:
        return
    if isinstance(value, dict):
        out.append(value)
        for item in value.values():
            _walk_dicts(item, out, depth + 1)
    elif isinstance(value, list):
        for item in value:
            _walk_dicts(item, out, depth + 1)


def _identity_values(row):
    if not isinstance(row, dict):
        return []
    vals = []
    for key in (
        "ip","ipAddress","ip_address","address","clientIp","client_ip",
        "name","clientName","client_name","masa","pc","host","hostname",
        "computerName","computer_name","machine","machineName","deviceName"
    ):
        v = row.get(key)
        if isinstance(v, (str, int, float)) and str(v).strip():
            vals.append(str(v).strip())
    return vals


def _hardware_match_score(row, remote_ip, host, reported):
    ids = _identity_values(row)
    if not ids:
        return -1
    nip = str(remote_ip or "").strip().lower()
    nh = normalize(host)
    nr = normalize(reported)
    score = 0
    matched = False
    for value in ids:
        low = value.lower()
        nv = normalize(value)
        if nip and low == nip:
            score = max(score, 100); matched = True
        if nh and nv == nh:
            score = max(score, 80); matched = True
        if nr and nv == nr:
            score = max(score, 75); matched = True
    return score if matched else -1


def _deep_gpu_models(value, out, depth=0):
    if depth > 9 or value is None:
        return
    if isinstance(value, str):
        model = _gpu_model_candidate(value)
        if model:
            out.append(model)
        return
    if isinstance(value, dict):
        for item in value.values():
            _deep_gpu_models(item, out, depth + 1)
    elif isinstance(value, list):
        for item in value:
            _deep_gpu_models(item, out, depth + 1)


def _html_gpu_models_near_identity(html_text, remote_ip, host, reported):
    if not html_text:
        return []
    needles = [str(remote_ip or "").strip(), str(host or "").strip(), str(reported or "").strip()]
    positions = []
    low_html = html_text.lower()
    for needle in needles:
        if not needle:
            continue
        start = 0
        low = needle.lower()
        while True:
            idx = low_html.find(low, start)
            if idx < 0:
                break
            positions.append(idx)
            start = idx + max(1, len(low))
            if len(positions) >= 12:
                break
    vals = []
    for pos in positions:
        chunk = html_text[max(0, pos-2200):min(len(html_text), pos+2200)]
        plain = re.sub(r"<[^>]+>", " ", chunk)
        for m in _GPU_MODEL_HINT.finditer(plain):
            vals.append(re.sub(r"\s+", " ", m.group(0)).strip())
    clean, seen = [], set()
    for v in vals:
        lk = v.lower()
        if lk not in seen:
            seen.add(lk)
            clean.append(v)
    return clean


def get_kafepin_hardware():
    def load():
        base, paths, page_html = _hardware_candidate_urls()
        rows, ok_urls = [], []
        last_error = ""
        for path in paths:
            try:
                data = http_json(base + path, timeout=1.8)
                found = []
                _walk_dicts(data, found)
                if found:
                    rows.extend(found)
                    ok_urls.append(path)
            except Exception as exc:
                last_error = str(exc)
        return {
            "ok": bool(rows or page_html),
            "rows": rows,
            "html": page_html,
            "apiPaths": ok_urls,
            "error": last_error
        }
    return mem_cached("kafepin_hardware", 8, load)


def find_hardware_gpu_models(hardware, remote_ip, host, reported):
    if not isinstance(hardware, dict):
        return []
    best, best_score = [], -1
    for row in hardware.get("rows") or []:
        score = _hardware_match_score(row, remote_ip, host, reported)
        if score < 0:
            continue
        vals = []
        _deep_gpu_models(row, vals, 0)
        clean, seen = [], set()
        for value in vals:
            value = re.sub(r"\s+", " ", str(value or "")).strip()
            if value and value.lower() not in seen:
                seen.add(value.lower())
                clean.append(value)
        if clean and score > best_score:
            best, best_score = clean, score
    if best:
        return best
    return _html_gpu_models_near_identity(
        str(hardware.get("html") or ""),
        remote_ip, host, reported
    )


def get_client_perf():
    try:
        d = http_json(str(config["kafepinMetricsUrl"]), timeout=3)
        return {"ok": True, "clients": list(d.get("clients") or []), "updatedAt": d.get("updatedAt")}
    except Exception as exc:
        return {"ok": False, "clients": [], "error": str(exc)}


def find_perf_match(perf, remote_ip, host, reported):
    rows = perf.get("clients") or []
    for row in rows:
        if remote_ip and str(row.get("ip") or "").strip() == remote_ip:
            return row
    nh, nr = normalize(host), normalize(reported)
    for row in rows:
        if nh and normalize(row.get("name")) == nh:
            return row
    for row in rows:
        if nr and normalize(row.get("name")) == nr:
            return row
    return None


def find_bridge(name, ip):
    with lock:
        for key, row in bridges.items():
            if ip and str(row.get("ip") or "").strip() == ip:
                return row
            if normalize(key) == normalize(name):
                return row
    return None


def parse_srb_payload(raw):
    result = {"hashrateHps": 0.0, "totalPowerW": 0.0, "maxTempC": 0.0,
              "acceptedShares": 0.0, "rejectedShares": 0.0, "gpus": []}
    if not isinstance(raw, dict):
        return result
    devices = raw.get("gpu_devices") or raw.get("gpus") or []
    if isinstance(devices, dict):
        devices = list(devices.values())
    result["gpus"] = devices if isinstance(devices, list) else []
    for dev in result["gpus"]:
        if not isinstance(dev, dict): continue
        result["totalPowerW"] += max(0.0, to_num(dev.get("asic_power") or dev.get("power") or dev.get("watts")))
        t = to_num(dev.get("temperature") or dev.get("temp"))
        if 0 < t < 150: result["maxTempC"] = max(result["maxTempC"], t)
    algos = raw.get("algorithms") or []
    if isinstance(algos, dict): algos = list(algos.values())
    algo = None
    for item in algos if isinstance(algos, list) else []:
        if isinstance(item, dict) and re.search(r"pearl|prl", str(item.get("name") or ""), re.I):
            algo = item; break
    if algo is None and isinstance(algos, list) and algos:
        algo = algos[0] if isinstance(algos[0], dict) else None
    if algo:
        hr = algo.get("hashrate") or {}
        gpu = hr.get("gpu") if isinstance(hr, dict) else None
        if isinstance(gpu, dict): result["hashrateHps"] = to_num(gpu.get("total") or gpu.get("hashrate"))
        if result["hashrateHps"] <= 0 and isinstance(hr, dict): result["hashrateHps"] = to_num(hr.get("1min") or hr.get("total") or hr.get("current"))
        shares = algo.get("shares") or {}
        if isinstance(shares, dict):
            result["acceptedShares"] = to_num(shares.get("accepted") or shares.get("valid"))
            result["rejectedShares"] = to_num(shares.get("rejected") or shares.get("invalid"))
    return result


def local_miner_running():
    if os.name != "nt":
        return False
    try:
        cp = subprocess.run(["tasklist", "/FI", "IMAGENAME eq SRBMiner-MULTI.exe", "/NH"],
                            capture_output=True, text=True, timeout=2,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return "SRBMiner-MULTI.exe" in (cp.stdout or "")
    except Exception:
        return False


def _nvidia_smi_exe():
    return shutil.which("nvidia-smi.exe") or shutil.which("nvidia-smi")


def local_nvidia_power_state():
    if os.name != "nt":
        return {"supported": False, "reason": "Windows/NVIDIA gerekli", "gpus": []}
    exe = _nvidia_smi_exe()
    if not exe:
        return {"supported": False, "reason": "nvidia-smi bulunamadi", "gpus": []}
    fields = "index,name,power.draw,power.limit,power.default_limit,power.min_limit,power.max_limit"
    try:
        cp = subprocess.run([exe, "--query-gpu=" + fields, "--format=csv,noheader,nounits"],
                            capture_output=True, text=True, timeout=4,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if cp.returncode != 0:
            return {"supported": False, "reason": (cp.stdout or cp.stderr or "nvidia-smi query basarisiz").strip(),
                    "gpus": [], "exe": exe}
        gpus=[]
        for raw in (cp.stdout or "").splitlines():
            parts=[x.strip() for x in raw.split(",")]
            if len(parts)<7: continue
            def val(i):
                t=parts[i] if i<len(parts) else ""
                return to_num(t) if t and t.upper() not in ("N/A","[N/A]") else 0.0
            gpus.append({"index":int(to_num(parts[0],len(gpus))),"name":parts[1],
                         "powerDrawW":val(2),"powerLimitW":val(3),"defaultLimitW":val(4),
                         "minLimitW":val(5),"maxLimitW":val(6)})
        supported=bool(gpus) and all(to_num(x.get("maxLimitW"))>0 for x in gpus)
        return {"supported":supported,"gpus":gpus,"exe":exe,
                "totalPowerDrawW":sum(max(0.0,to_num(x.get("powerDrawW"))) for x in gpus),
                "updatedAt":now_iso(),"reason":"" if supported else "GPU power-limit bilgisi okunamadi"}
    except Exception as exc:
        return {"supported":False,"reason":str(exc),"gpus":[],"exe":exe}


def cached_local_nvidia_power_state():
    return mem_cached("local_nvidia_power", 3, local_nvidia_power_state)


def set_local_nvidia_power_limit(watts=None, reset=False):
    if os.name != "nt":
        return {"ok":False,"error":"ANA-PC watt limiti yalniz Windows/NVIDIA'da kullanilir."}
    state=local_nvidia_power_state()
    if not state.get("supported") or not state.get("gpus"):
        return {"ok":False,"error":state.get("reason") or "NVIDIA power-limit desteklenmiyor.","state":state}
    exe=state.get("exe") or _nvidia_smi_exe()
    results=[]
    for gpu in state["gpus"]:
        target=to_num(gpu.get("defaultLimitW")) if reset else to_num(watts)
        min_w=to_num(gpu.get("minLimitW")); max_w=to_num(gpu.get("maxLimitW"))
        if target<=0: return {"ok":False,"error":"Gecerli watt limiti gir."}
        if min_w>0 and target<min_w: return {"ok":False,"error":"GPU %s minimum %.0f W."%(gpu.get("index"),min_w)}
        if max_w>0 and target>max_w: return {"ok":False,"error":"GPU %s maksimum %.0f W."%(gpu.get("index"),max_w)}
        cp=subprocess.run([exe,"-i",str(gpu.get("index")),"-pl","%.0f"%target],
                          capture_output=True,text=True,timeout=8,
                          creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        msg=(cp.stdout or cp.stderr or "").strip()
        results.append({"gpu":gpu.get("index"),"targetW":target,"ok":cp.returncode==0,"output":msg})
        if cp.returncode!=0:
            return {"ok":False,"error":msg or "nvidia-smi power limit uygulanamadi.","results":results}
    with lock: mem_cache.pop("local_nvidia_power",None)
    time.sleep(0.25)
    return {"ok":True,"reset":bool(reset),"results":results,"state":local_nvidia_power_state()}


def _read_text_flexible(path):
    data = Path(path).read_bytes()
    for enc in ("utf-8-sig", "utf-8", "cp1254", "cp1252"):
        try:
            return data.decode(enc), enc
        except Exception:
            continue
    return data.decode("latin-1", errors="replace"), "latin-1"


def ensure_local_miner_cmd_logging():
    bat = Path(str(config.get("minerStartFile") or ""))
    if not bat.is_file():
        return {"ok": False, "error": "Miner BAT bulunamadi: " + str(bat)}
    try:
        text, enc = _read_text_flexible(bat)
        if "--log-file" in text.lower() and "srbminer-console.log" in text.lower():
            return {"ok": True, "changed": False, "bat": str(bat), "logFile": str(SRB_CONSOLE_LOG)}
        lines = text.splitlines(True)
        changed = False
        for i, line in enumerate(lines):
            low = line.lower()
            stripped = line.lstrip()
            if stripped.lower().startswith(("rem ", "::")):
                continue
            if "srbminer-multi.exe" not in low:
                continue
            newline = "\r\n" if line.endswith("\r\n") else ("\n" if line.endswith("\n") else "")
            body = line[:-len(newline)] if newline else line
            trail = ""
            if body.rstrip().endswith("^"):
                body2 = body.rstrip()
                trail = " ^"
                body = body2[:-1].rstrip()
            body += ' --log-file "' + str(SRB_CONSOLE_LOG) + '" --log-file-mode 0 --extended-log'
            lines[i] = body + trail + newline
            changed = True
            break
        if not changed:
            return {"ok": False, "error": "BAT icinde SRBMiner-MULTI.exe komutu bulunamadi.", "bat": str(bat)}

        backup = Path(str(bat) + SRB_BAT_BACKUP_SUFFIX)
        if not backup.exists():
            shutil.copy2(str(bat), str(backup))

        out_text = "".join(lines)
        if enc == "utf-8-sig":
            bat.write_text(out_text, encoding="utf-8-sig")
        else:
            bat.write_bytes(out_text.encode(enc, errors="replace"))
        return {"ok": True, "changed": True, "bat": str(bat), "logFile": str(SRB_CONSOLE_LOG), "backup": str(backup)}
    except Exception as exc:
        return {"ok": False, "error": "BAT log parametresi eklenemedi: " + str(exc), "bat": str(bat)}


_HASH_UNITS = {"H/S":1.0,"KH/S":1e3,"MH/S":1e6,"GH/S":1e9,"TH/S":1e12,"PH/S":1e15,"EH/S":1e18}


def _strip_ansi(value):
    return re.sub(r"\x1b\[[0-9;?]*[ -/]*[@-~]", "", str(value or ""))


def parse_srb_console_log():
    try:
        if not SRB_CONSOLE_LOG.is_file():
            return {"ok": False, "error": "SRBMiner CMD log henuz yok.", "logFile": str(SRB_CONSOLE_LOG)}
        raw = SRB_CONSOLE_LOG.read_bytes()[-1024 * 1024:]
        if raw.startswith(b"\xff\xfe"):
            text = raw.decode("utf-16-le", errors="replace")
        elif raw.startswith(b"\xfe\xff"):
            text = raw.decode("utf-16-be", errors="replace")
        elif raw.startswith(b"\xef\xbb\xbf"):
            text = raw.decode("utf-8-sig", errors="replace")
        elif raw[1:4096:2].count(0) > 100:
            text = raw.decode("utf-16-le", errors="replace")
        else:
            try:
                text = raw.decode("utf-8")
            except Exception:
                text = raw.decode("cp1254", errors="replace")
        text = _strip_ansi(text).replace("\x00", "").replace("\r", "")
        idx = text.rfind("SRBMiner-MULTI")
        block = text[max(0, idx - 160):] if idx >= 0 else text
        gpu_re = re.compile(
            r"#(?P<id>\d+)\s+(?P<name>.*?)\s+"
            r"(?P<hash>[0-9.]+)\s+(?P<unit>[KMGTPE]?H/s)\s+"
            r"(?P<power>[0-9.]+)W\s+(?P<eff>[0-9.]+)\s+"
            r"(?P<fan>[0-9.]+)%\s+(?P<temp>[0-9.]+)C\s+"
            r"(?P<cclk>[0-9.]+)\s+(?P<mclk>[0-9.]+)\s+"
            r"(?P<a>\d+)\s+(?P<r>\d+)\s+(?P<hw>\d+)", re.I)
        gpus = []
        for line in block.splitlines():
            m = gpu_re.search(line)
            if not m:
                continue
            unit = m.group("unit").upper()
            gpus.append({
                "id": int(m.group("id")),
                "name": m.group("name").strip(),
                "hashrateHps": float(m.group("hash")) * _HASH_UNITS.get(unit, 1.0),
                "hashrateText": m.group("hash") + " " + m.group("unit"),
                "powerW": float(m.group("power")),
                "efficiency": float(m.group("eff")),
                "fanPct": float(m.group("fan")),
                "temperatureC": float(m.group("temp")),
                "coreClockMhz": float(m.group("cclk")),
                "memoryClockMhz": float(m.group("mclk")),
                "acceptedShares": int(m.group("a")),
                "rejectedShares": int(m.group("r")),
                "hwErrors": int(m.group("hw")),
            })
        if not gpus:
            return {"ok": False, "error": "Son SRBMiner Statistics blogunda GPU satiri bulunamadi.", "logFile": str(SRB_CONSOLE_LOG)}
        mtime = SRB_CONSOLE_LOG.stat().st_mtime
        return {
            "ok": True, "source": "SRBMiner Statistics LOG", "logFile": str(SRB_CONSOLE_LOG),
            "ageSec": round(max(0.0, time.time() - mtime), 1),
            "updatedAt": datetime.fromtimestamp(mtime, timezone.utc).astimezone().isoformat(),
            "gpus": gpus,
            "hashrateHps": sum(x["hashrateHps"] for x in gpus),
            "totalPowerW": sum(x["powerW"] for x in gpus),
            "maxTempC": max(x["temperatureC"] for x in gpus),
            "acceptedShares": sum(x["acceptedShares"] for x in gpus),
            "rejectedShares": sum(x["rejectedShares"] for x in gpus),
        }
    except Exception as exc:
        return {"ok": False, "error": "SRBMiner CMD log parse hatasi: " + str(exc), "logFile": str(SRB_CONSOLE_LOG)}


def _cmd_log_fresh(row, max_age=45):
    return bool(row and row.get("ok") and to_num(row.get("ageSec"), 999999) <= max_age)


def restart_local_miner_for_cmd_logging():
    launched = _desktop_double_click_main_miner("prepare-restart")
    if not launched.get("ok"): return launched
    deadline = time.time() + 20
    last = {}
    while time.time() < deadline:
        last = parse_srb_console_log()
        if _cmd_log_fresh(last, 20):
            return {"ok": True, "message": "SRBMiner CMD LOG aktif.", "telemetry": last}
        time.sleep(.25)
    return {"ok": False, "error": "Yonetici restart tamamlandi ama CMD log okunamadi.", "telemetry": last}

def local_gpu_inventory():
    power = local_nvidia_power_state()
    return [{
        "index": int(to_num(g.get("index"), i)),
        "name": str(g.get("name") or "NVIDIA GPU"),
        "minPowerW": to_num(g.get("minLimitW")),
        "maxPowerW": to_num(g.get("maxLimitW")),
        "defaultPowerW": to_num(g.get("defaultLimitW")),
        "currentPowerLimitW": to_num(g.get("powerLimitW")),
    } for i, g in enumerate(power.get("gpus") or [])]

def _preset_for_gpu_name(name):
    n = str(name or "").upper()
    if "4060 TI" in n: return dict(PEARL_OC_PRESETS["RTX 4060 Ti"])
    if "3060 TI" in n: return dict(PEARL_OC_PRESETS["RTX 3060 Ti"])
    if re.search(r"\b3060\b", n): return dict(PEARL_OC_PRESETS["RTX 3060"])
    return {}

def _parse_bat_oc_values():
    bat = Path(str(config.get("minerStartFile") or ""))
    if not bat.is_file(): return {}
    try:
        text, _ = _read_text_flexible(bat)
        cmd = next((x for x in text.splitlines()
                    if "srbminer-multi.exe" in x.lower()
                    and not x.lstrip().lower().startswith(("rem ", "::"))), "")
        out = {}
        for key in ("gpu-id","gpu-cclock0","gpu-coffset0","gpu-mclock0","gpu-plimit0"):
            m = re.search(r"(?:^|\s)--"+re.escape(key)+r"\s+(\"[^\"]*\"|\S+)", cmd, re.I)
            if m: out[key] = m.group(1).strip('"')
        return out
    except Exception:
        return {}

def local_bat_oc_state():
    vals = _parse_bat_oc_values()
    def first_num(key):
        raw = str(vals.get(key) or "")
        token = raw.split(",")[0].strip() if raw else ""
        return int(to_num(token, 0))
    state = {
        "verified": False,
        "gpuIds": str(vals.get("gpu-id") or ""),
        "cclock": first_num("gpu-cclock0"),
        "coffset": first_num("gpu-coffset0"),
        "mclock": first_num("gpu-mclock0"),
        "plimit": first_num("gpu-plimit0"),
        "source": "BAT"
    }
    state["verified"] = bool(state["gpuIds"] and state["cclock"] > 0 and state["mclock"] > 0 and state["plimit"] > 0)
    return state

def local_pearl_oc_state():
    gpus = local_gpu_inventory()
    saved = read_json(PEARL_OC_FILE, {})
    profiles = saved.get("profiles") if isinstance(saved, dict) else None
    if not isinstance(profiles, list) or not profiles:
        profiles = []
        for g in gpus:
            p = _preset_for_gpu_name(g.get("name"))
            profiles.append({
                "gpuId": g["index"], "name": g.get("name"),
                "cclock": int(to_num(p.get("cclock"), 0)),
                "coffset": int(to_num(p.get("coffset"), 0)),
                "mclock": int(to_num(p.get("mclock"), 0)),
                "plimit": int(to_num(p.get("plimit"), 0)),
                "preset": "auto" if p else "manual",
            })
    return {
        "supported": bool(gpus), "gpus": gpus, "profiles": profiles,
        "presets": PEARL_OC_PRESETS, "batValues": _parse_bat_oc_values(),
        "bat": str(config.get("minerStartFile") or ""),
        "requiresAdmin": True, "updatedAt": now_iso(),
    }

_OC_FLAGS_RE = re.compile(
    r"\s+--(?:gpu-id|gpu-cclock0|gpu-coffset0|gpu-mclock0|gpu-plimit0)\s+(?:\"[^\"]*\"|\S+)", re.I
)

def _validate_oc_profiles(profiles):
    if not isinstance(profiles, list) or not profiles:
        raise ValueError("En az bir GPU OC profili gerekli.")
    inv = {int(x["index"]): x for x in local_gpu_inventory()}
    clean, seen = [], set()
    for row in profiles:
        gid = int(to_num(row.get("gpuId"), -1))
        if gid < 0 or gid in seen: raise ValueError("GPU ID gecersiz/tekrar: %s" % gid)
        seen.add(gid)
        cc, co, mc, pw = [int(to_num(row.get(k), 0)) for k in ("cclock","coffset","mclock","plimit")]
        if not 300 <= cc <= 3500: raise ValueError("GPU %d Core Lock 300-3500 MHz olmali." % gid)
        if not -1000 <= co <= 1000: raise ValueError("GPU %d Core Offset -1000..1000 olmali." % gid)
        if not 300 <= mc <= 15000: raise ValueError("GPU %d Mem Lock 300-15000 MHz olmali." % gid)
        if not 25 <= pw <= 600: raise ValueError("GPU %d Power Limit 25-600W olmali." % gid)
        gi = inv.get(gid)
        if gi:
            mn, mx = to_num(gi.get("minPowerW")), to_num(gi.get("maxPowerW"))
            if mn > 0 and pw < mn: raise ValueError("GPU %d minimum %.0fW." % (gid, mn))
            if mx > 0 and pw > mx: raise ValueError("GPU %d maksimum %.0fW." % (gid, mx))
        clean.append({"gpuId":gid,"name":str(row.get("name") or (gi or {}).get("name") or ("GPU "+str(gid))),
                      "cclock":cc,"coffset":co,"mclock":mc,"plimit":pw})
    clean.sort(key=lambda x:x["gpuId"])
    return clean

def patch_local_miner_pearl_oc(profiles, remove=False):
    bat = Path(str(config.get("minerStartFile") or ""))
    if not bat.is_file(): return {"ok":False,"error":"Miner BAT bulunamadi: "+str(bat)}
    try:
        clean = [] if remove else _validate_oc_profiles(profiles)
        text, enc = _read_text_flexible(bat)
        lines = text.splitlines(True)
        found = False
        for i,line in enumerate(lines):
            if line.lstrip().lower().startswith(("rem ","::")) or "srbminer-multi.exe" not in line.lower():
                continue
            found = True
            nl = "\r\n" if line.endswith("\r\n") else ("\n" if line.endswith("\n") else "")
            body = line[:-len(nl)] if nl else line
            trail = ""
            if body.rstrip().endswith("^"):
                b2 = body.rstrip(); trail = " ^"; body = b2[:-1].rstrip()
            body = _OC_FLAGS_RE.sub("", body).rstrip()
            if not remove:
                body += (
                    " --gpu-id " + ",".join(str(x["gpuId"]) for x in clean) +
                    " --gpu-cclock0 " + ",".join(str(x["cclock"]) for x in clean) +
                    " --gpu-coffset0 " + ",".join(str(x["coffset"]) for x in clean) +
                    " --gpu-mclock0 " + ",".join(str(x["mclock"]) for x in clean) +
                    " --gpu-plimit0 " + ",".join(str(x["plimit"]) for x in clean)
                )
            lines[i] = body + trail + nl
            break
        if not found: return {"ok":False,"error":"BAT icinde SRBMiner-MULTI.exe bulunamadi."}

        backup = Path(str(bat) + SRB_OC_BAT_BACKUP_SUFFIX)
        if not backup.exists(): shutil.copy2(str(bat), str(backup))
        out_text = "".join(lines)
        bat.write_text(out_text, encoding="utf-8-sig" if enc=="utf-8-sig" else enc, errors="replace")
        save_json(PEARL_OC_FILE, {"profiles":[] if remove else clean, "savedAt":now_iso()})
        return {"ok":True,"removed":bool(remove),"bat":str(bat),"backup":str(backup),
                "profiles":clean,"batValues":_parse_bat_oc_values()}
    except Exception as exc:
        return {"ok":False,"error":str(exc)}

def apply_local_pearl_oc(profiles, restart=True, remove=False):
    try:
        clean = [] if remove else _validate_oc_profiles(profiles)
        save_json(PEARL_OC_FILE, {"profiles": clean, "savedAt": now_iso(), "removed": bool(remove)})
        result = _desktop_double_click_main_miner("prepare-restart" if restart else "prepare-only")
        if not result.get("ok"): return result
        return {"ok": True, "profiles": clean, "removed": bool(remove), "restarted": bool(restart),
                "message": "Pearl OC uygulandi." if restart else "Pearl OC BAT'e kaydedildi."}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

def local_gpu_temp_fallback():
    if os.name != "nt": return 0.0
    exe = shutil.which("nvidia-smi.exe") or shutil.which("nvidia-smi")
    if not exe: return 0.0
    try:
        cp = subprocess.run([exe, "--query-gpu=temperature.gpu", "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=3,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        vals = [to_num(x) for x in (cp.stdout or "").splitlines() if to_num(x) > 0]
        return max(vals) if vals else 0.0
    except Exception:
        return 0.0


def _local_stop_miner():
    if os.name != "nt": return
    try:
        subprocess.run(["taskkill", "/IM", "SRBMiner-MULTI.exe", "/F"], capture_output=True, text=True, timeout=4,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:
        pass
    try:
        ps = ("Get-CimInstance Win32_Process -Filter \"Name='cmd.exe'\" | "
              "Where-Object { ([string]$_.CommandLine) -match 'start-mining-pearl\\.bat|SRBMiner-MULTI\\.exe' } | "
              "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }")
        subprocess.run(["powershell.exe", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=6,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:
        pass


def local_srb_api_telemetry():
    try:
        raw = http_json("http://127.0.0.1:21550", timeout=0.9)
        d = parse_srb_payload(raw)
        d["minerOnline"] = True
        d["updatedAt"] = now_iso()
        d["telemetrySource"] = "SRBMiner JSON API"
        if (to_num(d.get("hashrateHps")) <= 0 and
                to_num(d.get("totalPowerW")) <= 0 and
                to_num(d.get("maxTempC")) <= 0 and
                not d.get("gpus")):
            raise RuntimeError("SRBMiner JSON API telemetri alanlari bos")
        return {"ok": True, "data": d}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def local_srb_telemetry():
    if not local_miner_running():
        temp = local_gpu_temp_fallback()
        if LOCAL_THERMAL_LOCK_FILE.is_file() and 0 < temp < to_num(config.get("resumeTempC"), 80):
            try:
                LOCAL_THERMAL_LOCK_FILE.unlink()
            except Exception:
                pass
        return {
            "minerOnline": False,
            "hashrateHps": 0,
            "totalPowerW": 0,
            "maxTempC": 0,
            "acceptedShares": 0,
            "rejectedShares": 0,
            "gpus": [],
            "updatedAt": now_iso(),
            "thermalStop": LOCAL_THERMAL_LOCK_FILE.is_file(),
            "telemetrySource": "SRBMiner"
        }

    api = local_srb_api_telemetry()
    if api.get("ok"):
        d = dict(api.get("data") or {})
    else:
        log_row = parse_srb_console_log()
        if _cmd_log_fresh(log_row, 45):
            d = {
                "minerOnline": True,
                "hashrateHps": to_num(log_row.get("hashrateHps")),
                "totalPowerW": to_num(log_row.get("totalPowerW")),
                "maxTempC": to_num(log_row.get("maxTempC")),
                "acceptedShares": to_num(log_row.get("acceptedShares")),
                "rejectedShares": to_num(log_row.get("rejectedShares")),
                "gpus": list(log_row.get("gpus") or []),
                "updatedAt": log_row.get("updatedAt") or now_iso(),
                "telemetrySource": "SRBMiner Statistics LOG",
                "telemetryAgeSec": log_row.get("ageSec"),
                "cmdLogFile": log_row.get("logFile"),
            }
        else:
            d = {
                "minerOnline": True,
                "hashrateHps": 0,
                "totalPowerW": 0,
                "maxTempC": 0,
                "acceptedShares": 0,
                "rejectedShares": 0,
                "gpus": [],
                "updatedAt": now_iso(),
                "telemetrySource": "SRBMiner",
                "error": "SRBMiner JSON API: %s; Statistics LOG: %s" % (
                    api.get("error"),
                    log_row.get("error")
                )
            }

    temp = to_num(d.get("maxTempC"))
    if temp >= to_num(config.get("hardStopTempC"), 90):
        save_json(
            LOCAL_THERMAL_LOCK_FILE,
            {"lockedAt": now_iso(), "tempC": temp, "reason": "Ana PC >= hard stop"}
        )
        _local_stop_miner()
        d["minerOnline"] = False
        d["hashrateHps"] = 0
        d["totalPowerW"] = 0
        d["thermalStop"] = True
        d["error"] = "Ana PC termal koruma: %.0fC, miner durduruldu." % temp
    else:
        d["thermalStop"] = LOCAL_THERMAL_LOCK_FILE.is_file()

    return d

def _delayed_main_monitor_off():
    if os.name != "nt": return
    for _ in range(30):
        time.sleep(0.25)
        if local_miner_running():
            time.sleep(1.0)
            try: ctypes.windll.user32.SendMessageW(0xFFFF, 0x0112, 0xF170, 2)
            except Exception: pass
            return

def _shell_open_bat_like_double_click(bat_path):
    """Open BAT exactly like Explorer/Open with the BAT directory as working directory."""
    if os.name != "nt":
        return {"ok": False, "error": "ShellExecute yalniz Windows'ta kullanilir."}
    bat = os.path.abspath(str(bat_path or ""))
    if not os.path.isfile(bat):
        return {"ok": False, "error": "Miner BAT bulunamadi: " + bat}
    workdir = os.path.dirname(bat)
    try:
        # ShellExecuteW > 32 means success. This preserves .bat file association
        # and uses its own folder as cwd, matching the user's double-click requirement.
        result = ctypes.windll.shell32.ShellExecuteW(None, "open", bat, None, workdir, 1)
        code = int(result)
        if code <= 32:
            errors = {
                0: "Isletim sistemi kaynak yetersizligi",
                2: "Dosya bulunamadi",
                3: "Yol bulunamadi",
                5: "Erisim reddedildi",
                8: "Yetersiz bellek",
                26: "Paylasim ihlali",
                27: "Dosya iliskilendirmesi eksik",
                28: "DDE zaman asimi",
                29: "DDE islemi basarisiz",
                30: "DDE mesgul",
                31: "Dosya iliskilendirmesi yok",
                32: "DLL bulunamadi",
            }
            return {"ok": False, "error": "ShellExecute BAT acamadi (%d): %s" % (code, errors.get(code, "Windows Shell hatasi"))}
        return {"ok": True, "message": "BAT Windows Shell/Open ile acildi.", "workdir": workdir, "shellCode": code}
    except Exception as exc:
        return {"ok": False, "error": "ShellExecute hatasi: " + str(exc)}


def _desktop_double_click_main_miner(action="start"):
    bat = r"C:\SRBMiner-Multi-3-7-9-win64\SRBMiner-Multi-3-7-9\start-mining-pearl.bat"
    if not os.path.isfile(bat):
        return {"ok": False, "error": "Ana PC miner BAT bulunamadi: " + bat}
    try:
        PROGRAM_DATA_ROOT.mkdir(parents=True, exist_ok=True)
        if str(action or "start") in ("start", "prepare-restart"):
            _local_stop_miner()
            time.sleep(0.5)
        request_id = uuid.uuid4().hex
        try:
            if MAIN_PC_START_RESULT_FILE.exists(): MAIN_PC_START_RESULT_FILE.unlink()
        except Exception:
            pass
        save_json(MAIN_PC_START_REQUEST_FILE, {
            "id": request_id, "action": str(action or "start"), "bat": bat,
            "workingDirectory": os.path.dirname(bat), "createdAt": now_iso()
        })
        deadline = time.time() + 30
        while time.time() < deadline:
            result = read_json(MAIN_PC_START_RESULT_FILE, {})
            if isinstance(result, dict) and str(result.get("id") or "") == request_id:
                if not result.get("ok"):
                    return {"ok": False, "error": str(result.get("error") or "Yonetici SRBMiner helper hatasi")}
                if action == "prepare-only":
                    return {"ok": True, "message": "BAT yonetici olarak hazirlandi."}
                for _ in range(100):
                    if local_miner_running():
                        return {"ok": True, "message": "SRBMiner yonetici olarak basladi."}
                    time.sleep(.1)
                return {"ok": False, "error": "BAT acildi ama SRBMiner-MULTI.exe gorulmedi."}
            time.sleep(.1)
        return {"ok": False, "error": "Yonetici helper 30 saniyede cevap vermedi."}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

def local_main_action(action):
    if os.name != "nt":
        return {"ok": False, "error": "Ana PC kontrolu yalniz Windows'ta calisir."}
    try:
        if action == "start":
            if local_miner_running():
                probe = local_srb_telemetry()
                if (to_num(probe.get("hashrateHps")) > 0 or
                        to_num(probe.get("totalPowerW")) > 0 or
                        to_num(probe.get("maxTempC")) > 0 or
                        probe.get("gpus")):
                    return {
                        "ok": True,
                        "message": "Ana PC miner zaten acik; SRBMiner LIVE telemetri aktif.",
                        "telemetry": probe
                    }

                repaired = _desktop_double_click_main_miner("prepare-restart")
                if not repaired.get("ok"):
                    return repaired
                return {
                    "ok": True,
                    "message": "Ana PC SRBMiner telemetri onarildi ve yonetici olarak yeniden baslatildi."
                }
            if LOCAL_THERMAL_LOCK_FILE.is_file():
                t = local_gpu_temp_fallback()
                if 0 < t < to_num(config.get("resumeTempC"), 80):
                    try: LOCAL_THERMAL_LOCK_FILE.unlink()
                    except Exception: pass
                else:
                    return {"ok": False, "error": "Ana PC termal kilit aktif. GPU %.0fC; %.0fC altinda yeniden baslar." % (t, to_num(config.get("resumeTempC"),80))}
            # v4.0.46: Python servis oturumundan BAT acma yok.
            # Interaktif KafePin Desktop, HOTFIX8 client ile birebir:
            # FileName=BAT, WorkingDirectory=BAT klasoru, UseShellExecute=true, Verb=open.
            launched = _desktop_double_click_main_miner("start")
            if not launched.get("ok"):
                return launched
            return {"ok": True,
                    "message": "Ana PC exact start-mining-pearl.bat masaustu oturumunda cift-tik gibi acildi; monitor acik kalacak.",
                    "requestId": launched.get("requestId")}
        if action == "stop":
            _local_stop_miner()
            return {"ok": True, "message": "Ana PC miner durdurma komutu verildi."}
        if action == "monitor-off":
            return {"ok": True, "message": "Ana PC monitörü muaf; ekran açık kalacak."}
        return {"ok": False, "error": "Gecersiz ana PC komutu."}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


_GPU_MODEL_HINT = re.compile(
    r"(?:NVIDIA\s+)?(?:GeForce\s+)?(?:RTX|GTX)\s*\d{3,4}(?:\s*Ti|\s*SUPER)?|"
    r"(?:AMD\s+)?Radeon\s+(?:RX\s*)?\d{3,4}(?:\s*XT|\s*XTX)?|"
    r"Intel\s+Arc\s+[A-Z]\d{3}",
    re.I
)

def _gpu_model_candidate(value):
    if value is None:
        return ""
    text = str(value).strip()
    if not text or len(text) > 180:
        return ""
    m = _GPU_MODEL_HINT.search(text)
    if m:
        return re.sub(r"\s+", " ", m.group(0)).strip()
    # Donanim PRO bazen model adini "NVIDIA GeForce RTX 3060 Ti" disinda
    # sade bir adapter/model alaninda dondurebilir. Marka + ekran karti ipucu varsa koru.
    low = text.lower()
    if any(x in low for x in ("nvidia", "geforce", "radeon", "intel arc")) and any(ch.isdigit() for ch in text):
        return re.sub(r"\s+", " ", text).strip()
    return ""

def _collect_gpu_models(value, out, depth=0, allow_plain=False):
    if depth > 5 or value is None:
        return
    if isinstance(value, str):
        model = _gpu_model_candidate(value)
        if model:
            out.append(model)
        elif allow_plain:
            plain = value.strip()
            if 3 <= len(plain) <= 120 and any(x in plain.lower() for x in ("rtx", "gtx", "radeon", "arc", "nvidia")):
                out.append(plain)
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            _collect_gpu_models(item, out, depth + 1, allow_plain)
        return
    if isinstance(value, dict):
        # Once a GPU/hardware branch is reached, inspect name/model/description deeply.
        preferred = (
            "name","model","gpuName","gpuModel","gpu_name","gpu_model","deviceName","device_name",
            "description","adapter","adapterName","adapter_name","videoController","video_controller",
            "graphicsCard","graphics_card"
        )
        for key in preferred:
            if key in value:
                _collect_gpu_models(value.get(key), out, depth + 1, True)
        for key, item in value.items():
            lk = str(key).lower()
            if any(token in lk for token in ("gpu","graphics","video","adapter","display")):
                _collect_gpu_models(item, out, depth + 1, True)
        return

def perf_gpu_models(perf_row):
    """Read GPU model from the already-existing KafePin Donanim/Client Performans payload."""
    if not isinstance(perf_row, dict):
        return []
    vals = []
    direct_keys = (
        "gpu","gpus","gpuName","gpuModel","gpu_name","gpu_model",
        "graphics","graphicsCard","graphics_card","video","videoCard","video_card",
        "adapter","displayAdapter","display_adapter","hardware"
    )
    for key in direct_keys:
        if key in perf_row:
            _collect_gpu_models(perf_row.get(key), vals, 0, True)

    # Some Client Performans builds expose hardware under nested metrics/device/system objects.
    for key in ("metrics","device","system","specs","hardwareInfo","hardware_info"):
        if key in perf_row:
            _collect_gpu_models(perf_row.get(key), vals, 0, False)

    clean = []
    seen = set()
    for value in vals:
        value = re.sub(r"\s+", " ", str(value or "")).strip()
        lk = value.lower()
        if value and lk not in seen:
            seen.add(lk)
            clean.append(value)
    return clean

def _client_row(name, ip, p, agent, bridge, local=False):
    now = time.time()
    runtime_sec = int(config.get("runtimeFreshSeconds", 15) or 15)
    offline_sec = int(config.get("offlineSeconds", 900) or 900)
    bridge_sec = int(config.get("bridgeReadySeconds", 20) or 20)
    agent_age = row_age(agent)
    bridge_age = row_age(bridge)
    telemetry_fresh = bool(agent) and agent_age <= runtime_sec
    bridge_ready = bool(local or (bridge and bridge_age <= bridge_sec))
    recent_connection = bool(local or (bridge and bridge_age <= offline_sec) or (agent and agent_age <= offline_sec))
    perf_online = bool(p.get("online")) if isinstance(p, dict) else False
    online = bool(local or perf_online or recent_connection)
    raw_miner = bool(agent.get("minerOnline")) if agent else False
    miner = bool(telemetry_fresh and raw_miner)
    raw_hash = to_num(agent.get("hashrateHps") if agent else 0)
    raw_power = to_num(agent.get("totalPowerW") if agent else 0)
    raw_temp = to_num(agent.get("maxTempC") if agent else 0)
    active_hash = raw_hash if miner else 0.0
    active_power = raw_power if miner else 0.0
    active_temp = raw_temp if miner else 0.0
    accepted = to_num(agent.get("acceptedShares") if agent else 0) if miner else 0.0
    rejected = to_num(agent.get("rejectedShares") if agent else 0) if miner else 0.0
    status = str(p.get("status") or "") if isinstance(p, dict) else ""
    if not online: status = "OFFLINE • 15 dk baglanti yok"
    elif local: status = "Ana KafePin PC"
    elif not perf_online and recent_connection: status = "Online (KafePin Client)"
    def _model_list():
        vals = []
        sources = []

        # v4.0.61 PRIMARY: KafePin PRO Donanim is the GPU model source.
        for gpu_name in (p.get("__hardwareGpuModels") or []):
            if gpu_name:
                vals.append(str(gpu_name))

        # Old /api/metrics hardware fields are compatibility fallback only.
        vals.extend(perf_gpu_models(p))

        # Local nvidia-smi is secondary for ANA-PC only if Donanim PRO has no model.
        if local:
            try: sources.extend(local_gpu_inventory())
            except Exception: pass

        # Mining Runtime / normal Client bridge are fallback sources only.
        if agent:
            sources.extend(agent.get("gpuInventory") or [])
            sources.extend(agent.get("gpus") or [])
            for gpu_name in (agent.get("gpuModels") or []):
                if gpu_name: vals.append(str(gpu_name))
        if bridge:
            sources.extend(bridge.get("gpuInventory") or [])
            for gpu_name in (bridge.get("gpuModels") or []):
                if gpu_name: vals.append(str(gpu_name))

        for item in sources:
            if isinstance(item, dict):
                gpu_name = (item.get("name") or item.get("model") or item.get("gpuName") or
                            item.get("gpuModel") or item.get("gpu_name") or item.get("gpu_model") or
                            item.get("device_name") or item.get("deviceName"))
                if gpu_name: vals.append(str(gpu_name))
            elif item:
                vals.append(str(item))

        clean = []
        seen = set()
        for value in vals:
            value = re.sub(r"\s+", " ", value.strip())
            if value and value.lower() not in seen:
                seen.add(value.lower()); clean.append(value)
        return clean
    gpu_models = _model_list()
    primary_gpu_model = gpu_models[0] if gpu_models else ""
    oc_capable = bool(local or (agent and agent.get("ocCapable")) or (bridge and bridge.get("ocCapable")))
    last_error = str(agent.get("error") or "") if agent else ""
    if telemetry_fresh is False and raw_miner:
        last_error = "Mining telemetrisi bayat; aktif miner sayilmiyor."
    return {
        "clientId": name, "ip": ip, "host": str(agent.get("host") if agent else name), "localMain": bool(local),
        "online": online, "perfOnline": perf_online, "status": status,
        "sessionOpen": bool(p.get("sessionOpen")) if isinstance(p, dict) else False,
        "sessionMode": str(p.get("sessionMode") or "-") if isinstance(p, dict) else "-",
        "cpuLoad": p.get("cpuLoad") if isinstance(p, dict) else None,
        "ramLoad": p.get("ramLoad") if isinstance(p, dict) else None,
        "cpuTemp": p.get("cpuTemp") if isinstance(p, dict) else None,
        "gpuTemp": active_temp, "bridgeReady": bridge_ready,
        "bridgeUpdatedAt": bridge.get("updatedAt") if bridge else (now_iso() if local else None),
        "agentConnected": telemetry_fresh, "telemetryFresh": telemetry_fresh,
        "telemetryAgeSec": None if not agent else round(agent_age, 1),
        "minerOnline": miner, "miningActive": bool(miner and active_hash > 0),
        "minerNoHash": bool(miner and active_hash <= 0), "hashrateHps": active_hash,
        "totalPowerW": active_power, "maxTempC": active_temp,
        "acceptedShares": accepted, "rejectedShares": rejected,
        "shareRejectPct": (rejected / max(1.0, accepted + rejected)) * 100.0 if miner else 0.0,
        "efficiencyHpsPerW": active_hash / active_power if active_power > 0 else 0.0,
        "thermalStop": bool(agent.get("thermalStop")) if agent else False,
        "gpus": list(agent.get("gpus") or []) if agent and miner else [],
        "gpuModels": gpu_models, "primaryGpuModel": primary_gpu_model, "ocCapable": oc_capable,
        "hardwareSource": ("KafePin PRO Donanim" if (p.get("__hardwareGpuModels") or []) else ("KafePin Metrics" if perf_gpu_models(p) else ("NVIDIA-SMI" if local and gpu_models else ("Mining Runtime" if agent and gpu_models else ("KafePin Client" if bridge and gpu_models else ""))))),
        "gpuInventory": list((agent.get("gpuInventory") if agent else None) or (bridge.get("gpuInventory") if bridge else None) or []),
        "updatedAt": agent.get("updatedAt") if agent else None,
        "lastHashrateHps": raw_hash, "lastPowerW": raw_power, "lastTempC": raw_temp,
        "lastAcceptedShares": to_num(agent.get("acceptedShares") if agent else 0),
        "lastRejectedShares": to_num(agent.get("rejectedShares") if agent else 0),
        "lastError": last_error if last_error else ("" if bridge_ready else "Mining bridge hazir degil"),
        "lastCommandResult": str(agent.get("lastCommandResult") or "") if agent else "",
        "lastCommandError": str(agent.get("lastCommandError") or "") if agent else "",
        "telemetrySource": str(agent.get("telemetrySource") or ("SRBMiner DIRECT" if miner else "")) if agent else "",
        "cmdLogError": str(agent.get("cmdLogError") or "") if agent else "",
        "minerRestartCount": int(to_num(agent.get("minerRestartCount"))) if agent else 0,
        "srbProcessCount": int(to_num(agent.get("srbProcessCount"))) if agent else (1 if local and local_srb_running() else 0),
        "forgeProcessCount": int(to_num(agent.get("forgeProcessCount"))) if agent else 0,
        "legacyMinerCmdCount": int(to_num(agent.get("legacyMinerCmdCount"))) if agent else 0,
        "runtimeElevated": bool(agent.get("runtimeElevated")) if agent else bool(local),
        "ocBatVerified": (bool(local_bat_oc_state().get("verified")) if local else bool(agent.get("ocBatVerified")) if agent and agent.get("ocBatVerified") is not None else bool(bridge.get("ocBatVerified")) if bridge else False),
        "ocBatProfile": (local_bat_oc_state() if local else dict(agent.get("ocBatProfile") or {}) if agent and agent.get("ocBatProfile") else dict(bridge.get("ocBatProfile") or {}) if bridge else {}),
        "clientMiningVersion": str((bridge.get("clientMiningVersion") if bridge else "") or (agent.get("clientMiningVersion") if agent else "")),
        "pendingCommand": dict(commands.get(name) or {}),
        "offlineAfterSec": offline_sec,
    }


def merged_clients():
    perf = get_client_perf()
    hardware = get_kafepin_hardware()
    result, matched = [], set()
    with lock:
        client_snapshot = dict(clients); bridge_snapshot = dict(bridges)
    for p in perf.get("clients") or []:
        p = dict(p)
        name = str(p.get("name") or "Masa"); ip = str(p.get("ip") or "").strip()
        p["__hardwareGpuModels"] = find_hardware_gpu_models(hardware, ip, name, name)
        agent = None; agent_key = None
        for key, row in client_snapshot.items():
            if (ip and str(row.get("ip") or "").strip() == ip) or normalize(key) == normalize(name) or (normalize(row.get("host")) and normalize(row.get("host")) == normalize(name)):
                agent, agent_key = row, key; break
        if agent_key: matched.add(agent_key)
        bridge = None
        for key, row in bridge_snapshot.items():
            if (ip and str(row.get("ip") or "").strip() == ip) or normalize(key) == normalize(name): bridge = row; break
        result.append(_client_row(name, ip, p, agent, bridge))
    for key, agent in client_snapshot.items():
        if key in matched: continue
        bridge = bridge_snapshot.get(key)
        aip = str(agent.get("ip") or "")
        hp = {"__hardwareGpuModels": find_hardware_gpu_models(hardware, aip, str(agent.get("host") or key), key)}
        result.append(_client_row(key, aip, hp, agent, bridge))
    if bool(config.get("includeMainPc", True)):
        cid = str(config.get("mainPcClientId") or "ANA-PC")
        telem = local_srb_telemetry()
        try:
            host = socket.gethostname(); ip = socket.gethostbyname(host)
        except Exception:
            host, ip = "ANA-PC", "127.0.0.1"
        telem["host"] = host
        local_perf = dict(find_perf_match(perf, ip, host, cid) or {})
        local_perf["__hardwareGpuModels"] = find_hardware_gpu_models(hardware, ip, host, cid)
        result = [r for r in result if normalize(r.get("clientId")) != normalize(cid) and normalize(r.get("host")) != normalize(host)]
        result.append(_client_row(cid, ip, local_perf, telem, {"updatedAt": now_iso()}, local=True))
    def sort_key(row):
        if row.get("localMain"): return (-1, str(row.get("clientId") or ""))
        m = re.search(r"(\d+)\s*$", str(row.get("clientId") or ""))
        return (int(m.group(1)) if m else 999999, str(row.get("clientId") or ""))
    return sorted(result, key=sort_key)


def save_sessions(force=False):
    global session_last_save
    now = time.time()
    if not force and now - session_last_save < 5.0:
        return
    with lock:
        save_json(SESSION_FILE, session_ledger)
        session_last_save = now


def session_sample(client_id, miner_online, hashrate_hps, power_w, sample_time=None):
    now = float(sample_time or time.time()); cid = str(client_id)
    with lock:
        e = dict(session_ledger.get(cid) or {})
        was_active = bool(e.get("active"))
        if miner_online and hashrate_hps > 0:
            if not was_active:
                e = {"sessionId": uuid.uuid4().hex, "active": True, "startedAt": datetime.fromtimestamp(now, timezone.utc).astimezone().isoformat(),
                     "lastSampleTs": now, "hashrateSeconds": 0.0, "energyKwh": 0.0, "activeSeconds": 0.0}
            last = to_num(e.get("lastSampleTs"), now); dt = max(0.0, min(10.0, now - last))
            eff_power = max(0.0, to_num(power_w))
            e["hashrateSeconds"] = to_num(e.get("hashrateSeconds")) + max(0.0, hashrate_hps) * dt
            e["energyKwh"] = to_num(e.get("energyKwh")) + eff_power / 1000.0 * dt / 3600.0
            e["activeSeconds"] = to_num(e.get("activeSeconds")) + dt
            e["lastSampleTs"] = now; e["active"] = True
        else:
            if was_active:
                e["active"] = False; e["stoppedAt"] = datetime.fromtimestamp(now, timezone.utc).astimezone().isoformat()
            e["lastSampleTs"] = now
        session_ledger[cid] = e
    save_sessions(False)

def session_reset(client_id):
    with lock:
        session_ledger[str(client_id)] = {"active": False, "resetAt": now_iso(), "hashrateSeconds": 0.0, "energyKwh": 0.0, "activeSeconds": 0.0}
    save_sessions(True)


def session_view(client_id, pool, market, fx):
    with lock:
        e = dict(session_ledger.get(str(client_id)) or {})
    hs = to_num(e.get("hashrateSeconds")); energy = to_num(e.get("energyKwh"))
    network = to_num(pool.get("networkHashrate")); reward = to_num(pool.get("blockRewardPrl")); block = to_num(pool.get("avgBlockTimeSec"))
    est_prl = (hs * reward / (network * block)) if hs > 0 and network > 0 and block > 0 else 0.0
    gross_try = est_prl * to_num(market.get("priceUsd")) * to_num(fx.get("usdTry"))
    electricity_try = energy * to_num(config.get("electricityTryKwh"))
    return {"active": bool(e.get("active")), "startedAt": e.get("startedAt"), "stoppedAt": e.get("stoppedAt"),
            "activeSeconds": to_num(e.get("activeSeconds")), "estimatedPrl": est_prl, "energyKwh": energy,
            "grossTry": gross_try, "electricityTry": electricity_try, "netTry": gross_try - electricity_try}

def save_commands():
    with lock:
        save_json(COMMANDS_FILE, commands)


def save_clients():
    with lock:
        save_json(CLIENTS_FILE, clients)


def cleanup_commands():
    changed = False
    with lock:
        for key in list(commands.keys()):
            issued = parse_iso(commands[key].get("issuedAt"))
            if not issued or time.time() - issued > 1800:
                commands.pop(key, None)
                changed = True
    if changed:
        save_commands()


def queue_command(targets, action, by="Mining Pro", payload=None):
    issued = {}
    with lock:
        for client_id in targets:
            if not str(client_id).strip():
                continue
            row = {"id": uuid.uuid4().hex, "action": action, "issuedAt": now_iso(), "by": by}
            if isinstance(payload, dict):
                for key, value in payload.items():
                    if key not in ("id", "action", "issuedAt", "by"):
                        row[key] = value
            commands[str(client_id)] = row
            issued[str(client_id)] = dict(row)
    save_commands()
    return issued


def direct_push(client_id, command):
    bridge = find_bridge(client_id, "")
    if not bridge or not fresh(bridge, 20):
        return {"ok": False, "error": "bridge hazır değil"}
    ip = str(bridge.get("ip") or "").strip()
    port = int(to_num(bridge.get("pushPort"), 0) or 0)
    key = str(bridge.get("pushKey") or "")
    if not ip or port <= 0 or not key:
        return {"ok": False, "error": "direct-push bilgisi yok"}
    try:
        d = http_json("http://%s:%d/command" % (ip, port), timeout=0.8, method="POST",
                      body={"key": key, "command": command})
        return {"ok": bool(d.get("ok")), "result": d}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def wake_client(client_name):
    try:
        d = http_json(str(config["kafepinActionUrl"]), timeout=5, method="POST", body={"client": client_name, "action": "wake"})
        return {"ok": True, "result": d}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def atomic_to_coin(value):
    units = to_num(config.get("coinUnits"), 100000000) or 100000000
    return to_num(value) / units


def cached_json(name, disk_file, ttl, loader):
    now = time.time()
    with lock:
        hit = mem_cache.get(name)
        if hit and now - hit[0] < ttl:
            return hit[1]
    try:
        data = loader()
        with lock:
            mem_cache[name] = (now, data)
        save_json(disk_file, data)
        return data
    except Exception as exc:
        old = read_json(disk_file, None)
        if isinstance(old, dict):
            old["stale"] = True
            old["error"] = str(exc)
            with lock:
                mem_cache[name] = (now, old)
            return old
        raise


def get_pool_data():
    def load():
        base = str(config["twoMinersBase"]).rstrip("/")
        wallet = str(config["wallet"])
        with ThreadPoolExecutor(max_workers=3) as ex:
            f_account = ex.submit(http_json, base + "/accounts/" + wallet, 7)
            f_stats = ex.submit(http_json, base + "/stats", 7)
            f_profit = ex.submit(http_json, "https://hr.2miners.com/api/v1/profit/prl", 7)
            raw = f_account.result()
            pool = f_stats.result()
            profit_row = f_profit.result()
        payments = []
        for p in raw.get("payments") or []:
            if not isinstance(p, dict):
                continue
            payments.append({
                "amountPrl": atomic_to_coin(p.get("amount")), "timestamp": p.get("timestamp"),
                "tx": str(p.get("tx") or p.get("txid") or ""), "txFeePrl": atomic_to_coin(p.get("txFee")),
            })
        workers = []
        for name, v in (raw.get("workers") or {}).items():
            if not isinstance(v, dict):
                continue
            workers.append({"name": name, "hr": to_num(v.get("hr")), "hr2": to_num(v.get("hr2")),
                            "lastBeat": v.get("lastBeat"), "offline": bool(v.get("offline")),
                            "sharesValid": to_num(v.get("sharesValid")), "sharesInvalid": to_num(v.get("sharesInvalid")),
                            "sharesStale": to_num(v.get("sharesStale"))})
        current = to_num(raw.get("currentHashrate")); average = to_num(raw.get("hashrate"))
        nodes = pool.get("nodes") or []
        node = nodes[0] if nodes and isinstance(nodes[0], dict) else {}
        network_hash = to_num(node.get("networkhashps")); block_sec = to_num(node.get("avgBlockTime")); block_reward = atomic_to_coin(node.get("blockReward"))
        blocks_day = 86400.0 / block_sec if block_sec > 0 else 0
        profit_per_hash = max(0.0, to_num((profit_row or {}).get("prl")))
        if profit_per_hash > 0:
            est_current = current * profit_per_hash
            est_average = average * profit_per_hash
            estimate_source = "2miners-profit-api"
        else:
            est_current = (current / network_hash) * blocks_day * block_reward if network_hash > 0 else 0
            est_average = (average / network_hash) * blocks_day * block_reward if network_hash > 0 else 0
            estimate_source = "network-fallback"
        actual24 = atomic_to_coin(raw.get("24hreward"))
        if actual24 <= 0:
            for row in raw.get("sumrewards") or []:
                if isinstance(row, dict) and str(row.get("name")) == "Last 24 hours":
                    actual24 = atomic_to_coin(row.get("reward")); break
        stats = raw.get("stats") or {}
        cfg = raw.get("config") or {}
        balance = atomic_to_coin(stats.get("balance", raw.get("balance", 0)))
        immature = atomic_to_coin(stats.get("immature", raw.get("immature", 0)))
        paid = atomic_to_coin(stats.get("paid", 0))
        if paid <= 0:
            paid = sum(to_num(p.get("amountPrl")) for p in payments)
        return {
            "ok": True, "source": "2Miners", "wallet": wallet, "currentHashrate": current, "averageHashrate": average,
            "workersOnline": to_num(raw.get("workersOnline")), "workersOffline": to_num(raw.get("workersOffline")),
            "workersTotal": to_num(raw.get("workersTotal")), "balancePrl": balance, "immaturePrl": immature, "paidPrl": paid,
            "actualReward24hPrl": actual24, "estimatedDailyPrlCurrent": est_current, "estimatedDailyPrlAverage": est_average,
            "estimateSource": estimate_source, "profitPerHashPrl": profit_per_hash,
            "minPayoutPrl": atomic_to_coin(cfg.get("minPayout")), "allowedMinPayoutPrl": atomic_to_coin(cfg.get("allowedMinPayout")),
            "sharesValid": to_num(raw.get("sharesValid")), "sharesInvalid": to_num(raw.get("sharesInvalid")),
            "sharesStale": to_num(raw.get("sharesStale")), "lastShare": to_num(stats.get("lastShare")),
            "paymentsTotal": to_num(raw.get("paymentsTotal")), "payments": payments[:30], "workers": workers,
            "networkHashrate": network_hash, "blockRewardPrl": block_reward, "avgBlockTimeSec": block_sec,
            "poolHashrate": to_num(pool.get("hashrate")), "updatedAt": now_iso(), "stale": False,
        }
    try:
        return cached_json("pool", POOL_CACHE_FILE, 15, load)
    except Exception as exc:
        return {"ok": False, "source": "2Miners", "error": str(exc), "stale": True, "wallet": str(config.get("wallet", "")),
                "payments": [], "workers": [], "currentHashrate": 0, "averageHashrate": 0, "actualReward24hPrl": 0,
                "estimatedDailyPrlCurrent": 0, "estimatedDailyPrlAverage": 0}


def observed_pool_daily_prl(pool):
    try:
        now = time.time()
        total = max(0.0, to_num(pool.get("balancePrl"))) + max(0.0, to_num(pool.get("immaturePrl"))) + max(0.0, to_num(pool.get("paidPrl")))
        hist = read_json(POOL_EARNINGS_FILE, [])
        if not isinstance(hist, list): hist = []
        hist = [x for x in hist if isinstance(x, dict) and now - to_num(x.get("ts")) <= 86400 * 2]
        if not hist or now - to_num(hist[-1].get("ts")) >= 15:
            hist.append({"ts": now, "totalPrl": total})
            save_json(POOL_EARNINGS_FILE, hist[-6000:])
        candidates = [x for x in hist if 1800 <= now - to_num(x.get("ts")) <= 21600]
        if not candidates:
            return {"ready": False, "dailyPrl": 0.0, "seconds": 0}
        base = candidates[0]
        dt = max(1.0, now - to_num(base.get("ts")))
        delta = total - to_num(base.get("totalPrl"))
        if delta <= 0:
            return {"ready": False, "dailyPrl": 0.0, "seconds": dt}
        return {"ready": True, "dailyPrl": delta * 86400.0 / dt, "seconds": dt}
    except Exception:
        return {"ready": False, "dailyPrl": 0.0, "seconds": 0}


def parse_bigone(ticker):
    body = ticker.get("data", ticker) if isinstance(ticker, dict) else ticker
    if isinstance(body, list):
        if not body:
            raise ValueError("BigONE ticker bos")
        body = body[0]
    if not isinstance(body, dict):
        raise ValueError("BigONE ticker gecersiz")
    close = to_num(body.get("close") or body.get("last") or body.get("price")); open_ = to_num(body.get("open"))
    if close <= 0:
        raise ValueError("BigONE PEARL-USDT close fiyati bulunamadi")
    change = ((close - open_) / open_) * 100 if open_ > 0 else 0
    return {"ok": True, "source": "BigONE", "pair": "PEARL-USDT", "displayPair": "PRL/USDT", "priceUsd": close,
            "change24h": change, "open": open_, "high": to_num(body.get("high")), "low": to_num(body.get("low")),
            "volume": to_num(body.get("volume")), "updatedAt": now_iso(), "stale": False}


def get_market_data():
    def load():
        try:
            return parse_bigone(http_json(str(config["bigoneTickerUrl"]), timeout=6))
        except Exception:
            return parse_bigone(http_json(str(config["bigoneTickerFallbackUrl"]), timeout=6))
    try:
        return cached_json("market", MARKET_CACHE_FILE, 20, load)
    except Exception as exc:
        return {"ok": False, "source": "BigONE", "pair": "PEARL-USDT", "displayPair": "PRL/USDT", "priceUsd": 0,
                "change24h": 0, "stale": True, "error": str(exc)}


def get_fx_data():
    def load():
        req = Request("https://www.tcmb.gov.tr/kurlar/today.xml", headers={"User-Agent": "KafePin-MiningPro/%s" % VERSION})
        with urlopen(req, timeout=6) as res:
            root = ET.fromstring(res.read())
        rate = 0.0
        for cur in root.findall("Currency"):
            if cur.attrib.get("CurrencyCode") == "USD":
                rate = to_num(cur.findtext("ForexSelling")); break
        if rate <= 0:
            raise ValueError("TCMB USD/TRY bulunamadi")
        return {"ok": True, "source": "TCMB", "usdTry": rate, "updatedAt": now_iso(), "stale": False}
    try:
        return cached_json("fx", FX_CACHE_FILE, 3600, load)
    except Exception as exc:
        fallback = to_num(config.get("usdTryFallback"))
        return {"ok": fallback > 0, "source": "fallback", "usdTry": fallback, "stale": True, "error": str(exc)}


def find_prlctl():
    candidates = []
    local = os.environ.get("LOCALAPPDATA")
    if local:
        candidates += [os.path.join(local, "Pearl", "bin", "prlctl.exe"), os.path.join(local, "Pearl", "prlctl.exe")]
    for name in ("prlctl.exe", "prlctl"):
        p = shutil.which(name)
        if p:
            candidates.append(p)
    for p in candidates:
        if p and os.path.isfile(p):
            return p
    return None


def invoke_prlctl(args):
    exe = find_prlctl()
    if not exe:
        return {"ok": False, "error": "prlctl bulunamadi. Resmi Pearl Wallet/CLI kurulu olmali."}
    try:
        cp = subprocess.run([exe] + list(args), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=8,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        out = (cp.stdout or "").strip()
        return {"ok": cp.returncode == 0, "output": out, "error": "" if cp.returncode == 0 else out, "exe": exe}
    except Exception as exc:
        return {"ok": False, "error": str(exc), "exe": exe}


def wallet_status():
    r = invoke_prlctl(["--wallet", "getbalance", "default", "1"])
    if not r.get("ok"):
        return {"ok": False, "available": False, "balancePrl": 0, "error": r.get("error")}
    m = re.search(r"[-+]?\d+(?:[\.,]\d+)?", str(r.get("output") or ""))
    return {"ok": True, "available": True, "balancePrl": to_num(m.group(0)) if m else 0, "exe": r.get("exe")}


def valid_pearl_address(addr):
    return bool(re.match(r"^prl1[0-9a-z]{20,}$", str(addr or "").strip()))


def bigone_gateway_info():
    def load():
        base = str(config.get("bigoneApiBase") or "https://api.big.one/api/v3").rstrip("/")
        assets = http_json(base + "/assets", timeout=7)
        rows = assets.get("data", assets) if isinstance(assets, dict) else assets
        for asset in rows if isinstance(rows, list) else []:
            if str(asset.get("symbol") or "").upper() != "USDT": continue
            gateways = asset.get("binding_gateways") or []
            wanted = normalize(config.get("binanceGatewayName"))
            aliases = {wanted, "binancesmartchain", "bsc", "bep20"}
            for g in gateways:
                name = str(g.get("gateway_name") or "")
                if normalize(name) in aliases or any(x in normalize(name) for x in ("binancesmartchain", "bsc", "bep20")):
                    return {"ok": True, "gatewayName": name, "enabled": bool(g.get("is_withdrawal_enabled")),
                            "feeUsdt": to_num(g.get("withdrawal_fee")), "minWithdrawalUsdt": to_num(g.get("min_withdrawal_amount")),
                            "withdrawalScale": int(to_num(g.get("withdrawal_scale"), 6)), "updatedAt": now_iso()}
        return {"ok": False, "gatewayName": str(config.get("binanceGatewayName")), "enabled": False, "feeUsdt": 0,
                "minWithdrawalUsdt": 0, "error": "BigONE USDT BEP20/BSC gateway bulunamadi.", "updatedAt": now_iso()}
    try:
        return mem_cached("bigone_gateway", 300, load)
    except Exception as exc:
        return {"ok": False, "enabled": False, "gatewayName": str(config.get("binanceGatewayName")), "feeUsdt": 0,
                "minWithdrawalUsdt": 0, "error": str(exc), "updatedAt": now_iso()}


def _bigone_account_path(symbol, fund=False):
    path = "/viewer/fund/accounts/" if fund else "/viewer/accounts/"
    d = bigone_auth_json(path + str(symbol).upper(), timeout=6)
    body = d.get("data", d) if isinstance(d, dict) else d
    if not isinstance(body, dict): raise RuntimeError("BigONE hesap cevabi gecersiz: " + str(symbol))
    balance = to_num(body.get("balance")); locked = to_num(body.get("locked_balance"))
    return {"symbol": str(symbol).upper(), "balance": balance, "locked": locked, "available": max(0.0, balance - locked)}


def bigone_account(symbol):
    spot = _bigone_account_path(symbol, False)
    try:
        fund = _bigone_account_path(symbol, True)
    except Exception:
        fund = {"symbol": str(symbol).upper(), "balance": 0, "locked": 0, "available": 0}
    return {"symbol": str(symbol).upper(), "spot": spot, "fund": fund,
            "balance": to_num(spot.get("balance")) + to_num(fund.get("balance")),
            "locked": to_num(spot.get("locked")) + to_num(fund.get("locked")),
            "available": to_num(spot.get("available")) + to_num(fund.get("available"))}


def bigone_internal_transfer(symbol, amount, from_account, to_account):
    amount = max(0.0, to_num(amount))
    if amount <= 0: return {"ok": True, "skipped": True}
    body = {"symbol": str(symbol).upper(), "amount": ("%.8f" % amount).rstrip("0").rstrip("."),
            "guid": str(uuid.uuid4()), "from": str(from_account).upper(), "to": str(to_account).upper(), "type": "NORMAL"}
    result = bigone_auth_json("/viewer/transfer", timeout=10, method="POST", body=body)
    with lock: mem_cache.pop("bigone_auth_state", None)
    finance_log("BIGONE_INTERNAL_TRANSFER", {"symbol": symbol, "amount": amount, "from": from_account, "to": to_account, "result": result})
    return {"ok": True, "result": result}


def ensure_bigone_spot(symbol, amount):
    acct = bigone_account(symbol); spot = to_num(acct.get("spot", {}).get("available")); fund = to_num(acct.get("fund", {}).get("available"))
    need = max(0.0, to_num(amount) - spot)
    if need <= 0: return acct
    if need > fund + 1e-12: raise RuntimeError("BigONE %s toplam bakiyesi yetersiz." % str(symbol).upper())
    bigone_internal_transfer(symbol, need, "FUND", "SPOT")
    with lock: mem_cache.pop("bigone_auth_state", None)
    time.sleep(0.4)
    return bigone_account(symbol)


def bigone_trading_fee():
    try:
        d = bigone_auth_json("/viewer/trading_fees?asset_pair_names=" + str(config.get("bigonePair") or "PEARL-USDT"), timeout=6)
        rows = d.get("data", d) if isinstance(d, dict) else d
        row = rows[0] if isinstance(rows, list) and rows else rows
        return {"takerFeeRate": to_num(row.get("taker_fee_rate")) if isinstance(row, dict) else 0,
                "makerFeeRate": to_num(row.get("maker_fee_rate")) if isinstance(row, dict) else 0}
    except Exception:
        return {"takerFeeRate": 0, "makerFeeRate": 0}


def bigone_finance_state():
    token_ok = bool(load_bigone_token())
    gateway = bigone_gateway_info()
    base = {"tokenConfigured": token_ok, "binanceAddress": str(config.get("binanceUsdtAddress") or ""),
            "network": str(config.get("binanceNetworkLabel") or "BEP20 (BSC)"), "gateway": gateway,
            "pearl": {"balance": 0, "available": 0, "locked": 0}, "usdt": {"balance": 0, "available": 0, "locked": 0},
            "fees": {"takerFeeRate": 0}, "sellReady": False, "transferReady": False, "updatedAt": now_iso()}
    if not token_ok:
        base["error"] = "BigONE API token tanimli degil."; return base
    try:
        def load():
            pearl = bigone_account("PEARL"); usdt = bigone_account("USDT"); fee = bigone_trading_fee()
            return {"pearl": pearl, "usdt": usdt, "fees": fee, "updatedAt": now_iso()}
        auth = mem_cached("bigone_auth_state", 4, load)
        base.update(auth)
        base["sellReady"] = to_num(base["pearl"].get("available")) > 0
        base["transferReady"] = bool(valid_evm_address(base["binanceAddress"]) and gateway.get("enabled") and
                                     to_num(base["usdt"].get("available")) >= max(0.0, to_num(gateway.get("minWithdrawalUsdt"))))
        return base
    except Exception as exc:
        base["error"] = str(exc); return base


def finance_log(kind, payload):
    items = read_json(FINANCE_LOG_FILE, [])
    row = {"kind": kind, "createdAt": now_iso(), "payload": payload}
    items = ([row] + (items if isinstance(items, list) else []))[:200]
    save_json(FINANCE_LOG_FILE, items)
    return row


def bigone_sell_preview(amount):
    fs = bigone_finance_state(); available = to_num(fs.get("pearl", {}).get("available"))
    amount = min(available, max(0.0, to_num(amount)))
    if amount <= 0: raise RuntimeError("Satilacak PEARL miktari yok.")
    market = get_market_data(); price = to_num(market.get("priceUsd")); fee_rate = to_num(fs.get("fees", {}).get("takerFeeRate"))
    gross = amount * price; fee = gross * max(0.0, fee_rate)
    return {"ok": True, "amountPearl": amount, "availablePearl": available, "priceUsdt": price,
            "grossUsdt": gross, "estimatedFeeUsdt": fee, "estimatedNetUsdt": max(0.0, gross-fee), "takerFeeRate": fee_rate,
            "pair": str(config.get("bigonePair") or "PEARL-USDT")}


def bigone_market_sell(amount):
    preview = bigone_sell_preview(amount)
    ensure_bigone_spot("PEARL", preview["amountPearl"])
    order = bigone_auth_json("/viewer/orders", timeout=12, method="POST", body={
        "asset_pair_name": str(config.get("bigonePair") or "PEARL-USDT"), "side": "ASK",
        "amount": ("%.8f" % preview["amountPearl"]).rstrip("0").rstrip("."), "type": "MARKET",
        "client_order_id": "kp-" + uuid.uuid4().hex[:20]})
    with lock: mem_cache.pop("bigone_auth_state", None)
    finance_log("BIGONE_SELL", {"amountPearl": preview["amountPearl"], "order": order})
    return {"ok": True, "preview": preview, "order": order}


def bigone_safe_all_usdt():
    fs = bigone_finance_state(); available = to_num(fs.get("usdt", {}).get("available")); fee = max(0.0, to_num((fs.get("gateway") or {}).get("feeUsdt")))
    return max(0.0, available - fee)


def bigone_withdraw_preview(amount):
    fs = bigone_finance_state(); available = to_num(fs.get("usdt", {}).get("available")); gateway = fs.get("gateway") or {}
    if not valid_evm_address(config.get("binanceUsdtAddress")): raise RuntimeError("Binance USDT adresi gecersiz.")
    if not gateway.get("enabled"): raise RuntimeError(gateway.get("error") or "BigONE BEP20 cekim agi aktif degil.")
    fee = max(0.0, to_num(gateway.get("feeUsdt"))); minimum = max(0.0, to_num(gateway.get("minWithdrawalUsdt")))
    amount = min(available, max(0.0, to_num(amount)))
    if amount <= 0: raise RuntimeError("Aktarilacak USDT miktari yok.")
    if amount < minimum: raise RuntimeError("BigONE minimum BEP20 cekim miktari %.8f USDT." % minimum)
    return {"ok": True, "amountUsdt": amount, "availableUsdt": available, "feeUsdt": fee,
            "estimatedReceiveUsdt": max(0.0, amount-fee), "minWithdrawalUsdt": minimum,
            "address": str(config.get("binanceUsdtAddress")), "network": str(config.get("binanceNetworkLabel")),
            "gatewayName": str(gateway.get("gatewayName") or config.get("binanceGatewayName"))}


def bigone_withdraw(amount):
    preview = bigone_withdraw_preview(amount)
    ensure_bigone_spot("USDT", preview["amountUsdt"])
    body = {"symbol": "USDT", "amount": ("%.8f" % preview["amountUsdt"]).rstrip("0").rstrip("."),
            "target_account": "SPOT", "target_address": preview["address"], "guid": str(uuid.uuid4()),
            "gateway_name": preview["gatewayName"]}
    result = bigone_auth_json("/viewer/withdrawals", timeout=15, method="POST", body=body)
    with lock: mem_cache.pop("bigone_auth_state", None)
    finance_log("BIGONE_TO_BINANCE", {"amountUsdt": preview["amountUsdt"], "address": preview["address"],
                                       "network": preview["network"], "result": result})
    return {"ok": True, "preview": preview, "withdrawal": result}

def _profile_cfg():
    vp = config.get("verifiedOcProfiles")
    return vp if isinstance(vp, dict) else {}

def _locked_clients():
    return set(str(x) for x in (config.get("ocLockedClients") or []))

def verified_profile(client_id, mode=None):
    cid = str(client_id)
    mode = str(mode or (config.get("ocModes") or {}).get(cid) or "").lower()
    vp = _profile_cfg().get(cid) or {}
    p = vp.get(mode) if isinstance(vp, dict) else None
    if isinstance(p, dict):
        out = dict(p)
        out["mode"] = mode
        return out
    return None

def profile_state_for(client_id):
    cid = str(client_id)
    modes = {}
    vp = _profile_cfg().get(cid) or {}
    if isinstance(vp, dict):
        for m, p in vp.items():
            if isinstance(p, dict):
                modes[str(m)] = dict(p)
    pin = (config.get("ocPinnedProfiles") or {}).get(cid)
    current = str((config.get("ocModes") or {}).get(cid) or ((pin or {}).get("mode") if isinstance(pin, dict) else "") or "")
    return {"locked": cid in _locked_clients(), "currentMode": current, "profiles": modes,
            "pinned": dict(pin) if isinstance(pin, dict) else {}}

def pool_latency_ms():
    def load():
        t = time.perf_counter()
        try:
            with socket.create_connection(("prl.2miners.com", 1818), timeout=2.5):
                return round((time.perf_counter() - t) * 1000.0, 1)
        except Exception:
            return None
    return mem_cached("pool_latency", 30, load)

def worker_for_client(pool, cid):
    target = normalize(cid)
    for w in (pool.get("workers") or []):
        if normalize(w.get("name")) == target:
            return w
    return {}

def pool_validation(row, pool, latency):
    cid = str(row.get("clientId") or "")
    w = worker_for_client(pool, cid)
    miner = bool(row.get("miningActive"))
    connected = bool(miner and pool.get("ok"))
    return {"connected": connected,
            "label": "2Miners bağlı" if connected else "2Miners bekliyor",
            "worker": str(w.get("name") or cid), "address": "prl.2miners.com:1818",
            "lastShare": w.get("lastBeat") or pool.get("lastShare"),
            "accepted": to_num(w.get("sharesValid"), row.get("acceptedShares", 0)),
            "rejected": to_num(w.get("sharesInvalid"), row.get("rejectedShares", 0)),
            "stale": to_num(w.get("sharesStale")), "latencyMs": latency}

def _health_save(force=False):
    global health_last_save
    now = time.time()
    if not force and now - health_last_save < 10:
        return
    with lock:
        save_json(HEALTH_FILE, health_ledger)
        health_last_save = now

def health_sample(row):
    cid = str(row.get("clientId") or "")
    now = time.time()
    temp = to_num(row.get("maxTempC"))
    mining = bool(row.get("miningActive"))
    rej = to_num(row.get("rejectedShares"))
    acc = to_num(row.get("acceptedShares"))
    with lock:
        e = dict(health_ledger.get(cid) or {})
        for k in ("temp80Events", "crashEvents", "restartEvents", "rejectSamples"):
            e.setdefault(k, [])
        if temp > 80 and not bool(e.get("_hot")):
            e["temp80Events"].append(now)
        prev = e.get("_mining")
        if prev is True and not mining and row.get("online") and not row.get("pendingCommand"):
            e["crashEvents"].append(now)
        rc = int(to_num(row.get("minerRestartCount")))
        old = int(to_num(e.get("_restartCount")))
        if rc > old:
            for _ in range(min(20, rc - old)):
                e["restartEvents"].append(now)
        if acc + rej > 0:
            e["rejectSamples"].append({"ts": now, "accepted": acc, "rejected": rej})
        e["_hot"] = temp > 80
        e["_mining"] = mining
        e["_restartCount"] = rc
        e["maxTempC"] = max(to_num(e.get("maxTempC")), temp)
        cutoff = now - 30 * 86400
        for k in ("temp80Events", "crashEvents", "restartEvents"):
            e[k] = [x for x in e.get(k, []) if to_num(x) >= cutoff]
        e["rejectSamples"] = [x for x in e.get("rejectSamples", []) if to_num(x.get("ts")) >= cutoff][-3000:]
        e["updatedAt"] = now_iso()
        health_ledger[cid] = e
    _health_save(False)

def health_view(cid):
    with lock:
        e = dict(health_ledger.get(str(cid)) or {})
    samples = e.get("rejectSamples") or []
    a = max([to_num(x.get("accepted")) for x in samples] or [0])
    r = max([to_num(x.get("rejected")) for x in samples] or [0])
    return {"days": 30, "temp80Events": len(e.get("temp80Events") or []),
            "crashes": len(e.get("crashEvents") or []), "minerRestarts": len(e.get("restartEvents") or []),
            "rejectedShares": r, "acceptedShares": a, "rejectPct": (r / max(1.0, a + r)) * 100.0,
            "maxTempC": to_num(e.get("maxTempC"))}

def apply_verified_profile_to_client(cid, profile, row=None, allow_locked=False):
    cid = str(cid)
    if cid in _locked_clients() and not allow_locked:
        return {"client": cid, "ok": False, "locked": True, "error": "Kilitli, dokunulmadı"}
    if not isinstance(profile, dict):
        return {"client": cid, "ok": False, "error": "Doğrulanmış profil yok"}
    if row is None:
        row = {str(x.get("clientId")): x for x in merged_clients()}.get(cid)
    if not row:
        return {"client": cid, "ok": False, "error": "Masa bulunamadı"}
    if row.get("localMain"):
        inv = local_gpu_inventory()
        profiles = []
        for i, g in enumerate(inv or [{}]):
            profiles.append({"gpuId": int(g.get("index", i)), "name": str(g.get("name") or profile.get("model") or ""),
                             "cclock": int(profile.get("cclock")), "coffset": int(profile.get("coffset")),
                             "mclock": int(profile.get("mclock")), "plimit": int(profile.get("plimit"))})
        res = apply_local_pearl_oc(profiles, restart=True, remove=False)
        return {"client": cid, "ok": bool(res.get("ok")), "profile": profile, "local": res,
                "error": res.get("error") if not res.get("ok") else None}
    issued = queue_command([cid], "oc-apply", payload={"profile": dict(profile)})
    push = direct_push(cid, issued.get(cid) or {})
    return {"client": cid, "ok": True, "profile": profile, "directPush": push}

def apply_profile_mode(targets, mode, active_only=True, allow_locked=False):
    mode = str(mode or "").lower()
    if mode not in ("balanced", "max"):
        return {"ok": False, "error": "Profil modu geçersiz"}
    rows = {str(x.get("clientId")): x for x in merged_clients()}
    results = []
    oc_modes = config.setdefault("ocModes", {})
    for cid in [str(x) for x in targets]:
        row = rows.get(cid)
        if not row:
            results.append({"client": cid, "ok": False, "error": "Masa bulunamadı"})
            continue
        if cid in _locked_clients() and not allow_locked:
            results.append({"client": cid, "ok": False, "locked": True, "error": "Kilitli, dokunulmadı"})
            continue
        if active_only and not row.get("miningActive"):
            results.append({"client": cid, "ok": False, "skipped": True, "error": "Mining aktif değil"})
            continue
        p = verified_profile(cid, mode)
        if not p:
            results.append({"client": cid, "ok": False, "skipped": True, "error": "Doğrulanmış profil yok"})
            continue
        rr = apply_verified_profile_to_client(cid, p, row, allow_locked=allow_locked)
        if rr.get("ok"):
            oc_modes[cid] = mode
        results.append(rr)
    save_json(CONFIG_FILE, config)
    return {"ok": True, "mode": mode, "results": results}

def current_scheduled_profile_mode(now=None):
    now = now or datetime.now().astimezone()
    def hm(v, default):
        m = re.match(r"^(\d{1,2}):(\d{2})$", str(v or ""))
        if not m:
            return default
        return max(0, min(23, int(m.group(1)))) * 60 + max(0, min(59, int(m.group(2))))
    daym = hm(config.get("profileDayStart"), 480)
    nightm = hm(config.get("profileNightStart"), 1320)
    nowm = now.hour * 60 + now.minute
    return ("balanced" if daym <= nowm < nightm else "max") if daym < nightm else ("balanced" if nowm >= daym or nowm < nightm else "max")

def profile_scheduler_tick():
    if not bool(config.get("profileScheduleEnabled", False)):
        return
    now = datetime.now().astimezone()
    mode = current_scheduled_profile_mode(now)
    def hm(v, default):
        m = re.match(r"^(\d{1,2}):(\d{2})$", str(v or ""))
        if not m:
            return default
        return max(0, min(23, int(m.group(1)))) * 60 + max(0, min(59, int(m.group(2))))
    st = read_json(PROFILE_SCHEDULE_STATE_FILE, {})
    key = now.date().isoformat() + ":" + mode
    if str(st.get("key") or "") == key:
        return
    targets = list(config.get("selectedClientIds") or [])
    result = apply_profile_mode(targets, mode, active_only=False, allow_locked=True)
    save_json(PROFILE_SCHEDULE_STATE_FILE, {"key": key, "mode": mode, "appliedAt": now_iso(), "result": result})

def profile_scheduler_loop():
    while True:
        try:
            profile_scheduler_tick()
        except Exception as exc:
            log("Profil scheduler hata: %s" % exc)
        time.sleep(30)

def rest_schedule_state():
    st = read_json(REST_STATE_FILE, {})
    return {"enabled": bool(config.get("restScheduleEnabled", True)), "start": str(config.get("restStart") or "05:00"),
            "durationMinutes": int(to_num(config.get("restDurationMinutes"), 120) or 120), "active": bool(st.get("active")),
            "resumeTargets": list(st.get("resumeTargets") or []), "windowDate": st.get("windowDate"),
            "startedAt": st.get("startedAt"), "resumeAt": st.get("resumeAt"), "lastAction": st.get("lastAction")}

def _rest_window(now=None):
    now = now or datetime.now().astimezone()
    text = str(config.get("restStart") or "05:00")
    m = re.match(r"^(\d{1,2}):(\d{2})$", text)
    hh, mm = (5, 0)
    if m:
        hh = max(0, min(23, int(m.group(1))))
        mm = max(0, min(59, int(m.group(2))))
    start = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
    dur = max(1, min(720, int(to_num(config.get("restDurationMinutes"), 120) or 120)))
    return start, start + timedelta(minutes=dur)

def _dispatch_simple_action(targets, action):
    rows = {str(x.get("clientId")): x for x in merged_clients()}
    local_results, remote = [], []
    for cid in [str(x) for x in targets]:
        row = rows.get(cid)
        if not row:
            continue
        if row.get("localMain"):
            r = local_main_action(action)
            local_results.append({"client": cid, "ok": bool(r.get("ok")), "message": r.get("message"), "error": r.get("error")})
        else:
            remote.append(cid)
    issued = queue_command(remote, action)
    pushes = []
    for cid in remote:
        pr = direct_push(cid, issued.get(cid) or {})
        pushes.append({"client": cid, "ok": bool(pr.get("ok")), "error": pr.get("error")})
    return {"local": local_results, "remote": remote, "directPush": pushes}

def rest_scheduler_tick():
    if not bool(config.get("restScheduleEnabled", True)):
        return
    now = datetime.now().astimezone()
    start, end = _rest_window(now)
    state = read_json(REST_STATE_FILE, {})
    active = bool(state.get("active"))
    in_window = start <= now < end
    if in_window and not active:
        rows = merged_clients()
        selected = set(str(x) for x in (config.get("selectedClientIds") or []))
        targets = [str(r.get("clientId")) for r in rows if str(r.get("clientId")) in selected and r.get("miningActive")]
        result = _dispatch_simple_action(targets, "stop") if targets else {"local": [], "remote": [], "directPush": []}
        save_json(REST_STATE_FILE, {"active": True, "windowDate": start.date().isoformat(), "resumeTargets": targets,
                                   "startedAt": now_iso(), "resumeAt": end.isoformat(), "lastAction": "rest-stop", "result": result})
        return
    if active and now >= end:
        targets = list(state.get("resumeTargets") or [])
        result = _dispatch_simple_action(targets, "start") if targets else {"local": [], "remote": [], "directPush": []}
        save_json(REST_STATE_FILE, {"active": False, "windowDate": state.get("windowDate") or start.date().isoformat(),
                                   "resumeTargets": [], "startedAt": state.get("startedAt"),
                                   "resumeAt": state.get("resumeAt") or end.isoformat(), "completedAt": now_iso(),
                                   "lastAction": "rest-resume", "result": result})

def rest_scheduler_loop():
    while True:
        try:
            rest_scheduler_tick()
        except Exception as exc:
            log("Dinlenme scheduler hata: %s" % exc)
        time.sleep(20)


def state_payload():
    all_clients = merged_clients()

    # v4.0.62: previous UI update could leave the fixed mining set empty.
    # Restore once only; future manual selections remain untouched.
    if not (config.get("selectedClientIds") or []) and not bool(config.get("selectionRecovered4062")):
        wanted = ["MASA-23", "ANA-PC", "MASA-14", "MASA-21", "MASA-22"]
        known = {str(x.get("clientId") or "") for x in all_clients}
        restored = [x for x in wanted if x in known]
        if restored:
            config["selectedClientIds"] = restored
            config["selectionRecovered4062"] = True
            save_json(CONFIG_FILE, config)
            log("v4.0.62 selection recovery: %s" % ",".join(restored))
    with ThreadPoolExecutor(max_workers=5) as ex:
        fp = ex.submit(get_pool_data); fm = ex.submit(get_market_data); ff = ex.submit(get_fx_data)
        fw = ex.submit(wallet_status); fb = ex.submit(bigone_finance_state)
        pool = fp.result(); market = fm.result(); fx = ff.result(); ws = fw.result(); finance = fb.result()

    # Ana PC client heartbeat almadigi icin session integralini state yenilemesinde ornekle.
    for row in all_clients:
        if row.get("localMain"):
            session_sample(row.get("clientId"), bool(row.get("miningActive")), to_num(row.get("hashrateHps")), to_num(row.get("totalPowerW")))

    for row in all_clients:
        row["session"] = session_view(row.get("clientId"), pool, market, fx)
    latency = pool_latency_ms()
    for row in all_clients:
        row["profileState"] = profile_state_for(row.get("clientId"))
        actual_bat = dict(row.get("ocBatProfile") or {})
        if row.get("ocBatVerified") and actual_bat.get("cclock"):
            row["displayBatProfile"] = actual_bat
            row["displayBatVerified"] = True
        else:
            ps = row.get("profileState") or {}
            mode = str(ps.get("currentMode") or "")
            target = verified_profile(row.get("clientId"), mode) or dict(ps.get("pinned") or {})
            row["displayBatProfile"] = target if isinstance(target, dict) else {}
            row["displayBatVerified"] = False
        row["poolValidation"] = pool_validation(row, pool, latency)
        health_sample(row)
        row["health30d"] = health_view(row.get("clientId"))

    selected = set(str(x) for x in (config.get("selectedClientIds") or []))
    selected_rows = [x for x in all_clients if str(x.get("clientId")) in selected]
    mining_clients = [x for x in selected_rows if x.get("miningActive")]
    mining_count = len(mining_clients)
    measured_power_w = sum(max(0.0, to_num(x.get("totalPowerW"))) for x in mining_clients if to_num(x.get("totalPowerW")) > 0)
    measured_count = sum(1 for x in mining_clients if to_num(x.get("totalPowerW")) > 0)
    effective_power_w = measured_power_w
    power_source = "measured-live"

    actual24_prl = max(0.0, to_num(pool.get("actualReward24hPrl")))
    observed = observed_pool_daily_prl(pool)
    avg_est = max(0.0, to_num(pool.get("estimatedDailyPrlAverage")))
    current_est = max(0.0, to_num(pool.get("estimatedDailyPrlCurrent")))
    estimated_prl = current_est or avg_est
    daily_prl = estimated_prl
    daily_prl_source = "2miners-current-estimate" if current_est > 0 else "2miners-average-estimate"
    price = max(0.0, to_num(market.get("priceUsd"))); usd_try = max(0.0, to_num(fx.get("usdTry")))
    prl_try = price * usd_try; gross_usd = daily_prl * price; gross_try = daily_prl * prl_try
    actual24_gross_try = actual24_prl * prl_try
    kwh_price = max(0.0, to_num(config.get("electricityTryKwh")))
    hourly_kwh = effective_power_w / 1000.0; daily_kwh = hourly_kwh * 24.0; monthly_kwh = daily_kwh * 30.0
    electricity_hourly = hourly_kwh * kwh_price; electricity_daily = daily_kwh * kwh_price; electricity_monthly = monthly_kwh * kwh_price
    net_daily = gross_try - electricity_daily; net_weekly = net_daily * 7.0; net_monthly = net_daily * 30.0
    actual24_net_try = actual24_gross_try - electricity_daily
    break_even_prl = electricity_daily / prl_try if prl_try > 0 else 0.0

    session_rows = [x.get("session") or {} for x in selected_rows]
    session_prl = sum(to_num(x.get("estimatedPrl")) for x in session_rows)
    session_energy = sum(to_num(x.get("energyKwh")) for x in session_rows)
    session_gross_try = session_prl * prl_try; session_electricity = session_energy * kwh_price

    total_hash = sum(to_num(x.get("hashrateHps")) for x in mining_clients)
    network_hash = max(0.0, to_num(pool.get("networkHashrate")))
    block_reward = max(0.0, to_num(pool.get("blockRewardPrl")))
    block_sec = max(0.0, to_num(pool.get("avgBlockTimeSec")))
    share_valid = max(0.0, to_num(pool.get("sharesValid")))
    share_bad = max(0.0, to_num(pool.get("sharesInvalid"))) + max(0.0, to_num(pool.get("sharesStale")))
    share_eff = share_valid / (share_valid + share_bad) if (share_valid + share_bad) > 0 else 1.0
    effective_hash_for_model = total_hash * share_eff
    pool_fee_pct = max(0.0, min(100.0, to_num(config.get("twoMinersFeePct"), 1.0)))
    pool_fee_factor = max(0.0, 1.0 - pool_fee_pct / 100.0)
    model_daily_prl_raw = (effective_hash_for_model / network_hash) * (86400.0 / block_sec) * block_reward if effective_hash_for_model > 0 and network_hash > 0 and block_sec > 0 else 0.0
    model_daily_prl = model_daily_prl_raw * pool_fee_factor
    model_gross_try = model_daily_prl * prl_try
    model_net_try = model_gross_try - electricity_daily
    efficiency = total_hash / effective_power_w if effective_power_w > 0 else 0.0
    warnings = []
    for row in selected_rows:
        if not row.get("online"): warnings.append("%s OFFLINE" % row.get("clientId"))
        if to_num(row.get("maxTempC")) >= to_num(config.get("warnTempC"), 85): warnings.append("%s SICAK %.0fC" % (row.get("clientId"), to_num(row.get("maxTempC"))))
        if to_num(row.get("shareRejectPct")) >= 5 and to_num(row.get("acceptedShares"))+to_num(row.get("rejectedShares")) >= 10: warnings.append("%s REJECT %.1f%%" % (row.get("clientId"), to_num(row.get("shareRejectPct"))))

    return {"ok": True, "version": VERSION, "clients": all_clients,
            "selectedClientIds": list(config.get("selectedClientIds") or []), "wallet": str(config.get("wallet", "")),
            "pearlTarget": max(0.0, to_num(config.get("pearlTarget"), 100.0) or 100.0),
            "bigoneDepositAddress": str(config.get("bigoneDepositAddress", "")),
            "binanceUsdtAddress": str(config.get("binanceUsdtAddress", "")), "binanceNetwork": str(config.get("binanceNetworkLabel", "")),
            "pool": pool, "market": market, "fx": fx, "walletState": ws, "bigone": finance,
            "mainPcPower": cached_local_nvidia_power_state() if bool(config.get("includeMainPc", True)) else {"supported": False, "gpus": []},
            "mainPcOc": local_pearl_oc_state() if bool(config.get("includeMainPc", True)) else {"supported": False, "gpus": [], "profiles": []},
            "profit": {"powerW": effective_power_w, "measuredPowerW": measured_power_w, "powerSource": power_source,
                "miningDeviceCount": mining_count, "measuredDeviceCount": measured_count, "totalHashrateHps": total_hash,
                "efficiencyHpsPerW": efficiency, "hourlyKwh": hourly_kwh, "dailyKwh": daily_kwh, "monthlyKwh": monthly_kwh,
                "estimatedDailyPrl": daily_prl, "actual24hPrl": actual24_prl, "estimatedLivePrl": estimated_prl, "dailyPrlSource": daily_prl_source, "prlTry": prl_try,
                "modelDailyPrl": model_daily_prl, "modelDailyPrlRaw": model_daily_prl_raw, "modelGrossTry": model_gross_try, "modelNetTry": model_net_try, "poolFeePct": pool_fee_pct,
                "grossUsd": gross_usd, "grossTry": gross_try, "actual24GrossTry": actual24_gross_try,
                "electricityHourlyTry": electricity_hourly, "electricityTry": electricity_daily, "electricityMonthlyTry": electricity_monthly,
                "netTry": net_daily, "net7Try": net_weekly, "monthlyNetTry": net_monthly, "actual24NetTry": actual24_net_try,
                "breakEvenPrlDaily": break_even_prl, "electricityTryKwh": kwh_price, "usdTry": usd_try,
                "sessionEstimatedPrl": session_prl, "sessionEnergyKwh": session_energy, "sessionGrossTry": session_gross_try,
                "sessionElectricityTry": session_electricity, "sessionNetTry": session_gross_try-session_electricity},
            "limits": {"warnTempC": to_num(config.get("warnTempC")), "hardStopTempC": to_num(config.get("hardStopTempC")),
                       "resumeTempC": to_num(config.get("resumeTempC")), "offlineSeconds": int(config.get("offlineSeconds", 900))},
            "online": sum(1 for x in selected_rows if x.get("online")), "bridges": sum(1 for x in selected_rows if x.get("bridgeReady")),
            "agents": sum(1 for x in selected_rows if x.get("agentConnected")), "mining": mining_count,
            "warnings": warnings[:30], "remoteAccess": tailscale_remote_state(),
            "restSchedule": rest_schedule_state(),
            "profileAutomation": {"enabled": bool(config.get("profileScheduleEnabled", False)),
                "dayMode": "balanced", "nightMode": "max",
                "dayStart": str(config.get("profileDayStart") or "08:00"),
                "nightStart": str(config.get("profileNightStart") or "22:00")},
            "now": now_iso()}


class Handler(BaseHTTPRequestHandler):
    server_version = "KafePinMiningPro/%s" % VERSION

    def log_message(self, fmt, *args):
        return

    def remote_ip(self):
        ip = self.client_address[0] if self.client_address else ""
        return ip[7:] if ip.startswith("::ffff:") else ip

    def loopback(self):
        return self.remote_ip() in ("127.0.0.1", "::1")

    def tailscale_peer(self):
        """Allow direct tailnet access in addition to Tailscale Serve localhost proxy."""
        raw = self.remote_ip()
        try:
            ip = ipaddress.ip_address(raw)
            return ip in ipaddress.ip_network("100.64.0.0/10") or ip in ipaddress.ip_network("fd7a:115c:a1e0::/48")
        except Exception:
            return False

    def admin_access(self):
        return self.loopback() or self.tailscale_peer()

    def json_body(self):
        try:
            length = max(0, min(int(self.headers.get("Content-Length", "0") or 0), 65536))
            raw = self.rfile.read(length).decode("utf-8-sig") if length else "{}"
            return json.loads(raw or "{}")
        except Exception:
            return {}

    def send_json(self, code, payload):
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-KafePin-MiningPro-Version", VERSION)
        self.end_headers()
        self.wfile.write(body)

    def send_html(self, code, text):
        body = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def require_local(self):
        if self.admin_access():
            return True
        self.send_json(403, {"ok": False, "error": "Mining Pro yonetimi yalniz ana makine localhost veya yetkili Tailscale tailnet baglantisindan kabul edilir."})
        return False

    def do_GET(self):
        cleanup_commands()
        path = self.path.split("?", 1)[0].rstrip("/") or "/"
        try:
            if path in ("/", "/index.html"):
                self.send_html(200, (WEB / "index.html").read_text(encoding="utf-8-sig")); return
            if path == "/api/v1/health":
                self.send_json(200, {"ok": True, "app": "KafePin Mining Pro", "version": VERSION,
                                     "auth": "localhost-admin+tailscale-tailnet-admin+known-client-ip", "clientMode": "existing-kafepin-client-bridge+on-demand-runtime",
                                     "port": int(config.get("port", 17897)), "moduleRoot": str(ROOT)}); return
            if not self.require_local():
                return
            if path == "/api/v1/state":
                self.send_json(200, state_payload()); return
            if path == "/api/v1/pool":
                self.send_json(200, get_pool_data()); return
            if path == "/api/v1/market":
                self.send_json(200, get_market_data()); return
            if path == "/api/v1/wallet/status":
                self.send_json(200, wallet_status()); return
            if path == "/api/v1/transfer/log":
                self.send_json(200, {"ok": True, "items": read_json(TRANSFER_LOG_FILE, [])}); return
            if path == "/api/v1/finance/log":
                self.send_json(200, {"ok": True, "items": read_json(FINANCE_LOG_FILE, [])}); return
            self.send_json(404, {"ok": False, "error": "Bulunamadi"})
        except Exception as exc:
            log("GET %s error: %s" % (path, exc))
            self.send_json(500, {"ok": False, "error": str(exc)})

    def do_POST(self):
        cleanup_commands()
        path = self.path.split("?", 1)[0].rstrip("/") or "/"
        body = self.json_body()
        remote_ip = self.remote_ip()
        try:
            if path == "/api/v1/bridge/poll":
                perf = get_client_perf(); match = find_perf_match(perf, remote_ip, body.get("host"), body.get("masa"))
                if not match and not self.loopback():
                    self.send_json(403, {"ok": False, "error": "Bu IP KafePin Client Performans Pro masa listesinde yok."}); return
                cid = str(match.get("name")) if match else (str(body.get("host") or remote_ip))
                with lock:
                    push_port = int(to_num(body.get("pushPort"), 0) or 0)
                    push_key = str(body.get("pushKey") or "")
                    bridges[cid] = {"clientId": cid, "ip": remote_ip, "host": str(body.get("host") or ""),
                                    "masa": str(body.get("masa") or ""), "pushPort": push_port,
                                    "pushKey": push_key, "gpuModels": list(body.get("gpuModels") or []),
                                    "gpuInventory": list(body.get("gpuInventory") or []),
                                    "ocCapable": bool(body.get("ocCapable")),
                                    "clientMiningVersion": str(body.get("miningVersion") or ""),
                                    "ocBatVerified": bool(body.get("ocBatVerified")),
                                    "ocBatProfile": dict(body.get("ocBatProfile") or {}),
                                    "updatedAt": now_iso()}
                    runtime = None
                    for key, row in clients.items():
                        if normalize(key) == normalize(cid) or (remote_ip and str(row.get("ip") or "").strip() == remote_ip):
                            runtime = row; break
                    runtime_fresh = fresh(runtime, int(config.get("runtimeFreshSeconds", 15) or 15))
                    command = commands.get(cid) if (not runtime_fresh and cid in commands) else None
                reply = {"ok": True, "clientId": cid, "runtimeFresh": runtime_fresh, "command": command,
                         "mode": "on-demand", "version": VERSION}
                runtime_version = "4.0.35-RUNTIME14"
                client_runtime_version = str(body.get("runtimeVersion") or "")
                runtime_file = ROOT / "client" / "MiningRuntime.ps1"
                if not runtime_file.is_file():
                    runtime_file = Path(r"C:\KafePin\MiningPro\client\MiningRuntime.ps1")
                if client_runtime_version != runtime_version and runtime_file.is_file():
                    try:
                        reply["runtimeUpdate"] = {"version": runtime_version,
                                                  "scriptB64": base64.b64encode(runtime_file.read_bytes()).decode("ascii")}
                    except Exception as exc:
                        log("Runtime update payload hata: %s" % exc)
                self.send_json(200, reply); return

            if path == "/api/v1/heartbeat":
                perf = get_client_perf(); match = find_perf_match(perf, remote_ip, body.get("host"), body.get("clientId"))
                if not match and not self.loopback():
                    self.send_json(403, {"ok": False, "error": "Bu IP KafePin Client Performans Pro masa listesinde yok."}); return
                reported = str(body.get("clientId") or "")
                cid = str(match.get("name")) if match else (reported if reported and reported != "auto" else str(body.get("host") or remote_ip))
                row = dict(body); row["clientId"] = cid; row["ip"] = remote_ip; row["updatedAt"] = now_iso()
                with lock:
                    clients[cid] = row
                    last_id = str(body.get("lastCommandId") or "")
                    if last_id and cid in commands and str(commands[cid].get("id") or "") == last_id:
                        commands.pop(cid, None)
                    command = commands.get(cid)
                session_sample(cid, bool(body.get("minerOnline")) and to_num(body.get("hashrateHps")) > 0,
                               to_num(body.get("hashrateHps")), to_num(body.get("totalPowerW")))
                save_clients(); save_commands()
                self.send_json(200, {"ok": True, "clientId": cid, "command": command,
                                     "limits": {"warnTempC": to_num(config.get("warnTempC")), "hardStopTempC": to_num(config.get("hardStopTempC")),
                                                "resumeTempC": to_num(config.get("resumeTempC"))}}); return

            if not self.require_local():
                return

            if path == "/api/v1/profile/apply":
                mode = str(body.get("mode") or "").lower()
                targets = body.get("targets") or list(config.get("selectedClientIds") or [])
                if not isinstance(targets, list): targets = [targets]
                self.send_json(200, apply_profile_mode(targets, mode, active_only=bool(body.get("activeOnly", True)), allow_locked=bool(body.get("allowLocked", False)))); return

            if path == "/api/v1/profile/best":
                targets = body.get("targets") or list(config.get("selectedClientIds") or [])
                if not isinstance(targets, list): targets = [targets]
                rows = {str(x.get("clientId")): x for x in merged_clients()}
                results = []
                for cid in [str(x) for x in targets]:
                    if cid in _locked_clients():
                        results.append({"client": cid, "ok": False, "locked": True, "error": "Kilitli, dokunulmadı"}); continue
                    row = rows.get(cid)
                    if not row or not row.get("miningActive"):
                        results.append({"client": cid, "ok": False, "skipped": True, "error": "Mining aktif değil"}); continue
                    mode = str((config.get("ocModes") or {}).get(cid) or "balanced")
                    p = verified_profile(cid, mode) or verified_profile(cid, "balanced") or verified_profile(cid, "max")
                    if not p:
                        results.append({"client": cid, "ok": False, "skipped": True, "error": "Pinned profil yok"}); continue
                    results.append(apply_verified_profile_to_client(cid, p, row))
                self.send_json(200, {"ok": True, "results": results}); return

            if path == "/api/v1/rest/schedule":
                enabled = bool(body.get("enabled"))
                start = str(body.get("start") or config.get("restStart") or "05:00")
                if not re.match(r"^(?:[01]\d|2[0-3]):[0-5]\d$", start):
                    self.send_json(400, {"ok": False, "error": "Dinlenme başlangıç saati HH:MM olmalı"}); return
                duration = max(1, min(720, int(to_num(body.get("durationMinutes"), config.get("restDurationMinutes", 120)) or 120)))
                config["restScheduleEnabled"] = enabled
                config["restStart"] = start
                config["restDurationMinutes"] = duration
                save_json(CONFIG_FILE, config)
                self.send_json(200, {"ok": True, "enabled": enabled, "start": start, "durationMinutes": duration}); return

            if path == "/api/v1/profile/schedule":
                config["profileScheduleEnabled"] = bool(body.get("enabled"))
                if body.get("dayStart"): config["profileDayStart"] = str(body.get("dayStart"))
                if body.get("nightStart"): config["profileNightStart"] = str(body.get("nightStart"))
                save_json(CONFIG_FILE, config)
                self.send_json(200, {"ok": True, "enabled": bool(config.get("profileScheduleEnabled")),
                                     "dayStart": config.get("profileDayStart"), "nightStart": config.get("profileNightStart")}); return

            if path == "/api/v1/oc/apply":
                cid = str(body.get("client") or "").strip()
                if not cid:
                    self.send_json(400, {"ok": False, "error": "Masa zorunlu"}); return
                if cid in _locked_clients():
                    self.send_json(423, {"ok": False, "locked": True, "error": cid + " kilitli; OC değiştirilemez."}); return

                rows = {str(x.get("clientId")): x for x in merged_clients()}
                row = rows.get(cid)
                if not row:
                    self.send_json(404, {"ok": False, "error": "Masa bulunamadi"}); return

                model = str(row.get("primaryGpuModel") or ((row.get("gpuModels") or [""])[0] if row.get("gpuModels") else ""))
                upper = model.upper()
                if "4060 TI" in upper:
                    profile = {"model": "RTX 4060 Ti", "cclock": 2450, "coffset": 200, "mclock": 5001, "plimit": 120}
                elif "3060 TI" in upper:
                    profile = {"model": "RTX 3060 Ti", "cclock": 1500, "coffset": 200, "mclock": 5001, "plimit": 140}
                elif re.search(r"\b3060\b", upper):
                    profile = {"model": "RTX 3060", "cclock": 1500, "coffset": 200, "mclock": 5001, "plimit": 110}
                else:
                    self.send_json(409, {"ok": False, "error": "Desteklenen Pearl OC profili yok: " + (model or "GPU modeli bilinmiyor")}); return

                if row.get("localMain"):
                    inv = local_gpu_inventory()
                    profiles = []
                    for i, gpu in enumerate(inv):
                        gpu_name = str(gpu.get("name") or model)
                        gpu_upper = gpu_name.upper()
                        if "4060 TI" in gpu_upper:
                            gp = {"cclock": 2450, "coffset": 200, "mclock": 5001, "plimit": 120}
                        elif "3060 TI" in gpu_upper:
                            gp = {"cclock": 1500, "coffset": 200, "mclock": 5001, "plimit": 140}
                        elif re.search(r"\b3060\b", gpu_upper):
                            gp = {"cclock": 1500, "coffset": 200, "mclock": 5001, "plimit": 110}
                        else:
                            gp = dict(profile)
                        profiles.append({"gpuId": int(gpu.get("index", i)), "name": gpu_name, **gp})
                    if not profiles:
                        profiles = [{"gpuId": 0, "name": model, **{k:v for k,v in profile.items() if k != "model"}}]
                    result = apply_local_pearl_oc(profiles, restart=True, remove=False)
                    actual = local_bat_oc_state()
                    result["batVerified"] = bool(actual.get("verified"))
                    result["batProfile"] = actual
                    if result.get("ok") and actual.get("verified"):
                        sign = "+" if int(actual.get("coffset") or 0) >= 0 else ""
                        result["message"] = (cid + " • BAT ✓ " + profile["model"] + " • " +
                                             str(actual.get("cclock")) + "/" + sign + str(actual.get("coffset")) + "/" +
                                             str(actual.get("mclock")) + "/" + str(actual.get("plimit")) +
                                             "W • SRBMiner yonetici olarak baslatildi.")
                    elif result.get("ok"):
                        result["ok"] = False
                        result["error"] = "ANA-PC BAT OC dogrulanamadi; islem basarili sayilmadi."
                    self.send_json(200 if result.get("ok") else 409, result); return

                if not row.get("ocCapable") or "HOTFIX10" not in str(row.get("clientMiningVersion") or "").upper():
                    self.send_json(409, {"ok": False, "error": "Bu masada HOTFIX10 Admin + BAT Verified OC client gerekli."}); return

                issued = queue_command([cid], "oc-apply", payload={"profile": profile})
                push = direct_push(cid, issued.get(cid) or {})
                self.send_json(200, {
                    "ok": True, "client": cid, "profile": profile, "directPush": push,
                    "message": cid + " • " + profile["model"] + " profili gonderildi; SRBMiner baslatilacak."
                }); return

            if path == "/api/v1/command":
                action = str(body.get("action") or "")
                if action not in ("start", "stop", "monitor-off"):
                    self.send_json(400, {"ok": False, "error": "Gecersiz komut"}); return
                all_rows = merged_clients(); requested = body.get("targets") or []
                if not isinstance(requested, list): requested = [requested]
                selected_set = set(str(x) for x in (config.get("selectedClientIds") or []))
                if not requested or "*" in requested:
                    requested = list(config.get("selectedClientIds") or []) if action == "start" else [x.get("clientId") for x in all_rows]
                valid, wake, skipped, local_results, remote, pushed = [], [], [], [], [], []
                by_id = {str(x.get("clientId")): x for x in all_rows}
                for item in requested:
                    cid = str(item); row = by_id.get(cid)
                    if not row: continue
                    if action == "start" and cid not in selected_set: skipped.append(cid); continue
                    valid.append(cid)
                    if action == "start":
                        mode = current_scheduled_profile_mode()
                        profile = verified_profile(cid, mode)
                        if row.get("miningActive"):
                            if row.get("localMain"):
                                local_results.append({"client": cid, "ok": True, "message": "Zaten çalışıyor; miner ve oturum korunuyor."})
                            else:
                                pushed.append({"client": cid, "ok": True, "message": "Zaten çalışıyor; miner ve oturum korunuyor."})
                            continue
                        session_reset(cid)
                        if profile:
                            if not row.get("localMain") and not row.get("online"):
                                w = wake_client(cid); wake.append({"client": cid, "ok": bool(w.get("ok")), "error": w.get("error")})
                            rr = apply_verified_profile_to_client(cid, profile, row, allow_locked=True)
                            if row.get("localMain"):
                                local_results.append({"client": cid, "ok": bool(rr.get("ok")), "message": "Kilitli %s profil ile başlatıldı" % mode, "error": rr.get("error")})
                            else:
                                dp = rr.get("directPush") or {}
                                pushed.append({"client": cid, "ok": bool(dp.get("ok")), "error": dp.get("error"), "profileMode": mode})
                            config.setdefault("ocModes", {})[cid] = mode
                            continue
                    if row.get("localMain"):
                        r = local_main_action(action); local_results.append({"client": cid, "ok": bool(r.get("ok")), "message": r.get("message"), "error": r.get("error")})
                        continue
                    remote.append(cid)
                issued = queue_command(remote, action)
                for cid in remote:
                    result = direct_push(cid, issued.get(cid) or {})
                    pushed.append({"client": cid, "ok": bool(result.get("ok")), "error": result.get("error")})
                self.send_json(200, {"ok": True, "action": action, "targets": valid, "wake": wake,
                                     "directPush": pushed, "local": local_results, "skippedNotSelected": skipped}); return

            if path == "/api/v1/wake":
                cid = str(body.get("client") or "").strip()
                if not cid:
                    self.send_json(400, {"ok": False, "error": "Masa zorunlu"}); return
                if normalize(cid) == normalize(config.get("mainPcClientId")):
                    self.send_json(200, {"ok": True, "message": "Ana PC zaten acik."}); return
                r = wake_client(cid); self.send_json(200 if r.get("ok") else 502, r); return

            if path == "/api/v1/wake-mining":
                selected = [str(x) for x in (config.get("selectedClientIds") or []) if str(x).strip()]
                results = []
                for cid in selected:
                    if normalize(cid) == normalize(config.get("mainPcClientId")):
                        results.append({"client": cid, "ok": True, "skipped": True, "message": "Ana PC zaten acik."})
                        continue
                    rr = wake_client(cid)
                    results.append({"client": cid, "ok": bool(rr.get("ok")), "result": rr.get("result"), "error": rr.get("error")})
                self.send_json(200, {"ok": True, "count": len(selected), "sent": sum(1 for x in results if x.get("ok") and not x.get("skipped")), "results": results}); return

            if path == "/api/v1/tailscale/ensure":
                result = ensure_tailscale_serve()
                self.send_json(200 if result.get("ok") else 409, result); return

            if path == "/api/v1/settings/bigone-address":
                addr = str(body.get("address") or "").strip()
                if not valid_pearl_address(addr):
                    self.send_json(400, {"ok": False, "error": "Gecerli bir Pearl prl1... BigONE yatirma adresi gir."}); return
                config["bigoneDepositAddress"] = addr; save_json(CONFIG_FILE, config)
                self.send_json(200, {"ok": True, "address": addr}); return

            if path == "/api/v1/settings/selected-clients":
                requested = body.get("clients")
                if not isinstance(requested, list):
                    self.send_json(400, {"ok": False, "error": "clients listesi zorunlu"}); return
                all_rows = merged_clients()
                known = {str(x.get("clientId")): x for x in all_rows if str(x.get("clientId") or "").strip()}
                selected, unknown, seen = [], [], set()
                for item in requested[:500]:
                    cid = str(item or "").strip()
                    if not cid or cid in seen: continue
                    seen.add(cid)
                    if cid in known: selected.append(cid)
                    else: unknown.append(cid)
                config["selectedClientIds"] = selected
                save_json(CONFIG_FILE, config)
                self.send_json(200, {"ok": True, "clients": selected, "unknown": unknown, "count": len(selected)}); return

            if path == "/api/v1/settings/electricity":
                value = to_num(body.get("tryKwh"), -1)
                if value < 0 or value > 100:
                    self.send_json(400, {"ok": False, "error": "Elektrik birim fiyati 0 ile 100 TL/kWh arasinda olmali."}); return
                config["electricityTryKwh"] = round(value, 6); save_json(CONFIG_FILE, config)
                self.send_json(200, {"ok": True, "tryKwh": config["electricityTryKwh"]}); return

            if path == "/api/v1/settings/device-power":
                value = to_num(body.get("watts"), -1)
                if value < 1 or value > 1000:
                    self.send_json(400, {"ok": False, "error": "Cihaz gucu 1 ile 1000 W arasinda olmali."}); return
                config["defaultDevicePowerW"] = round(value, 2); save_json(CONFIG_FILE, config)
                self.send_json(200, {"ok": True, "watts": config["defaultDevicePowerW"]}); return

            if path == "/api/v1/local-pearl-oc":
                remove = bool(body.get("remove"))
                restart = body.get("restart") is not False
                profiles = body.get("profiles") or []
                result = apply_local_pearl_oc(profiles, restart=restart, remove=remove)
                self.send_json(200 if result.get("ok") else 409, result); return

            if path == "/api/v1/local-cmd-telemetry/enable":
                result = restart_local_miner_for_cmd_logging()
                self.send_json(200 if result.get("ok") else 409, result); return

            if path == "/api/v1/local-power-limit":
                reset = bool(body.get("reset"))
                watts = to_num(body.get("watts"), 0)
                result = set_local_nvidia_power_limit(watts, reset=reset)
                self.send_json(200 if result.get("ok") else 409, result); return

            if path == "/api/v1/settings/binance":
                addr = str(body.get("address") or "").strip()
                if not valid_evm_address(addr):
                    self.send_json(400, {"ok": False, "error": "Gecerli 0x... Binance USDT BEP20 adresi gir."}); return
                config["binanceUsdtAddress"] = addr; config["binanceNetworkLabel"] = "BEP20 (BSC)"; config["binanceGatewayName"] = "BinanceSmartChain"
                save_json(CONFIG_FILE, config); self.send_json(200, {"ok": True, "address": addr, "network": "BEP20 (BSC)"}); return

            if path == "/api/v1/settings/bigone-token":
                if bool(body.get("clear")):
                    save_bigone_credentials("", "")
                else:
                    api_key = str(body.get("apiKey") or "").strip()
                    api_secret = str(body.get("apiSecret") or "").strip()
                    if len(api_key) < 8 or len(api_secret) < 16:
                        self.send_json(400, {"ok": False, "error": "BigONE API Key veya API Secret gecersiz/gereksiz kisa."}); return
                    save_bigone_credentials(api_key, api_secret)
                with lock: mem_cache.pop("bigone_auth_state", None)
                self.send_json(200, {"ok": True, "configured": bool(load_bigone_credentials())}); return

            if path == "/api/v1/bigone/sell/prepare":
                amount = to_num(body.get("amount"));
                if str(body.get("mode") or "") == "all": amount = to_num(bigone_finance_state().get("pearl", {}).get("available"))
                self.send_json(200, bigone_sell_preview(amount)); return

            if path == "/api/v1/bigone/sell":
                if str(body.get("confirm") or "") != "SAT": self.send_json(400, {"ok": False, "error": "Gercek satis icin SAT onayi zorunlu."}); return
                amount = to_num(body.get("amount"));
                if str(body.get("mode") or "") == "all": amount = to_num(bigone_finance_state().get("pearl", {}).get("available"))
                self.send_json(200, bigone_market_sell(amount)); return

            if path == "/api/v1/bigone/withdraw/prepare":
                amount = to_num(body.get("amount"));
                if str(body.get("mode") or "") == "all": amount = bigone_safe_all_usdt()
                self.send_json(200, bigone_withdraw_preview(amount)); return

            if path == "/api/v1/bigone/withdraw":
                if str(body.get("confirm") or "") != "AKTAR": self.send_json(400, {"ok": False, "error": "Gercek Binance aktarimi icin AKTAR onayi zorunlu."}); return
                amount = to_num(body.get("amount"));
                if str(body.get("mode") or "") == "all": amount = bigone_safe_all_usdt()
                self.send_json(200, bigone_withdraw(amount)); return

            if path == "/api/v1/bigone/sell-transfer":
                if str(body.get("confirm") or "") != "SAT+AKTAR": self.send_json(400, {"ok": False, "error": "Gercek zincir icin SAT+AKTAR onayi zorunlu."}); return
                amount = to_num(body.get("amount"));
                if str(body.get("mode") or "") == "all": amount = to_num(bigone_finance_state().get("pearl", {}).get("available"))
                before = to_num(bigone_finance_state().get("usdt", {}).get("available")); sold = bigone_market_sell(amount)
                after = before
                for _ in range(15):
                    time.sleep(1); 
                    with lock: mem_cache.pop("bigone_auth_state", None)
                    after = to_num(bigone_finance_state().get("usdt", {}).get("available"))
                    if after > before + 0.000001: break
                gateway = bigone_gateway_info(); fee = to_num(gateway.get("feeUsdt"))
                sale_delta = max(0.0, after - before)
                transferable = max(0.0, sale_delta - max(0.0, fee))
                if transferable <= 0 or sale_delta <= 0:
                    self.send_json(202, {"ok": True, "sold": sold, "withdrawal": None, "message": "Satis emri verildi; USDT bakiye henuz kesinlesmedi. AKTAR butonunu kullan."}); return
                wd = bigone_withdraw(transferable)
                self.send_json(200, {"ok": True, "sold": sold, "withdrawal": wd}); return

            if path == "/api/v1/auto-policy":
                config["autoOnlyWhenCafeEmpty"] = bool(body.get("enabled")); save_json(CONFIG_FILE, config)
                self.send_json(200, {"ok": True, "enabled": config["autoOnlyWhenCafeEmpty"]}); return

            if path == "/api/v1/transfer/prepare":
                amount = to_num(body.get("amount")); addr = str(config.get("bigoneDepositAddress") or "").strip()
                if amount <= 0:
                    self.send_json(400, {"ok": False, "error": "Miktar 0 dan buyuk olmali."}); return
                if not valid_pearl_address(addr):
                    self.send_json(400, {"ok": False, "error": "Once BigONE Pearl yatirma adresini kaydet."}); return
                ws = wallet_status()
                self.send_json(200, {"ok": True, "asset": "PRL", "amount": amount, "address": addr, "network": "Pearl",
                                     "feeRatePrlPerKb": to_num(config.get("feeRatePrlPerKb"), 0.00001), "wallet": ws,
                                     "warning": "Sonraki GONDER adimi gercek zincir islemi yapar. Adres ve miktari tekrar kontrol et."}); return

            if path == "/api/v1/transfer/send":
                amount = to_num(body.get("amount")); confirm = str(body.get("confirm") or ""); addr = str(config.get("bigoneDepositAddress") or "").strip()
                if confirm != "GONDER":
                    self.send_json(400, {"ok": False, "error": "Gercek gonderim icin GONDER onayi zorunlu."}); return
                if amount <= 0 or not valid_pearl_address(addr):
                    self.send_json(400, {"ok": False, "error": "Miktar veya BigONE adresi gecersiz."}); return
                ws = wallet_status()
                if not ws.get("ok"):
                    self.send_json(409, {"ok": False, "error": "Pearl wallet RPC hazir degil. Resmi Pearl Wallet/Oyster acik olmali.", "detail": ws.get("error")}); return
                if to_num(ws.get("balancePrl")) < amount:
                    self.send_json(400, {"ok": False, "error": "Pearl wallet bakiyesi yetersiz.", "balancePrl": ws.get("balancePrl")}); return
                fee = to_num(config.get("feeRatePrlPerKb"), 0.00001)
                r = invoke_prlctl(["--wallet", "sendtoaddress", addr, ("%.8f" % amount).rstrip("0").rstrip("."), ("%.8f" % fee).rstrip("0").rstrip(".")])
                if not r.get("ok"):
                    msg = str(r.get("error") or "")
                    if re.search(r"locked|walletpassphrase", msg, re.I):
                        self.send_json(409, {"ok": False, "error": "Pearl wallet kilitli. Resmi Pearl Wallet/Oyster icinde kilidi acip tekrar dene.", "detail": msg}); return
                    self.send_json(502, {"ok": False, "error": "Pearl transferi basarisiz.", "detail": msg}); return
                tx = str(r.get("output") or "").strip(); entry = {"amountPrl": amount, "tx": tx, "destination": addr, "feeRatePrlPerKb": fee, "createdAt": now_iso()}
                items = read_json(TRANSFER_LOG_FILE, []); items = ([entry] + (items if isinstance(items, list) else []))[:100]; save_json(TRANSFER_LOG_FILE, items)
                self.send_json(200, {"ok": True, "tx": tx, "entry": entry}); return

            self.send_json(404, {"ok": False, "error": "Bulunamadi"})
        except Exception as exc:
            log("POST %s from %s error: %s" % (path, remote_ip, exc))
            self.send_json(500, {"ok": False, "error": str(exc)})


class MiningHTTPServer(ThreadingHTTPServer):
    # v4.0.51: 17897 yalniz Mining backend portudur.
    # Tailscale HTTPS ayri 18443 portundadir. Normal bind kullanilir.
    allow_reuse_address = False
    daemon_threads = True


def _windows_port_diagnostic(port):
    if os.name != "nt":
        return ""
    parts = []
    for args in (["netstat", "-ano", "-p", "tcp"],
                 ["netsh", "interface", "ipv4", "show", "excludedportrange", "protocol=tcp"]):
        try:
            cp = subprocess.run(args, capture_output=True, text=True, timeout=6, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            text = (cp.stdout or cp.stderr or "").strip()
            if text:
                parts.append(" ".join(text.splitlines()[-40:]))
        except Exception:
            pass
    return " | ".join(parts)


def main():
    port = int(config.get("port", 17897))
    try:
        if os.name == "nt":
            log("SRBMiner BAT/API/log/OC preparation is delegated to elevated desktop helper.")
        server = MiningHTTPServer(("0.0.0.0", port), Handler)
        log("Mining Pro v%s started 0.0.0.0:%d root=%s tailscaleHttps=%s" % (VERSION, port, ROOT, config.get("tailscaleHttpsPort", 18443)))
        threading.Thread(target=ensure_tailscale_serve, name="MiningProTailscaleServe", daemon=True).start()
        threading.Thread(target=rest_scheduler_loop, name="MiningProRestScheduler", daemon=True).start()
        threading.Thread(target=profile_scheduler_loop, name="MiningProProfileScheduler", daemon=True).start()
        server.serve_forever(poll_interval=0.5)
    except OSError as exc:
        detail = _windows_port_diagnostic(port)
        log("FATAL start error port=%d errno=%s winerror=%s: %s%s" % (port, getattr(exc, "errno", ""), getattr(exc, "winerror", ""), exc, (" | " + detail) if detail else ""))
        raise
    except Exception as exc:
        log("FATAL start error port=%d: %s" % (port, exc))
        raise


if __name__ == "__main__":
    main()
