@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Repair-And-Start-MiningPRO.ps1"
echo.
echo KafePin Mining Pro repair finished. Check the message above.
pause
exit /b %errorlevel%
