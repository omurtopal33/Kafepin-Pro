param([string]$Action = 'prepare-restart')
$ErrorActionPreference = 'Stop'
$reqPath = 'C:\ProgramData\KafePinPro\mainpc-mining-start.request'
$resPath = 'C:\ProgramData\KafePinPro\mainpc-mining-start.result'
$profilePath = 'C:\KafePinPro\MiningPRO\data\pearl-oc-profile.json'
function Reply($requestId,$success,$errorMessage) {
  $tempPath = $resPath + '.tmp'
  @{id=$requestId;ok=[bool]$success;error=[string]$errorMessage;time=(Get-Date).ToString('o')} | ConvertTo-Json -Compress | Set-Content -LiteralPath $tempPath -Encoding UTF8
  Move-Item -LiteralPath $tempPath -Destination $resPath -Force
  Remove-Item -LiteralPath $reqPath -Force -ErrorAction SilentlyContinue
}
$requestId = ''
try {
  $request = Get-Content -LiteralPath $reqPath -Raw | ConvertFrom-Json
  $requestId = [string]$request.id
  $bat = [string]$request.bat
  if (!$bat -or !(Test-Path -LiteralPath $bat)) { throw 'SRBMiner BAT dosyasi bulunamadi.' }
  if (!(Test-Path -LiteralPath $profilePath)) { throw 'GPU OC profil dosyasi bulunamadi.' }
  $profiles = (Get-Content -LiteralPath $profilePath -Raw | ConvertFrom-Json).profiles
  if (!$profiles -or @($profiles).Count -ne 1) { throw 'ANA-PC icin tek GPU OC profili gerekli.' }
  $p = @($profiles)[0]
  if ((([int]$p.cclock -ne 0) -and ([int]$p.cclock -lt 300 -or [int]$p.cclock -gt 3500)) -or [int]$p.mclock -lt 300 -or [int]$p.mclock -gt 15000 -or [int]$p.plimit -lt 25 -or [int]$p.plimit -gt 600) { throw 'OC profil sinirlari gecersiz.' }
  $text = Get-Content -LiteralPath $bat -Raw
  $lines = $text -split '\r?\n'
  $index = -1
  for ($i=0;$i -lt $lines.Count;$i++) { if ($lines[$i] -match '(?i)SRBMiner-MULTI\.exe' -and $lines[$i] -notmatch '^\s*(rem\s|::)') { $index=$i; break } }
  if ($index -lt 0) { throw 'BAT icinde SRBMiner komutu yok.' }
  $pattern = '(?i)\s+--gpu-(?:id|cclock0?|coffset0?|coff|mclock0?|plimit0?)\s+("[^"]*"|\S+)'
  $line = [regex]::Replace($lines[$index],$pattern,'')
  $line = [regex]::Replace($line,'(?i)\s+--(?:api-enable|extended-log)(?=\s|$)|\s+--(?:api-port|log-file|log-file-mode)\s+("[^"]*"|\S+)','')
  $line += ' --gpu-id 0'
  if ([int]$p.cclock -gt 0) { $line += ' --gpu-cclock0 ' + [int]$p.cclock }
  $line += ' --gpu-coffset0 ' + [int]$p.coffset + ' --gpu-mclock0 ' + [int]$p.mclock + ' --gpu-plimit0 ' + [int]$p.plimit
  $line += ' --api-enable --api-port 21550 --log-file "C:\ProgramData\KafePinPro\srbminer-console.log" --log-file-mode 1 --extended-log'
  $backup = $bat + '.before-oc-admin.bak'
  if (!(Test-Path -LiteralPath $backup)) { Copy-Item -LiteralPath $bat -Destination $backup }
  $lines[$index]=$line
  [System.IO.File]::WriteAllText($bat,($lines -join "`r`n"),[System.Text.UTF8Encoding]::new($false))
  $verify = Get-Content -LiteralPath $bat -Raw
  $verifyFlags=@('--gpu-coffset0 ' + [int]$p.coffset,'--gpu-mclock0 ' + [int]$p.mclock,'--gpu-plimit0 ' + [int]$p.plimit)
  if ([int]$p.cclock -gt 0) { $verifyFlags += '--gpu-cclock0 ' + [int]$p.cclock }
  elseif ($verify -match '(?i)(?:^|\s)--gpu-cclock0\s+\S+') { throw 'BAT OC dogrulama basarisiz: fixed core kaldirilmadi' }
  foreach ($flag in $verifyFlags) { if (!$verify.Contains($flag)) { throw ('BAT OC dogrulama basarisiz: '+$flag) } }
  if ($Action -ne 'prepare-only' -and [string]$request.action -ne 'prepare-only') {
    $exe = Join-Path (Split-Path $bat) 'SRBMiner-MULTI.exe'
    if (!(Test-Path $exe)) { throw 'SRBMiner-MULTI.exe yok.' }
    Get-Process -Name 'SRBMiner-MULTI' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Get-CimInstance Win32_Process -Filter "Name='cmd.exe'" -ErrorAction SilentlyContinue |
      Where-Object { $_.CommandLine -match '(?i)start-mining-pearl\.bat' } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 1
    Start-Process -FilePath 'cmd.exe' -ArgumentList @('/d','/c',('"' + $bat + '"')) -WorkingDirectory (Split-Path $bat) -Verb RunAs -WindowStyle Normal
  }
  Reply $requestId $true ''
} catch { Reply $requestId $false $_.Exception.Message }
