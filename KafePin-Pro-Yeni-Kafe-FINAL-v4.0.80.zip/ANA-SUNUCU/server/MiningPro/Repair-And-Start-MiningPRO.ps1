﻿# KafePin Mining Pro v4.0.51. Cafe main PC only.
# Manual targeted recovery: healthy Mining is left intact; otherwise only
# Python/pythonw listeners on TCP 17897 are stopped. No other PRO is touched.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$service = Join-Path $root 'web_service.py'
$port = 17897
$log = Join-Path $root 'logs\manual-repair.log'
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $log) | Out-Null
function Write-Diag([string]$message) {
    Write-Host $message
    try { Add-Content -LiteralPath $log -Value ((Get-Date).ToString('o')+' '+$message) -Encoding UTF8 } catch {}
}
function Test-MiningHealth {
    try {
        $health = Invoke-RestMethod -Uri ('http://127.0.0.1:17897/api/v1/health?_='+[DateTime]::UtcNow.Ticks) -TimeoutSec 3
        return (($health.ok -eq $true) -and ($health.app -eq 'KafePin Mining Pro'))
    } catch { return $false }
}
try {
    if (Test-MiningHealth) {
      Write-Diag 'SUCCESS: Mining Pro backend 17897 already healthy.'
      $tsScript = Join-Path $root 'Ensure-Tailscale.ps1'
      if(Test-Path -LiteralPath $tsScript){ try { & $tsScript | Out-Null; Write-Diag 'SUCCESS: Tailscale HTTPS 18443 refreshed.' } catch { Write-Diag ('WARN: Tailscale refresh: '+$_.Exception.Message) } }
      exit 0
    }
    if (-not (Test-Path -LiteralPath $service -PathType Leaf)) { throw ('Missing Mining service: '+$service) }
    $cleanup = Join-Path $root 'Repair-Mining-Listener.ps1'
    if (-not (Test-Path -LiteralPath $cleanup)) { throw ('Missing listener repair script: '+$cleanup) }
    & $cleanup
    if ($LASTEXITCODE -ne 0) { throw ('Port repair failed. Exit='+$LASTEXITCODE+'; inspect 17897 ownership') }
    $candidates = @(
      (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\python.exe'),
      (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'),
      (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python311\python.exe')
    )
    $py = $null
    foreach($candidate in $candidates) { if(Test-Path -LiteralPath $candidate -PathType Leaf) {$py=$candidate; break} }
    if (-not $py) {
      $cmd=Get-Command python.exe -ErrorAction SilentlyContinue
      if($cmd) {$py=$cmd.Source}
    }
    if (-not $py) { throw 'Python 3 interpreter could not be found on this computer.' }
    Write-Diag ('Starting Mining with '+$py)
    $p = Start-Process -FilePath $py -ArgumentList @('-B',('"'+$service+'"')) -WorkingDirectory $root -WindowStyle Hidden -PassThru
    Write-Diag ('Mining process launched, PID='+$p.Id)
    for ($i = 0; $i -lt 48; $i++) {
       Start-Sleep -Milliseconds 250
       if(Test-MiningHealth) {
         Write-Diag 'SUCCESS: Mining Pro localhost:17897/ is healthy.'
         $tsScript = Join-Path $root 'Ensure-Tailscale.ps1'
         if(Test-Path -LiteralPath $tsScript){ try { & $tsScript | Out-Null; Write-Diag 'SUCCESS: Tailscale HTTPS 18443 refreshed.' } catch { Write-Diag ('WARN: Tailscale refresh: '+$_.Exception.Message) } }
         exit 0
       }
       try {$p.Refresh(); if ($p.HasExited) { break }} catch {}
    }
    Write-Diag 'ERROR: Mining health not ready after bounded wait.'
    $serviceLog=Join-Path $root 'logs\mining-pro.log'
    if(Test-Path -LiteralPath $serviceLog) {
       Get-Content -LiteralPath $serviceLog -Tail 12 | ForEach-Object { Write-Diag ([string]$_) }
    }
    exit 1
}
catch { Write-Diag ('ERROR: '+$_.Exception.Message); exit 2 }
