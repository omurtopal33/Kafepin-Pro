from pathlib import Path
import json
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import web_service as ws

mode = (sys.argv[1] if len(sys.argv) > 1 else "balanced").strip().lower()
if mode not in ("balanced", "max"):
    raise SystemExit("mode must be balanced or max")

# Scheduled profile application is the only trusted path allowed to bypass manual OC locks.
ws._locked_clients = lambda: set()

targets = [str(x) for x in (ws.config.get("selectedClientIds") or [])]
rows = {str(x.get("clientId")): x for x in ws.merged_clients()}
results = []

for cid in targets:
    profile = ws.verified_profile(cid, mode)
    if not profile:
        results.append({"client": cid, "ok": False, "error": "verified profile missing"})
        continue
    row = rows.get(cid)
    if not row:
        results.append({"client": cid, "ok": False, "error": "client missing"})
        continue
    result = ws.apply_verified_profile_to_client(cid, profile, row)
    results.append(result)
    if result.get("ok"):
        ws.config.setdefault("ocModes", {})[cid] = mode

ws.save_json(ws.CONFIG_FILE, ws.config)
print(json.dumps({"mode": mode, "targets": targets, "results": results}, ensure_ascii=False))
