﻿$ErrorActionPreference='Stop'
$localPort=17897
$httpsPort=18443
$ts=(Get-Command tailscale.exe -ErrorAction SilentlyContinue)
if(-not $ts){
  $candidate=Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
  if(Test-Path -LiteralPath $candidate){$ts=Get-Item -LiteralPath $candidate}
}
if(-not $ts){throw 'Tailscale bulunamadi. Ana KafePin PCye Tailscale kurup tailnete giris yap.'}
$exe=$ts.Source
if(-not $exe){$exe=$ts.FullName}
$status=& $exe status --json 2>&1
if($LASTEXITCODE -ne 0){throw ('Tailscale bagli degil: '+($status -join ' '))}
# v4.0.51: Eski hatali 17897 HTTPS Serve kuralini yalniz o port icin kapat.
# Diger Tailscale Serve/Funnel ayarlarina dokunma.
try { & $exe serve --https=17897 off 2>&1 | Out-Null } catch {}

& $exe serve --bg --yes --https=$httpsPort "http://127.0.0.1:$localPort" 2>&1
if($LASTEXITCODE -ne 0){throw 'Tailscale Serve 18443 etkinlestirilemedi. Tailnet HTTPS/Serve iznini bir kez etkinlestir.'}
Write-Host ('TAMAM: Mining Pro backend 17897, Tailscale HTTPS '+$httpsPort+' olarak yayinlandi.') -ForegroundColor Green
exit 0
