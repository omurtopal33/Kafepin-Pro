# KafePin Mining Pro v4.0.36 PRO TEK PENCERE TEST

## Kurulum
KafePin ana makinesinde bu ZIP güncellemesini kurun. Client tarafı HOTFIX8 FINAL olarak kilitlidir; yeniden client image yazılmaz.

Mining Pro modülü `C:\KafePinPro\MiningPRO` altına senkronlanır. Merkez yalnız Mining Pro açıldığında 17897/TCP üzerinde çalışır.

## v4.0.36
- 15 dakika bağlantı yoksa OFFLINE.
- Runtime telemetrisi bayatsa eski miner/Watt/sıcaklık aktif sayılmaz.
- Ana KafePin PC, ANA-PC olarak seçim listesine dahil.
- Oturum bazlı tahmini PRL, enerji ve elektrik sonrası net kâr.
- 2Miners gerçek unpaid/payout ayrı gösterilir.
- BigONE PEARL MARKET SAT, USDT bakiyesi ve Binance BEP20 AKTAR hazır.
- Binance adresi: panelde kayıtlı hedef, ağ BEP20 (BSC).
- BigONE API token Windows DPAPI ile ayrı credential dosyasında şifreli tutulur, frontend'e geri dönmez.
- BigONE withdrawal için adresin BigONE whitelist'inde olması gerekir.
- SAT / AKTAR / SAT+AKTAR gerçek para hareketidir ve kullanıcı onayı olmadan çağrılmaz.
- Client güncellemesi yok.


## Tailscale uzaktan erişim
Ana KafePin PC'de Tailscale kurulu ve aynı tailnet'e giriş yapılmışsa Mining Pro merkez açılırken Tailscale Serve otomatik denenir. Public Funnel kullanılmaz. Panel yerel 17897 servisini tailnet içinde HTTPS 17897 üzerinden yayınlar. Tailnet HTTPS/Serve ilk kez izin istiyorsa Tailscale hesabında bir defa etkinleştirmen gerekir. Panelde oluşan HTTPS adresi görünür.


## v4.0.38 iOS KafePin Admin
- KafePin masaustu acilirken yalniz Mining Pro MERKEZ servisi ve Tailscale erisimi hazirlanir.
- SRBMiner veya client mining runtime otomatik baslatilmaz.
- Mevcut C:\KafePin\public\admin.html yerinde patch edilir; eski Admin dosyasi komple overwrite edilmez.
- iOS KafePin Admin'de `⛏ Mining Pro` butonu gorunur.
- Tailscale/MagicDNS ile acilan Admin'den ayni hostun HTTPS 17897 Mining Pro sayfasina gecilir.
- ANA-PC ve secili client mining makineleri ayni paneldedir.
- Client HOTFIX8 final degismez.


## v4.0.39 Admin Sekmesi PRO
- KafePin Admin panel switcher içine gerçek `⛏ MINING PRO` sekmesi eklenir.
- Sekme iframe durumunu korur; başka Admin sekmesine geçip dönünce Mining Pro yeniden kurulmaz.
- Tailscale Serve/MagicDNS HTTPS üzerinden tam yönetim yapılabilir.
- Doğrudan 100.64.0.0/10 veya Tailscale IPv6 erişimi için backend yönetim yetkisi yalnız tailnet IP aralığına açılır.
- Normal LAN cihazları Mining Pro yönetim/finans API'sini kullanamaz; client heartbeat/poll yolları çalışmaya devam eder.
- ANA-PC ve seçili clientlar aynı paneldedir.
- Client HOTFIX8 final değişmez.


## v4.0.40 ANA-PC Başlatma Düzeltmesi
- ANA-PC miner BAT, Windows ShellExecute `open` ile açılır.
- BAT'in kendi klasörü working directory olarak kullanılır.
- Explorer'da çift tıklama davranışıyla eşleştirilmiştir.
- Client tarafında değişiklik yoktur.


## v4.0.41 ANA-PC Monitör
- ANA-PC mining başlatıldığında monitör otomatik uyutulmaz.
- Ana yönetim bilgisayarının ekranı açık kalır.
- Client tarafında dosya değişikliği yoktur.


## v4.0.42 Açılmama / Self-Heal
- Health JSON sürüm kontrolü boşluk/format farklarından etkilenmez.
- Çalışan doğru Mining Pro servisi yanlışlıkla öldürülmez.
- Aynı anda birden fazla başlatma girişimi tekilleştirilir.
- Eski listener temizlenirken 17897 portunun gerçekten kapanması beklenir.
- İlk deneme başarısızsa yalnız bir kez otomatik recovery uygulanır.
- ANA-PC monitör açık kalma davranışı korunur.


## v4.0.43 PRO Stabilite
- Ana KafePin arayüzü hiçbir PRO servisinin başlamasını beklemez.
- Açılışta toplu PRO servis kapatma/yeniden başlatma yoktur.
- Çalışan servis korunur, yalnız eksik servis arka planda başlatılır.
- 30 saniyelik hafif watchdog yalnız düşen PRO servisini self-heal eder.
- Başlangıç PRO kontrolü kullanıcı arayüzünü kilitlemez.


## v4.0.44 UI Tıklama Stabilitesi
- Ana pencere görünür olur olmaz mesaj döngüsü serbest bırakılır.
- PRO/Mining startup işleri worker thread üzerinde çalışır.
- Admin entegrasyon PowerShell artık UI'de beklenmez.
- Mining port cleanup ve firewall kontrolü UI thread dışında.
- WhatsApp/Telegram startup pre-warm kaldırıldı; ilk tıklamada lazy-load.


## v4.0.45 Update Lifecycle + Mining Singleton
- `Kurulum devam ediyor...` yalnız gerçek updater/supervisor varken aktif kalır.
- Hedef sürüm çalışıyor ve gerçek updater yoksa stale lock otomatik başarıyla temizlenir.
- Mining 17897 eski Python listener temizliğinde PowerShell `$PID` kullanılmaz; `$ownerPid` kullanılır.
- Windows'ta Mining Pro 17897 exclusive bind ile tek instance olur.
- Core fix `C:\KafePin\server.js` dosyasını yerinde ve idempotent düzeltir; başka değişiklikleri ezmez.
- Client HOTFIX8 değiştirilmez.


## v4.0.46 ANA-PC Gerçek Çift Tık + BigONE
- ANA-PC yalnız `C:\SRBMiner-Multi-3-7-9-win64\SRBMiner-Multi-3-7-9\start-mining-pearl.bat` çalıştırır.
- KafePin masaüstü BAT'i HOTFIX8 ile aynı `ProcessStartInfo + UseShellExecute=true + Verb=open` yoluyla açar.
- Working directory `C:\SRBMiner-Multi-3-7-9-win64\SRBMiner-Multi-3-7-9` sabittir.
- ANA-PC monitörü mining/toplu monitor-off sırasında kapanmaz.
- BigONE `PEARL-USDT` canlı fiyat + fallback/cache + TL/net kâr korunur.
- `Kurulum devam ediyor...` alt uyarısı kilitliyken gizlenir.


## v4.0.47 Mining Pro Anında Açılış
- Mining Pro düğmesi health/self-heal sonucunu beklemez.
- Görünüm tıklamayla hemen açılır.
- Servis/self-heal/firewall/Admin entegrasyonu arka planda hazırlanır.
- Servis hazır olunca Mining URL otomatik yeniden yüklenir.
- Açılış hatası modal pencereyle kullanıcıyı durdurmaz.


## v4.0.48 Mining Ready-Gated Reconnect
- Mining Pro seçilince 17897 hazır olmadan WebView'e URL verilmez.
- Kullanıcı hemen `Mining Pro bağlanıyor...` görünümünü görür.
- Health hazır olunca panel otomatik açılır.
- Mining bağlantısı düşerse genel `KafePin ekranı yüklenemedi` ekranına geçmez.
- Mining kendi otomatik reconnect/self-heal akışında kalır.


## v4.0.49
- Sağlıklı Mining Pro eski sürüm olsa da panel açılır, sürüm uyuşmazlığı açılışa engel değildir.
- Bağlantı başarısızlığında süresiz splash yerine Mining Yeniden Dene ve hata günlüğü.
- Startup/Click kopyalama tek kilitle koordine edilir.

**Tanılama:** sorun devam ederse `C:\KafePinPro\MiningPRO\Diagnose-MiningPro.cmd` açılır; `Public\Documents\KafePin-Mining-Diagnose.txt` oluşur. Script hiçbir servisi durdurmaz/başlatmaz.


## v4.0.50 Mining Pro + PRO Yenile
- PRO Servisleri yenile raporunda Mining Pro 17897 sagligi gorunur.
- Servis saglikliysa ellemez; durmussa onarimi arka planda yapar.
- 17897 Python listener temizleme PowerShell ayrik script ile yapilir.
- Mining Yeniden Dene artik dogrudan Mining reconnect calistirir.
- Ayrintili tanilama: MiningPro\Diagnose-MiningPro.cmd.


### Tek tıklamalık 17897 onarım
PRO yenilemesi de çalışmıyorsa ana PC'de yalnız bir defa
`C:\KafePinPro\MiningPRO\Repair-And-Start-MiningPRO.cmd` çalıştır.
Sağlıklı servise dokunmaz. Bozuk 17897 Python listener'larını kontrollü temizler,
Mining'i başlatıp health sonucunu gösterir. Diğer PRO'lara dokunmaz.


## v4.0.51 Mining Port Çakışması Kök Fix
- Mining backend yalnız `17897` kullanır.
- Tailscale HTTPS yalnız `18443` kullanır ve `127.0.0.1:17897` backend'e proxy eder.
- Eski Tailscale HTTPS `17897` Serve kaydı yalnız o port için kapatılır.
- Admin HTTPS/Tailscale Mining URL artık `https://<host>:18443/`.
- Local Mining URL `http://127.0.0.1:17897/`.

## v4.0.52 UI + Direkt Telemetri + ANA-PC Watt
- Üst OFFLINE uyarıları kaldırıldı; seçili masa sırası sabit.
- BigONE PEARL fiyatı yukarı eklendi.
- SRBMiner DIRECT telemetri kaynağı görünür.
- ANA-PC gerçek NVIDIA `nvidia-smi -pl` watt kontrolü var.
- v4.0.51 açılış/17897/18443 mimarisine dokunulmadı.


## v4.0.53 ANA-PC SRBMiner CMD LOG
- Aynı `start-mining-pearl.bat` dosyası kullanılır.
- SRBMiner resmi `--log-file` parametresi otomatik eklenir.
- Panel ANA-PC değerlerini CMD Statistics satırlarından okur.
- Miner kurulum anında zaten açıksa **CMD Verisini Etkinleştir** düğmesine bir kez bas.

## v4.0.54 Pearl OC + Yönetici
- GPU modeli otomatik tanınır: RTX 3060 / 3060 Ti / 4060 Ti.
- Her modele kendi Pearl OC profili uygulanır.
- Her kart satırı ayrıca elle değiştirilebilir.
- **Başlat** ve **Uygula + Yönetici Olarak Yeniden Başlat** Windows UAC `runas` kullanır.

## v4.0.55 Satır Donanım + OC
- Monitör yanında GPU modeli ve OC düğmesi görünür.
- Uzak OC için v4.0.32 HOTFIX9 client gerekir.
- ANA-PC CMD telemetry BAT hazırlama UAC yönetici helper ile yapılır.

## v4.0.56 Donanım PRO GPU Kaynağı
- Mining satırındaki GPU modeli artık doğrudan mevcut **KafePin Donanım / Client Performans** verisinden gelir.
- Miner veya Mining Runtime kapalı olsa bile kart modeli görünür.
- ANA-PC de mevcut Donanım satırıyla eşleştirilir.
- Uzak OC uygulaması için HOTFIX9 gereksinimi devam eder.

## v4.0.57 Tek Tık Satır OC
- Ayrı Pearl OC kartı ve manuel OC penceresi kaldırıldı.
- Satırdaki GPU modeli KafePin Donanım verisinden gelir.
- **OC** tek tıkla modele göre hazır Pearl profilini uygular ve SRBMiner'ı başlatır/restart eder.
- ANA-PC Başlat RequestId elevated helper'a doğrudan aktarılır.


## v4.0.58 Kullanıcı Pearl OC Profilleri
- RTX 3060 Ti → `1500 / +200 / 5001 / 140W`
- RTX 3060 → `1500 / +200 / 5001 / 110W`
- RTX 4060 Ti → `2450 / +200 / 5001 / 120W`
- OC tek tık akışı bu değerleri modele göre uygular.
- Pool/cüzdan/worker korunur.

## v4.0.59 BAT Verified Admin OC
- Mining satırında gerçek BAT değerleri `BAT ✓ ...` olarak görünür.
- Uzak OC için HOTFIX10 gerekir.
- Admin/Highest doğrulanmadan OC ve SRBMiner start başarılı sayılmaz.


## v4.0.60 SRBMiner LIVE
- ANA-PC mining değerleri yalnız SRBMiner JSON API → Statistics LOG zincirinden gelir.
- Miner açık fakat SRBMiner telemetri yoksa **Başlat** telemetri flaglerini yönetici olarak onarıp miner'ı bir kez restart eder.
- Uzak masalar için HOTFIX10b kullanılır.

## v4.0.61 KafePin Donanım GPU
- GPU modeli doğrudan KafePin PRO Donanım servisinden okunur.
- Hashrate/Watt/Sıcaklık/Share SRBMiner LIVE kalır.
- GPU eşleşmesi yalnız aynı IP/host/masa için yapılır.
- Gereksiz ANA-PC Power Limit/CMD satırı kaldırıldı.

## v4.0.62 Root Fix
- UI null-reference çökmesi giderildi.
- 5 sabit mining masa seçimi bir defa geri yüklenir.
- ANA-PC exact BAT elevated cmd.exe ile açılır; SRBMiner prosesi doğrulanır.
