﻿param(
  [string]$SourceRoot = 'C:\KafePin\MiningPro',
  [string]$TargetRoot = 'C:\KafePinPro\MiningPRO'
)
$ErrorActionPreference='Stop'

if(-not (Test-Path -LiteralPath $SourceRoot -PathType Container)){ throw "Mining Pro kaynak klasoru bulunamadi: $SourceRoot" }
$service=Join-Path $SourceRoot 'web_service.py'
$web=Join-Path $SourceRoot 'web'
if(-not (Test-Path -LiteralPath $service -PathType Leaf)){ throw "Mining Pro web_service.py bulunamadi: $service" }
if(-not (Test-Path -LiteralPath $web -PathType Container)){ throw "Mining Pro web klasoru bulunamadi: $web" }

New-Item -ItemType Directory -Force -Path $TargetRoot | Out-Null
$runtime=@('web_service.py','mining-pro-version.json','START_MINING_PRO.cmd','Ensure-Network.ps1','Ensure-Tailscale.ps1','Integrate-KafePinAdmin.ps1','Diagnose-MiningPro.ps1','Diagnose-MiningPro.cmd','Repair-Mining-Listener.ps1','Repair-And-Start-MiningPRO.ps1','Repair-And-Start-MiningPRO.cmd','KURULUM.md','V4.0.62-UI-START-SELECTION-ROOT-FIX-RAPORU.txt')
foreach($name in $runtime){
  $src=Join-Path $SourceRoot $name
  if(Test-Path -LiteralPath $src -PathType Leaf){ Copy-Item -LiteralPath $src -Destination (Join-Path $TargetRoot $name) -Force }
}

$targetWeb=Join-Path $TargetRoot 'web'
if(Test-Path -LiteralPath $targetWeb){ Remove-Item -LiteralPath $targetWeb -Recurse -Force -ErrorAction Stop }
Copy-Item -LiteralPath $web -Destination $targetWeb -Recurse -Force

# Kullanici/runtime verisi korunur. Paket data/logs tasimaz; varsa hedefte kalir.
foreach($stale in @('server','client')){
  $p=Join-Path $TargetRoot $stale
  if(Test-Path -LiteralPath $p){ Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction SilentlyContinue }
}

$targetService=Join-Path $TargetRoot 'web_service.py'
$targetMeta=Join-Path $TargetRoot 'mining-pro-version.json'
if(-not (Test-Path -LiteralPath $targetService -PathType Leaf)){ throw 'Mining Pro hedef web_service.py dogrulanamadi.' }
if(-not (Test-Path -LiteralPath $targetMeta -PathType Leaf)){ throw 'Mining Pro hedef version metadata dogrulanamadi.' }
$meta=Get-Content -LiteralPath $targetMeta -Raw | ConvertFrom-Json
if([string]$meta.version -ne '4.0.80'){ throw ('Mining Pro hedef surumu uyusmuyor: '+[string]$meta.version) }

Write-Host ('TAMAM: Mining Pro modulu hazir: '+$TargetRoot) -ForegroundColor Green
exit 0

