﻿param(
  [string]$AdminHtml = 'C:\KafePin\public\admin.html'
)
$ErrorActionPreference='Stop'
if(-not (Test-Path -LiteralPath $AdminHtml -PathType Leaf)){
  throw ('KafePin Admin HTML bulunamadi: '+$AdminHtml)
}

$begin='<!-- KAFEPIN_MINING_PRO_ADMIN_TAB_V2_BEGIN -->'
$end='<!-- KAFEPIN_MINING_PRO_ADMIN_TAB_V2_END -->'
$oldBegin='<!-- KAFEPIN_MINING_PRO_IOS_V1_BEGIN -->'
$oldEnd='<!-- KAFEPIN_MINING_PRO_IOS_V1_END -->'

$block=@'
<!-- KAFEPIN_MINING_PRO_ADMIN_TAB_V2_BEGIN -->
<style id="kafepinMiningProAdminTabStyle">
.admin-panel-switcher button.active[data-panel="mining"]{
  background:linear-gradient(135deg,#4b2d75,#0f7080)!important;
  border-color:#a879ff!important;color:#fff!important;
  box-shadow:0 0 18px rgba(168,121,255,.35)!important
}
#kafepinMiningProPanel{
  display:none;margin:10px 0 0;border:1px solid #384c66;border-radius:14px;
  overflow:hidden;background:#08111b;box-shadow:0 12px 36px rgba(0,0,0,.30)
}
#kafepinMiningProPanelBar{
  display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;
  padding:9px 10px;background:#101d2c;border-bottom:1px solid #26384d;color:#eaf3ff
}
#kafepinMiningProPanelBar .kp-mining-title{font-weight:900}
#kafepinMiningProPanelBar button,#kafepinMiningProPanelBar a{
  min-height:42px;padding:8px 11px;border-radius:9px;border:1px solid #3c5675;
  background:#172a40;color:#fff;text-decoration:none;font-weight:750;cursor:pointer
}
#kafepinMiningProFrame{display:block;width:100%;height:calc(100vh - 210px);min-height:620px;border:0;background:#08111b}
body.kafepin-mining-tab-active .admin-quick-nav,
body.kafepin-mining-tab-active .ops-grid,
body.kafepin-mining-tab-active .lastUpdateBar{display:none!important}
@media(max-width:700px){
  #kafepinMiningProPanel{margin:6px -4px 0}
  #kafepinMiningProFrame{height:calc(100vh - 150px);min-height:560px}
  #kafepinMiningProPanelBar{position:sticky;top:0;z-index:2}
}
</style>

<section id="kafepinMiningProPanel" aria-label="Mining Pro">
  <div id="kafepinMiningProPanelBar">
    <span class="kp-mining-title">⛏ Mining Pro • ANA-PC + Seçili Masalar</span>
    <span>
      <button type="button" id="kafepinMiningReload">↻ Yenile</button>
      <a id="kafepinMiningExternal" href="#" target="_blank" rel="noopener">↗ Ayrı Aç</a>
    </span>
  </div>
  <iframe id="kafepinMiningProFrame" title="KafePin Mining Pro" loading="eager" referrerpolicy="same-origin"></iframe>
</section>

<script>
(function(){
  const PANEL_KEY="kafepin_admin_active_panel_v1";
  let originalSetAdminPanel=null;

  function miningUrl(){
    const host=window.location.hostname;
    const secure=window.location.protocol==="https:" || /\.ts\.net$/i.test(host);
    // v4.0.51: local/LAN backend 17897, Tailscale HTTPS 18443.
    return secure ? ("https://"+host+":18443/") : ("http://"+host+":17897/");
  }

  function ensureElements(){
    const switcher=document.getElementById("adminPanelSwitcher");
    const panel=document.getElementById("kafepinMiningProPanel");
    if(!switcher || !panel) return false;

    let button=switcher.querySelector('button[data-panel="mining"]');
    if(!button){
      button=document.createElement("button");
      button.type="button";
      button.dataset.panel="mining";
      button.textContent="⛏ MINING PRO";
      switcher.appendChild(button);
    }
    button.onclick=function(){ window.setAdminPanel("mining",true); };

    const iframe=document.getElementById("kafepinMiningProFrame");
    const external=document.getElementById("kafepinMiningExternal");
    const reload=document.getElementById("kafepinMiningReload");
    const url=miningUrl();
    external.href=url;
    reload.onclick=function(){
      if(iframe) iframe.src=url+(url.includes("?")?"&":"?")+"r="+Date.now();
    };
    return true;
  }

  function showMining(scrollTop){
    if(!ensureElements()) return;
    const panel=document.getElementById("kafepinMiningProPanel");
    const iframe=document.getElementById("kafepinMiningProFrame");
    document.body.dataset.adminPanel="mining";
    document.body.classList.add("kafepin-mining-tab-active");
    try{ localStorage.setItem(PANEL_KEY,"mining"); }catch(_e){}
    document.querySelectorAll(".card.admin-section").forEach(function(card){
      card.classList.add("panel-hidden");
    });
    document.querySelectorAll("#adminPanelSwitcher button[data-panel]").forEach(function(button){
      button.classList.toggle("active",button.dataset.panel==="mining");
    });
    panel.style.display="block";
    if(iframe && !iframe.getAttribute("src")) iframe.src=miningUrl();
    if(scrollTop) window.scrollTo({top:0,behavior:"smooth"});
  }

  function hideMining(){
    const panel=document.getElementById("kafepinMiningProPanel");
    document.body.classList.remove("kafepin-mining-tab-active");
    if(panel) panel.style.display="none";
  }

  function install(){
    if(!ensureElements()) return false;
    if(!originalSetAdminPanel && typeof window.setAdminPanel==="function"){
      originalSetAdminPanel=window.setAdminPanel;
      window.setAdminPanel=function(panel,scrollTop){
        if(panel==="mining"){ showMining(scrollTop); return; }
        hideMining();
        return originalSetAdminPanel(panel,scrollTop);
      };
    }
    let saved="";
    try{saved=localStorage.getItem(PANEL_KEY)||"";}catch(_e){}
    if(saved==="mining") setTimeout(function(){showMining(false);},0);
    return true;
  }

  if(!install()){
    document.addEventListener("DOMContentLoaded",install,{once:true});
  }else{
    document.addEventListener("DOMContentLoaded",function(){install();},{once:true});
  }
  setTimeout(install,500);
})();
</script>
<!-- KAFEPIN_MINING_PRO_ADMIN_TAB_V2_END -->
'@

$raw=[System.IO.File]::ReadAllText($AdminHtml,[System.Text.Encoding]::UTF8)
$backup=$AdminHtml+'.before-miningpro-admin-tab-v2.bak'
if(-not (Test-Path -LiteralPath $backup)){
  [System.IO.File]::Copy($AdminHtml,$backup,$false)
}

# Remove old v1 floating-button integration if present.
if($raw.Contains($oldBegin) -and $raw.Contains($oldEnd)){
  $oldPattern='(?s)'+[regex]::Escape($oldBegin)+'.*?'+[regex]::Escape($oldEnd)
  $raw=[regex]::Replace($raw,$oldPattern,'',1)
}

# Replace/update v2 block idempotently.
if($raw.Contains($begin) -and $raw.Contains($end)){
  $pattern='(?s)'+[regex]::Escape($begin)+'.*?'+[regex]::Escape($end)
  $raw=[regex]::Replace($raw,$pattern,[System.Text.RegularExpressions.MatchEvaluator]{param($m) $block},1)
}else{
  $idx=$raw.LastIndexOf('</body>',[System.StringComparison]::OrdinalIgnoreCase)
  if($idx -ge 0){$raw=$raw.Substring(0,$idx)+$block+"`r`n"+$raw.Substring($idx)}
  else{$raw=$raw+"`r`n"+$block}
}

[System.IO.File]::WriteAllText($AdminHtml,$raw,(New-Object System.Text.UTF8Encoding($false)))
Write-Host 'TAMAM: KafePin Admin icine gercek MINING PRO sekmesi eklendi.' -ForegroundColor Green
exit 0
