﻿$ErrorActionPreference='SilentlyContinue'

$rule='KafePin Mining Pro 17897'
if(-not (Get-NetFirewallRule -DisplayName $rule -ErrorAction SilentlyContinue)){
  New-NetFirewallRule -DisplayName $rule -Direction Inbound -Action Allow -Protocol TCP -LocalPort 17897 -Profile Private | Out-Null
}

# Tailscale direct-IP fallback. Management authorization is also checked by web_service.py.
$ts4='KafePin Mining Pro Tailscale IPv4 17897'
if(-not (Get-NetFirewallRule -DisplayName $ts4 -ErrorAction SilentlyContinue)){
  New-NetFirewallRule -DisplayName $ts4 -Direction Inbound -Action Allow -Protocol TCP -LocalPort 17897 -RemoteAddress '100.64.0.0/10' -Profile Any | Out-Null
}

$ts6='KafePin Mining Pro Tailscale IPv6 17897'
if(-not (Get-NetFirewallRule -DisplayName $ts6 -ErrorAction SilentlyContinue)){
  New-NetFirewallRule -DisplayName $ts6 -Direction Inbound -Action Allow -Protocol TCP -LocalPort 17897 -RemoteAddress 'fd7a:115c:a1e0::/48' -Profile Any | Out-Null
}

exit 0
