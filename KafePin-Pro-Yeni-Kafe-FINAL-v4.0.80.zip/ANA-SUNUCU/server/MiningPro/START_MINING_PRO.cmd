@echo off
setlocal
cd /d "%~dp0"
where py.exe >nul 2>nul
if not errorlevel 1 (
  start "KafePin Mining Pro" /b py.exe -3 -B "%~dp0web_service.py"
  exit /b 0
)
where python.exe >nul 2>nul
if not errorlevel 1 (
  start "KafePin Mining Pro" /b python.exe -B "%~dp0web_service.py"
  exit /b 0
)
echo Python bulunamadi. Client Performans PRO icin kullanilan Python kurulumunu kontrol edin.
exit /b 2
