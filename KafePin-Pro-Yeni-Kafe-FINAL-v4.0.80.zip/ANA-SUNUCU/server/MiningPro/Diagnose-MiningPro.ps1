﻿# KafePin Mining Pro v4.0.51 non-destructive localhost diagnostics.
$ErrorActionPreference = 'Continue'
$folder = Join-Path $env:PUBLIC 'Documents'
if (-not (Test-Path -LiteralPath $folder)) { New-Item -ItemType Directory -Path $folder -Force | Out-Null }
$out = Join-Path $folder 'KafePin-Mining-Diagnose.txt'
$lines = New-Object System.Collections.Generic.List[string]
$lines.Add('KafePin Mining Pro v4.0.51 / localhost diagnostic')
$lines.Add('Time: ' + (Get-Date).ToString('o'))
$lines.Add('Only local service/port/process IDs and Mining logs; no credentials requested.')
try {
  $tailscaleExe = (Get-Command tailscale.exe -ErrorAction SilentlyContinue).Source
  if (-not $tailscaleExe) {
    $candidate = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
    if (Test-Path -LiteralPath $candidate) { $tailscaleExe = $candidate }
  }
  if ($tailscaleExe) {
    $serve = & $tailscaleExe serve status 2>&1
    $lines.Add('TAILSCALE 18443 EXPECTED -> 127.0.0.1:17897')
    foreach($line in $serve){ $lines.Add('TAILSCALE: '+[string]$line) }
  } else { $lines.Add('TAILSCALE: tailscale.exe not found') }
} catch { $lines.Add('TAILSCALE STATUS ERROR: '+$_.Exception.Message) }
try {
  $r = Invoke-RestMethod -Uri 'http://127.0.0.1:17897/api/v1/health' -TimeoutSec 4
  $lines.Add('HEALTH: ok=' + $r.ok + ' app=' + $r.app + ' version=' + $r.version + ' port=' + $r.port)
} catch { $lines.Add('HEALTH ERROR: ' + $_.Exception.Message) }
try {
  $listeners = @(Get-NetTCPConnection -LocalPort 17897 -State Listen -ErrorAction Stop)
  $lines.Add('LISTENER COUNT: '+$listeners.Count)
  foreach ($conn in $listeners) {
    $ownerPid = $conn.OwningProcess
    try {
      $proc = Get-Process -Id $ownerPid -ErrorAction Stop
      $lines.Add(('LISTENER PID={0} EXE={1} ADDR={2}' -f $ownerPid,$proc.ProcessName,$conn.LocalAddress))
    } catch { $lines.Add('LISTENER PID=' + $ownerPid + ' (details unavailable)') }
  }
} catch { $lines.Add('PORT ENUMERATION ERROR: '+$_.Exception.Message) }
foreach ($path in @('C:\KafePinPro\MiningPRO\logs\mining-pro.log',
                    (Join-Path $env:LOCALAPPDATA 'KafePinPro\logs\mining-pro-reconnect.log'),
                    (Join-Path $env:LOCALAPPDATA 'KafePinPro\logs\mining-pro-remote-startup.log'))) {
  $lines.Add('LOG FILE: '+$path)
  try {
    if (Test-Path -LiteralPath $path -PathType Leaf) {
      # Only last 25 service startup errors; other logs and finance data not collected.
      foreach ($line in (Get-Content -LiteralPath $path -Tail 25 -ErrorAction Stop)) {
        $lines.Add([string]$line)
      }
    } else { $lines.Add('(not found)') }
  } catch { $lines.Add('(could not read)') }
}
$lines | Set-Content -LiteralPath $out -Encoding UTF8
Write-Host ('Mining Pro diagnostic saved: ' + $out)
Start-Process -FilePath 'notepad.exe' -ArgumentList ('"' + $out + '"')
