'use strict';

const assert = require('assert');
const { decideInstallLifecycle } = require('../services/pro-update-lifecycle');

const MAX = 30 * 60 * 1000;

function eq(name, input, expected) {
  const got = decideInstallLifecycle({ maxAgeMs: MAX, ...input });
  assert.strictEqual(got.state, expected.state, name + ' state');
  assert.strictEqual(got.clearLock, expected.clearLock, name + ' clearLock');
  return got;
}

// Fresh install: current server owns lock -> installing.
eq('fresh install owner active', {
  ownerIsCurrentServer: true, supervisorAlive: false,
  targetInstalled: false, serverHealthy: true,
  stateStage: 'copy', stateRunning: true, stateAgeMs: 500, lockAgeMs: 1000
}, { state: 'installing', clearLock: false });

// KEY regression: target version is running, but only restart_pending file remains.
// Progress state alone must NOT hold install lock.
eq('target running stale restart_pending only', {
  ownerIsCurrentServer: false, supervisorAlive: false,
  targetInstalled: true, serverHealthy: true,
  stateStage: 'restart_pending', stateRunning: true, stateAgeMs: 1000, lockAgeMs: 5000
}, { state: 'installed', clearLock: true });

// Real supervisor still active -> keep locked.
eq('real supervisor active', {
  ownerIsCurrentServer: false, supervisorAlive: true,
  targetInstalled: true, serverHealthy: true,
  stateStage: 'restart_pending', stateRunning: true, stateAgeMs: 1000, lockAgeMs: 5000
}, { state: 'installing', clearLock: false });

// Error/cancel path clears.
eq('terminal error', {
  ownerIsCurrentServer: false, supervisorAlive: false,
  targetInstalled: false, serverHealthy: true,
  stateStage: 'error', stateRunning: false, stateAgeMs: 100, lockAgeMs: 1000
}, { state: 'error', clearLock: true });

// Stale lock with no real owner clears.
eq('stale ownerless lock', {
  ownerIsCurrentServer: false, supervisorAlive: false,
  targetInstalled: false, serverHealthy: true,
  stateStage: 'copy', stateRunning: true, stateAgeMs: MAX + 1, lockAgeMs: MAX + 1
}, { state: 'stale', clearLock: true });

// Different/live arbitrary PID is not modeled as owner. Only current server/supervisor count.
eq('pid reuse cannot keep lock', {
  ownerIsCurrentServer: false, supervisorAlive: false,
  targetInstalled: true, serverHealthy: true,
  stateStage: 'restart_pending', stateRunning: true, stateAgeMs: 100, lockAgeMs: 100
}, { state: 'installed', clearLock: true });

console.log('PASS pro-update-lifecycle: 6/6');
