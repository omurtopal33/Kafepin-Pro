param(
  [string]$ManifestUrl = "",
  [string]$ExpectedVersion = "",
  [string]$LocalZipPath = ""
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$work = Join-Path $env:TEMP ('KafePinProUpdate_' + [guid]::NewGuid().ToString('N'))
$zip = Join-Path $work 'update.zip'
$expanded = Join-Path $work 'expanded'
$updateLog = Join-Path $root 'logs\kafepin-update.log'
$resultFile = Join-Path $root 'logs\kafepin-pro-update-result.json'

function Write-UpdateLog([string]$message) {
  New-Item -ItemType Directory -Path (Split-Path -Parent $updateLog) -Force | Out-Null
  ((Get-Date).ToString('s') + '  ' + $message) | Add-Content -LiteralPath $updateLog
}

function Write-UpdateResult([bool]$ok, [string]$version, [string]$errorMessage) {
  $payload = @{ ok=$ok; version=$version; error=$errorMessage; time=(Get-Date).ToString('o') } | ConvertTo-Json
  New-Item -ItemType Directory -Path (Split-Path -Parent $resultFile) -Force | Out-Null
  [System.IO.File]::WriteAllText($resultFile, $payload, (New-Object System.Text.UTF8Encoding($false)))
}

try {
  Write-UpdateLog 'Guncelleme baslatildi.'
  Start-Sleep -Seconds 2
  New-Item -ItemType Directory -Path $work -Force | Out-Null
  if ($LocalZipPath) {
    if (-not (Test-Path -LiteralPath $LocalZipPath -PathType Leaf) -or $LocalZipPath -notmatch '\.zip$') { throw 'Secilen guncelleme paketi bulunamadi.' }
    Copy-Item -LiteralPath $LocalZipPath -Destination $zip -Force
  } else {
    Write-UpdateLog 'Manifest indiriliyor.'
    if (-not $ManifestUrl -or -not $ExpectedVersion) { throw 'Guncelleme bilgisi eksik.' }
    try {
      $manifest = Invoke-RestMethod -Uri $ManifestUrl -UseBasicParsing
    } catch {
      # BazÄ± Windows kurulumlarÄ±nda GitHub TLS yanÄ±tÄ± Invoke-RestMethod
      # tarafÄ±ndan kesilebiliyor. Windows 11'de gelen curl ikinci yoldur.
      $manifest = (& curl.exe -fsSL --retry 2 $ManifestUrl | ConvertFrom-Json)
      if ($LASTEXITCODE -ne 0 -or -not $manifest) { throw }
    }
    Write-UpdateLog 'Paket indirildi ve dogrulandi.'
    if ([string]$manifest.version -ne $ExpectedVersion) { throw 'Surum bilgisi degisti; guncelleme iptal edildi.' }
    if (-not $manifest.downloadUrl -or $manifest.downloadUrl -notmatch '^https://') { throw 'Guncelleme indirme adresi gecersiz.' }
    try {
      Invoke-WebRequest -Uri $manifest.downloadUrl -OutFile $zip -UseBasicParsing
    } catch {
      & curl.exe -fL --retry 2 --retry-delay 1 -o $zip $manifest.downloadUrl
      if ($LASTEXITCODE -ne 0) { throw }
    }
    if ($manifest.sha256) {
      $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
      if ($hash -ne ([string]$manifest.sha256).ToLowerInvariant()) { throw 'Indirilen paket dogrulanamadi.' }
    }
  }

  Expand-Archive -LiteralPath $zip -DestinationPath $expanded -Force
  $updateInfoPath = Join-Path $expanded 'update.json'
  if (-not (Test-Path -LiteralPath $updateInfoPath)) { throw 'Paket tanim dosyasi bulunamadi.' }
  $update = Get-Content -LiteralPath $updateInfoPath -Raw | ConvertFrom-Json
  $targetVersion = [string]$update.version
  if (-not $targetVersion -or -not $update.files) { throw 'Paket surumu gecersiz.' }
  if ($ExpectedVersion -and $targetVersion -ne $ExpectedVersion) { throw 'Paket surumu beklenen surumle uyusmuyor.' }

  Write-UpdateLog 'Emniyet yedegi aliniyor.'
  & (Join-Path $root 'KafePin_Pro_Yedek_Al.bat') /AUTO
  if ($LASTEXITCODE -ne 0) { throw 'Emniyet yedegi alinamadi.' }
  Write-UpdateLog 'Emniyet yedegi tamamlandi.'
  & (Join-Path $root 'KafePin_Pro_Durdur.bat')

  # Eski Pro penceresi, güncellenmiş dosyaları önbellekten göstermesin.
  # Yalnızca KafePin'in kendi Edge profili hedeflenir; kullanıcının normal
  # Edge/Chrome pencerelerine dokunulmaz.
  try {
    Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" |
      Where-Object { $_.CommandLine -and $_.CommandLine -like ("*" + $root + "\.kafepin-pro-window*") } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  } catch {}

  foreach ($relative in $update.files) {
    $safe = [string]$relative
    if ([string]::IsNullOrWhiteSpace($safe) -or $safe -match '(^|[\\/])\.\.([\\/]|$)' -or [IO.Path]::IsPathRooted($safe)) { throw 'Paket dosya yolu gecersiz.' }
    $source = Join-Path $expanded $safe
    $target = Join-Path $root $safe
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Paket dosyasi eksik: $safe" }
    New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
    Copy-Item -LiteralPath $source -Destination $target -Force
  }
  $versionJson = @{ version=$targetVersion; channel='stable'; installedAt=(Get-Date).ToString('o') } | ConvertTo-Json
  [System.IO.File]::WriteAllText((Join-Path $root 'kafepin-pro-version.json'), $versionJson, (New-Object System.Text.UTF8Encoding($false)))
  Write-UpdateLog ('Dosyalar kuruldu: v' + $targetVersion)
  Write-UpdateResult $true $targetVersion ''
  Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
  $startBat = Join-Path $root 'KafePin_Pro_Baslat.bat'
  Start-Process -FilePath 'cmd.exe' -ArgumentList ('/d /c ""' + $startBat + '""') -WindowStyle Hidden
  Start-Sleep -Seconds 3
  Write-UpdateLog 'Sunucu yeniden baslatildi.'
  $appLauncher = Join-Path $root 'KafePin_Pro_Uygulama.vbs'
  if (Test-Path -LiteralPath $appLauncher) {
    Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + $appLauncher + '"') -WindowStyle Hidden
  }
  Write-UpdateLog 'Guncelleme basariyla tamamlandi.'
} catch {
  $log = Join-Path $root 'logs\kafepin-update-error.log'
  New-Item -ItemType Directory -Path (Split-Path -Parent $log) -Force | Out-Null
  ((Get-Date).ToString('s') + '  ' + $_.Exception.Message) | Add-Content -LiteralPath $log
  try { Write-UpdateResult $false '' $_.Exception.Message } catch {}
  try { Start-Process -FilePath 'cmd.exe' -ArgumentList ('/d /c ""' + (Join-Path $root 'KafePin_Pro_Baslat.bat') + '""') -WindowStyle Hidden } catch {}
}
