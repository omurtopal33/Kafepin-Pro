'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const { spawn, spawnSync } = require('child_process');

function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }
function log(root, text){
  try { const p=path.join(root,'logs','update-supervisor.log'); fs.mkdirSync(path.dirname(p),{recursive:true}); fs.appendFileSync(p,`${new Date().toISOString()} ${text}\n`,'utf8'); } catch(_){}
}
function hidden(exe,args,opts={}){
  return spawn(exe,args,{cwd:opts.cwd||undefined,detached:!!opts.detached,stdio:opts.stdio||'ignore',windowsHide:true});
}
function launchServerDetached(installRoot, attempt){
  const server=path.join(installRoot,'server.js');
  const bootLog=path.join(installRoot,'logs','update-supervisor-server-launch.log');
  fs.mkdirSync(path.dirname(bootLog),{recursive:true});
  const out=fs.openSync(bootLog,'a');
  try{
    const child=spawn(process.execPath,[server],{
      cwd:installRoot,detached:true,stdio:['ignore',out,out],windowsHide:true
    });
    child.unref();
    log(installRoot,`server launch attempt=${attempt} pid=${child.pid||0} node=${process.execPath}`);
    return child.pid||0;
  } finally { try{fs.closeSync(out);}catch(_){} }
}
function run(exe,args,opts={}){
  const r=spawnSync(exe,args,{cwd:opts.cwd||undefined,encoding:'utf8',windowsHide:true,timeout:opts.timeout||15000});
  return {code:Number.isInteger(r.status)?r.status:-1,stdout:String(r.stdout||''),stderr:String(r.stderr||''),error:r.error||null};
}
function portPid(port){
  if(process.platform!=='win32') return 0;
  const r=run('netstat.exe',['-ano','-p','tcp'],{timeout:5000});
  for(const raw of r.stdout.split(/\r?\n/)){
    const line=raw.trim(); if(!line || !/^TCP\s/i.test(line)) continue;
    const parts=line.split(/\s+/); if(parts.length<5) continue;
    if(!parts[1].endsWith(':'+port) || String(parts[3]).toUpperCase()!=='LISTENING') continue;
    const pid=Number(parts[4]); if(pid>0) return pid;
  }
  return 0;
}
function killPid(pid){ if(process.platform==='win32' && pid>0) run('taskkill.exe',['/PID',String(pid),'/F','/T'],{timeout:7000}); }
async function waitPortDown(port,timeoutMs){ const end=Date.now()+timeoutMs; while(Date.now()<end){ if(!portPid(port)) return true; await sleep(150); } return !portPid(port); }
function httpJson(port,urlPath,timeoutMs=1200){
  return new Promise(resolve=>{
    const req=http.get({host:'127.0.0.1',port,path:urlPath,timeout:timeoutMs,headers:{'Cache-Control':'no-cache'}},res=>{
      let body=''; res.on('data',c=>body+=String(c)); res.on('end',()=>{ try{resolve({ok:res.statusCode>=200&&res.statusCode<300,json:JSON.parse(body),headers:res.headers});}catch(_){resolve({ok:false,json:null,headers:res.headers});} });
    });
    req.on('timeout',()=>req.destroy()); req.on('error',()=>resolve({ok:false,json:null,headers:{}}));
  });
}
async function waitServerVersion(version,timeoutMs){ const end=Date.now()+timeoutMs; while(Date.now()<end){ const r=await httpJson(3000,'/api/health?_supervisor='+Date.now()); const h=String((r.headers||{})['x-kafepin-version']||''); if(r.ok && (!version || h===version)) return true; await sleep(250); } return false; }
function readJson(p){ try{return JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));}catch(_){return null;} }
function sha256File(p){ try{return require('crypto').createHash('sha256').update(fs.readFileSync(p)).digest('hex');}catch(_){return '';} }
function copyTree(src,dst,preserveTop){
  fs.mkdirSync(dst,{recursive:true});
  for(const ent of fs.readdirSync(src,{withFileTypes:true})){
    if(preserveTop && preserveTop.has(ent.name)) continue;
    const s=path.join(src,ent.name), d=path.join(dst,ent.name);
    if(ent.isDirectory()){ fs.rmSync(d,{recursive:true,force:true}); copyTree(s,d,null); }
    else if(ent.isFile()){ fs.mkdirSync(path.dirname(d),{recursive:true}); fs.copyFileSync(s,d); }
  }
}
function extractZip(zip,dst){
  fs.mkdirSync(dst,{recursive:true});
  const exe=process.platform==='win32'?'tar.exe':'unzip';
  const args=process.platform==='win32'?['-xf',zip,'-C',dst]:['-q','-o',zip,'-d',dst];
  const r=run(exe,args,{timeout:60000}); if(r.code!==0) throw new Error(`ZIP acilamadi: ${(r.stderr||r.stdout).trim()}`);
}
function syncMp3Payload(installRoot,proRoot){
  const zip=path.join(installRoot,'pro-components','mp3-bot-pro.zip');
  if(!fs.existsSync(zip)) return {required:false,version:''};
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'kafepin-mp3-activate-'));
  try{
    extractZip(zip,tmp);
    const meta=readJson(path.join(tmp,'mp3-web-version.json')); const expected=String(meta&&meta.version||'');
    if(!expected) throw new Error('MP3 payload surumu okunamadi');
    const root=path.join(proRoot,'MP3BotPRO');
    const installed=readJson(path.join(root,'mp3-web-version.json')); const current=String(installed&&installed.version||'');
    // LOCK: version ayni olsa bile stale web/index.html veya app.js kalmis olabilir.
    // Her update aktivasyonunda paket payloadini exact olarak yeniden esle; yalniz
    // kullanici state/.venv/logs gibi kalici verileri koru.
    const pid=portPid(17890); if(pid) killPid(pid);
    const preserve=new Set(['state.json','favorites.json','.env','.venv','logs']);
    fs.mkdirSync(root,{recursive:true});
    copyTree(tmp,root,preserve);
    const actual=readJson(path.join(root,'mp3-web-version.json'));
    if(String(actual&&actual.version||'')!==expected) throw new Error('MP3 payload dogrulama hatasi');
    return {required:true,version:expected,root};
  } finally { try{fs.rmSync(tmp,{recursive:true,force:true});}catch(_){} }
}
async function startAndVerifyMp3(info){
  if(!info.required) return true;
  const pid=portPid(17890); if(pid) killPid(pid);
  await waitPortDown(17890,5000);
  if(process.platform!=='win32') throw new Error('MP3 interaktif oturum baslatma yalniz Windows icin destekleniyor');

  // MP3'ü supervisor/SYSTEM oturumunda değil, kullanıcının gerçek interaktif
  // masaüstü tokenında başlat. Bu, kullanıcının elle PRO Servisleri demesiyle aynı
  // LOCALAPPDATA/profil/dosya erişim bağlamını kullanır ve pencere açmaz.
  // Desktop Action gorevini her MP3 aktivasyonunda sessizce CREATE_OR_UPDATE et.
  // Boylece onceki TEST'ten kalmis eski gorev tanimi yeni delete/restart aksiyonlarini engelleyemez.
  const helperEnsure=path.join(path.dirname(__filename),'KafePin_Desktop_Helper_Ensure.ps1');
  if(fs.existsSync(helperEnsure)){
    const ensure=run('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',helperEnsure,'-InstallRoot',path.dirname(__filename)],{timeout:12000});
    if(ensure.code!==0) throw new Error(`Desktop Action gorevi guncellenemedi: ${(ensure.stderr||ensure.stdout).trim()}`);
  }
  const pd=process.env.ProgramData||'C:\\ProgramData';
  const bridge=path.join(pd,'KafePinPro','DesktopBridge');
  const requestFile=path.join(bridge,'request.json'), resultFile=path.join(bridge,'result.json');
  const requestId=`mp3-${process.pid}-${Date.now()}`;
  fs.mkdirSync(bridge,{recursive:true});
  fs.writeFileSync(requestFile,JSON.stringify({requestId,action:'restart-mp3-only',expectedVersion:info.version,createdAt:Date.now()}),'utf8');
  try{fs.unlinkSync(resultFile);}catch(_err){}
  const task=run('schtasks.exe',['/Run','/TN','KafePin Pro Desktop Action'],{timeout:5000});
  if(task.code!==0) throw new Error('MP3 interaktif Desktop Bridge gorevi baslatilamadi');
  const bridgeEnd=Date.now()+45000;
  while(Date.now()<bridgeEnd){
    const d=readJson(resultFile);
    if(d&&String(d.requestId||'')===requestId){
      if(d.ok!==true) throw new Error(String(d.error||'MP3 interaktif baslatma basarisiz'));
      break;
    }
    await sleep(200);
  }
  const finalResult=readJson(resultFile);
  if(!finalResult||String(finalResult.requestId||'')!==requestId||finalResult.ok!==true) throw new Error('MP3 interaktif baslatma sonucu zaman asimi');

  const end=Date.now()+12000;
  while(Date.now()<end){ const r=await httpJson(17890,'/api/health?_supervisor='+Date.now()); if(r.ok&&r.json&&String(r.json.version||'')===info.version) return true; await sleep(250); }
  throw new Error(`MP3 health-check gecmedi: ${info.version}`);
}
function isDesktopRunning(){
  if(process.platform!=='win32') return true;
  const r=run('tasklist.exe',['/FI','IMAGENAME eq KafePin Pro.exe','/NH'],{timeout:5000});
  return r.code===0 && /KafePin Pro\.exe/i.test(r.stdout);
}
async function launchDesktop(installRoot){
  if(process.platform!=='win32') return true;
  const appPath=path.join(installRoot,'desktop-app','KafePin Pro.exe');
  if(!fs.existsSync(appPath)) throw new Error('KafePin Pro.exe bulunamadi');
  const pd=process.env.ProgramData||'C:\\ProgramData'; const bridge=path.join(pd,'KafePinPro','DesktopBridge');
  const requestFile=path.join(bridge,'request.json'), resultFile=path.join(bridge,'result.json');
  const requestId=`upd-${process.pid}-${Date.now()}`; fs.mkdirSync(bridge,{recursive:true});
  fs.writeFileSync(requestFile,JSON.stringify({requestId,action:'launch-kafepin',appPath,forceRestart:true,createdAt:Date.now()}),'utf8'); try{fs.unlinkSync(resultFile);}catch(_){}
  const r=run('schtasks.exe',['/Run','/TN','KafePin Pro Desktop Action'],{timeout:5000}); if(r.code!==0) throw new Error('Desktop Bridge gorevi baslatilamadi');
  const end=Date.now()+15000; while(Date.now()<end){ const d=readJson(resultFile); if(d&&String(d.requestId||'')===requestId){ if(d.ok===true&&Number(d.sessionId||0)>0&&String(d.selectedPath||'').toLowerCase()===String(appPath).toLowerCase()) return true; throw new Error(String(d.error||'Masaustu acilamadi')); } await sleep(200); }
  throw new Error('Masaustu acilis health-check zaman asimi');
}
function desktopExpectedVersion(installRoot){
  const meta=readJson(path.join(installRoot,'desktop-app','desktop-app-version.json'));
  return String(meta&&meta.version||'').trim();
}
function desktopInstalledVersion(installRoot){
  const meta=readJson(path.join(installRoot,'desktop-app','desktop-app-installed.json'));
  return String(meta&&meta.version||'').trim();
}
async function ensureDesktopShellExact(installRoot){
  if(process.platform!=='win32') return {required:false,version:''};
  const expected=desktopExpectedVersion(installRoot);
  if(!expected) throw new Error('Masaustu kabuk beklenen surumu okunamadi');
  const appDir=path.join(installRoot,'desktop-app');
  const exe=path.join(appDir,'KafePin Pro.exe');
  const source=path.join(appDir,'KafePinProDesktop.cs');
  const markerPath=path.join(appDir,'desktop-app-installed.json');
  const marker=readJson(markerPath)||{};
  const current=String(marker.version||'').trim();
  const sourceSha=sha256File(source), exeSha=sha256File(exe);
  const markerSourceSha=String(marker.sourceSha256||'').toLowerCase();
  const markerExeSha=String(marker.exeSha256||'').toLowerCase();
  const shellHasCv = fs.existsSync(source) && /CV Oluştur PRO/.test(fs.readFileSync(source,'utf8')) && /17895/.test(fs.readFileSync(source,'utf8'));
  if(!shellHasCv) throw new Error('Masaustu kabuk kaynaginda CV Olustur PRO dogrulanamadi');
  const required=!fs.existsSync(exe)||current!==expected||!sourceSha||markerSourceSha!==sourceSha||!exeSha||markerExeSha!==exeSha;
  if(required){
    const setup=path.join(installRoot,'KafePin_Desktop_App_Setup.ps1');
    if(!fs.existsSync(setup)) throw new Error('Masaustu kabuk setup bulunamadi');
    log(installRoot,`desktop shell exact refresh current=${current||'none'} expected=${expected} sourceMatch=${markerSourceSha===sourceSha} exeMatch=${markerExeSha===exeSha}`);
    const r=run('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',setup,'-InstallRoot',installRoot,'-AppVersion',expected],{timeout:240000});
    if(r.code!==0) throw new Error(`Masaustu kabuk yenileme basarisiz: ${(r.stderr||r.stdout).trim().slice(0,1800)}`);
    const after=readJson(markerPath)||{};
    const afterSourceSha=sha256File(source), afterExeSha=sha256File(exe);
    if(String(after.version||'').trim()!==expected) throw new Error(`Masaustu kabuk marker surumu dogrulanamadi: ${after.version||'none'} != ${expected}`);
    if(String(after.sourceSha256||'').toLowerCase()!==afterSourceSha) throw new Error('Masaustu kabuk source SHA dogrulanamadi');
    if(String(after.exeSha256||'').toLowerCase()!==afterExeSha) throw new Error('Masaustu kabuk EXE SHA dogrulanamadi');
    // Setup SYSTEM/Session0'da eski kabugu kapatabilir. Yeni EXE'yi her zaman
    // Desktop Bridge ile aktif kullanici oturumunda exact olarak yeniden ac.
    await launchDesktop(installRoot);
  } else if(!isDesktopRunning()) {
    await launchDesktop(installRoot);
  }
  const end=Date.now()+20000;
  while(Date.now()<end){ if(isDesktopRunning()) return {required,version:expected}; await sleep(250); }
  throw new Error(`Masaustu kabuk calisma health-check gecmedi: ${expected}`);
}
async function runDesktopBridgeAction(installRoot,action,timeoutMs=60000){
  if(process.platform!=='win32') return true;
  const helperEnsure=path.join(installRoot,'KafePin_Desktop_Helper_Ensure.ps1');
  if(fs.existsSync(helperEnsure)){
    const e=run('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',helperEnsure,'-InstallRoot',installRoot],{timeout:15000});
    if(e.code!==0) throw new Error(`Desktop Action gorevi hazirlanamadi: ${(e.stderr||e.stdout).trim()}`);
  }
  const pd=process.env.ProgramData||'C:\\ProgramData'; const bridge=path.join(pd,'KafePinPro','DesktopBridge');
  const requestFile=path.join(bridge,'request.json'), resultFile=path.join(bridge,'result.json');
  const requestId=`std-${action}-${process.pid}-${Date.now()}`; fs.mkdirSync(bridge,{recursive:true});
  fs.writeFileSync(requestFile,JSON.stringify({requestId,action,createdAt:Date.now()}),'utf8'); try{fs.unlinkSync(resultFile);}catch(_){}
  const t=run('schtasks.exe',['/Run','/TN','KafePin Pro Desktop Action'],{timeout:5000});
  if(t.code!==0) throw new Error(`Desktop Bridge baslatilamadi: ${action}`);
  const end=Date.now()+timeoutMs;
  while(Date.now()<end){ const d=readJson(resultFile); if(d&&String(d.requestId||'')===requestId){ if(d.ok===true) return d; throw new Error(String(d.error||d.message||`${action} basarisiz`)); } await sleep(250); }
  throw new Error(`Desktop Bridge zaman asimi: ${action}`);
}
function syncPackagedProComponents(installRoot){
  if(process.platform!=='win32') return false;
  const ps=path.join(installRoot,'KafePin_Pro_Component_Update.ps1');
  if(!fs.existsSync(ps)) return false;
  const r=run('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',ps,'-InstallRoot',installRoot,'-ProRoot','C:\\KafePinPro'],{timeout:120000});
  if(r.code!==0) throw new Error(`PRO bilesen esitleme basarisiz: ${(r.stderr||r.stdout).trim()}`);
  return true;
}
function activationPath(){ const pd=process.platform==='win32'?(process.env.ProgramData||'C:\\ProgramData'):process.cwd(); return path.join(pd,'KafePinPro','update-activation.json'); }
function desktopMarkerPath(){ const pd=process.platform==='win32'?(process.env.ProgramData||'C:\\ProgramData'):process.cwd(); return path.join(pd,'KafePinPro','desktop-reopen-after-update.json'); }
function supervisorLockPath(){ const pd=process.platform==='win32'?(process.env.ProgramData||'C:\\ProgramData'):process.cwd(); return path.join(pd,'KafePinPro','update-supervisor.lock'); }
function writeActivation(data){ const p=activationPath(); fs.mkdirSync(path.dirname(p),{recursive:true}); fs.writeFileSync(p,JSON.stringify(data,null,2),'utf8'); }
async function activateOnly(installRoot,targetVersion){
  const lockPath=supervisorLockPath();
  try{
    const prior=readJson(lockPath); if(prior && Date.now()-Number(prior.startedAt||0)<60000) { log(installRoot,'activate skipped: supervisor already running'); return false; }
    fs.mkdirSync(path.dirname(lockPath),{recursive:true}); fs.writeFileSync(lockPath,JSON.stringify({pid:process.pid,targetVersion,startedAt:Date.now()}),'utf8');
    const proRoot=process.env.KAFEPIN_PRO_ROOT||'C:\\KafePinPro';
    log(installRoot,`activate start target=${targetVersion}`);
    const desktopWasRunning=isDesktopRunning();
    const serverOk=await waitServerVersion(targetVersion,15000); if(!serverOk) throw new Error(`Yeni KafePin server health-check gecmedi: ${targetVersion}`);

    // STANDARD UPDATE AKISI: paket hangi katmani degistirdiyse o katman burada exact
    // yenilenir. Kabuk surumu farkliysa derlenir ve kullanici oturumunda yeniden acilir;
    // PRO payloadlar eslenir ve bes PRO servis ayni refresh akisi ile yeniden baslatilir.
    // v4.0.3 candidate3: Yazici-only paket ana desktop kabugunu ve diger PRO'lari
    // gereksiz yere refresh etmez. Bu yol update.json files listesiyle fail-closed calisir.
    const installedMeta=readJson(path.join(installRoot,'kafepin-pro-version.json'))||{};
    const updateFiles=Array.isArray(installedMeta.files)?installedMeta.files.map(String):[];
    const unifiedTarget=updateFiles.length===7 && updateFiles.includes('KafePin_Update_Supervisor.js') && updateFiles.includes('pro-components/yazici-pro.zip') && updateFiles.includes('desktop-app/KafePinProDesktop.cs') && updateFiles.includes('server.js') && updateFiles.includes('public/admin.html') && updateFiles.includes('KafePin_System_Manager.ps1') && updateFiles.includes('KafePin_Manager_Ensure.ps1');
    const componentOnly=unifiedTarget || (updateFiles.length===2 && updateFiles.includes('KafePin_Update_Supervisor.js') && updateFiles.includes('pro-components/yazici-pro.zip'));
    let shell={required:false,version:desktopExpectedVersion(installRoot)};
    let mp3={required:false,version:''};
    let componentsSynced=false;
    let proServicesRefreshed=false;
    if(componentOnly){
      if(unifiedTarget){
        shell=await ensureDesktopShellExact(installRoot);
        const managerEnsure=path.join(installRoot,'KafePin_Manager_Ensure.ps1');
        const ensured=run('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',managerEnsure,'-InstallRoot',installRoot,'-NodePath',process.execPath],{timeout:35000});
        if(ensured.code!==0) throw new Error(`Server Manager activation failed: ${(ensured.stderr||ensured.stdout).trim().slice(0,900)}`);
        log(installRoot,'unified activation: Server Manager payload synchronized');
      }
      const manager=path.join(installRoot,'KafePin_Pro_Component_Manager.ps1');
      if(!fs.existsSync(manager)) throw new Error('Yazici PRO component manager bulunamadi');
      const r=run('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',manager,'-Action','repair','-Component','yazici-pro'],{timeout:120000});
      if(r.code!==0) throw new Error(`Yazici PRO hedefli guncelleme basarisiz: ${(r.stderr||r.stdout).trim().slice(0,1800)}`);
      componentsSynced=true; proServicesRefreshed=true;
      log(installRoot,'component-only activation: Yazici PRO repaired; desktop shell and other PRO refresh skipped');
      const end=Date.now()+45000;
      let yazici={ok:false,details:''};
      while(Date.now()<end){
        const main=await httpJson(17891,'/api/health?_supervisor='+Date.now(),1500);
        const revenue=await httpJson(17893,'/health?_supervisor='+Date.now(),1500);
        const yaziciMeta=readJson(path.join(proRoot,'YaziciPRO','yazici-pro-version.json'))||{};
        const yaziciExpectedVersion=String(yaziciMeta.version||'').trim();
        const mainOk=Boolean(yaziciExpectedVersion)&&main.ok&&main.json&&main.json.ok===true&&String(main.json.version||'')===yaziciExpectedVersion;
        const revenueOk=Boolean(yaziciExpectedVersion)&&revenue.ok&&revenue.json&&revenue.json.ok===true&&String(revenue.json.version||'')===yaziciExpectedVersion;
        if(mainOk&&revenueOk){ yazici={ok:true,details:'17891+17893 health/version OK'}; break; }
        yazici={ok:false,details:JSON.stringify({main:main.json||null,revenue:revenue.json||null})};
        await sleep(250);
      }
      if(!yazici.ok){
        const logDir=path.join(process.env.LOCALAPPDATA||'', 'KafePinYaziciPRO','logs');
        const tails=[];
        for(const f of ['yazici-startup.log','yazici-revenue.err.log','yazici-webservice.err.log']){
          try{ const lines=fs.readFileSync(path.join(logDir,f),'utf8').split(/\r?\n/).filter(Boolean); tails.push(`${f}: ${lines.slice(-12).join(' | ')}`); }catch(_){ tails.push(`${f}: okunamadi`); }
        }
        throw new Error(`Yazici PRO 17891/17893 health veya version dogrulamasi basarisiz: ${yazici.details}; ${tails.join(' || ')}`);
      }
      log(installRoot,'component-only Yazici PRO health/version verified: '+yazici.details);
    } else {
      shell=await ensureDesktopShellExact(installRoot);
      mp3=syncMp3Payload(installRoot,proRoot); await startAndVerifyMp3(mp3);
      componentsSynced=syncPackagedProComponents(installRoot);
      if(componentsSynced){ await runDesktopBridgeAction(installRoot,'refresh-pro-services',70000); proServicesRefreshed=true; }
    }
    const desktopLaunched=!desktopWasRunning || shell.required;
    writeActivation({ok:true,targetVersion,serverVerified:true,desktopShellVersion:shell.version,desktopShellRefreshed:shell.required,mp3Required:mp3.required,mp3Version:mp3.version,mp3Verified:true,proComponentsSynced:componentsSynced,proServicesRefreshed,desktopPreserved:desktopWasRunning&&!shell.required,desktopLaunched,completedAt:Date.now()});
    try{fs.unlinkSync(desktopMarkerPath());}catch(_){}
    log(installRoot,`activate success target=${targetVersion} mp3=${mp3.version||'n/a'}`);
    return true;
  } finally { try{fs.unlinkSync(lockPath);}catch(_){} }
}
async function fullRestart(installRoot,targetVersion){
  log(installRoot,`restart supervisor start target=${targetVersion}`);
  try{fs.unlinkSync(activationPath());}catch(_){}
  // Masaustu kabugunu OLDURME. Desktop kendi 1.5 sn watchdog'u ile server kesintisini
  // gorur ve yeni server gelince WebView'i cache-bust ile otomatik yeniler.
  // Boylece update sonrasi 'kapandi ama geri acilmadi' sinifi tamamen ortadan kalkar.
  const pid=portPid(3000); if(pid&&pid!==process.pid) killPid(pid);
  await waitPortDown(3000,7000);
  launchServerDetached(installRoot,1);
  let serverOk=await waitServerVersion(targetVersion,15000);
  // Birinci detached Windows başlatması bir antivirüs/oturum geçişinde sessizce
  // sonlanırsa, aynı güvenli Node komutu bir kez daha denenir. Her iki deneme de
  // ayrı günlükte görünür; sağlık geçmeden güncelleme başarılı kabul edilmez.
  if(!serverOk){
    log(installRoot,`server launch attempt=1 health timeout target=${targetVersion}; retrying`);
    launchServerDetached(installRoot,2);
    serverOk=await waitServerVersion(targetVersion,15000);
  }
  if(!serverOk) throw new Error(`Yeni KafePin server health-check gecmedi: ${targetVersion}; ayrinti: logs\\update-supervisor-server-launch.log`);
  const end=Date.now()+45000;
  while(Date.now()<end){ const a=readJson(activationPath()); if(a&&a.ok===true&&String(a.targetVersion||'')===targetVersion) return true; if(a&&a.ok===false&&String(a.targetVersion||'')===targetVersion) throw new Error(String(a.error||'Post-update activation failed')); await sleep(300); }
  throw new Error('Post-update aktivasyon health-check zaman asimi');
}
async function selfTest(){
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'kafepin-supervisor-selftest-'));
  try{
    const src=path.join(tmp,'src'),dst=path.join(tmp,'dst'); fs.mkdirSync(src,{recursive:true}); fs.mkdirSync(dst,{recursive:true});
    fs.writeFileSync(path.join(src,'a.txt'),'new'); fs.writeFileSync(path.join(dst,'state.json'),'keep'); fs.writeFileSync(path.join(dst,'a.txt'),'old');
    copyTree(src,dst,new Set(['state.json']));
    if(fs.readFileSync(path.join(dst,'a.txt'),'utf8')!=='new') throw new Error('copyTree overwrite');
    if(fs.readFileSync(path.join(dst,'state.json'),'utf8')!=='keep') throw new Error('preserve failed');
    process.stdout.write('SELFTEST_OK\n');
  } finally { fs.rmSync(tmp,{recursive:true,force:true}); }
}
(async()=>{
  const args=process.argv.slice(2); if(args.includes('--self-test')) return selfTest();
  const root=path.resolve(args[args.indexOf('--install-root')+1]||process.cwd());
  const target=String(args[args.indexOf('--target-version')+1]||'').trim(); if(!/^\d+(\.\d+){1,3}$/.test(target)) throw new Error('target-version gecersiz');
  const activate=args.includes('--activate-only');
  try{ if(activate) await activateOnly(root,target); else await fullRestart(root,target); }
  catch(err){ writeActivation({ok:false,targetVersion:target,error:String(err&&err.message||err),completedAt:Date.now()}); log(root,`FAILED ${String(err&&err.stack||err)}`); process.exitCode=1; }
})();
