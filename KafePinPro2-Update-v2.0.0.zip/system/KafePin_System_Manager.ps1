﻿$ErrorActionPreference='SilentlyContinue'
$Root='C:\KafePin'
$MgrDir='C:\ProgramData\KafePinPro'
$CfgFile=Join-Path $MgrDir 'manager-config.json'
$Maintenance=Join-Path $MgrDir 'maintenance.lock'
$Log=Join-Path $MgrDir 'system-manager.log'

function Log([string]$text){try{Add-Content -Path $Log -Value ("[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$text) -Encoding UTF8}catch{}}
function Get-Cfg { try { return Get-Content $CfgFile -Raw | ConvertFrom-Json } catch { return $null } }
function Get-OwnServerProcess {
  $pidFile=Join-Path $Root 'data\server.pid';if(-not(Test-Path $pidFile)){return $null}
  try{
    $serverPid=[int](Get-Content $pidFile -Raw)
    $p=Get-CimInstance Win32_Process -Filter "ProcessId=$serverPid" -ErrorAction SilentlyContinue
    if(-not $p){return $null}
    $cfg=Get-Cfg;if(-not $cfg){return $null}
    $node=[IO.Path]::GetFullPath([string]$cfg.nodePath)
    $exe=if($p.ExecutablePath){[IO.Path]::GetFullPath([string]$p.ExecutablePath)}else{''}
    $cmd=[string]$p.CommandLine
    $serverScript=Join-Path $Root 'server.js'
    $cmdExpected=[regex]::Escape($serverScript)
    $port=[int]$cfg.port
    $ownsPort=$false
    try{
      $listen=Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue | Where-Object { $_.OwningProcess -eq $serverPid } | Select-Object -First 1
      $ownsPort=[bool]$listen
    }catch{}
    if($exe -eq $node -and $cmd -match $cmdExpected){
      if($ownsPort){return $p}
      # Yeni başlatılan süreç birkaç saniye PID dosyasını yazıp portu daha sonra dinlemeye başlayabilir.
      try{if($p.CreationDate -and ((Get-Date)-([datetime]$p.CreationDate)).TotalSeconds -lt 30){return $p}}catch{}
    }
  }catch{}
  return $null
}
function Apply-PendingRestore {
  $pending=Join-Path $Root 'data\restore-pending.db';$marker=Join-Path $Root 'data\restore-pending.json';$db=Join-Path $Root 'data\kafepin-pro2.db'
  if(-not(Test-Path $pending)){return}
  try{
    $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
    if(Test-Path $db){Copy-Item $db (Join-Path $Root "data\pre-restore-$stamp.db") -Force}
    Move-Item $pending $db -Force
    Remove-Item $marker -Force -ErrorAction SilentlyContinue
    Remove-Item ($db+'-wal') -Force -ErrorAction SilentlyContinue
    Remove-Item ($db+'-shm') -Force -ErrorAction SilentlyContinue
    Log 'Bekleyen yedek geri yükleme uygulandı.'
  }catch{Log ('Geri yükleme uygulanamadı: '+$_.Exception.Message)}
}
Log 'KafePin Pro 2.0 System Manager başladı.'
while($true){
  try{
    if(Test-Path $Maintenance){Start-Sleep -Seconds 2;continue}
    $cfg=Get-Cfg;if(-not $cfg){Log 'manager-config.json okunamadı';Start-Sleep -Seconds 5;continue}
    $own=Get-OwnServerProcess
    if(-not $own){
      Apply-PendingRestore
      $node=[string]$cfg.nodePath
      if((Test-Path $node) -and (Test-Path (Join-Path $Root 'server.js'))){
        $serverScript=Join-Path $Root 'server.js'
        Start-Process -FilePath $node -ArgumentList $serverScript -WorkingDirectory $Root -WindowStyle Hidden
        Log 'KafePin sunucusu başlatıldı.'
      }
    }
  }catch{Log ('Manager hata: '+$_.Exception.Message)}
  Start-Sleep -Seconds 5
}
