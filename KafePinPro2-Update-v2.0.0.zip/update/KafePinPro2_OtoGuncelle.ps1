﻿param(
  [Parameter(Mandatory=$true)][string]$ManifestUrl,
  [Parameter(Mandatory=$true)][string]$ExpectedVersion,
  [Parameter(Mandatory=$true)][string]$ExpectedSha256,
  [string]$SafetyBackup = ''
)
$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$Root='C:\KafePin'
$MgrDir='C:\ProgramData\KafePinPro'
$Marker=Join-Path $Root '.kafepin-pro2-install.json'
$MgrMarker=Join-Path $MgrDir '.kafepin-pro2-manager.json'
$MgrCfg=Join-Path $MgrDir 'manager-config.json'
$Maintenance=Join-Path $MgrDir 'maintenance.lock'
$State=Join-Path $Root 'data\update-state.json'
$Log=Join-Path $Root 'data\update.log'
$RollbackBase=Join-Path $MgrDir 'update-backups'
$ServerScript=Join-Path $Root 'server.js'
$Product='KafePin Pro 2.0'
$ChannelProduct='KAFEPIN_PRO_2'

function Write-Log([string]$t){try{New-Item -ItemType Directory -Force -Path (Split-Path $Log -Parent)|Out-Null;Add-Content -LiteralPath $Log -Value ('['+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')+'] '+$t) -Encoding UTF8}catch{}}
function Write-State([string]$stage,[string]$message,[bool]$running=$true,[hashtable]$extra=@{}){
  try{$o=@{running=$running;stage=$stage;message=$message;time=[DateTimeOffset]::Now.ToUnixTimeMilliseconds();version=$ExpectedVersion;safetyBackup=$SafetyBackup};foreach($k in $extra.Keys){$o[$k]=$extra[$k]};[IO.File]::WriteAllText($State,($o|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))}catch{}
}
function Read-Json([string]$p){return Get-Content -LiteralPath $p -Raw|ConvertFrom-Json}
function Assert-Markers {
  if(-not(Test-Path $Marker)){throw 'KafePin Pro 2.0 sunucu işaretçisi bulunamadı.'}
  if(-not(Test-Path $MgrMarker)){throw 'KafePin Pro 2.0 manager işaretçisi bulunamadı.'}
  if([string](Read-Json $Marker).product -ne $Product){throw 'Sunucu ürün işaretçisi uyuşmuyor.'}
  if([string](Read-Json $MgrMarker).product -ne $Product){throw 'Manager ürün işaretçisi uyuşmuyor.'}
  if(-not(Test-Path $MgrCfg)){throw 'manager-config.json bulunamadı.'}
}
function Stop-OwnServer {
  $pidFile=Join-Path $Root 'data\server.pid';if(-not(Test-Path $pidFile)){return}
  try{
    $serverPid=[int](Get-Content $pidFile -Raw);$p=Get-CimInstance Win32_Process -Filter "ProcessId=$serverPid" -ErrorAction SilentlyContinue;if(-not $p){return}
    $cfg=Read-Json $MgrCfg;$node=[IO.Path]::GetFullPath([string]$cfg.nodePath);$exe=if($p.ExecutablePath){[IO.Path]::GetFullPath([string]$p.ExecutablePath)}else{''}
    if($exe -ne $node){throw 'PID başka bir programa ait; güncelleme güvenlik için durdu.'}
    if(([string]$p.CommandLine) -notmatch [regex]::Escape($ServerScript)){throw 'PID KafePin server.js süreci değil; güncelleme durdu.'}
    Stop-Process -Id $serverPid -Force -ErrorAction Stop
    for($i=0;$i-lt 40;$i++){if(-not(Get-Process -Id $serverPid -ErrorAction SilentlyContinue)){return};Start-Sleep -Milliseconds 250}
    throw 'KafePin sunucusu durdurulamadı.'
  }catch{if($_.Exception.Message -match 'Cannot find a process'){return};throw}
}
function Wait-Health([string]$version,[int]$seconds=40){
  for($i=0;$i-lt ($seconds*2);$i++){Start-Sleep -Milliseconds 500;try{$h=Invoke-RestMethod 'http://127.0.0.1:3000/health' -TimeoutSec 2;if($h.ok -and ([string]$h.version -eq $version)){return $true}}catch{}}
  return $false
}
function Safe-Rel([string]$r){
  if([string]::IsNullOrWhiteSpace($r)){throw 'Boş güncelleme dosya yolu.'}
  if([IO.Path]::IsPathRooted($r) -or $r -match '(^|[\\/])\.\.([\\/]|$)'){throw "Geçersiz güncelleme yolu: $r"}
  $n=$r.Replace('/','\\').TrimStart('\\')
  if($n -match '^(?i:data\\)' -or $n -match '^(?i:logs?\\)' -or $n -match '^\.kafepin'){throw "Kafe verisi/işaretçisi güncelleme paketiyle değiştirilemez: $r"}
  return $n
}
function Download-File([string]$url,[string]$dest){
  try{Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing -TimeoutSec 180}catch{& curl.exe -fL --retry 3 --retry-delay 1 -o $dest $url;if($LASTEXITCODE -ne 0){throw}}
}
function Copy-Backup([string]$source,[string]$relative,[string]$rollback){if(Test-Path $source){$d=Join-Path $rollback $relative;New-Item -ItemType Directory -Force -Path (Split-Path $d -Parent)|Out-Null;Copy-Item -LiteralPath $source -Destination $d -Force;return $true};return $false}

$work=Join-Path $env:TEMP ('KafePinPro2Update_'+[guid]::NewGuid().ToString('N'))
$zip=Join-Path $work 'update.zip';$expanded=Join-Path $work 'expanded';$rollback=$null;$newFiles=@();$existingFiles=@();$managerWasBacked=$false;$touchedProduction=$false
try{
  Assert-Markers
  Write-Log ('Güncelleme başladı → v'+$ExpectedVersion)
  Write-State 'download' 'Merkezi paket indiriliyor.' $true
  New-Item -ItemType Directory -Force -Path $work,$expanded,$RollbackBase|Out-Null
  $sep=if($ManifestUrl.Contains('?')){'&'}else{'?'};$fresh=$ManifestUrl+$sep+'cb='+[DateTimeOffset]::Now.ToUnixTimeMilliseconds()
  $manifest=$null
  try{$manifest=Invoke-RestMethod -Uri $fresh -UseBasicParsing -TimeoutSec 30}catch{$manifest=(& curl.exe -fsSL --retry 2 $fresh|ConvertFrom-Json);if($LASTEXITCODE -ne 0 -or -not $manifest){throw}}
  if([string]$manifest.product -ne $ChannelProduct){throw 'GitHub manifesti KafePin Pro 2.0 kanalına ait değil.'}
  if([string]$manifest.version -ne $ExpectedVersion){throw 'GitHub sürümü kontrol sonrası değişti; işlem iptal edildi.'}
  if([string]$manifest.sha256 -ne $ExpectedSha256){throw 'GitHub SHA256 kontrol sonrası değişti; işlem iptal edildi.'}
  if(([string]$manifest.downloadUrl) -notmatch '^https://'){throw 'Güncelleme indirme adresi geçersiz.'}
  Download-File ([string]$manifest.downloadUrl) $zip
  $actual=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
  if($actual -ne $ExpectedSha256.ToLowerInvariant()){throw 'İndirilen güncelleme ZIP SHA256 doğrulaması başarısız.'}
  Expand-Archive -LiteralPath $zip -DestinationPath $expanded -Force
  $infoPath=Join-Path $expanded 'update.json';if(-not(Test-Path $infoPath)){throw 'update.json bulunamadı.'}
  $info=Read-Json $infoPath
  if([string]$info.product -ne $ChannelProduct){throw 'update.json ürün kimliği geçersiz.'}
  if([string]$info.version -ne $ExpectedVersion){throw 'update.json sürümü beklenen sürüm değil.'}
  if(-not $info.files -or $info.files.Count -lt 1){throw 'Güncellenecek dosya listesi boş.'}

  $safeFiles=@();foreach($r in $info.files){$safe=Safe-Rel ([string]$r);$source=Join-Path $expanded $safe;if(-not(Test-Path $source -PathType Leaf)){throw "Paket dosyası eksik: $safe"};$safeFiles+=$safe}
  $managerRel='';if($info.managerFile){$managerRel=Safe-Rel ([string]$info.managerFile);if(-not(Test-Path (Join-Path $expanded $managerRel) -PathType Leaf)){throw 'Manager güncelleme dosyası pakette yok.'}}

  Write-State 'prepare' 'Paket doğrulandı; rollback yedeği hazırlanıyor.' $true
  $rollback=Join-Path $RollbackBase (Get-Date -Format 'yyyyMMdd-HHmmss')
  New-Item -ItemType Directory -Force -Path $rollback|Out-Null
  Copy-Item $Marker (Join-Path $rollback 'install-marker.json') -Force
  Copy-Item $MgrCfg (Join-Path $rollback 'manager-config.json') -Force
  foreach($safe in $safeFiles){$target=Join-Path $Root $safe;if(Copy-Backup $target $safe $rollback){$existingFiles+=$safe}else{$newFiles+=$safe}}
  if($managerRel){$mgrTarget=Join-Path $MgrDir 'KafePin_System_Manager.ps1';$managerWasBacked=Copy-Backup $mgrTarget 'manager\KafePin_System_Manager.ps1' $rollback}
  [IO.File]::WriteAllText((Join-Path $rollback 'rollback-meta.json'),(@{existing=$existingFiles;newFiles=$newFiles;managerWasBacked=$managerWasBacked;version=$ExpectedVersion}|ConvertTo-Json -Depth 5),(New-Object Text.UTF8Encoding($false)))

  [IO.File]::WriteAllText($Maintenance,('UPDATE '+$ExpectedVersion+' '+(Get-Date).ToString('o')),(New-Object Text.UTF8Encoding($false)))
  Write-State 'stop' 'KafePin sunucusu güvenli biçimde durduruluyor.' $true
  Stop-OwnServer
  $touchedProduction=$true
  Start-Sleep -Milliseconds 500

  Write-State 'copy' ('Program dosyaları kuruluyor: v'+$ExpectedVersion) $true
  foreach($safe in $safeFiles){$source=Join-Path $expanded $safe;$target=Join-Path $Root $safe;New-Item -ItemType Directory -Force -Path (Split-Path $target -Parent)|Out-Null;Copy-Item -LiteralPath $source -Destination $target -Force}
  if($managerRel){Copy-Item -LiteralPath (Join-Path $expanded $managerRel) -Destination (Join-Path $MgrDir 'KafePin_System_Manager.ps1') -Force}
  $mark=Read-Json $Marker;$mark.version=$ExpectedVersion;$mark.updatedAt=(Get-Date).ToString('o');[IO.File]::WriteAllText($Marker,($mark|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
  $cfg=Read-Json $MgrCfg;$cfg.version=$ExpectedVersion;[IO.File]::WriteAllText($MgrCfg,($cfg|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
  Remove-Item $Maintenance -Force -ErrorAction SilentlyContinue
  Write-State 'restart' 'System Manager yeni sürümü başlatıyor.' $true
  if(-not(Wait-Health $ExpectedVersion 45)){throw 'Yeni sürüm sağlık kontrolünden geçmedi.'}
  Write-State 'success' ('Güncelleme tamamlandı: v'+$ExpectedVersion) $false @{rollback=$rollback}
  Write-Log ('Güncelleme başarılı: v'+$ExpectedVersion)
  # En yeni 3 rollback klasörünü sakla.
  try{Get-ChildItem $RollbackBase -Directory|Sort-Object LastWriteTime -Descending|Select-Object -Skip 3|Remove-Item -Recurse -Force}catch{}
}catch{
  $msg=$_.Exception.Message;Write-Log ('Güncelleme hatası: '+$msg);Write-State 'rollback' ('Hata oluştu; eski sürüme dönülüyor: '+$msg) $true
  if($touchedProduction){
    try{
      if(-not(Test-Path $Maintenance)){[IO.File]::WriteAllText($Maintenance,'ROLLBACK',(New-Object Text.UTF8Encoding($false)))}
      Stop-OwnServer
      if($rollback -and (Test-Path $rollback)){
        $metaPath=Join-Path $rollback 'rollback-meta.json'
        if(-not(Test-Path $metaPath)){throw 'Rollback meta dosyası bulunamadı.'}
        $meta=Read-Json $metaPath
        foreach($safe in $meta.existing){$src=Join-Path $rollback ([string]$safe);$dst=Join-Path $Root ([string]$safe);if(Test-Path $src){New-Item -ItemType Directory -Force -Path (Split-Path $dst -Parent)|Out-Null;Copy-Item $src $dst -Force}}
        foreach($safe in $meta.newFiles){$dst=Join-Path $Root ([string]$safe);Remove-Item $dst -Force -ErrorAction SilentlyContinue}
        if($meta.managerWasBacked){Copy-Item (Join-Path $rollback 'manager\KafePin_System_Manager.ps1') (Join-Path $MgrDir 'KafePin_System_Manager.ps1') -Force}
        Copy-Item (Join-Path $rollback 'install-marker.json') $Marker -Force
        Copy-Item (Join-Path $rollback 'manager-config.json') $MgrCfg -Force
      }
    }catch{Write-Log ('Rollback dosya hatası: '+$_.Exception.Message)}
    Remove-Item $Maintenance -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
    Write-State 'error' ('Güncelleme tamamlanamadı; eski sürüm geri yüklendi: '+$msg) $false @{rollback=$rollback}
  }else{
    Remove-Item $Maintenance -Force -ErrorAction SilentlyContinue
    Write-State 'error' ('Güncelleme uygulanmadan durdu; çalışan sürüm değiştirilmedi: '+$msg) $false @{rollback=$rollback}
  }
}finally{
  Remove-Item $Maintenance -Force -ErrorAction SilentlyContinue
  Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue
}
