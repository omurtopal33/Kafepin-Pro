'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { URL } = require('url');
const { DatabaseSync } = require('node:sqlite');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA, 'kafepin-pro2.db');
const RUNTIME_FILE = path.join(DATA, 'runtime.json');
const LOG_FILE = path.join(DATA, 'server.log');
const PID_FILE = path.join(DATA, 'server.pid');
const VERSION = '2.0.0';
const TIME_ZONE = 'Europe/Istanbul';
fs.mkdirSync(DATA, { recursive: true });
try { fs.writeFileSync(PID_FILE, String(process.pid), 'ascii'); } catch (_) {}

function readJson(file, fallback = {}) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) { return fallback; }
}
const RT = readJson(RUNTIME_FILE, {});
const PORT = Math.max(1, Math.min(65535, Number(process.env.KAFEPIN_PORT || RT.port || 3000)));
const HOST = RT.safeMode ? '127.0.0.1' : '0.0.0.0';
const TEST_MODE = Boolean(RT.testMode);
const CLIENT_ONLINE_MS = 15000;

function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}`;
  console.log(line);
  try { fs.appendFileSync(LOG_FILE, line + '\n', 'utf8'); } catch (_) {}
}


// KafePin Pro 2.0 merkezi güncelleme kanalı.
// Mevcut kafedeki eski KafePin güncelleme kanalıyla karışmaması için ayrı manifest kullanılır.
const UPDATE_CHANNEL = 'kafepinpro2';
const UPDATE_MANIFEST_URL = process.env.KAFEPIN_UPDATE_MANIFEST_URL ||
  'https://raw.githubusercontent.com/omurtopal33/Kafepin-Pro/main/kafepinpro2/latest.json';
const UPDATE_STATE_FILE = path.join(DATA, 'update-state.json');
const UPDATE_SCRIPT = path.join(ROOT, 'update', 'KafePinPro2_OtoGuncelle.ps1');
const CLIENT_DIR = path.join(ROOT, 'client');
const CLIENT_VERSION_FILE = path.join(CLIENT_DIR, 'client-version.json');
const CLIENT_SOURCE_FILE = path.join(CLIENT_DIR, 'KafePinClient.cs');
const CLIENT_UPDATER_FILE = path.join(CLIENT_DIR, 'KafePinClientSelfUpdate.ps1');
let updateCache = { checkedAt: 0, data: null, error: '' };

function compareVersions(a,b){
  const aa=String(a||'0').split('.').map(x=>Number(x)||0),bb=String(b||'0').split('.').map(x=>Number(x)||0);
  for(let i=0;i<Math.max(aa.length,bb.length);i++){const x=aa[i]||0,y=bb[i]||0;if(x!==y)return x>y?1:-1;}return 0;
}
function fileSha256(file){return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');}
function readUpdateState(){return readJson(UPDATE_STATE_FILE,{running:false,stage:'idle',message:'',time:0});}
function writeUpdateState(stage,message,extra={}){try{fs.writeFileSync(UPDATE_STATE_FILE,JSON.stringify({running:!['success','error','idle'].includes(stage),stage,message,time:Date.now(),...extra},null,2),'utf8');}catch(_){}}
async function checkUpdateManifest(force=false){
  const now=Date.now();
  if(!force&&updateCache.data&&now-updateCache.checkedAt<60000)return updateCache.data;
  const sep=UPDATE_MANIFEST_URL.includes('?')?'&':'?';
  const url=UPDATE_MANIFEST_URL+sep+'cb='+Date.now()+'_'+Math.random().toString(36).slice(2);
  try{
    const r=await fetch(url,{headers:{'User-Agent':'KafePin-Pro-2-Updater','Cache-Control':'no-cache, no-store','Pragma':'no-cache'}});
    if(!r.ok)throw new Error('Güncelleme merkezi HTTP '+r.status);
    const remote=await r.json();
    if(!remote||remote.product!=='KAFEPIN_PRO_2')throw new Error('Güncelleme kanalı bu ürün için değil');
    if(!/^\d+(\.\d+){1,3}$/.test(String(remote.version||'')))throw new Error('Güncelleme sürümü geçersiz');
    if(!/^https:\/\//i.test(String(remote.downloadUrl||'')))throw new Error('Güncelleme indirme adresi geçersiz');
    if(!/^[a-f0-9]{64}$/i.test(String(remote.sha256||'')))throw new Error('Güncelleme SHA256 eksik/geçersiz');
    const data={ok:true,channel:UPDATE_CHANNEL,currentVersion:VERSION,latestVersion:String(remote.version),available:compareVersions(remote.version,VERSION)>0,notes:String(remote.notes||''),publishedAt:remote.publishedAt||null,downloadUrl:String(remote.downloadUrl),sha256:String(remote.sha256).toLowerCase(),manifestUrl:UPDATE_MANIFEST_URL,checkedAt:Date.now()};
    updateCache={checkedAt:Date.now(),data,error:''};return data;
  }catch(e){updateCache={checkedAt:Date.now(),data:null,error:String(e.message||e)};throw e;}
}
function clientPackageMeta(){
  const v=readJson(CLIENT_VERSION_FILE,{version:'2.0.0'});
  const version=String(v.version||'2.0.0');
  if(!fs.existsSync(CLIENT_SOURCE_FILE)||!fs.existsSync(CLIENT_UPDATER_FILE))return null;
  return {version,sourceSha256:fileSha256(CLIENT_SOURCE_FILE),updaterSha256:fileSha256(CLIENT_UPDATER_FILE)};
}
function clientUpdateInfo(currentVersion,host){
  const m=clientPackageMeta(); if(!m)return {available:false};
  const base='http://'+host;
  return {available:compareVersions(m.version,currentVersion)>0,version:m.version,sourceSha256:m.sourceSha256,updaterSha256:m.updaterSha256,sourceUrl:base+'/api/client/package/source',updaterUrl:base+'/api/client/package/updater'};
}
function serveFile(res,file,type){if(!fs.existsSync(file))return text(res,404,'Not found');const b=fs.readFileSync(file);res.writeHead(200,{'Content-Type':type,'Content-Length':b.length,'Cache-Control':'no-store'});res.end(b);}
function launchServerUpdater(status,backupPath){
  if(!fs.existsSync(UPDATE_SCRIPT))throw new Error('Güncelleyici dosyası bulunamadı');
  const args=['-NoProfile','-ExecutionPolicy','Bypass','-File',UPDATE_SCRIPT,'-ManifestUrl',UPDATE_MANIFEST_URL,'-ExpectedVersion',status.latestVersion,'-ExpectedSha256',status.sha256,'-SafetyBackup',String(backupPath||'')];
  const child=spawn('powershell.exe',args,{detached:true,stdio:'ignore',windowsHide:true});child.unref();
}

const db = new DatabaseSync(DB_FILE);
db.exec(`
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA foreign_keys=ON;
PRAGMA busy_timeout=10000;
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS client_state(masa INTEGER PRIMARY KEY,last_seen INTEGER NOT NULL DEFAULT 0,client_id TEXT NOT NULL DEFAULT '',client_version TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS sessions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  masa INTEGER NOT NULL,
  source TEXT NOT NULL,
  source_id TEXT NOT NULL DEFAULT '',
  start_ts INTEGER NOT NULL,
  end_ts INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  free_minutes REAL NOT NULL DEFAULT 0,
  spin_used INTEGER NOT NULL DEFAULT 0,
  wheel_ready_at INTEGER NOT NULL DEFAULT 0,
  final_fee REAL NOT NULL DEFAULT 0,
  source_total REAL NOT NULL DEFAULT 0,
  close_reason TEXT NOT NULL DEFAULT '',
  day_key TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_sessions_active_masa ON sessions(masa) WHERE active=1;
CREATE UNIQUE INDEX IF NOT EXISTS ux_sessions_source_id ON sessions(source,source_id) WHERE source_id<>'';
CREATE TABLE IF NOT EXISTS rewards(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  weight REAL NOT NULL DEFAULT 1,
  type TEXT NOT NULL DEFAULT 'PRODUCT',
  value REAL NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS spin_history(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL,
  day_key TEXT NOT NULL,
  masa INTEGER NOT NULL,
  session_id INTEGER NOT NULL,
  reward_id INTEGER NOT NULL DEFAULT 0,
  reward_name TEXT NOT NULL,
  reward_type TEXT NOT NULL,
  reward_value REAL NOT NULL DEFAULT 0,
  pending INTEGER NOT NULL DEFAULT 0,
  approved_at INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS local_products(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Diğer',
  price REAL NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS direct_sales(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL,
  day_key TEXT NOT NULL,
  product_source TEXT NOT NULL,
  external_id TEXT NOT NULL DEFAULT '',
  product_name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT '',
  unit_price REAL NOT NULL,
  quantity REAL NOT NULL,
  total REAL NOT NULL,
  payment_method TEXT NOT NULL DEFAULT 'CASH',
  note TEXT NOT NULL DEFAULT '',
  voided INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS ledger(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL,
  day_key TEXT NOT NULL,
  type TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT '',
  amount REAL NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  voided INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS everycafe_categories(
  category_id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  last_seen INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS everycafe_products(
  stock_id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  category_id INTEGER NOT NULL DEFAULT 0,
  category_name TEXT NOT NULL DEFAULT '',
  price REAL NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  last_seen INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS everycafe_sales(
  source_id TEXT PRIMARY KEY,
  client_name TEXT NOT NULL DEFAULT '',
  masa INTEGER NOT NULL DEFAULT 0,
  start_ts INTEGER NOT NULL DEFAULT 0,
  end_ts INTEGER NOT NULL,
  day_key TEXT NOT NULL,
  total REAL NOT NULL DEFAULT 0,
  payment_method TEXT NOT NULL DEFAULT 'OTHER',
  direct_sale INTEGER NOT NULL DEFAULT 0,
  session_type INTEGER NOT NULL DEFAULT 0,
  session_type_text TEXT NOT NULL DEFAULT '',
  orders_json TEXT NOT NULL DEFAULT '[]',
  imported_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS everycafe_member_payments(
  history_id INTEGER PRIMARY KEY,
  member_id INTEGER NOT NULL DEFAULT 0,
  ts INTEGER NOT NULL,
  day_key TEXT NOT NULL,
  amount REAL NOT NULL,
  payment_method TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  imported_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL,
  type TEXT NOT NULL,
  text TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
`);

const stmt = {
  getSetting: db.prepare('SELECT value FROM settings WHERE key=?'),
  setSetting: db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value"),
  getMeta: db.prepare('SELECT value FROM meta WHERE key=?'),
  setMeta: db.prepare("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value"),
  addEvent: db.prepare('INSERT INTO events(ts,type,text) VALUES(?,?,?)'),
  trimEvents: db.prepare('DELETE FROM events WHERE id NOT IN (SELECT id FROM events ORDER BY id DESC LIMIT 500)'),
  getClient: db.prepare('SELECT * FROM client_state WHERE masa=?'),
  touchClient: db.prepare("INSERT INTO client_state(masa,last_seen,client_id,client_version) VALUES(?,?,?,?) ON CONFLICT(masa) DO UPDATE SET last_seen=excluded.last_seen,client_id=excluded.client_id,client_version=excluded.client_version"),
  activeSession: db.prepare('SELECT * FROM sessions WHERE masa=? AND active=1 ORDER BY id DESC LIMIT 1'),
  sessionById: db.prepare('SELECT * FROM sessions WHERE id=?'),
  insertSession: db.prepare('INSERT INTO sessions(masa,source,source_id,start_ts,end_ts,active,free_minutes,spin_used,wheel_ready_at,final_fee,source_total,close_reason,day_key,created_at) VALUES(?,?,?,?,0,1,0,0,?,0,0,\'\',\'\',?)'),
  updateSessionClose: db.prepare('UPDATE sessions SET end_ts=?,active=0,final_fee=?,source_total=?,close_reason=?,day_key=? WHERE id=? AND active=1'),
  updateSessionWheel: db.prepare('UPDATE sessions SET spin_used=?,wheel_ready_at=?,free_minutes=? WHERE id=? AND active=1'),
  activeRewards: db.prepare('SELECT * FROM rewards WHERE active=1 AND weight>0 ORDER BY sort_order,id'),
};

function metaGet(key, fallback = '') { const r = stmt.getMeta.get(key); return r ? r.value : fallback; }
function metaSet(key, value) { stmt.setMeta.run(key, String(value)); }
function event(type, text) { stmt.addEvent.run(Date.now(), String(type), String(text)); stmt.trimEvents.run(); }

function defaultRewards() {
  return [
    { name: 'Tekrar Dene', weight: 30, type: 'NONE', value: 0 },
    { name: '30 dk Ücretsiz', weight: 20, type: 'MINUTES', value: 30 },
    { name: '60 dk Ücretsiz', weight: 8, type: 'MINUTES', value: 60 },
    { name: 'İçecek Hediyesi', weight: 18, type: 'PRODUCT', value: 0 },
    { name: 'Atıştırmalık Hediyesi', weight: 14, type: 'PRODUCT', value: 0 },
    { name: 'Sürpriz Hediye', weight: 10, type: 'PRODUCT', value: 0 },
  ];
}

function incrementIpv4(base,offset=0){const a=String(base).split('.').map(Number);let n=(((a[0]*256+a[1])*256+a[2])*256+a[3])+Number(offset||0);return [Math.floor(n/16777216)%256,Math.floor(n/65536)%256,Math.floor(n/256)%256,n%256].join('.');}
function defaultConfig() {
  const tables = [];
  for (let i = 1; i <= 8; i++) tables.push({ masa: i, ip: incrementIpv4('192.168.1.101',i-1), type: i <= 2 ? 'VIP' : 'Normal' });
  return {
    cafeName: 'Yeni Kafe', tableCount: 8, tables,
    everyCafe: false, everyPath: 'C:\\Program Files (x86)\\EveryCafeManager\\ecmdata.ecm',
    normalOpen: 100, vipOpen: 120, normalBaseMin: 60, normalIncMin: 30,
    normalInc: 50, vipInc: 60, tolerance: 2, graceMinutes: 5,
    offlineMinutes: 8,
    wheel: true, wheelMinutes: 45, dailySpin: 5,
    telegram: false, telegramToken: '', telegramChat: '',
    backup: 'D:\\KafePin_Yedek', dayEnd: '19:59',
    installedVersion: VERSION
  };
}

function normalizeConfig(input) {
  const f = defaultConfig();
  const c = { ...f, ...(input || {}) };
  c.cafeName = String(c.cafeName || 'Yeni Kafe').trim().slice(0, 80) || 'Yeni Kafe';
  c.tableCount = Math.max(1, Math.min(200, Math.trunc(Number(c.tableCount) || 8)));
  c.tables = Array.isArray(c.tables) ? c.tables : [];
  while (c.tables.length < c.tableCount) {
    const i = c.tables.length + 1;
    c.tables.push({ masa: i, ip: incrementIpv4('192.168.1.101',i-1), type: 'Normal' });
  }
  c.tables = c.tables.slice(0, c.tableCount).map((t, i) => ({ masa: i + 1, ip: String(t.ip || '').trim(), type: t.type === 'VIP' ? 'VIP' : 'Normal' }));
  const ips = new Set();
  for (const t of c.tables) {
    if (!isIpv4(t.ip)) throw new Error(`Masa ${t.masa} için geçerli IPv4 girilmedi: ${t.ip}`);
    if (ips.has(t.ip)) throw new Error(`Aynı IP iki masada kullanılamaz: ${t.ip}`);
    ips.add(t.ip);
  }
  for (const k of ['normalOpen','vipOpen','normalBaseMin','normalIncMin','normalInc','vipInc','tolerance','graceMinutes','offlineMinutes','wheelMinutes','dailySpin']) {
    c[k] = Math.max(0, Number(c[k]) || 0);
  }
  c.normalBaseMin = Math.max(1, c.normalBaseMin);
  c.normalIncMin = Math.max(1, c.normalIncMin);
  c.offlineMinutes = Math.max(1, c.offlineMinutes);
  c.wheelMinutes = Math.max(1, c.wheelMinutes);
  c.dailySpin = Math.max(1, Math.trunc(c.dailySpin));
  c.everyCafe = Boolean(c.everyCafe);
  c.everyPath = String(c.everyPath || '').trim();
  c.wheel = Boolean(c.wheel);
  c.telegram = Boolean(c.telegram);
  c.telegramToken = String(c.telegramToken || '').trim();
  c.telegramChat = String(c.telegramChat || '').trim();
  c.backup = String(c.backup || '').trim();
  c.dayEnd = /^\d{2}:\d{2}$/.test(String(c.dayEnd || '')) ? String(c.dayEnd) : '19:59';
  c.installedVersion = VERSION;
  return c;
}
function getConfig() {
  const r = stmt.getSetting.get('config');
  if (!r) {
    const c = defaultConfig();
    setConfig(c, { seedRewards: true, silent: true });
    return c;
  }
  try { return normalizeConfig(JSON.parse(r.value)); } catch (e) { log('Config parse error: ' + e.message); return defaultConfig(); }
}
function setConfig(raw, options = {}) {
  const c = normalizeConfig(raw);
  stmt.setSetting.run('config', JSON.stringify(c));
  for (const t of c.tables) stmt.touchClient.run(t.masa, 0, '', '');
  if (options.seedRewards && Number(db.prepare('SELECT COUNT(*) AS n FROM rewards').get().n) === 0) {
    const ins = db.prepare('INSERT INTO rewards(name,weight,type,value,active,sort_order) VALUES(?,?,?,?,1,?)');
    defaultRewards().forEach((r, i) => ins.run(r.name, r.weight, r.type, r.value, i));
  }
  if (!options.silent) event('config', 'Kurulum / ayarlar güncellendi');
  return c;
}
let config = getConfig();
if (Number(db.prepare('SELECT COUNT(*) AS n FROM rewards').get().n) === 0) setConfig(config, { seedRewards: true, silent: true });

function isIpv4(v) {
  const p = String(v).split('.');
  return p.length === 4 && p.every(x => /^\d{1,3}$/.test(x) && Number(x) >= 0 && Number(x) <= 255);
}
function reqIp(req) {
  let ip = String(req.socket && req.socket.remoteAddress || '');
  if (ip.startsWith('::ffff:')) ip = ip.slice(7);
  if (ip === '::1') ip = '127.0.0.1';
  if (TEST_MODE && req.headers['x-kafepin-test-ip']) ip = String(req.headers['x-kafepin-test-ip']);
  return ip;
}
function isLocal(req) {
  const ip = reqIp(req);
  return ip === '127.0.0.1' || ip === '::1';
}
function tableByIp(ip) { return config.tables.find(t => t.ip === ip) || null; }
function tableByMasa(masa) { return config.tables.find(t => Number(t.masa) === Number(masa)) || null; }

const dayFmt = new Intl.DateTimeFormat('en-CA', { timeZone: TIME_ZONE, year:'numeric', month:'2-digit', day:'2-digit' });
const clockFmt = new Intl.DateTimeFormat('en-GB', { timeZone: TIME_ZONE, hour:'2-digit', minute:'2-digit', hour12:false });
function dayKey(ts = Date.now()) {
  const parts = Object.fromEntries(dayFmt.formatToParts(new Date(ts)).filter(p => p.type !== 'literal').map(p => [p.type,p.value]));
  return `${parts.year}-${parts.month}-${parts.day}`;
}
function clockKey(ts = Date.now()) {
  const parts = Object.fromEntries(clockFmt.formatToParts(new Date(ts)).filter(p => p.type !== 'literal').map(p => [p.type,p.value]));
  return `${parts.hour}:${parts.minute}`;
}
function addIsoDays(iso, days) {
  const [y,m,d]=String(iso).split('-').map(Number),x=new Date(Date.UTC(y,m-1,d));
  x.setUTCDate(x.getUTCDate()+Number(days||0));
  return `${x.getUTCFullYear()}-${String(x.getUTCMonth()+1).padStart(2,'0')}-${String(x.getUTCDate()).padStart(2,'0')}`;
}
function businessDayKey(ts = Date.now()) {
  const base=dayKey(ts),clock=clockKey(ts),[h,m]=clock.split(':').map(Number);
  const end=String((typeof config!=='undefined'&&config&&config.dayEnd)||'19:59'),[eh,em]=end.split(':').map(Number);
  // Gün sonu dakikası eski iş gününün son dakikasıdır. Sonraki dakika yeni iş gününe yazılır.
  return (h*60+m)>(eh*60+em) ? addIsoDays(base,1) : base;
}
function elapsedMinutes(session, now = Date.now()) { return session && session.active ? Math.max(0, (now - Number(session.start_ts)) / 60000) : 0; }
function feeFor(masa, elapsed, freeMinutes = 0) {
  if (config.everyCafe) return null;
  const t = tableByMasa(masa); if (!t) return 0;
  const billable = Math.max(0, Number(elapsed) - Math.max(0, Number(freeMinutes) || 0));
  const m = billable;
  if (m <= config.graceMinutes) return 0;
  const opening = t.type === 'VIP' ? config.vipOpen : config.normalOpen;
  const inc = t.type === 'VIP' ? config.vipInc : config.normalInc;
  const first = config.normalBaseMin + config.tolerance;
  if (m < first) return roundMoney(opening);
  return roundMoney(opening + (1 + Math.floor((m - first) / config.normalIncMin)) * inc);
}
function feeSchedule(elapsed, freeMinutes = 0) {
  const billable = Math.max(0, Number(elapsed) - Math.max(0, Number(freeMinutes) || 0));
  const first = config.normalBaseMin + config.tolerance;
  let next = first;
  if (billable >= first) next = first + (Math.floor((billable - first) / config.normalIncMin) + 1) * config.normalIncMin;
  return { firstIncreaseAt:first, nextIncreaseAt:next, billableMinutes:round1(billable) };
}
function roundMoney(v) { return Math.round((Number(v) || 0) * 100) / 100; }
function round1(v) { return Math.round((Number(v) || 0) * 10) / 10; }

function getActiveSession(masa) { return stmt.activeSession.get(Number(masa)) || null; }
function startStandaloneSession(masa, now = Date.now()) {
  if (config.everyCafe) return getActiveSession(masa);
  let s = getActiveSession(masa); if (s) return s;
  const ready = now + config.wheelMinutes * 60000;
  stmt.insertSession.run(Number(masa), 'KAFEPIN', '', now, ready, now);
  s = getActiveSession(masa);
  event('session', `Masa ${masa} oturumu başladı`);
  return s;
}
function startEveryCafeSession(masa, sourceId, startTs, sourceTotal = 0) {
  const old = getActiveSession(masa);
  if (old && old.source === 'EVERYCAFE' && old.source_id === sourceId) return old;
  if (old) closeSession(old, Date.now(), 'SOURCE_CHANGED', old.source_total || 0);
  const ready = startTs + config.wheelMinutes * 60000;
  try { stmt.insertSession.run(Number(masa), 'EVERYCAFE', String(sourceId), Number(startTs), ready, Date.now()); } catch (e) {
    const prior = db.prepare('SELECT * FROM sessions WHERE source=\'EVERYCAFE\' AND source_id=? ORDER BY id DESC LIMIT 1').get(String(sourceId));
    if (prior && !prior.active) {
      db.prepare('UPDATE sessions SET masa=?,start_ts=?,end_ts=0,active=1,free_minutes=0,spin_used=0,wheel_ready_at=?,final_fee=0,source_total=? ,close_reason=\'\',day_key=\'\' WHERE id=?').run(Number(masa), Number(startTs), ready, Number(sourceTotal)||0, prior.id);
    } else throw e;
  }
  event('everycafe', `Masa ${masa} EveryCafe oturumu algılandı`);
  return getActiveSession(masa);
}
function closeSession(session, endTs = Date.now(), reason = 'CLOSED', sourceTotal = null) {
  if (!session || !session.active) return;
  const elapsed = Math.max(0, (Number(endTs) - Number(session.start_ts)) / 60000);
  const total = sourceTotal == null ? Number(session.source_total || 0) : Number(sourceTotal || 0);
  const f = session.source === 'KAFEPIN' ? feeFor(session.masa, elapsed, session.free_minutes) : 0;
  stmt.updateSessionClose.run(Number(endTs), f == null ? 0 : f, total, String(reason), businessDayKey(endTs), session.id);
  event('session', `Masa ${session.masa} oturumu kapandı • ${reason}`);
}
function wheelState(session, now = Date.now()) {
  if (!config.wheel) return { enabled:false,status:'disabled',remainingMs:0,used:session?session.spin_used:0,limit:config.dailySpin };
  if (!session || !session.active) return { enabled:true,status:'waiting_session',remainingMs:0,used:0,limit:config.dailySpin };
  if (Number(session.spin_used) >= config.dailySpin) return { enabled:true,status:'limit',remainingMs:0,used:Number(session.spin_used),limit:config.dailySpin };
  const readyAt = Number(session.wheel_ready_at) || (Number(session.start_ts) + config.wheelMinutes*60000);
  const remainingMs = Math.max(0, readyAt - now);
  return { enabled:true,status:remainingMs <= 0 ? 'ready' : 'countdown',remainingMs,readyAt,used:Number(session.spin_used),limit:config.dailySpin,wheelMinutes:config.wheelMinutes };
}
function tableView(t) {
  const c = stmt.getClient.get(t.masa) || { last_seen:0,client_id:'',client_version:'' };
  const s = getActiveSession(t.masa);
  const mins = elapsedMinutes(s);
  return {
    ...t,
    lastSeen:Number(c.last_seen)||0,
    clientId:c.client_id||'',clientVersion:c.client_version||'',
    online:Boolean(c.last_seen && Date.now()-Number(c.last_seen) <= CLIENT_ONLINE_MS),
    session:s,
    elapsedMinutes:round1(mins),
    fee:s ? feeFor(t.masa, mins, s.free_minutes) : null,
    feeSchedule:s ? feeSchedule(mins, s.free_minutes) : feeSchedule(0,0),
    wheelState:wheelState(s)
  };
}

function rewardRows() { return stmt.activeRewards.all().map(r => ({...r,id:Number(r.id),weight:Number(r.weight),value:Number(r.value)})); }
function chooseReward(rows) {
  const total = rows.reduce((s,r)=>s+Math.max(0,Number(r.weight)||0),0);
  if (!rows.length || total <= 0) return null;
  let x = Math.random()*total;
  for (const r of rows) { x -= Math.max(0,Number(r.weight)||0); if (x <= 0) return r; }
  return rows[rows.length-1];
}
function useSpin(masa) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const s = getActiveSession(masa);
    const st = wheelState(s);
    if (st.status !== 'ready') throw new Error(st.status === 'limit' ? 'Çark limiti doldu' : 'Çark henüz hazır değil');
    const rewards = rewardRows();
    const reward = chooseReward(rewards);
    if (!reward) throw new Error('Aktif çark ödülü tanımlanmamış');
    let free = Number(s.free_minutes)||0;
    const type = String(reward.type||'PRODUCT').toUpperCase();
    const val = Math.max(0,Number(reward.value)||0);
    if (type === 'MINUTES' && s.source === 'KAFEPIN') free += val;
    const nextReady = Date.now() + config.wheelMinutes*60000;
    const used = Number(s.spin_used)+1;
    stmt.updateSessionWheel.run(used,nextReady,free,s.id);
    const pending = type === 'PRODUCT' || (type === 'MINUTES' && s.source === 'EVERYCAFE') ? 1 : 0;
    const info = stmt.activeSession.get(Number(masa));
    const result = db.prepare('INSERT INTO spin_history(ts,day_key,masa,session_id,reward_id,reward_name,reward_type,reward_value,pending,approved_at) VALUES(?,?,?,?,?,?,?,?,?,0)').run(Date.now(),businessDayKey(),Number(masa),s.id,reward.id,reward.name,type,val,pending);
    db.exec('COMMIT');
    event('spin', `Masa ${masa} • ${reward.name}` + (pending ? ' • onay bekliyor' : ''));
    return { spinId:Number(result.lastInsertRowid),reward:{id:reward.id,name:reward.name,type,value:val},pending:Boolean(pending),state:wheelState(info) };
  } catch (e) { try { db.exec('ROLLBACK'); } catch (_) {} throw e; }
}

function normalizeText(v) { return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/ı/g,'i'); }
function everyCafeTableNumber(name) { const m=String(name||'').trim().match(/(\d+)\s*$/); return m ? Number(m[1]) : 0; }
function isEveryCafeDirectName(name) { const n=normalizeText(name); return n.includes('dogrudan satis') || n.includes('direct sale'); }
function everyCafePaymentMethod(v) { const n=Number(v); return n===1?'CASH':n===2?'CARD':'OTHER'; }
function sourceTableExists(src, name) { try { return Boolean(src.prepare("SELECT 1 AS x FROM sqlite_master WHERE type='table' AND name=?").get(name)); } catch (_) { return false; } }

function setEveryCafeState(status,error='',lastSync=0) {
  metaSet('everycafe_status',status); metaSet('everycafe_error',error); if(lastSync) metaSet('everycafe_last_sync',String(lastSync));
}
function getEveryCafeState() {
  return { status:metaGet('everycafe_status',config.everyCafe?'pending':'disabled'),error:metaGet('everycafe_error',''),lastSync:Number(metaGet('everycafe_last_sync','0'))||0 };
}
function syncEveryCafe() {
  config = getConfig();
  if (!config.everyCafe) { setEveryCafeState('disabled',''); return {ok:true,skipped:true}; }
  const p = config.everyPath;
  if (!p || !fs.existsSync(p)) { setEveryCafeState('error','EveryCafe veritabanı bulunamadı: '+p); return {ok:false,error:metaGet('everycafe_error')}; }
  let src;
  try {
    src = new DatabaseSync(p,{readOnly:true});
    const cats = src.prepare("SELECT LookupValue1 AS category_id,COALESCE(LookupText1,'') AS name FROM LookupValues WHERE LookupKey='ProductCategories' ORDER BY LookupValue1").all();
    const prods = src.prepare("SELECT s.StockID AS stock_id,COALESCE(s.StockName,'') AS name,s.CategoryID AS category_id,COALESCE(c.LookupText1,'') AS category_name,COALESCE(s.SalesPrice,0) AS price,COALESCE(s.ClientVisible,1) AS visible,COALESCE(s.SortOrder,0) AS sort_order FROM Stocks s LEFT JOIN LookupValues c ON c.LookupKey='ProductCategories' AND c.LookupValue1=s.CategoryID ORDER BY s.SortOrder,s.StockID").all();
    const activeRows = src.prepare("SELECT s.SessionID,s.ClientName,s.StartDate,s.EndDate,s.SessionType,s.SessionTypeText,s.Price,s.PaymentAmount,s.GiftTime,COALESCE(c.ClientStatus,0) AS ClientStatus FROM Sessions s LEFT JOIN Clients c ON c.ClientGuid=s.ClientGuid WHERE COALESCE(s.Deleted,0)=0 AND COALESCE(s.IsActive,0)=1 ORDER BY StartDate ASC LIMIT 500").all();
    const closedRows = src.prepare("SELECT SessionID,ClientName,StartDate,EndDate,PaymentMethod,PaymentAmount,SessionType,SessionTypeText FROM Sessions WHERE COALESCE(Deleted,0)=0 AND COALESCE(IsPaid,0)=1 AND COALESCE(EndDate,0)>0 ORDER BY EndDate DESC LIMIT 5000").all();
    const sessionIds = closedRows.map(x=>String(x.SessionID||'')).filter(Boolean);
    const ordersBy = new Map();
    if (sessionIds.length) {
      const q = src.prepare('SELECT o.OrderID,o.SessionID,o.StockID,o.StockName,o.Quantity,o.Price,o.AddDate,o.OrderIsActive,COALESCE(c.LookupText1,\'\') AS CategoryName FROM Orders o LEFT JOIN Stocks s ON s.StockID=o.StockID LEFT JOIN LookupValues c ON c.LookupKey=\'ProductCategories\' AND c.LookupValue1=s.CategoryID WHERE o.SessionID=? ORDER BY o.AddDate ASC');
      for (const id of sessionIds) ordersBy.set(id,q.all(id));
    }
    let memberRows=[];
    if(sourceTableExists(src,'MemberPaymentHistory')) memberRows=src.prepare("SELECT HistoryID,MemberID,PaymentAmount,PaymentMethod,IsActive,PaymentDate,PaymentKey,Note,CashierName FROM MemberPaymentHistory WHERE COALESCE(IsActive,1)<>0 AND PaymentMethod IN (1,2) AND COALESCE(PaymentAmount,0)>0 ORDER BY PaymentDate DESC LIMIT 5000").all();
    const now=Date.now();
    db.exec('BEGIN IMMEDIATE');
    try {
      db.prepare('UPDATE everycafe_categories SET active=0').run();
      db.prepare('UPDATE everycafe_products SET active=0').run();
      const upCat=db.prepare("INSERT INTO everycafe_categories(category_id,name,active,sort_order,last_seen) VALUES(?,?,1,?,?) ON CONFLICT(category_id) DO UPDATE SET name=excluded.name,active=1,sort_order=excluded.sort_order,last_seen=excluded.last_seen");
      cats.forEach((r,i)=>upCat.run(Number(r.category_id)||0,String(r.name||''),i,now));
      const upProd=db.prepare("INSERT INTO everycafe_products(stock_id,name,category_id,category_name,price,active,sort_order,last_seen) VALUES(?,?,?,?,?,1,?,?) ON CONFLICT(stock_id) DO UPDATE SET name=excluded.name,category_id=excluded.category_id,category_name=excluded.category_name,price=excluded.price,active=1,sort_order=excluded.sort_order,last_seen=excluded.last_seen");
      prods.filter(r=>Number(r.visible)!==0).forEach(r=>upProd.run(Number(r.stock_id)||0,String(r.name||''),Number(r.category_id)||0,String(r.category_name||''),Number(r.price)||0,Number(r.sort_order)||0,now));
      const insSale=db.prepare("INSERT OR IGNORE INTO everycafe_sales(source_id,client_name,masa,start_ts,end_ts,day_key,total,payment_method,direct_sale,session_type,session_type_text,orders_json,imported_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
      for(const r of closedRows){
        const sid=String(r.SessionID||'').trim(); if(!sid)continue;
        const masa=everyCafeTableNumber(r.ClientName); const direct=isEveryCafeDirectName(r.ClientName)||Number(r.SessionType)===26;
        if(!masa&&!direct)continue;
        const end=Number(r.EndDate||0)*1000; if(!end)continue;
        insSale.run(sid,String(r.ClientName||''),masa,Number(r.StartDate||0)*1000,end,businessDayKey(end),roundMoney(r.PaymentAmount),everyCafePaymentMethod(r.PaymentMethod),direct?1:0,Number(r.SessionType)||0,String(r.SessionTypeText||''),JSON.stringify(ordersBy.get(sid)||[]),now);
      }
      const insMem=db.prepare("INSERT OR IGNORE INTO everycafe_member_payments(history_id,member_id,ts,day_key,amount,payment_method,note,imported_at) VALUES(?,?,?,?,?,?,?,?)");
      for(const r of memberRows){const ts=Number(r.PaymentDate||0)*1000;if(!ts)continue;insMem.run(Number(r.HistoryID),Number(r.MemberID)||0,ts,businessDayKey(ts),roundMoney(r.PaymentAmount),everyCafePaymentMethod(r.PaymentMethod),String(r.Note||''),now);}
      db.exec('COMMIT');
    }catch(e){db.exec('ROLLBACK');throw e;}

    const running = new Map();
    for(const r of activeRows){
      const masa=everyCafeTableNumber(r.ClientName); if(!masa||!tableByMasa(masa))continue;
      const status=Number(r.ClientStatus)||0;
      const isRunning=status===1||((status&4)===4)||((status&128)===128)||((status&1024)===1024);
      if(isRunning&&Number(r.StartDate)>0){running.set(masa,String(r.SessionID));startEveryCafeSession(masa,String(r.SessionID),Number(r.StartDate)*1000,Number(r.PaymentAmount)||0);}
    }
    const activeLocal=db.prepare("SELECT * FROM sessions WHERE active=1 AND source='EVERYCAFE'").all();
    for(const s of activeLocal){if(running.get(Number(s.masa))!==String(s.source_id))closeSession(s,now,'EVERYCAFE_CLOSED',Number(s.source_total)||0);}
    setEveryCafeState('ok','',now);
    event('everycafe',`Senkron tamam • ${cats.length} kategori • ${prods.filter(r=>Number(r.visible)!==0).length} ürün`);
    return {ok:true,categories:cats.length,products:prods.length};
  } catch (e) {
    const msg=String(e.message||e); setEveryCafeState('error',msg); event('error','EveryCafe senkron hatası: '+msg); return {ok:false,error:msg};
  } finally { try{if(src)src.close();}catch(_){} }
}

function catalogRows() {
  const ec = config.everyCafe ? db.prepare('SELECT stock_id AS id,name,category_name AS category,price,\'EVERYCAFE\' AS source FROM everycafe_products WHERE active=1 ORDER BY category_name,sort_order,name').all() : [];
  const local = db.prepare("SELECT id,name,category,price,'LOCAL' AS source FROM local_products WHERE active=1 ORDER BY category,name").all();
  return [...ec,...local].map(r=>({...r,id:Number(r.id),price:Number(r.price)}));
}
function recordDirectSale(body) {
  const source=String(body.source||'').toUpperCase(),id=Number(body.id),qty=Math.max(0.01,Math.min(999,Number(body.quantity)||1));
  let p;
  if(source==='EVERYCAFE')p=db.prepare('SELECT stock_id AS id,name,category_name AS category,price FROM everycafe_products WHERE stock_id=? AND active=1').get(id);
  else if(source==='LOCAL')p=db.prepare('SELECT id,name,category,price FROM local_products WHERE id=? AND active=1').get(id);
  if(!p)throw new Error('Ürün bulunamadı veya pasif');
  const price=Number(p.price)||0,total=roundMoney(price*qty),method=['CASH','CARD','OTHER'].includes(String(body.paymentMethod||'').toUpperCase())?String(body.paymentMethod).toUpperCase():'CASH';
  const ts=Date.now();
  const r=db.prepare('INSERT INTO direct_sales(ts,day_key,product_source,external_id,product_name,category,unit_price,quantity,total,payment_method,note,voided) VALUES(?,?,?,?,?,?,?,?,?,?,?,0)').run(ts,businessDayKey(ts),source,String(p.id),String(p.name),String(p.category||''),price,qty,total,method,String(body.note||''));
  event('sale',`KafePin Doğrudan Satış • ${p.name} • ${total.toFixed(2)} TL`);
  return {id:Number(r.lastInsertRowid),total};
}
function summaryToday() {
  const d=businessDayKey();
  const tableRevenue=Number(db.prepare("SELECT COALESCE(SUM(final_fee),0) AS v FROM sessions WHERE active=0 AND source='KAFEPIN' AND day_key=?").get(d).v)||0;
  const directRevenue=Number(db.prepare('SELECT COALESCE(SUM(total),0) AS v FROM direct_sales WHERE voided=0 AND day_key=?').get(d).v)||0;
  const manualIncome=Number(db.prepare("SELECT COALESCE(SUM(amount),0) AS v FROM ledger WHERE voided=0 AND type='INCOME' AND day_key=?").get(d).v)||0;
  const expenses=Number(db.prepare("SELECT COALESCE(SUM(amount),0) AS v FROM ledger WHERE voided=0 AND type='EXPENSE' AND day_key=?").get(d).v)||0;
  const ecSessions=Number(db.prepare('SELECT COALESCE(SUM(total),0) AS v FROM everycafe_sales WHERE day_key=?').get(d).v)||0;
  const ecMembers=Number(db.prepare('SELECT COALESCE(SUM(amount),0) AS v FROM everycafe_member_payments WHERE day_key=?').get(d).v)||0;
  const everyCafeTurnover=roundMoney(ecSessions+ecMembers);
  let activeEstimated=0;
  if(!config.everyCafe)for(const t of config.tables){const s=getActiveSession(t.masa);if(s)activeEstimated+=Number(feeFor(t.masa,elapsedMinutes(s),s.free_minutes)||0);}
  const base=config.everyCafe?everyCafeTurnover:tableRevenue;
  const generalRevenue=roundMoney(base+directRevenue+manualIncome);
  const net=roundMoney(generalRevenue-expenses);
  return {dayKey:d,tableRevenue:roundMoney(tableRevenue),activeEstimated:roundMoney(activeEstimated),directRevenue:roundMoney(directRevenue),manualIncome:roundMoney(manualIncome),expenses:roundMoney(expenses),everyCafeTurnover,generalRevenue,net};
}

async function telegramApiWith(token,method,payload={}) {
  token=String(token||'').trim(); if(!token)throw new Error('Telegram Bot Token eksik');
  const r=await fetch(`https://api.telegram.org/bot${token}/${method}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const j=await r.json(); if(!j.ok)throw new Error(String(j.description||'Telegram hatası')); return j;
}
async function findChatIdWith(token) {
  token=String(token||'').trim(); if(!token)throw new Error('Telegram Bot Token eksik');
  const r=await fetch(`https://api.telegram.org/bot${token}/getUpdates`,{headers:{'Cache-Control':'no-store'}});const j=await r.json();if(!j.ok)throw new Error(j.description||'getUpdates başarısız');
  const arr=j.result||[];for(let i=arr.length-1;i>=0;i--){const m=arr[i].message||arr[i].channel_post;if(m&&m.chat&&m.chat.id)return String(m.chat.id);}throw new Error('Bota önce “Merhaba” gönder, sonra tekrar dene.');
}
async function findChatId(token=config.telegramToken){return findChatIdWith(token);}
async function sendTelegramWith(token,chatId,text){chatId=String(chatId||'').trim();if(!chatId)throw new Error('Telegram Chat ID eksik');return telegramApiWith(token,'sendMessage',{chat_id:chatId,text});}
async function sendTelegram(text){if(!config.telegram)throw new Error('Telegram kapalı');return sendTelegramWith(config.telegramToken,config.telegramChat,text);}

function backupDir(){const dir=String(config.backup||'').trim();if(!dir)throw new Error('Yedek klasörü boş');return dir;}
function backupNow(reason='MANUAL') {
  const dir=backupDir();fs.mkdirSync(dir,{recursive:true});
  try{db.exec('PRAGMA wal_checkpoint(FULL)');}catch(_){}
  const stamp=new Date().toISOString().replace(/[:.]/g,'-');
  const name=`KafePin-Backup-${stamp}.db`,dest=path.join(dir,name);
  fs.copyFileSync(DB_FILE,dest);
  const manifest={product:'KafePin Pro 2.0',version:VERSION,cafeName:config.cafeName,createdAt:new Date().toISOString(),reason,db:name};
  fs.writeFileSync(dest+'.json',JSON.stringify(manifest,null,2),'utf8');
  event('backup','Yedek oluşturuldu: '+dest); return dest;
}
function listBackups(){const dir=backupDir();if(!fs.existsSync(dir))return[];return fs.readdirSync(dir).filter(n=>/^KafePin-Backup-.*\.db$/i.test(n)).map(n=>{const p=path.join(dir,n),st=fs.statSync(p);return{name:n,size:st.size,mtime:st.mtimeMs};}).sort((a,b)=>b.mtime-a.mtime).slice(0,100);}
function validateBackupFile(file){let x;try{x=new DatabaseSync(file,{readOnly:true});const r=x.prepare("SELECT value FROM settings WHERE key='config'").get();if(!r)throw new Error('config kaydı yok');JSON.parse(r.value);return true;}finally{try{x&&x.close();}catch(_){}}}
function stageRestore(name){const base=path.basename(String(name||''));if(base!==name||!/^KafePin-Backup-.*\.db$/i.test(base))throw new Error('Geçersiz yedek adı');const src=path.join(backupDir(),base);if(!fs.existsSync(src))throw new Error('Yedek bulunamadı');validateBackupFile(src);const pending=path.join(DATA,'restore-pending.db');fs.copyFileSync(src,pending);fs.writeFileSync(path.join(DATA,'restore-pending.json'),JSON.stringify({source:src,requestedAt:new Date().toISOString()},null,2),'utf8');event('restore','Geri yükleme sıraya alındı: '+base);return true;}

function networkAddresses(){const out=[];for(const arr of Object.values(os.networkInterfaces()))for(const x of arr||[])if(x.family==='IPv4'&&!x.internal)out.push(x.address);return [...new Set(out)];}
function everyCafeStats(){const st=getEveryCafeState();return{...st,categories:Number(db.prepare('SELECT COUNT(*) AS n FROM everycafe_categories WHERE active=1').get().n),products:Number(db.prepare('SELECT COUNT(*) AS n FROM everycafe_products WHERE active=1').get().n)};}

function statusPayload(){config=getConfig();return{ok:true,version:VERSION,port:PORT,config,tables:config.tables.map(tableView),summary:summaryToday(),everyCafe:everyCafeStats(),events:db.prepare('SELECT * FROM events ORDER BY id DESC LIMIT 100').all(),pendingRewards:config.wheel?db.prepare('SELECT * FROM spin_history WHERE pending=1 ORDER BY id DESC LIMIT 50').all():[],rewards:config.wheel?db.prepare('SELECT * FROM rewards ORDER BY sort_order,id').all():[],network:networkAddresses(),backupCount:(()=>{try{return listBackups().length}catch(_){return 0}})()};}

function performDayEnd(ts=Date.now()) {
  const key=businessDayKey(ts);
  let rolled=0;
  if(!config.everyCafe){
    for(const t of config.tables){
      const s=getActiveSession(t.masa);if(!s||s.source!=='KAFEPIN')continue;
      const c=stmt.getClient.get(t.masa);
      const online=Boolean(c&&c.last_seen&&ts-Number(c.last_seen)<=CLIENT_ONLINE_MS);
      closeSession(s,ts,'DAY_END');
      // Müşteri bilgisayarı hâlâ online ise gün geçişinde aynı masa yeni iş günü oturumuyla devam eder.
      if(online){startStandaloneSession(t.masa,ts);rolled++;}
    }
  }
  let backup='';try{backup=backupNow('DAY_END');}catch(e){event('error','Gün sonu yedek hatası: '+e.message);}
  const sum=summaryToday();metaSet('last_day_end',key);event('dayend',`Gün sonu tamamlandı${rolled?` • ${rolled} aktif masa yeni güne devredildi`:''}`);
  if(config.telegram){const msg=`${config.cafeName} • Gün Sonu\nGenel ciro: ${sum.generalRevenue.toFixed(2)} TL\nNet: ${sum.net.toFixed(2)} TL\nKafePin doğrudan satış: ${sum.directRevenue.toFixed(2)} TL\nGider: ${sum.expenses.toFixed(2)} TL${config.everyCafe?`\nEveryCafe genel ciro: ${sum.everyCafeTurnover.toFixed(2)} TL`:`\nMasa geliri: ${sum.tableRevenue.toFixed(2)} TL`}${rolled?`\nYeni güne devreden aktif masa: ${rolled}`:''}${backup?`\nYedek: ${backup}`:''}`;sendTelegram(msg).catch(e=>event('error','Telegram gün sonu: '+e.message));}
  return {ok:true,key,rolled,backup};
}
function dayEndCheck() {
  const now=Date.now();if(clockKey(now)!==config.dayEnd)return;
  const key=businessDayKey(now);if(metaGet('last_day_end','')===key)return;
  performDayEnd(now);
}
function maintenanceTick(){config=getConfig();const now=Date.now();if(!config.everyCafe){const offMs=config.offlineMinutes*60000;for(const t of config.tables){const s=getActiveSession(t.masa);if(!s||s.source!=='KAFEPIN')continue;const c=stmt.getClient.get(t.masa);if(c&&c.last_seen&&now-Number(c.last_seen)>offMs)closeSession(s,Number(c.last_seen),'OFFLINE');}}dayEndCheck();}

function json(res,status,obj){const b=Buffer.from(JSON.stringify(obj),'utf8');res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':b.length,'Cache-Control':'no-store'});res.end(b);}
function text(res,status,body,type='text/plain; charset=utf-8'){const b=Buffer.from(String(body),'utf8');res.writeHead(status,{'Content-Type':type,'Content-Length':b.length,'Cache-Control':'no-store'});res.end(b);}
function readBody(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>2*1024*1024){reject(new Error('İstek çok büyük'));req.destroy();}});req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}});req.on('error',reject);});}
function safeStatic(req,res,u){let rel=u.pathname==='/'?'/index.html':u.pathname;try{rel=decodeURIComponent(rel);}catch(_){};const p=path.normalize(path.join(PUBLIC,rel));if(!p.startsWith(PUBLIC))return text(res,403,'Forbidden');if(!fs.existsSync(p)||!fs.statSync(p).isFile())return text(res,404,'Not found');const ext=path.extname(p).toLowerCase(),types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.ico':'image/x-icon'};const b=fs.readFileSync(p);res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Content-Length':b.length,'Cache-Control':'no-store'});res.end(b);}
function requireLocal(req,res){if(!isLocal(req)){json(res,403,{ok:false,error:'Yönetim işlemleri sadece sunucu bilgisayarından yapılabilir.'});return false;}return true;}

const server=http.createServer(async(req,res)=>{
  const u=new URL(req.url,`http://${req.headers.host||'localhost'}`),m=req.method||'GET';
  try{
    if(u.pathname==='/health')return json(res,200,{ok:true,version:VERSION,port:PORT,time:Date.now()});
    if((u.pathname==='/'||u.pathname==='/index.html'||u.pathname==='/setup.html')&&!isLocal(req))return text(res,403,'Yönetim Merkezi yalnızca sunucu bilgisayarında açılabilir.');

    if(u.pathname.startsWith('/api/admin/')){
      if(!requireLocal(req,res))return;
      if(u.pathname==='/api/admin/config'&&m==='GET')return json(res,200,{ok:true,config,safeMode:false,version:VERSION});
      if(u.pathname==='/api/admin/config'&&m==='POST'){
        const b=await readBody(req),oldEvery=config.everyCafe,proposed=normalizeConfig(b.config||{});
        const proposedMasas=new Set(proposed.tables.map(t=>Number(t.masa)));
        const removedActive=db.prepare('SELECT masa,source FROM sessions WHERE active=1').all().filter(x=>!proposedMasas.has(Number(x.masa)));
        if(removedActive.length)return json(res,409,{ok:false,error:'Aktif oturumu olan masa silinemez. Önce şu masaları kapatın: '+removedActive.map(x=>x.masa).join(', ')});
        // EveryCafe açılırken bağımsız KafePin oturumlarını eski ücret ayarlarıyla güvenli biçimde kapat.
        if(!oldEvery&&proposed.everyCafe){for(const t of config.tables){const ss=getActiveSession(t.masa);if(ss&&ss.source==='KAFEPIN')closeSession(ss,Date.now(),'EVERYCAFE_ENABLED');}}
        config=setConfig(proposed);
        if(oldEvery&&!config.everyCafe){for(const t of config.tables){const ss=getActiveSession(t.masa);if(ss&&ss.source==='EVERYCAFE')closeSession(ss,Date.now(),'EVERYCAFE_DISABLED');}}
        if(config.everyCafe)setTimeout(syncEveryCafe,20);
        return json(res,200,{ok:true,config});
      }
      if(u.pathname==='/api/admin/status'&&m==='GET')return json(res,200,statusPayload());
      if(u.pathname==='/api/admin/session/start'&&m==='POST'){
        if(config.everyCafe)return json(res,409,{ok:false,error:'EveryCafe açıkken oturumu EveryCafe başlatır.'});
        const b=await readBody(req),masa=Number(b.masa),t=tableByMasa(masa);if(!t)throw new Error('Masa bulunamadı');
        const c=stmt.getClient.get(masa),now=Date.now(),online=Boolean(c&&c.last_seen&&now-Number(c.last_seen)<=CLIENT_ONLINE_MS);
        if(!online)return json(res,409,{ok:false,error:`Masa ${masa} client çevrimdışı. Önce bilgisayar/client online olmalı.`});
        const prior=getActiveSession(masa);const session=prior||startStandaloneSession(masa,now);
        return json(res,200,{ok:true,started:!prior,sessionId:Number(session.id)});
      }
      if(u.pathname==='/api/admin/session/close'&&m==='POST'){
        if(config.everyCafe)return json(res,409,{ok:false,error:'EveryCafe açıkken oturumu EveryCafe kapatır.'});
        const b=await readBody(req),masa=Number(b.masa),session=getActiveSession(masa);if(!session)return json(res,200,{ok:true,closed:false,message:'Aktif oturum yok.'});
        const elapsed=elapsedMinutes(session),fee=feeFor(masa,elapsed,session.free_minutes);closeSession(session,Date.now(),'MANUAL');
        return json(res,200,{ok:true,closed:true,minutes:round1(elapsed),fee:roundMoney(fee)});
      }
      if(u.pathname==='/api/admin/update/status'&&m==='GET'){
        try{return json(res,200,await checkUpdateManifest(String(u.searchParams.get('force')||'')==='1'));}
        catch(e){return json(res,200,{ok:false,currentVersion:VERSION,channel:UPDATE_CHANNEL,error:String(e.message||e),manifestUrl:UPDATE_MANIFEST_URL});}
      }
      if(u.pathname==='/api/admin/update/state'&&m==='GET')return json(res,200,{ok:true,...readUpdateState()});
      if(u.pathname==='/api/admin/update/apply'&&m==='POST'){
        const st=readUpdateState();if(st.running)return json(res,409,{ok:false,error:'Bir güncelleme zaten çalışıyor.'});
        let up;try{up=await checkUpdateManifest(true);}catch(e){return json(res,500,{ok:false,error:'Güncelleme kontrol edilemedi: '+String(e.message||e)});}
        if(!up.available)return json(res,200,{ok:true,available:false,message:'Sistem zaten güncel.',currentVersion:VERSION});
        let safety='';try{safety=backupNow('PRE_UPDATE');}catch(e){return json(res,500,{ok:false,error:'Güncelleme öncesi emniyet yedeği alınamadı: '+String(e.message||e)});}
        writeUpdateState('launch','Paket doğrulanmak üzere güncelleyici başlatılıyor',{version:up.latestVersion,safetyBackup:safety});
        try{launchServerUpdater(up,safety);}catch(e){writeUpdateState('error',String(e.message||e),{version:up.latestVersion});return json(res,500,{ok:false,error:String(e.message||e)});}
        event('update',`KafePin Pro 2.0 v${up.latestVersion} güncellemesi başlatıldı`);
        return json(res,200,{ok:true,message:'Emniyet yedeği alındı. Güncelleme başlatıldı.',version:up.latestVersion,safetyBackup:safety});
      }
      if(u.pathname==='/api/admin/everycafe/sync'&&m==='POST')return json(res,200,syncEveryCafe());
      if(u.pathname==='/api/admin/everycafe/detect'&&m==='GET'){
        const candidates=['C:\\Program Files (x86)\\EveryCafeManager\\ecmdata.ecm','C:\\Program Files\\EveryCafeManager\\ecmdata.ecm','C:\\EveryCafe\\ecmdata.ecm'];
        return json(res,200,{ok:true,found:candidates.filter(fs.existsSync)});
      }
      if(u.pathname==='/api/admin/rewards'&&m==='GET')return json(res,200,{ok:true,list:db.prepare('SELECT * FROM rewards ORDER BY sort_order,id').all()});
      if(u.pathname==='/api/admin/rewards/save'&&m==='POST'){
        const b=await readBody(req),name=String(b.name||'').trim().slice(0,80),weight=Math.max(0,Number(b.weight)||0),type=['NONE','MINUTES','PRODUCT'].includes(String(b.type||'').toUpperCase())?String(b.type).toUpperCase():'PRODUCT',value=Math.max(0,Number(b.value)||0),active=b.active===false?0:1;
        if(!name)throw new Error('Ödül adı boş olamaz');
        if(b.id)db.prepare('UPDATE rewards SET name=?,weight=?,type=?,value=?,active=? WHERE id=?').run(name,weight,type,value,active,Number(b.id));else db.prepare('INSERT INTO rewards(name,weight,type,value,active,sort_order) VALUES(?,?,?,?,?,?)').run(name,weight,type,value,active,Number(db.prepare('SELECT COALESCE(MAX(sort_order),0)+1 AS n FROM rewards').get().n));
        event('reward','Çark ödülleri güncellendi');return json(res,200,{ok:true});
      }
      if(u.pathname==='/api/admin/rewards/delete'&&m==='POST'){const b=await readBody(req);db.prepare('DELETE FROM rewards WHERE id=?').run(Number(b.id));return json(res,200,{ok:true});}
      if(u.pathname==='/api/admin/rewards/approve'&&m==='POST'){const b=await readBody(req);db.prepare('UPDATE spin_history SET pending=0,approved_at=? WHERE id=?').run(Date.now(),Number(b.id));event('reward','Ödül teslim/onay kaydı tamamlandı');return json(res,200,{ok:true});}
      if(u.pathname==='/api/admin/catalog'&&m==='GET')return json(res,200,{ok:true,list:catalogRows()});
      if(u.pathname==='/api/admin/local-products'&&m==='GET')return json(res,200,{ok:true,list:db.prepare('SELECT * FROM local_products ORDER BY active DESC,category,name').all()});
      if(u.pathname==='/api/admin/local-products/save'&&m==='POST'){const b=await readBody(req),name=String(b.name||'').trim().slice(0,100),cat=String(b.category||'Diğer').trim().slice(0,80)||'Diğer',price=Math.max(0,Number(b.price)||0),active=b.active===false?0:1,now=Date.now();if(!name)throw new Error('Ürün adı boş olamaz');if(b.id)db.prepare('UPDATE local_products SET name=?,category=?,price=?,active=?,updated_at=? WHERE id=?').run(name,cat,price,active,now,Number(b.id));else db.prepare('INSERT INTO local_products(name,category,price,active,created_at,updated_at) VALUES(?,?,?,?,?,?)').run(name,cat,price,active,now,now);event('product','Yerel KafePin ürünü güncellendi');return json(res,200,{ok:true});}
      if(u.pathname==='/api/admin/direct-sale'&&m==='POST'){const b=await readBody(req);return json(res,200,{ok:true,...recordDirectSale(b)});}
      if(u.pathname==='/api/admin/direct-sales'&&m==='GET')return json(res,200,{ok:true,list:db.prepare('SELECT * FROM direct_sales WHERE voided=0 ORDER BY id DESC LIMIT 200').all()});
      if(u.pathname==='/api/admin/ledger/add'&&m==='POST'){const b=await readBody(req),type=String(b.type||'').toUpperCase();if(!['INCOME','EXPENSE'].includes(type))throw new Error('Gelir/gider tipi geçersiz');const amount=Math.max(0,Number(b.amount)||0);if(amount<=0)throw new Error('Tutar 0 olamaz');const ts=Date.now();db.prepare('INSERT INTO ledger(ts,day_key,type,category,amount,note,voided) VALUES(?,?,?,?,?,?,0)').run(ts,businessDayKey(ts),type,String(b.category||'Diğer').slice(0,80),amount,String(b.note||'').slice(0,200));event('ledger',`${type==='INCOME'?'Gelir':'Gider'} kaydı • ${amount.toFixed(2)} TL`);return json(res,200,{ok:true});}
      if(u.pathname==='/api/admin/ledger'&&m==='GET')return json(res,200,{ok:true,list:db.prepare('SELECT * FROM ledger WHERE voided=0 ORDER BY id DESC LIMIT 200').all()});
      if(u.pathname==='/api/admin/backup/create'&&m==='POST')return json(res,200,{ok:true,path:backupNow('MANUAL')});
      if(u.pathname==='/api/admin/backup/list'&&m==='GET')return json(res,200,{ok:true,list:listBackups()});
      if(u.pathname==='/api/admin/backup/validate'&&m==='POST'){
        const b=await readBody(req),name=String(b.name||''),base=path.basename(name);if(base!==name||!/^KafePin-Backup-.*\.db$/i.test(base))throw new Error('Geçersiz yedek adı');
        const src=path.join(backupDir(),base);if(!fs.existsSync(src))throw new Error('Yedek bulunamadı');validateBackupFile(src);
        const mf=readJson(src+'.json',{});return json(res,200,{ok:true,name:base,size:fs.statSync(src).size,manifest:mf,message:'Yedek yapısı doğrulandı; geri yüklenebilir.'});
      }
      if(u.pathname==='/api/admin/backup/restore'&&m==='POST'){const b=await readBody(req);stageRestore(String(b.name||''));json(res,200,{ok:true,message:'Geri yükleme hazırlandı. Sunucu yeniden başlatılıyor.'});setTimeout(()=>process.exit(0),600);return;}
      if(u.pathname==='/api/admin/telegram/find-chat'&&m==='POST'){const b=await readBody(req),id=await findChatId(String(b.token||config.telegramToken||''));return json(res,200,{ok:true,chatId:id});}
      if(u.pathname==='/api/admin/telegram/test'&&m==='POST'){const b=await readBody(req),token=String(b.token||config.telegramToken||''),chat=String(b.chatId||config.telegramChat||'');await sendTelegramWith(token,chat,'✅ KafePin Pro Telegram bağlantısı başarılı');return json(res,200,{ok:true});}
      if(u.pathname==='/api/admin/client-package-info'&&m==='GET')return json(res,200,{ok:true,serverPort:PORT,network:networkAddresses(),instructions:'Diskless-Client\\KafePinPro-Client-Kur.ps1 dosyasını WKS ana imajı yazma modundayken bir kez çalıştırın. Client daha sonra yeni sürümleri sunucudan otomatik alır.'});
      if(TEST_MODE&&u.pathname==='/api/admin/test/session-age'&&m==='POST'){const b=await readBody(req),s=getActiveSession(Number(b.masa));if(!s)throw new Error('Aktif oturum yok');const start=Date.now()-Number(b.minutes)*60000;db.prepare('UPDATE sessions SET start_ts=?,wheel_ready_at=? WHERE id=?').run(start,Number(b.wheelReadyAt||s.wheel_ready_at),s.id);return json(res,200,{ok:true});}
      if(TEST_MODE&&u.pathname==='/api/admin/test/wheel-ready'&&m==='POST'){const b=await readBody(req),s=getActiveSession(Number(b.masa));if(!s)throw new Error('Aktif oturum yok');db.prepare('UPDATE sessions SET wheel_ready_at=? WHERE id=?').run(Date.now()-1,s.id);return json(res,200,{ok:true});}
      if(TEST_MODE&&u.pathname==='/api/admin/test/business-day'&&m==='POST'){const b=await readBody(req);return json(res,200,{ok:true,dayKey:businessDayKey(Number(b.ts)||Date.now()),clock:clockKey(Number(b.ts)||Date.now()),dayEnd:config.dayEnd});}
      if(TEST_MODE&&u.pathname==='/api/admin/test/maintenance'&&m==='POST'){maintenanceTick();return json(res,200,{ok:true});}
      if(TEST_MODE&&u.pathname==='/api/admin/test/day-end'&&m==='POST'){return json(res,200,performDayEnd(Date.now()));}
      return json(res,404,{ok:false,error:'Admin endpoint bulunamadı'});
    }

    if(u.pathname==='/api/client/package/source'&&m==='GET'){
      const t=tableByIp(reqIp(req));if(!t)return text(res,403,'Bu IP için masa tanımı yok');return serveFile(res,CLIENT_SOURCE_FILE,'text/plain; charset=utf-8');
    }
    if(u.pathname==='/api/client/package/updater'&&m==='GET'){
      const t=tableByIp(reqIp(req));if(!t)return text(res,403,'Bu IP için masa tanımı yok');return serveFile(res,CLIENT_UPDATER_FILE,'text/plain; charset=utf-8');
    }

    if(u.pathname==='/api/client/ping'&&m==='POST'){
      const ip=reqIp(req),t=tableByIp(ip);if(!t)return json(res,200,{ok:false,error:`Bu IP için masa tanımı yok: ${ip}`});
      const b=await readBody(req),now=Date.now();stmt.touchClient.run(t.masa,now,String(b.clientId||''),String(b.version||''));const s=getActiveSession(t.masa);return json(res,200,{ok:true,masa:t.masa,cafeName:config.cafeName,wheel:Boolean(config.wheel),wheelUrl:`http://${req.headers.host}/wheel.html`,wheelState:wheelState(s),clientUpdate:clientUpdateInfo(String(b.version||'0'),req.headers.host)});
    }
    if(u.pathname==='/api/client/wheel-state'&&m==='GET'){
      const ip=reqIp(req),t=tableByIp(ip);if(!t)return json(res,200,{ok:false,error:`Bu IP için masa tanımı yok: ${ip}`});const s=getActiveSession(t.masa);return json(res,200,{ok:true,masa:t.masa,cafeName:config.cafeName,state:wheelState(s),rewards:config.wheel?rewardRows().map(r=>({id:r.id,name:r.name,type:r.type,value:r.value})):[]});
    }
    if(u.pathname==='/api/client/spin-use'&&m==='POST'){
      const ip=reqIp(req),t=tableByIp(ip);if(!t)return json(res,200,{ok:false,error:'Masa bulunamadı'});try{return json(res,200,{ok:true,...useSpin(t.masa)});}catch(e){return json(res,200,{ok:false,error:e.message,state:wheelState(getActiveSession(t.masa))});}
    }

    return safeStatic(req,res,u);
  }catch(e){log('HTTP error '+(e.stack||e));return json(res,500,{ok:false,error:String(e.message||e)});}
});

setInterval(maintenanceTick,5000);
setInterval(()=>{if(config.everyCafe)syncEveryCafe();},60000);
setTimeout(()=>{if(config.everyCafe)syncEveryCafe();},2500);
server.listen(PORT,HOST,()=>log(`KafePin Pro 2.0 ${VERSION} • http://${HOST}:${PORT}`));
server.on('error',e=>{log('SERVER ERROR '+(e.stack||e));process.exitCode=1;});
process.on('uncaughtException',e=>log('UNCAUGHT '+(e.stack||e)));
process.on('unhandledRejection',e=>log('REJECTION '+(e&&e.stack||e)));
process.on('exit',()=>{try{db.close();}catch(_){}try{fs.unlinkSync(PID_FILE);}catch(_){}});
