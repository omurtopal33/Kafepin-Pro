﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace KafePinClient
{
    internal sealed class ClientSettings
    {
        public string serverBaseUrl { get; set; }
        public bool testMode { get; set; }
        public string simulatedIp { get; set; }
        public string shortcutDirectory { get; set; }
        public int pingIntervalSeconds { get; set; }
    }

    internal static class Program
    {
        private static readonly object Gate = new object();
        private static JavaScriptSerializer Json = new JavaScriptSerializer();
        private static string Root;
        private static string SettingsFile;
        private static string StateFile;
        private static string LogFile;
        private static string ShortcutFile;
        private static ClientSettings Settings;
        private static System.Threading.Timer Timer;
        private static Mutex AppMutex;
        private static volatile bool Stopping;
        private static bool? LastWheel;
        private static string LastWheelUrl = "";
        private static int LastMasa;
        private static string LastCafe = "";
        private static bool UpdateStarted;
        private const string ClientVersion = "2.0.0";

        [STAThread]
        private static void Main(string[] args)
        {
            Root = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
            SettingsFile = Path.Combine(Root, "client.json");
            StateFile = Path.Combine(Root, "client-state.json");
            LogFile = Path.Combine(Root, "client.log");

            if (HasArg(args, "--wheel"))
            {
                OpenWheel();
                return;
            }

            bool created;
            AppMutex = new Mutex(true, "Local\\KafePinClientBackground", out created);
            if (!created) return;

            try
            {
                Settings = LoadSettings();
                if (Settings == null)
                {
                    MessageBox.Show("KafePin Client ayar dosyası bulunamadı veya okunamadı.\n\n" + SettingsFile,
                        "KafePin Client", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string shortcutDir = ResolveShortcutDirectory(Settings);
                Directory.CreateDirectory(shortcutDir);
                ShortcutFile = Path.Combine(shortcutDir, "🎡 Şans Çarkı.lnk");
                WritePid();
                Log("KafePin Client başladı" + (Settings.testMode ? " • GÜVENLİ TEST MODU" : ""));

                int sec = Settings.pingIntervalSeconds > 0 ? Settings.pingIntervalSeconds : 5;
                Timer = new System.Threading.Timer(_ => Heartbeat(), null, 100, sec * 1000);
                Application.ApplicationExit += delegate { Shutdown(); };
                Application.Run(new ApplicationContext());
            }
            finally
            {
                Shutdown();
                try { if (AppMutex != null) AppMutex.ReleaseMutex(); } catch { }
                try { if (AppMutex != null) AppMutex.Dispose(); } catch { }
            }
        }

        private static bool HasArg(string[] args, string value)
        {
            foreach (string a in args) if (string.Equals(a, value, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        private static ClientSettings LoadSettings()
        {
            try
            {
                if (!File.Exists(SettingsFile)) return null;
                string raw = File.ReadAllText(SettingsFile, Encoding.UTF8);
                ClientSettings s = Json.Deserialize<ClientSettings>(raw);
                if (s == null || string.IsNullOrWhiteSpace(s.serverBaseUrl)) return null;
                s.serverBaseUrl = s.serverBaseUrl.TrimEnd('/');
                return s;
            }
            catch (Exception ex)
            {
                SafeAppend(LogFile, "Ayar hatası: " + ex.Message);
                return null;
            }
        }

        private static string ResolveShortcutDirectory(ClientSettings s)
        {
            if (s.testMode && !string.IsNullOrWhiteSpace(s.shortcutDirectory))
            {
                string v = s.shortcutDirectory;
                if (!Path.IsPathRooted(v)) v = Path.Combine(Root, v);
                return Path.GetFullPath(v);
            }
            return Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory);
        }

        private static void Heartbeat()
        {
            if (Stopping || Settings == null) return;
            if (!Monitor.TryEnter(Gate)) return;
            try
            {
                Dictionary<string, object> body = new Dictionary<string, object>();
                if (Settings.testMode) body["ip"] = Settings.simulatedIp ?? "";
                body["clientId"] = Environment.MachineName;
                body["version"] = ClientVersion;

                Dictionary<string, object> response = PostJson(Settings.serverBaseUrl + "/api/client/ping", body);
                bool ok = GetBool(response, "ok");
                if (!ok) throw new Exception(GetString(response, "error", "Sunucu ping yanıtını reddetti"));

                bool wheel = GetBool(response, "wheel");
                string wheelUrl = GetString(response, "wheelUrl", "");
                int masa = GetInt(response, "masa");
                string cafe = GetString(response, "cafeName", "KafePin Pro");

                LastMasa = masa;
                LastCafe = cafe;
                LastWheelUrl = wheelUrl;
                SyncShortcut(wheel);
                LastWheel = wheel;
                WriteState(true, "", response);
                TryStartClientUpdate(response);
            }
            catch (Exception ex)
            {
                // Sunucu geçici olarak yoksa son bilinen kısayol durumuna dokunmuyoruz.
                WriteState(false, ex.Message, null);
                LogOnce("Bağlantı hatası: " + ex.Message);
            }
            finally
            {
                Monitor.Exit(Gate);
            }
        }

        private static void SyncShortcut(bool shouldExist)
        {
            try
            {
                if (shouldExist)
                {
                    if (!File.Exists(ShortcutFile) || LastWheel != true)
                    {
                        CreateShortcut(ShortcutFile, Application.ExecutablePath, "--wheel", Root,
                            "KafePin Pro Şans Çarkı");
                        Log("Şans Çarkı kısayolu oluşturuldu • Masa " + LastMasa);
                    }
                }
                else
                {
                    if (File.Exists(ShortcutFile))
                    {
                        File.Delete(ShortcutFile);
                        Log("Çark kapalı • Şans Çarkı kısayolu kaldırıldı");
                    }
                }
            }
            catch (Exception ex)
            {
                Log("Kısayol hatası: " + ex.Message);
            }
        }

        private static void OpenWheel()
        {
            try
            {
                ClientSettings s = LoadSettingsStatic();
                if (s == null)
                {
                    MessageBox.Show("KafePin Client ayarları okunamadı.", "KafePin Client");
                    return;
                }
                s.serverBaseUrl = (s.serverBaseUrl ?? "").TrimEnd('/');
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new WheelForm(s));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Çark açılamadı: " + ex.Message, "KafePin Pro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private sealed class WheelForm : Form
        {
            private readonly ClientSettings _settings;
            private readonly Label _title = new Label();
            private readonly Label _masa = new Label();
            private readonly Label _time = new Label();
            private readonly Label _status = new Label();
            private readonly Label _result = new Label();
            private readonly Label _info = new Label();
            private readonly Button _spin = new Button();
            private readonly WheelCanvas _canvas = new WheelCanvas();
            private readonly System.Windows.Forms.Timer _timer = new System.Windows.Forms.Timer();
            private List<Dictionary<string, object>> _rewards = new List<Dictionary<string, object>>();
            private bool _busy;

            public WheelForm(ClientSettings settings)
            {
                _settings = settings;
                Text = "KafePin Pro • Şans Çarkı";
                StartPosition = FormStartPosition.CenterScreen;
                Width = 920;
                Height = 760;
                MinimumSize = new Size(720, 620);
                BackColor = Color.FromArgb(14, 24, 42);
                ForeColor = Color.White;
                Font = new Font("Segoe UI", 10F, FontStyle.Regular);

                Panel top = new Panel();
                top.Dock = DockStyle.Top;
                top.Height = 76;
                top.BackColor = Color.FromArgb(28, 43, 69);
                Controls.Add(top);

                _title.Text = "🎡 KafePin Pro";
                _title.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
                _title.AutoSize = true;
                _title.Location = new Point(18, 18);
                top.Controls.Add(_title);

                _masa.Text = "Masa --";
                _masa.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
                _masa.AutoSize = true;
                _masa.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                _masa.Location = new Point(760, 25);
                top.Controls.Add(_masa);
                top.Resize += delegate { _masa.Left = Math.Max(20, top.ClientSize.Width - _masa.Width - 22); };

                Panel bottom = new Panel();
                bottom.Dock = DockStyle.Bottom;
                bottom.Height = 210;
                bottom.BackColor = Color.FromArgb(28, 43, 69);
                Controls.Add(bottom);

                _time.Text = "--:--";
                _time.Font = new Font("Segoe UI", 30F, FontStyle.Bold);
                _time.TextAlign = ContentAlignment.MiddleCenter;
                _time.Dock = DockStyle.Top;
                _time.Height = 58;
                bottom.Controls.Add(_time);

                _status.Text = "Sunucu kontrol ediliyor...";
                _status.TextAlign = ContentAlignment.MiddleCenter;
                _status.Dock = DockStyle.Top;
                _status.Height = 28;
                bottom.Controls.Add(_status);

                _result.Text = "";
                _result.ForeColor = Color.FromArgb(101, 223, 130);
                _result.Font = new Font("Segoe UI", 17F, FontStyle.Bold);
                _result.TextAlign = ContentAlignment.MiddleCenter;
                _result.Dock = DockStyle.Top;
                _result.Height = 42;
                bottom.Controls.Add(_result);

                _spin.Text = "🎯 Çarkı Çevir";
                _spin.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
                _spin.Width = 180;
                _spin.Height = 38;
                _spin.Enabled = false;
                bottom.Controls.Add(_spin);

                _info.Text = "Sayaç sunucuda tutulur; bilgisayar yeniden başlasa süre sıfırlanmaz.";
                _info.ForeColor = Color.FromArgb(190, 205, 230);
                _info.TextAlign = ContentAlignment.MiddleCenter;
                _info.AutoEllipsis = true;
                _info.Height = 30;
                bottom.Controls.Add(_info);

                bottom.Resize += delegate
                {
                    _spin.Left = Math.Max(10, (bottom.ClientSize.Width - _spin.Width) / 2);
                    _spin.Top = 132;
                    _info.Left = 10;
                    _info.Top = 172;
                    _info.Width = Math.Max(100, bottom.ClientSize.Width - 20);
                };

                _canvas.Dock = DockStyle.Fill;
                _canvas.BackColor = Color.FromArgb(14, 24, 42);
                Controls.Add(_canvas);
                _canvas.SendToBack();
                top.BringToFront();
                bottom.BringToFront();

                _spin.Click += delegate { SpinNow(); };
                _timer.Interval = 1000;
                _timer.Tick += delegate { RefreshState(); };
                Shown += delegate { RefreshState(); _timer.Start(); };
                FormClosed += delegate { _timer.Stop(); };
            }

            private void RefreshState()
            {
                if (_busy) return;
                try
                {
                    Dictionary<string, object> j = GetJson(_settings.serverBaseUrl + "/api/client/wheel-state");
                    if (!GetBool(j, "ok")) throw new Exception(GetString(j, "error", "Sunucu yanıtı geçersiz"));
                    string cafe = GetString(j, "cafeName", "KafePin Pro");
                    _title.Text = "🎡 " + cafe;
                    _masa.Text = "Masa " + GetInt(j, "masa");
                    Text = cafe + " • Şans Çarkı";
                    _rewards = GetDictionaryList(j.ContainsKey("rewards") ? j["rewards"] : null);
                    List<string> names = new List<string>();
                    foreach (Dictionary<string, object> r in _rewards) names.Add(GetString(r, "name", "Ödül"));
                    _canvas.SetItems(names);

                    Dictionary<string, object> state = AsDictionary(j.ContainsKey("state") ? j["state"] : null);
                    string st = GetString(state, "status", "disabled");
                    long remaining = GetLong(state, "remainingMs");
                    int used = GetInt(state, "used");
                    int limit = GetInt(state, "limit");
                    _time.Text = st == "countdown" ? FormatRemaining(remaining) : (st == "ready" ? "HAZIR" : "--:--");
                    _time.ForeColor = st == "ready" ? Color.FromArgb(101, 223, 130) : Color.FromArgb(255, 209, 102);
                    if (st == "ready") _status.Text = "✅ Çark hakkın hazır";
                    else if (st == "countdown") _status.Text = "Geri sayım devam ediyor";
                    else if (st == "limit") _status.Text = "Oturumluk çark limiti doldu";
                    else if (st == "waiting_session") _status.Text = "Müşteri oturumu bekleniyor";
                    else _status.Text = "Şans Çarkı kapalı";
                    _spin.Enabled = st == "ready" && _rewards.Count > 0;
                    _info.Text = "Kullanılan: " + used + " / " + limit + " • Sayaç sunucuda tutulur.";
                }
                catch (Exception ex)
                {
                    _status.Text = "Sunucu bağlantısı yok";
                    _info.Text = ex.Message;
                    _spin.Enabled = false;
                }
            }

            private void SpinNow()
            {
                if (_busy) return;
                if (MessageBox.Show("Çarkı şimdi çevirmek istiyor musun?", "KafePin Pro", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                _busy = true;
                _spin.Enabled = false;
                _result.Text = "";
                try
                {
                    Dictionary<string, object> j = PostJson(_settings.serverBaseUrl + "/api/client/spin-use", new Dictionary<string, object>());
                    if (!GetBool(j, "ok")) throw new Exception(GetString(j, "error", "Çark kullanılamadı"));
                    Dictionary<string, object> reward = AsDictionary(j.ContainsKey("reward") ? j["reward"] : null);
                    int rewardId = GetInt(reward, "id");
                    string rewardName = GetString(reward, "name", "Ödül");
                    int index = 0;
                    for (int i = 0; i < _rewards.Count; i++) if (GetInt(_rewards[i], "id") == rewardId) { index = i; break; }
                    _canvas.SpinTo(index);
                    _result.Text = "🎁 " + rewardName;
                    if (GetBool(j, "pending")) _info.Text = "Bu ödül personel teslim/onayına düştü.";
                    else _info.Text = "Ödül KafePin tarafından kaydedildi.";
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "KafePin Pro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                finally
                {
                    _busy = false;
                    RefreshState();
                }
            }

            private static string FormatRemaining(long ms)
            {
                if (ms < 0) ms = 0;
                long total = (long)Math.Ceiling(ms / 1000.0);
                long min = total / 60;
                long sec = total % 60;
                return min.ToString("00") + ":" + sec.ToString("00");
            }
        }

        private sealed class WheelCanvas : Panel
        {
            private List<string> _items = new List<string>();
            private float _rotation;
            private float _startRotation;
            private float _targetRotation;
            private int _tick;
            private readonly System.Windows.Forms.Timer _anim = new System.Windows.Forms.Timer();

            public WheelCanvas()
            {
                DoubleBuffered = true;
                _anim.Interval = 25;
                _anim.Tick += delegate
                {
                    _tick++;
                    float p = Math.Min(1F, _tick / 168F);
                    float inv = 1F - p;
                    float ease = 1F - inv * inv * inv;
                    _rotation = _startRotation + (_targetRotation - _startRotation) * ease;
                    Invalidate();
                    if (p >= 1F) _anim.Stop();
                };
            }

            public void SetItems(List<string> items)
            {
                if (items == null) items = new List<string>();
                bool changed = items.Count != _items.Count;
                if (!changed) for (int i = 0; i < items.Count; i++) if (!String.Equals(items[i], _items[i], StringComparison.Ordinal)) { changed = true; break; }
                if (changed) { _items = new List<string>(items); Invalidate(); }
            }

            public void SpinTo(int index)
            {
                int n = Math.Max(1, _items.Count);
                if (index < 0 || index >= n) index = 0;
                float sweep = 360F / n;
                float desired = -(index * sweep + sweep / 2F);
                float current = _rotation % 360F;
                float delta = desired - current;
                while (delta < 0F) delta += 360F;
                _startRotation = _rotation;
                _targetRotation = _rotation + 1440F + delta;
                _tick = 0;
                _anim.Stop();
                _anim.Start();
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                Graphics g = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                int size = Math.Min(ClientSize.Width, ClientSize.Height) - 44;
                if (size < 100) return;
                float cx = ClientSize.Width / 2F;
                float cy = ClientSize.Height / 2F + 5F;
                RectangleF rect = new RectangleF(cx - size / 2F, cy - size / 2F, size, size);
                int n = Math.Max(1, _items.Count);
                float sweep = 360F / n;
                Color[] palette = new Color[] {
                    Color.FromArgb(91,92,224), Color.FromArgb(20,160,133), Color.FromArgb(230,126,34),
                    Color.FromArgb(192,57,43), Color.FromArgb(142,68,173), Color.FromArgb(41,128,185),
                    Color.FromArgb(39,174,96), Color.FromArgb(211,84,0)
                };
                g.TranslateTransform(cx, cy);
                g.RotateTransform(_rotation);
                RectangleF centered = new RectangleF(-size / 2F, -size / 2F, size, size);
                for (int i = 0; i < n; i++)
                {
                    using (SolidBrush b = new SolidBrush(palette[i % palette.Length])) g.FillPie(b, centered, -90F + i * sweep, sweep);
                }
                using (Pen border = new Pen(Color.WhiteSmoke, 8F)) g.DrawEllipse(border, centered);
                g.ResetTransform();

                if (_items.Count > 0)
                {
                    using (StringFormat sf = new StringFormat())
                    using (SolidBrush tb = new SolidBrush(Color.White))
                    {
                        sf.Alignment = StringAlignment.Center;
                        sf.LineAlignment = StringAlignment.Center;
                        for (int i = 0; i < _items.Count; i++)
                        {
                            double a = ((_rotation + i * sweep + sweep / 2F) - 90F) * Math.PI / 180.0;
                            float r = size * 0.31F;
                            float x = cx + (float)Math.Cos(a) * r;
                            float y = cy + (float)Math.Sin(a) * r;
                            string label = _items[i] ?? "Ödül";
                            if (label.Length > 18) label = label.Substring(0, 17) + "…";
                            g.DrawString(label, Font, tb, new RectangleF(x - 65, y - 18, 130, 36), sf);
                        }
                    }
                }

                PointF[] pointer = new PointF[] { new PointF(cx, cy - size / 2F + 4), new PointF(cx - 17, cy - size / 2F - 26), new PointF(cx + 17, cy - size / 2F - 26) };
                using (SolidBrush pb = new SolidBrush(Color.White)) g.FillPolygon(pb, pointer);
            }
        }

        private static ClientSettings LoadSettingsStatic()
        {
            try
            {
                string p = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "client.json");
                if (!File.Exists(p)) return null;
                return Json.Deserialize<ClientSettings>(File.ReadAllText(p, Encoding.UTF8));
            }
            catch { return null; }
        }

        private static void TryStartClientUpdate(Dictionary<string, object> response)
        {
            if (UpdateStarted || response == null || !response.ContainsKey("clientUpdate") || response["clientUpdate"] == null) return;
            try
            {
                Dictionary<string, object> up = response["clientUpdate"] as Dictionary<string, object>;
                if (up == null || !GetBool(up, "available")) return;
                string version = GetString(up, "version", "");
                string updaterUrl = GetString(up, "updaterUrl", "");
                string updaterSha = GetString(up, "updaterSha256", "");
                string sourceSha = GetString(up, "sourceSha256", "");
                if (string.IsNullOrWhiteSpace(version) || string.IsNullOrWhiteSpace(updaterUrl) || updaterSha.Length != 64 || sourceSha.Length != 64) return;

                string temp = Path.Combine(Path.GetTempPath(), "KafePinClientSelfUpdate-" + Guid.NewGuid().ToString("N") + ".ps1");
                using (WebClient wc = new WebClient()) wc.DownloadFile(updaterUrl, temp);
                string actual = Sha256(temp);
                if (!string.Equals(actual, updaterSha, StringComparison.OrdinalIgnoreCase))
                {
                    try { File.Delete(temp); } catch { }
                    throw new Exception("Client güncelleyici SHA256 doğrulaması başarısız");
                }
                UpdateStarted = true;
                string args = "-NoProfile -ExecutionPolicy Bypass -File " + QuoteArg(temp) +
                    " -ServerBaseUrl " + QuoteArg(Settings.serverBaseUrl) +
                    " -ExpectedVersion " + QuoteArg(version) +
                    " -ExpectedSourceSha256 " + QuoteArg(sourceSha) +
                    " -CurrentPid " + Process.GetCurrentProcess().Id;
                Process.Start(new ProcessStartInfo("powershell.exe", args) { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden });
                Log("Client otomatik güncellemesi başlatıldı • v" + version);
                Thread t = new Thread(delegate { Thread.Sleep(700); Environment.Exit(0); });
                t.IsBackground = true; t.Start();
            }
            catch (Exception ex)
            {
                UpdateStarted = false;
                LogOnce("Client güncelleme hatası: " + ex.Message);
            }
        }

        private static string Sha256(string file)
        {
            using (SHA256 h = SHA256.Create())
            using (FileStream f = File.OpenRead(file))
            {
                byte[] b = h.ComputeHash(f); StringBuilder sb = new StringBuilder(b.Length * 2);
                foreach (byte x in b) sb.Append(x.ToString("x2")); return sb.ToString();
            }
        }
        private static string QuoteArg(string value) { return "\"" + (value ?? "").Replace("\"", "\\\"") + "\""; }

        private static Dictionary<string, object> GetJson(string url)
        {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            req.Method = "GET";
            req.Timeout = 3500;
            req.ReadWriteTimeout = 3500;
            req.CachePolicy = new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);
            using (HttpWebResponse res = (HttpWebResponse)req.GetResponse())
            using (StreamReader sr = new StreamReader(res.GetResponseStream(), Encoding.UTF8))
            {
                return Json.Deserialize<Dictionary<string, object>>(sr.ReadToEnd());
            }
        }

        private static Dictionary<string, object> PostJson(string url, Dictionary<string, object> body)
        {
            byte[] raw = Encoding.UTF8.GetBytes(Json.Serialize(body));
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            req.Method = "POST";
            req.ContentType = "application/json; charset=utf-8";
            req.ContentLength = raw.Length;
            req.Timeout = 3500;
            req.ReadWriteTimeout = 3500;
            using (Stream st = req.GetRequestStream()) st.Write(raw, 0, raw.Length);
            using (HttpWebResponse res = (HttpWebResponse)req.GetResponse())
            using (StreamReader sr = new StreamReader(res.GetResponseStream(), Encoding.UTF8))
            {
                string text = sr.ReadToEnd();
                return Json.Deserialize<Dictionary<string, object>>(text);
            }
        }

        private static void WriteState(bool connected, string error, Dictionary<string, object> response)
        {
            try
            {
                Dictionary<string, object> state = new Dictionary<string, object>();
                state["connected"] = connected;
                state["testMode"] = Settings != null && Settings.testMode;
                state["updatedAt"] = (long)(DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;
                state["masa"] = response != null ? GetInt(response, "masa") : LastMasa;
                state["cafeName"] = response != null ? GetString(response, "cafeName", LastCafe) : LastCafe;
                state["wheel"] = response != null ? GetBool(response, "wheel") : (LastWheel == true);
                state["wheelUrl"] = response != null ? GetString(response, "wheelUrl", LastWheelUrl) : LastWheelUrl;
                state["error"] = error ?? "";
                if (response != null && response.ContainsKey("wheelState")) state["wheelState"] = response["wheelState"];
                string tmp = StateFile + ".tmp";
                File.WriteAllText(tmp, Json.Serialize(state), new UTF8Encoding(false));
                if (File.Exists(StateFile)) File.Delete(StateFile);
                File.Move(tmp, StateFile);
            }
            catch { }
        }

        private static long GetLong(Dictionary<string, object> d, string key)
        {
            try
            {
                if (d == null || !d.ContainsKey(key) || d[key] == null) return 0;
                long n; if (long.TryParse(Convert.ToString(d[key]), out n)) return n;
                double x; if (double.TryParse(Convert.ToString(d[key]), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out x)) return (long)x;
            }
            catch { }
            return 0;
        }

        private static Dictionary<string, object> AsDictionary(object value)
        {
            Dictionary<string, object> d = value as Dictionary<string, object>;
            return d ?? new Dictionary<string, object>();
        }

        private static List<Dictionary<string, object>> GetDictionaryList(object value)
        {
            List<Dictionary<string, object>> result = new List<Dictionary<string, object>>();
            IEnumerable en = value as IEnumerable;
            if (en == null || value is string) return result;
            foreach (object item in en)
            {
                Dictionary<string, object> d = item as Dictionary<string, object>;
                if (d != null) result.Add(d);
            }
            return result;
        }

        private static void WritePid()
        {
            try { File.WriteAllText(Path.Combine(Root, "client.pid"), Process.GetCurrentProcess().Id.ToString(), Encoding.ASCII); } catch { }
        }

        private static string LastLogOnce = "";
        private static void LogOnce(string text)
        {
            if (string.Equals(LastLogOnce, text, StringComparison.Ordinal)) return;
            LastLogOnce = text;
            Log(text);
        }

        private static void Log(string text)
        {
            string line = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] " + text;
            SafeAppend(LogFile, line);
        }

        private static void SafeAppend(string file, string line)
        {
            try { File.AppendAllText(file, line + Environment.NewLine, new UTF8Encoding(false)); } catch { }
        }

        private static void Shutdown()
        {
            if (Stopping) return;
            Stopping = true;
            try { if (Timer != null) Timer.Dispose(); } catch { }
            try { File.Delete(Path.Combine(Root, "client.pid")); } catch { }
        }

        private static bool GetBool(Dictionary<string, object> d, string key)
        {
            try
            {
                if (d == null || !d.ContainsKey(key) || d[key] == null) return false;
                object v = d[key];
                if (v is bool) return (bool)v;
                bool b; if (bool.TryParse(Convert.ToString(v), out b)) return b;
                int i; if (int.TryParse(Convert.ToString(v), out i)) return i != 0;
            }
            catch { }
            return false;
        }

        private static int GetInt(Dictionary<string, object> d, string key)
        {
            try
            {
                if (d == null || !d.ContainsKey(key) || d[key] == null) return 0;
                int i; if (int.TryParse(Convert.ToString(d[key]), out i)) return i;
            }
            catch { }
            return 0;
        }

        private static string GetString(Dictionary<string, object> d, string key, string fallback)
        {
            try
            {
                if (d == null || !d.ContainsKey(key) || d[key] == null) return fallback;
                return Convert.ToString(d[key]) ?? fallback;
            }
            catch { return fallback; }
        }

        [ComImport]
        [Guid("00021401-0000-0000-C000-000000000046")]
        private class ShellLink { }

        [ComImport]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        [Guid("000214F9-0000-0000-C000-000000000046")]
        private interface IShellLinkW
        {
            void GetPath([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszFile, int cchMaxPath, IntPtr pfd, uint fFlags);
            void GetIDList(out IntPtr ppidl);
            void SetIDList(IntPtr pidl);
            void GetDescription([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszName, int cchMaxName);
            void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string pszName);
            void GetWorkingDirectory([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszDir, int cchMaxPath);
            void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string pszDir);
            void GetArguments([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszArgs, int cchMaxPath);
            void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string pszArgs);
            void GetHotkey(out short pwHotkey);
            void SetHotkey(short wHotkey);
            void GetShowCmd(out int piShowCmd);
            void SetShowCmd(int iShowCmd);
            void GetIconLocation([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszIconPath, int cchIconPath, out int piIcon);
            void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string pszIconPath, int iIcon);
            void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string pszPathRel, uint dwReserved);
            void Resolve(IntPtr hwnd, uint fFlags);
            void SetPath([MarshalAs(UnmanagedType.LPWStr)] string pszFile);
        }

        [ComImport]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        [Guid("0000010b-0000-0000-C000-000000000046")]
        private interface IPersistFile
        {
            void GetClassID(out Guid pClassID);
            [PreserveSig] int IsDirty();
            void Load([MarshalAs(UnmanagedType.LPWStr)] string pszFileName, uint dwMode);
            void Save([MarshalAs(UnmanagedType.LPWStr)] string pszFileName, bool fRemember);
            void SaveCompleted([MarshalAs(UnmanagedType.LPWStr)] string pszFileName);
            void GetCurFile([MarshalAs(UnmanagedType.LPWStr)] out string ppszFileName);
        }

        private static void CreateShortcut(string shortcutPath, string targetPath, string arguments, string workingDir, string description)
        {
            IShellLinkW link = (IShellLinkW)new ShellLink();
            link.SetPath(targetPath);
            link.SetArguments(arguments ?? "");
            link.SetWorkingDirectory(workingDir ?? "");
            link.SetDescription(description ?? "KafePin Pro");
            link.SetIconLocation(targetPath, 0);
            ((IPersistFile)link).Save(shortcutPath, true);
        }
    }
}
