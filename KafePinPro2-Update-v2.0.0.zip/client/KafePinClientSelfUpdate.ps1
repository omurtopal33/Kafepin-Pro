﻿param(
  [Parameter(Mandatory=$true)][string]$ServerBaseUrl,
  [Parameter(Mandatory=$true)][string]$ExpectedVersion,
  [Parameter(Mandatory=$true)][string]$ExpectedSourceSha256,
  [int]$CurrentPid = 0
)
$ErrorActionPreference='Stop'
$Root='C:\ProgramData\KafePinClient'
$Task='KafePin Client'
$Exe=Join-Path $Root 'KafePin Client.exe'
$Marker=Join-Path $Root '.kafepin-client-install.json'
$Log=Join-Path $Root 'client-update.log'
function Log([string]$t){try{Add-Content -LiteralPath $Log -Value ('['+(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')+'] '+$t) -Encoding UTF8}catch{}}
function Get-Csc {
  $c=@('C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe','C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe')|Where-Object{Test-Path $_}|Select-Object -First 1
  if(-not $c){throw '.NET Framework C# derleyicisi bulunamadı.'};return $c
}
try{
  if(-not(Test-Path $Marker)){throw 'KafePin Client kurulum işaretçisi yok; otomatik güncelleme durduruldu.'}
  $m=Get-Content $Marker -Raw|ConvertFrom-Json
  if([string]$m.product -ne 'KafePin Pro Diskless Client'){throw 'Client ürün işaretçisi uyuşmuyor.'}
  $work=Join-Path $env:TEMP ('KafePinClientUpdate_'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $work|Out-Null
  $src=Join-Path $work 'KafePinClient.cs';$newExe=Join-Path $work 'KafePin Client.exe'
  $url=$ServerBaseUrl.TrimEnd('/')+'/api/client/package/source'
  try{Invoke-WebRequest -Uri $url -OutFile $src -UseBasicParsing -TimeoutSec 30}catch{& curl.exe -fL --retry 2 -o $src $url;if($LASTEXITCODE -ne 0){throw}}
  $sha=(Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant()
  if($sha -ne $ExpectedSourceSha256.ToLowerInvariant()){throw 'Client kaynak SHA256 doğrulaması başarısız.'}
  $csc=Get-Csc
  & $csc /nologo /target:winexe /optimize+ /out:"$newExe" /reference:System.Windows.Forms.dll /reference:System.Web.Extensions.dll /reference:System.Drawing.dll /reference:System.dll /reference:System.Core.dll $src
  if($LASTEXITCODE -ne 0 -or -not(Test-Path $newExe)){throw 'Yeni KafePin Client derlenemedi.'}
  try{Stop-ScheduledTask -TaskName $Task -ErrorAction SilentlyContinue}catch{}
  if($CurrentPid -gt 0){for($i=0;$i-lt 40;$i++){if(-not(Get-Process -Id $CurrentPid -ErrorAction SilentlyContinue)){break};Start-Sleep -Milliseconds 250}}
  $pidFile=Join-Path $Root 'client.pid'
  if(Test-Path $pidFile){try{$pid=[int](Get-Content $pidFile -Raw);$p=Get-CimInstance Win32_Process -Filter "ProcessId=$pid" -ErrorAction SilentlyContinue;if($p -and $p.ExecutablePath -and ([IO.Path]::GetFullPath($p.ExecutablePath) -eq [IO.Path]::GetFullPath($Exe))){Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue}}catch{}}
  $bak=Join-Path $Root 'KafePin Client.previous.exe';if(Test-Path $Exe){Copy-Item $Exe $bak -Force}
  Copy-Item $newExe $Exe -Force
  $m.version=$ExpectedVersion;$m.updatedAt=(Get-Date).ToString('o');[IO.File]::WriteAllText($Marker,($m|ConvertTo-Json -Depth 5),(New-Object Text.UTF8Encoding($false)))
  Log ('Client güncellendi: v'+$ExpectedVersion)
  Start-ScheduledTask -TaskName $Task
  Start-Sleep -Seconds 2
  if(-not(Get-ScheduledTask -TaskName $Task -ErrorAction SilentlyContinue)){throw 'Client görevi yeniden başlatılamadı.'}
  Remove-Item $bak -Force -ErrorAction SilentlyContinue
}catch{
  Log ('Güncelleme hatası: '+$_.Exception.Message)
  try{if(Test-Path (Join-Path $Root 'KafePin Client.previous.exe')){Copy-Item (Join-Path $Root 'KafePin Client.previous.exe') $Exe -Force;Start-ScheduledTask -TaskName $Task -ErrorAction SilentlyContinue}}catch{}
}finally{try{if($work){Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue}}catch{}}
