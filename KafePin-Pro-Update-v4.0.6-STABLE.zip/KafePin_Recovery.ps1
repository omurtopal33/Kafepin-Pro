﻿param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$Reason = 'automatic',
  [switch]$WaitForDownFirst,
  [switch]$LaunchDesktop
)

$ErrorActionPreference = 'SilentlyContinue'
$SystemRoot = Join-Path $env:ProgramData 'KafePinPro'
$LogDir = Join-Path $SystemRoot 'logs'
$LogFile = Join-Path $LogDir 'recovery.log'
$ResultFile = Join-Path $InstallRoot 'logs\kafepin-recovery-result.json'
$DesktopExe = Join-Path $InstallRoot 'desktop-app\KafePin Pro.exe'
$EnsureScript = Join-Path $InstallRoot 'KafePin_Manager_Ensure.ps1'
New-Item -ItemType Directory -Force -Path $SystemRoot,$LogDir | Out-Null

function Log([string]$Message) { try { Add-Content -LiteralPath $LogFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' [recovery-v4] ' + $Message) -Encoding UTF8 } catch {} }
function Write-Result([bool]$Ok,[string]$Stage,[string]$Message) {
  try {
    $payload=[ordered]@{ok=$Ok;stage=$Stage;message=$Message;reason=$Reason;time=(Get-Date).ToString('o')}
    $tmp=$ResultFile+'.tmp'
    $payload | ConvertTo-Json -Compress | Set-Content -LiteralPath $tmp -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination $ResultFile -Force
  } catch {}
}
function Health {
  try {
    $r=Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:3000/api/health?_recovery=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 2 -Headers @{'Cache-Control'='no-cache'}
    if ($r.StatusCode -lt 200 -or $r.StatusCode -ge 300) { return $false }
    $body=$r.Content | ConvertFrom-Json
    return ($body.ok -eq $true -and $body.db -eq $true)
  } catch { return $false }
}
function Wait-Health([int]$Seconds) { for($i=0;$i -lt $Seconds;$i++){ if(Health){return $true}; Start-Sleep -Seconds 1 }; return $false }
function Start-Desktop {
  if(-not $LaunchDesktop){return}
  try { if((Get-Process -Name 'KafePin Pro' -ErrorAction SilentlyContinue).Count -gt 0){return} } catch {}
  if(Test-Path -LiteralPath $DesktopExe){ try { Start-Process -FilePath $DesktopExe -WorkingDirectory (Split-Path -Parent $DesktopExe)|Out-Null } catch {} }
}

function Find-Node {
  $candidates=@(
    (Join-Path $InstallRoot 'node\node.exe'),
    (Join-Path ${env:ProgramFiles} 'nodejs\node.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'nodejs\node.exe')
  ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
  # PowerShell'de [string]$candidates[0] ifadesi önce diziyi stringe çevirip
  # sonra ilk karakteri alır ("C"). Parantez gerçek node.exe yolunu korur.
  if($candidates.Count -gt 0){ return [string]($candidates[0]) }
  try {
    $cmd=Get-Command node.exe -ErrorAction Stop | Select-Object -First 1
    if($cmd -and $cmd.Source -and (Test-Path -LiteralPath $cmd.Source)){ return [string]$cmd.Source }
  } catch {}
  return ''
}

function Start-NodeDirect {
  $server=Join-Path $InstallRoot 'server.js'
  $node=Find-Node
  if(-not (Test-Path -LiteralPath $server)){ Log 'server.js bulunamadi.'; return $false }
  if([string]::IsNullOrWhiteSpace($node)){ Log 'node.exe bulunamadi.'; return $false }
  try {
    $out=Join-Path $LogDir 'recovery-node.out.log'
    $err=Join-Path $LogDir 'recovery-node.err.log'
    Start-Process -FilePath $node -ArgumentList @($server) -WorkingDirectory $InstallRoot -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err | Out-Null
    Log ('Dogru Node baslatildi: '+$node)
    return $true
  } catch { Log ('Dogru Node baslatilamadi: '+$_.Exception.Message); return $false }
}

function Clear-StaleRecoveryMarkers {
  # Güncelleme işaretlerinin sahibi yalnız post-update aktivasyon zinciridir.
  # Kurtarma, sağlıklı bir runtime bulsa bile bu işaretleri silmez; aksi halde
  # update sırasında açılan yardımcı süreç masaüstü/PRO aktivasyonunu yarıda
  # bırakabilirdi. Burada sadece geriye dönük çağrı uyumluluğu korunur.
  if(-not (Health)){ return }
}

Log ('Kurtarma istegi • ' + $Reason)
Write-Result $false 'starting' 'Kurtarma kontrolleri baslatildi.'
if($WaitForDownFirst){ for($i=0;$i -lt 20;$i++){ if(-not(Health)){break}; Start-Sleep -Seconds 1 } }
if(Health){ Log 'Sunucu zaten saglikli.'; Clear-StaleRecoveryMarkers; Write-Result $true 'already_healthy' 'Sunucu ve veritabani zaten saglikli.'; Start-Desktop; exit 0 }

# STABLE: Recovery Node baslatmaz ve art arda schtasks tetiklemez.
# Tek gorevi Manager Ensure ile kalici Server Manager'i dogrulamak.
if(Test-Path -LiteralPath $EnsureScript){
  try {
    $p=Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$EnsureScript,'-InstallRoot',$InstallRoot) -Wait -PassThru -WindowStyle Hidden
    Log ('Manager Ensure cikis=' + $p.ExitCode)
  } catch { Log ('Manager Ensure baslatilamadi: ' + $_.Exception.Message) }
}else{
  try { & schtasks.exe /Run /TN 'KafePin Pro Server Manager' 2>$null | Out-Null; Log 'Server Manager gorevi bir kez tetiklendi.' } catch {}
}

if(Wait-Health 20){ Log 'BASARILI: Server Manager ile sunucu acildi.'; Clear-StaleRecoveryMarkers; Write-Result $true 'manager' 'Server Manager ve veritabani saglikli.'; Start-Desktop; exit 0 }

# Manager yoksa ya da güncelleme sonrası gecikirse yalnızca bu butonla çağrılan
# güvenli fallback devreye girer. Port/DB doğrulanmadan hiçbir kilit temizlenmez.
Write-Result $false 'node_fallback' 'Server Manager yanit vermedi; güvenli Node fallback deneniyor.'
if(Start-NodeDirect){
  if(Wait-Health 35){ Log 'BASARILI: Dogru Node fallback ile sunucu acildi.'; Clear-StaleRecoveryMarkers; Write-Result $true 'node_fallback' 'KafePin sunucusu ve veritabani saglikli.'; Start-Desktop; exit 0 }
}

Log 'BASARISIZ: Server Manager ve Node fallback sunucuyu acamadi.'
Write-Result $false 'failed' 'Sunucu baslatilamadi. recovery-node.err.log ve recovery.log incelenmeli.'
exit 1
