@echo off
setlocal
py.exe -3 -B "%~dp0web_service.py"
