﻿param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$ProRoot = 'C:\KafePinPro'
)

$ErrorActionPreference = 'Stop'
$LogDir = Join-Path $InstallRoot 'logs'
$LogPath = Join-Path $LogDir 'structure-optimize.log'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

function Log([string]$Text) {
  try { Add-Content -LiteralPath $LogPath -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Text) -Encoding UTF8 } catch {}
}

function Get-ArchiveRoot {
  $preferred = 'D:\KAFEPIN_YEDEK\LEGACY_CLEANUP'
  try {
    if (Test-Path -LiteralPath 'D:\' -PathType Container) {
      New-Item -ItemType Directory -Force -Path $preferred | Out-Null
      return $preferred
    }
  } catch {}
  $fallback = Join-Path $InstallRoot 'backup\legacy-cleanup'
  New-Item -ItemType Directory -Force -Path $fallback | Out-Null
  return $fallback
}

$ArchiveRoot = Get-ArchiveRoot
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$SessionArchive = Join-Path $ArchiveRoot $Stamp
New-Item -ItemType Directory -Force -Path $SessionArchive | Out-Null

function Move-ToArchive([string]$Path, [string]$Group) {
  if (-not (Test-Path -LiteralPath $Path)) { return $false }
  try {
    $groupRoot = Join-Path $SessionArchive $Group
    New-Item -ItemType Directory -Force -Path $groupRoot | Out-Null
    $leaf = Split-Path -Leaf $Path
    if ([string]::IsNullOrWhiteSpace($leaf)) { $leaf = 'legacy-item' }
    $destination = Join-Path $groupRoot $leaf
    if (Test-Path -LiteralPath $destination) {
      $destination = Join-Path $groupRoot ($leaf + '-' + [guid]::NewGuid().ToString('N').Substring(0,8))
    }
    Move-Item -LiteralPath $Path -Destination $destination -Force -ErrorAction Stop
    Log ('ARSIVLENDI ' + $Path + ' -> ' + $destination)
    return $true
  } catch {
    Log ('ARSIVLENEMEDI ' + $Path + ' :: ' + $_.Exception.Message)
    return $false
  }
}

function Remove-ObsoleteProTasks {
  $keep = @(
    'KafePin Pro Server Manager',
    'KafePin Pro Restore Worker',
    'KafePin Pro Desktop Action'
  )
  $tokens = @(
    'c:\kafepinpro\mp3botpro',
    'c:\kafepinpro\mp3bot\',
    'c:\kafepinmp3botpro',
    'c:\kafepinpro\yazicipro',
    'c:\kafepinyazicipro',
    'c:\kafepinpro\teknikservispro',
    'c:\kafepinteknikservispro',
    'c:\kafepinpro\clientyonetimpro',
    'c:\kafepinclientyonetimpro'
  )
  try {
    $service = New-Object -ComObject 'Schedule.Service'
    $service.Connect()
    $root = $service.GetFolder('\')
    try {
      $oldRuntime = $root.GetTask('KafePin PRO Runtime Refresh')
      if ($oldRuntime) { $root.DeleteTask('KafePin PRO Runtime Refresh', 0); Log 'ESKI PRO RUNTIME GOREVI KALDIRILDI KafePin PRO Runtime Refresh' }
    } catch {}
    foreach ($task in @($root.GetTasks(0))) {
      try {
        $name = [string]$task.Name
        if ($name -in $keep) { continue }
        $hit = $false
        foreach ($action in @($task.Definition.Actions)) {
          $text = (([string]$action.Path) + ' ' + ([string]$action.Arguments) + ' ' + ([string]$action.WorkingDirectory)).Replace('/','\').ToLowerInvariant()
          foreach ($token in $tokens) {
            if ($text.Contains($token)) { $hit = $true; break }
          }
          if ($hit) { break }
        }
        if ($hit) {
          $root.DeleteTask($name, 0)
          Log ('ESKI PRO GOREVI KALDIRILDI ' + $name)
        }
      } catch { Log ('GOREV TEMIZLEME UYARISI ' + $_.Exception.Message) }
    }
  } catch { Log ('TASK SCHEDULER TEMIZLEME UYARISI ' + $_.Exception.Message) }
}

# C:\KafePin kökünde yalnız geçmiş geliştirme/test çalışma alanlarını temizle.
# Çalışan çekirdek klasörlere (backup/config/desktop-app/logs/node_modules/pro-components/
# public/services/tools/utils/node) ve bilinmeyen klasörlere ASLA dokunulmaz.
$devPatterns = @(
  'dotnet-cli',
  'kafepin-pro-admin',
  'kafepin-pro-window',
  'publish-v*',
  '_final_compare_*',
  '_release_compare_*',
  '_release_verify_*',
  '_release_v*',
  '_v*',
  'KafePinPro',
  'KafePin-Pro-release',
  'KafePinYaziciPRO_BACKUP_*',
  'mp3-favorites-stage',
  'native-engine-*',
  'rollback-program-backup-before-*',
  'v*-yazici*'
)

$seen = New-Object System.Collections.Generic.HashSet[string]
foreach ($pattern in $devPatterns) {
  foreach ($item in @(Get-ChildItem -LiteralPath $InstallRoot -Directory -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -like $pattern })) {
    $full = [IO.Path]::GetFullPath($item.FullName)
    if ($seen.Add($full)) { [void](Move-ToArchive $full 'kafepin-root-workspaces') }
  }
}

# PRO çalışma kökü yalnız dört servis klasörüdür. Eski/yanlış program kökleri silinmez;
# geri dönüş için KAFEPIN_YEDEK altına alınır.
$legacyProRoots = @(
  (Join-Path $ProRoot 'MP3Bot'),
  (Join-Path $ProRoot '_LegacyDisabled'),
  'C:\KafePinMp3BotPRO',
  'C:\KafePinYaziciPRO',
  'C:\KafePinTeknikServisPRO',
  'C:\KafePinClientYonetimPRO'
)
foreach ($legacy in $legacyProRoots) { [void](Move-ToArchive $legacy 'pro-legacy-roots') }

Remove-ObsoleteProTasks
Log ('YAPI OPTIMIZASYONU TAMAMLANDI archive=' + $SessionArchive)
Write-Output ('OK|' + $SessionArchive)
exit 0
