﻿param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$ProRoot = 'C:\KafePinPro'
)

$ErrorActionPreference = 'Stop'
$ProgramDataRoot = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
$StateRoot = Join-Path $ProgramDataRoot 'KafePinPro'
$LogPath = Join-Path $StateRoot 'pro-runtime-refresh.log'
$RuntimePath = Join-Path $StateRoot 'pro-runtime.json'
$Mp3Root = Join-Path $ProRoot 'MP3BotPRO'
$PrinterRoot = Join-Path $ProRoot 'YaziciPRO'
$TechnicalRoot = Join-Path $ProRoot 'TeknikServisPRO'
$ClientRoot = Join-Path $ProRoot 'ClientYonetimPRO'
# v4.0.6: Client Yönetim PRO emekliye ayrıldı; işlevler Client Performans PRO'ya taşındı.
try { Unregister-ScheduledTask -TaskName 'KafePin Client Yonetim PRO' -Confirm:$false -ErrorAction SilentlyContinue } catch {}
$PerformanceRoot = Join-Path $ProRoot 'ClientPerformansPRO'
$CvRoot = Join-Path $ProRoot 'CVOlusturPRO'
$StatePath = Join-Path $InstallRoot 'config\pro-components.json'
$RuntimeLockPath = Join-Path $StateRoot 'pro-runtime-refresh.lock'
$RuntimeLockHandle = $null
try {
  New-Item -ItemType Directory -Force -Path $StateRoot | Out-Null
  $RuntimeLockHandle = [IO.File]::Open($RuntimeLockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
} catch {
  # Ayni anda logon + server tetigi gelirse ikinci kopya servisleri tekrar tekrar
  # kapatip acmaz. Ilk runtime yenilemesi bitince sonraki normal tetik calisabilir.
  exit 0
}

function Test-Mp3Selected {
  if (Test-Path -LiteralPath $Mp3Root -PathType Container) { return $true }
  foreach ($legacy in @((Join-Path $ProRoot 'MP3Bot'), 'C:\KafePinMp3BotPRO')) {
    if (Test-Path -LiteralPath $legacy -PathType Container) { return $true }
  }
  try {
    if (Test-Path -LiteralPath $StatePath -PathType Leaf) {
      $state = Get-Content -LiteralPath $StatePath -Raw | ConvertFrom-Json
      if ($state.choices -and $state.choices.mp3 -eq $true) { return $true }
    }
  } catch {}
  return $false
}

function Log([string]$Text) {
  try {
    New-Item -ItemType Directory -Force -Path $StateRoot | Out-Null
    Add-Content -LiteralPath $LogPath -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Text) -Encoding UTF8
  } catch {}
}

function Invoke-HiddenProcess([string]$FilePath, [string[]]$Arguments, [string]$WorkingDirectory, [bool]$Wait = $false, [int]$TimeoutSeconds = 45) {
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $FilePath
  $psi.WorkingDirectory = $WorkingDirectory
  $psi.UseShellExecute = $false
  $psi.CreateNoWindow = $true
  $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
  $quoted = foreach ($arg in $Arguments) {
    $text = [string]$arg
    if ($text -match '[\s"]') { '"' + ($text -replace '"','\"') + '"' } else { $text }
  }
  $psi.Arguments = ($quoted -join ' ')
  $p = [System.Diagnostics.Process]::Start($psi)
  if (-not $p) { throw ('Proses baslatilamadi: ' + $FilePath) }
  if ($Wait) {
    if (-not $p.WaitForExit([Math]::Max(1000, $TimeoutSeconds * 1000))) {
      try { $p.Kill() } catch {}
      throw ('Proses zaman asimi: ' + $FilePath)
    }
    if ($p.ExitCode -ne 0) { throw ('Proses cikis kodu ' + $p.ExitCode + ': ' + $FilePath) }
  }
  return $p
}

function Get-PortOwnerPids([int]$Port) {
  $ids = New-Object System.Collections.Generic.HashSet[int]
  try {
    foreach ($c in @(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue)) {
      if ([int]$c.OwningProcess -gt 0) { [void]$ids.Add([int]$c.OwningProcess) }
    }
  } catch {}
  if ($ids.Count -eq 0) {
    try {
      foreach ($line in @(& netstat.exe -ano -p tcp 2>$null)) {
        $parts = @(([string]$line).Trim() -split '\s+')
        if ($parts.Count -lt 5 -or $parts[0].ToUpperInvariant() -ne 'TCP' -or $parts[3].ToUpperInvariant() -ne 'LISTENING') { continue }
        if (-not $parts[1].EndsWith((':' + $Port))) { continue }
        $pidValue = 0
        if ([int]::TryParse($parts[4], [ref]$pidValue) -and $pidValue -gt 0) { [void]$ids.Add($pidValue) }
      }
    } catch {}
  }
  return @($ids)
}

function Stop-PortOwner([int]$Port, [switch]$Reserved) {
  foreach ($pidValue in @(Get-PortOwnerPids $Port)) {
    if ($pidValue -le 0 -or $pidValue -eq $PID) { continue }
    $allowed = $Reserved.IsPresent
    if (-not $allowed) {
      try {
        $row = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $pidValue) -ErrorAction SilentlyContinue
        $name = ([string]$row.Name).ToLowerInvariant()
        $cmd = ([string]$row.CommandLine).ToLowerInvariant()
        $allowed = ($name -in @('python.exe','pythonw.exe','py.exe','python3.exe','node.exe','powershell.exe')) -and $cmd.Contains('kafepin')
      } catch {}
    }
    if ($allowed) {
      try { Stop-Process -Id $pidValue -Force -ErrorAction SilentlyContinue } catch {}
      try { & taskkill.exe /PID $pidValue /T /F 2>$null | Out-Null } catch {}
      Log ('Port sahibi durduruldu. port=' + $Port + ' pid=' + $pidValue)
    }
  }
}

function Stop-ProProcesses {
  $tokens = @(
    'c:\kafepinpro\mp3botpro', 'c:\kafepinpro\yazicipro',
    'c:\kafepinpro\teknikservispro', 'c:\kafepinpro\clientyonetimpro', 'c:\kafepinpro\clientperformanspro', 'c:\kafepinpro\cvolusturpro',
    'c:\kafepinpro\mp3bot\', 'c:\kafepinmp3botpro'
  )
  try {
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
      $pidValue = [int]$_.ProcessId
      if ($pidValue -eq $PID) { return $false }
      $name = ([string]$_.Name).ToLowerInvariant()
      if ($name -notin @('python.exe','pythonw.exe','py.exe','python3.exe','node.exe','powershell.exe')) { return $false }
      $cmd = ([string]$_.CommandLine).Replace('/','\').ToLowerInvariant()
      foreach ($token in $tokens) { if ($cmd.Contains($token)) { return $true } }
      return $false
    } | ForEach-Object {
      try { Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue } catch {}
    }
  } catch {}
  Stop-PortOwner 17890 -Reserved
  foreach ($port in @(17891,17892,17893,17894,17895,17896)) { Stop-PortOwner $port -Reserved }
  # Eski Client Yönetim PRO görevini/prosesini aktif yapıdan çıkar; klasörü geri alınabilir arşive taşı.
  try { Unregister-ScheduledTask -TaskName 'KafePin Client Yonetim PRO' -Confirm:$false -ErrorAction SilentlyContinue } catch {}
  if (Test-Path -LiteralPath $ClientRoot -PathType Container) {
    try {
      $retiredRoot = Join-Path $ProRoot '_kaldirilanlar'
      New-Item -ItemType Directory -Force -Path $retiredRoot | Out-Null
      $retired = Join-Path $retiredRoot ('ClientYonetimPRO-v406-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
      Move-Item -LiteralPath $ClientRoot -Destination $retired -Force
      Log ('Client Yonetim PRO aktif servisten kaldirildi; geri alinabilir arsiv: ' + $retired)
    } catch { Log ('Client Yonetim PRO arsivleme uyarisi: ' + $_.Exception.Message) }
  }
  $deadline = (Get-Date).AddSeconds(7)
  do {
    if (@(Get-PortOwnerPids 17890).Count -eq 0) { break }
    Start-Sleep -Milliseconds 120
  } while ((Get-Date) -lt $deadline)
}

function Get-Mp3ExpectedVersion {
  $meta = Join-Path $Mp3Root 'mp3-web-version.json'
  if (-not (Test-Path -LiteralPath $meta -PathType Leaf)) { return '' }
  try { return [string]((Get-Content -LiteralPath $meta -Raw | ConvertFrom-Json).version) } catch { return '' }
}

function Test-Mp3Payload {
  if (-not (Test-Path -LiteralPath $Mp3Root -PathType Container)) { return $false }
  $expected = Get-Mp3ExpectedVersion
  if ([string]::IsNullOrWhiteSpace($expected)) { return $false }
  $manifest = Join-Path $Mp3Root 'SHA256_COMPONENTS.txt'
  if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { return $false }
  $rows = @{}
  try {
    foreach ($row in @(Get-Content -LiteralPath $manifest)) {
      if ([string]$row -match '^([0-9a-fA-F]{64})\s+(.+)$') { $rows[$matches[2].Trim().Replace('\','/')] = $matches[1].ToLowerInvariant() }
    }
    foreach ($relative in @('web/index.html','web/app.js','web_service.py','service_control.py','archive_index.py','mp3-web-version.json')) {
      if (-not $rows.ContainsKey($relative)) { return $false }
      $file = Join-Path $Mp3Root ($relative.Replace('/','\'))
      if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { return $false }
      if ((Get-FileHash -Algorithm SHA256 -LiteralPath $file).Hash.ToLowerInvariant() -ne $rows[$relative]) { return $false }
    }
    return $true
  } catch { return $false }
}

function Repair-Mp3PayloadIfNeeded {
  if (Test-Mp3Payload) { return }
  $archive = Join-Path (Join-Path $InstallRoot 'pro-components') 'mp3-bot-pro.zip'
  if (-not (Test-Path -LiteralPath $archive -PathType Leaf)) { throw 'MP3 self-heal paketi bulunamadi.' }
  $temp = Join-Path $env:TEMP ('KafePin-MP3-SelfHeal-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $temp | Out-Null
  try {
    Expand-Archive -LiteralPath $archive -DestinationPath $temp -Force
    New-Item -ItemType Directory -Force -Path $Mp3Root | Out-Null
    $preserve = @('.venv','logs','state.json','favorites.json','.env')
    foreach ($item in @(Get-ChildItem -LiteralPath $temp -Force)) {
      if ($item.Name -in $preserve) { continue }
      $target = Join-Path $Mp3Root $item.Name
      if ($item.PSIsContainer) {
        if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction SilentlyContinue }
        Copy-Item -LiteralPath $item.FullName -Destination $target -Recurse -Force
      } else {
        Copy-Item -LiteralPath $item.FullName -Destination $target -Force
      }
    }
  } finally {
    Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
  }
  if (-not (Test-Mp3Payload)) { throw 'MP3 self-heal dogrulamasi basarisiz.' }
  Log ('MP3 payload self-heal tamamlandi. version=' + (Get-Mp3ExpectedVersion))
}

function Get-PythonW {
  foreach ($candidate in @(
    (Join-Path $Mp3Root '.venv\Scripts\pythonw.exe'),
    (Join-Path $PrinterRoot '.venv\Scripts\pythonw.exe')
  )) { if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate } }
  try {
    $cmd = Get-Command pythonw.exe -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) { return [string]$cmd.Source }
  } catch {}
  return ''
}

function Test-Http([string]$Uri, [string]$ExpectedVersion = '', [string]$ExpectedRoot = '') {
  try {
    $sep = if ($Uri.Contains('?')) { '&' } else { '?' }
    $r = Invoke-WebRequest -UseBasicParsing -Uri ($Uri + $sep + '_kp=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 2 -Headers @{ 'Cache-Control'='no-cache' }
    if ([int]$r.StatusCode -lt 200 -or [int]$r.StatusCode -ge 300) { return $false }
    if ($ExpectedVersion -or $ExpectedRoot) {
      $j = $r.Content | ConvertFrom-Json
      if ($ExpectedVersion -and [string]$j.version -ne $ExpectedVersion) { return $false }
      if ($ExpectedRoot) {
        $actualRoot = ([string]$j.programRoot).TrimEnd('\').ToLowerInvariant()
        $wantedRoot = ([string]$ExpectedRoot).TrimEnd('\').ToLowerInvariant()
        if ($actualRoot -ne $wantedRoot) { return $false }
      }
    }
    return $true
  } catch { return $false }
}

New-Item -ItemType Directory -Force -Path $StateRoot | Out-Null
$startedAt = (Get-Date).ToString('o')
$sessionId = [int][System.Diagnostics.Process]::GetCurrentProcess().SessionId
if ($sessionId -le 0) { throw 'PRO runtime yenileme interaktif Windows oturumunda calismiyor.' }

Stop-ProProcesses
$mp3Selected = Test-Mp3Selected
if ($mp3Selected) { Repair-Mp3PayloadIfNeeded }

$expectedMp3 = Get-Mp3ExpectedVersion
if ($mp3Selected -and (Test-Path -LiteralPath $Mp3Root -PathType Container)) {
  $pythonw = Join-Path $Mp3Root '.venv\Scripts\pythonw.exe'
  $ctl = Join-Path $Mp3Root 'service_control.py'
  if (-not (Test-Path -LiteralPath $pythonw -PathType Leaf)) { throw 'MP3 pythonw.exe bulunamadi.' }
  if (-not (Test-Path -LiteralPath $ctl -PathType Leaf)) { throw 'MP3 service_control.py bulunamadi.' }
  $p = Invoke-HiddenProcess $pythonw @($ctl,'start','--wait','--timeout','25','--expected-version',$expectedMp3,'--expected-root',$Mp3Root) $Mp3Root $true 35
  Log ('MP3 baslatildi. version=' + $expectedMp3)
}

if (Test-Path -LiteralPath $PrinterRoot -PathType Container) {
  $host = Join-Path $PrinterRoot 'KafePin_YaziciPRO_ServiceHost.ps1'
  if (Test-Path -LiteralPath $host -PathType Leaf) {
    [void](Invoke-HiddenProcess 'powershell.exe' @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',$host,'-InstallRoot',$PrinterRoot) $PrinterRoot $false 30)
  }
}

$sharedPythonW = Get-PythonW
foreach ($item in @(
  @{Name='Teknik Servis PRO';Root=$TechnicalRoot;Port=17892},
  @{Name='Client Performans PRO';Root=$PerformanceRoot;Port=17896},
  @{Name='CV Olustur PRO';Root=$CvRoot;Port=17895}
)) {
  if (-not (Test-Path -LiteralPath $item.Root -PathType Container)) { continue }
  $serviceFile = Join-Path $item.Root 'web_service.py'
  if (-not (Test-Path -LiteralPath $serviceFile -PathType Leaf)) { continue }
  if (-not $sharedPythonW) { throw ($item.Name + ' icin pythonw.exe bulunamadi.') }
  [void](Invoke-HiddenProcess $sharedPythonW @('-B',$serviceFile) $item.Root $false 30)
}

$checks = [ordered]@{}
if ($mp3Selected -and (Test-Path -LiteralPath $Mp3Root -PathType Container)) { $checks['MP3 Bot PRO'] = @('http://127.0.0.1:17890/api/health') }
if (Test-Path -LiteralPath $PrinterRoot -PathType Container) { $checks['Yazici PRO'] = @('http://127.0.0.1:17891/api/health','http://127.0.0.1:17893/health') }
if (Test-Path -LiteralPath $TechnicalRoot -PathType Container) { $checks['Teknik Servis PRO'] = @('http://127.0.0.1:17892/api/health') }
if (Test-Path -LiteralPath $PerformanceRoot -PathType Container) { $checks['Client Performans PRO'] = @('http://127.0.0.1:17896/api/health') }
if (Test-Path -LiteralPath $CvRoot -PathType Container) { $checks['CV Olustur PRO'] = @('http://127.0.0.1:17895/api/health') }

$pending = @{}
foreach ($name in $checks.Keys) { $pending[$name] = @($checks[$name]) }
$deadline = (Get-Date).AddSeconds(45)
do {
  foreach ($name in @($pending.Keys)) {
    $ok = $true
    foreach ($uri in @($pending[$name])) {
      if ($name -eq 'MP3 Bot PRO') {
        if (-not (Test-Http $uri $expectedMp3 $Mp3Root)) { $ok = $false; break }
      } elseif (-not (Test-Http $uri)) { $ok = $false; break }
    }
    if ($ok) { $pending.Remove($name) }
  }
  if ($pending.Count -eq 0) { break }
  Start-Sleep -Milliseconds 250
} while ((Get-Date) -lt $deadline)

$report = [ordered]@{
  checkedAt = (Get-Date).ToString('o')
  startedAt = $startedAt
  sessionId = $sessionId
  proRoot = $ProRoot
  mp3 = [ordered]@{ root=$Mp3Root; expected=$expectedMp3; ready=(-not $pending.ContainsKey('MP3 Bot PRO')); pid=(@(Get-PortOwnerPids 17890) | Select-Object -First 1) }
  printer = [ordered]@{ root=$PrinterRoot; ready=(-not $pending.ContainsKey('Yazici PRO')) }
  technical = [ordered]@{ root=$TechnicalRoot; ready=(-not $pending.ContainsKey('Teknik Servis PRO')) }
  performance = [ordered]@{ root=$PerformanceRoot; ready=(-not $pending.ContainsKey('Client Performans PRO')); port=17896 }
  cv = [ordered]@{ root=$CvRoot; ready=(-not $pending.ContainsKey('CV Olustur PRO')) }
}
$report | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $RuntimePath -Encoding UTF8
if ($pending.Count -gt 0) {
  Log ('Hazir olmayan servisler: ' + (($pending.Keys | Sort-Object) -join ', '))
  exit 4
}
Log ('Tum kurulu PRO servisleri hazir. MP3=' + $expectedMp3)
exit 0
