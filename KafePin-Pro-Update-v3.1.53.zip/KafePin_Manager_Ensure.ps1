﻿param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$NodePath = ''
)

$ErrorActionPreference = 'Stop'
$TaskName = 'KafePin Pro Server Manager'
$RestoreTaskName = 'KafePin Pro Restore Worker'
$SystemRoot = Join-Path $env:ProgramData 'KafePinPro'
$ManagerSource = Join-Path $InstallRoot 'KafePin_System_Manager.ps1'
$ManagerLive = Join-Path $SystemRoot 'KafePin_System_Manager.ps1'
$RestoreSource = Join-Path $InstallRoot 'KafePin_Restore_Worker.ps1'
$RestoreLive = Join-Path $SystemRoot 'KafePin_Restore_Worker.ps1'
$ConfigFile = Join-Path $SystemRoot 'manager-config.json'
$TokenFile = Join-Path $SystemRoot 'manager.token'
$RestartRequestFile = Join-Path $SystemRoot 'server-restart-request.json'
$LogDir = Join-Path $SystemRoot 'logs'
$LogFile = Join-Path $LogDir 'manager-ensure.log'
$ControlPort = 2999
$ExpectedManagerVersion = '3.1.4'
New-Item -ItemType Directory -Force -Path $SystemRoot,$LogDir | Out-Null

function Log([string]$Message) {
  try { Add-Content -LiteralPath $LogFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' [ensure-3.1.4] ' + $Message) -Encoding UTF8 } catch {}
}
function Find-Node {
  if ($NodePath -and (Test-Path -LiteralPath $NodePath -PathType Leaf)) { return $NodePath }
  try {
    if (Test-Path -LiteralPath $ConfigFile) {
      $cfg = Get-Content -LiteralPath $ConfigFile -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($cfg.nodePath -and (Test-Path -LiteralPath ([string]$cfg.nodePath) -PathType Leaf)) { return [string]$cfg.nodePath }
    }
  } catch {}
  $candidates = @(
    (Join-Path $InstallRoot 'node\node.exe'),
    'C:\Program Files\nodejs\node.exe',
    'C:\Program Files (x86)\nodejs\node.exe'
  )
  foreach ($candidate in $candidates) { if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate } }
  try {
    $cmd = Get-Command node.exe -ErrorAction Stop
    if ($cmd.Source -and (Test-Path -LiteralPath $cmd.Source -PathType Leaf)) { return $cmd.Source }
  } catch {}
  throw 'Node.exe bulunamadi.'
}
function Get-ControlState {
  try {
    if (-not (Test-Path -LiteralPath $TokenFile)) { return $null }
    $token = (Get-Content -LiteralPath $TokenFile -Raw -ErrorAction Stop).Trim()
    if (-not $token) { return $null }
    $r = Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:' + $ControlPort + '/status?_=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 2 -Headers @{ 'X-KafePin-Manager-Token'=$token; 'Cache-Control'='no-cache' }
    if ($r.StatusCode -lt 200 -or $r.StatusCode -ge 300) { return $null }
    $j = $r.Content | ConvertFrom-Json
    if (-not [bool]$j.ok) { return $null }
    return $j
  } catch { return $null }
}
function Test-Control {
  return ($null -ne (Get-ControlState))
}
function Test-ControlExpectedVersion {
  $state = Get-ControlState
  return ($null -ne $state -and [string]$state.managerVersion -eq $ExpectedManagerVersion)
}
function Wait-Control([int]$Seconds) {
  for ($i=0; $i -lt $Seconds; $i++) {
    if (Test-ControlExpectedVersion) { return $true }
    Start-Sleep -Seconds 1
  }
  return $false
}
function Stop-ManagerProcesses {
  try { & schtasks.exe /End /TN $TaskName 2>$null | Out-Null } catch {}
  Start-Sleep -Milliseconds 400
  try {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue | Where-Object {
      $cmd=[string]$_.CommandLine
      $cmd -and $cmd.IndexOf('KafePin_System_Manager.ps1',[StringComparison]::OrdinalIgnoreCase) -ge 0
    } | ForEach-Object { try { Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue } catch {} }
  } catch {}
  Start-Sleep -Milliseconds 500
}
function Ensure-RestoreTask {
  if (-not (Test-Path -LiteralPath $RestoreSource -PathType Leaf)) { throw 'KafePin_Restore_Worker.ps1 bulunamadi.' }
  Copy-Item -LiteralPath $RestoreSource -Destination $RestoreLive -Force
  try { & schtasks.exe /End /TN $RestoreTaskName 2>$null | Out-Null } catch {}
  try { & schtasks.exe /Delete /TN $RestoreTaskName /F 2>$null | Out-Null } catch {}
  $powershellExe = Join-Path $PSHOME 'powershell.exe'
  $taskCommand = '"' + $powershellExe + '" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $RestoreLive + '"'
  $out = & schtasks.exe /Create /TN $RestoreTaskName /SC ONSTART /RU SYSTEM /RL HIGHEST /TR $taskCommand /F 2>&1
  if ($LASTEXITCODE -ne 0) { throw ('Restore Worker gorevi olusturulamadi: ' + ($out -join ' ')) }
  Log 'Restore Worker SYSTEM gorevi hazirlandi.'
}

function Register-Task([string]$Node) {
  if (-not (Test-Path -LiteralPath $ManagerSource -PathType Leaf)) { throw 'KafePin_System_Manager.ps1 bulunamadi.' }
  Copy-Item -LiteralPath $ManagerSource -Destination $ManagerLive -Force
  [ordered]@{ nodePath=$Node; root=$InstallRoot; port=3000; controlPort=$ControlPort; version=$ExpectedManagerVersion } | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $ConfigFile -Encoding UTF8
  if (-not (Test-Path -LiteralPath $TokenFile)) { [guid]::NewGuid().ToString('N') | Set-Content -LiteralPath $TokenFile -Encoding ASCII }
  try { & schtasks.exe /Delete /TN $TaskName /F 2>$null | Out-Null } catch {}
  $powershellExe = Join-Path $PSHOME 'powershell.exe'
  $taskCommand = '"' + $powershellExe + '" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $ManagerLive + '" -Loop'
  $out = & schtasks.exe /Create /TN $TaskName /SC ONSTART /RU SYSTEM /RL HIGHEST /TR $taskCommand /F 2>&1
  if ($LASTEXITCODE -ne 0) { throw ('Server Manager gorevi olusturulamadi: ' + ($out -join ' ')) }
  $out = & schtasks.exe /Run /TN $TaskName 2>&1
  if ($LASTEXITCODE -ne 0) { throw ('Server Manager gorevi baslatilamadi: ' + ($out -join ' ')) }
}

try {
  $node = Find-Node


  # v3.1.53 CANDIDATE3 - hizli ve guvenli Yazici PRO uygulamasi.
  # Server Manager on-kontrolu 35 sn timeout ile calisir; burada runtime beklenmez.
  $YaziciPayload = Join-Path $InstallRoot 'v3153-yazici-payload'
  $YaziciRoot = Join-Path $InstallRoot 'KafePinYaziciPRO'
  $YaziciWeb = Join-Path $YaziciRoot 'web'
  $YaziciLog = Join-Path $LogDir 'v3153-yazici-apply.log'
  function YaziciLog([string]$Text) { try { Add-Content -LiteralPath $YaziciLog -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' [v3.1.53-candidate3] ' + $Text) -Encoding UTF8 } catch {} }
  function YaziciFileSha([string]$P) { return (Get-FileHash -Algorithm SHA256 -LiteralPath $P).Hash.ToLowerInvariant() }
  if (-not (Test-Path -LiteralPath $YaziciPayload -PathType Container)) { throw 'v3.1.53 Yazici payload klasoru bulunamadi.' }
  if (-not (Test-Path -LiteralPath $YaziciRoot -PathType Container)) { throw ('Yazici PRO kurulum klasoru bulunamadi: ' + $YaziciRoot) }
  New-Item -ItemType Directory -Force -Path $YaziciWeb | Out-Null
  $pairs = @(
    [pscustomobject]@{ Src='index.html'; Dst='web\index.html'; Sha='62ed70615127589f5d876db23d895fd50d5ed7944057e18dc4df3fe835e96ec4' },
    [pscustomobject]@{ Src='v3153-ai.js'; Dst='web\v3153-ai.js'; Sha='8dcd12f0315a0146ab5c085e90228b177d510feb30c542b7e8b6fa025c20a0b3' },
    [pscustomobject]@{ Src='web_service.py'; Dst='web_service.py'; Sha='57e311f36eb5d05b55bae71a19fce6cc71238af5146b68ac3e5b1fff492cdec2' },
    [pscustomobject]@{ Src='KafePin_YaziciGelir_Service.js'; Dst='KafePin_YaziciGelir_Service.js'; Sha='a4847b89b477fb13a455310e6df58713630012afa466955b9d0b5176ccf7eb8e' },
    [pscustomobject]@{ Src='START_YAZICI_PRO.cmd'; Dst='START_YAZICI_PRO.cmd'; Sha='2c9e44667888d12ca222d0653339c46efa09b28e8066253455a5a275582c2534' },
    [pscustomobject]@{ Src='KafePin_YaziciPRO_WebView2.ps1'; Dst='KafePin_YaziciPRO_WebView2.ps1'; Sha='d3d76e8415d57d50b42025602cf071c1086e7f47560eb6d9840276381e2aa036' },
    [pscustomobject]@{ Src='KafePin_AI_Ayarla.ps1'; Dst='KafePin_AI_Ayarla.ps1'; Sha='b3dc98197d8f629e2b5dfcee26df8fe0c7538b38fd010bda1a3295b77a5ac6bd' },
    [pscustomobject]@{ Src='KafePin_AI_Ayarla.cmd'; Dst='KafePin_AI_Ayarla.cmd'; Sha='96848d3cbfe32faa7579c581909c3b676726d75686fcdde8a88242433847f89d' },
    [pscustomobject]@{ Src='yazici-pro-version.json'; Dst='yazici-pro-version.json'; Sha='dbd2e43f826b8a07a97d77684bbb01de42c8a775c8518864c1357841bd70dcd4' }
  )
  foreach ($pair in $pairs) {
    $src = Join-Path $YaziciPayload ([string]$pair.Src); $dst = Join-Path $YaziciRoot ([string]$pair.Dst)
    if (-not (Test-Path -LiteralPath $src -PathType Leaf)) { throw ('Yazici payload dosyasi eksik: ' + [string]$pair.Src) }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
    Copy-Item -LiteralPath $src -Destination $dst -Force
    if ((YaziciFileSha $dst) -ne [string]$pair.Sha) { throw ('Yazici PRO SHA256 dogrulamasi basarisiz: ' + [string]$pair.Dst) }
  }
  $indexRaw = Get-Content -LiteralPath (Join-Path $YaziciWeb 'index.html') -Raw -Encoding UTF8
  foreach ($marker in @('v3153Verified','FOTOKOP','WHATSAPP WEB','BELGE / DİLEKÇE & AI','FOTOĞRAFTAN WORD','confirm3153Delete','KAFEP')) { if ($indexRaw.IndexOf($marker,[StringComparison]::OrdinalIgnoreCase) -lt 0) { throw ('Yazici PRO marker yok: ' + $marker) } }
  Set-Content -LiteralPath (Join-Path $YaziciRoot 'node-path.txt') -Value $node -Encoding ASCII
  try { & wevtutil.exe sl 'Microsoft-Windows-PrintService/Operational' /e:true 2>$null | Out-Null } catch {}
  $startCmd = Join-Path $YaziciRoot 'START_YAZICI_PRO.cmd'
  try {
    $shell = New-Object -ComObject WScript.Shell; $desktopDirs = @([Environment]::GetFolderPath('Desktop')); if ($env:PUBLIC) { $desktopDirs += (Join-Path $env:PUBLIC 'Desktop') }
    foreach ($desk in ($desktopDirs | Select-Object -Unique)) { if (-not $desk) { continue }; New-Item -ItemType Directory -Force -Path $desk | Out-Null; $lnk=Join-Path $desk 'KafePin Yazıcı PRO.lnk'; $sc=$shell.CreateShortcut($lnk); $sc.TargetPath=$startCmd; $sc.WorkingDirectory=$YaziciRoot; $sc.Description='KafePin Yazıcı PRO 3.1.53'; $sc.Save() }
  } catch { YaziciLog ('Kisayol uyarisi: ' + $_.Exception.Message) }
  [ordered]@{ version='3.1.53'; build='candidate3'; appliedAt=(Get-Date).ToString('o'); yaziciRoot=$YaziciRoot; runtimeActivation='on-first-launch'; updaterWait='none' } | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $SystemRoot 'v3153-yazici-applied.json') -Encoding UTF8
  if (-not (Test-Path -LiteralPath $ManagerSource -PathType Leaf)) { throw 'Manager kaynak dosyasi yok.' }
  Copy-Item -LiteralPath $ManagerSource -Destination $ManagerLive -Force
  [ordered]@{ nodePath=$node; root=$InstallRoot; port=3000; controlPort=$ControlPort; version=$ExpectedManagerVersion } | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $ConfigFile -Encoding UTF8
  if (-not (Test-Path -LiteralPath $TokenFile)) { [guid]::NewGuid().ToString('N') | Set-Content -LiteralPath $TokenFile -Encoding ASCII }
  Ensure-RestoreTask

  if (Test-ControlExpectedVersion) { Log 'Manager control zaten hazir ve surum dogru.'; exit 0 }

  if (Test-Control) {
    Log 'Manager control var fakat surum eski; yeni surum temizden kaydediliyor.'
    Stop-ManagerProcesses
    Remove-Item -LiteralPath $RestartRequestFile -Force -ErrorAction SilentlyContinue
    Register-Task $node
    if (-not (Wait-Control 15)) { throw 'Yeni Server Manager surumu 15 saniye icinde hazir olmadi.' }
    Log 'BASARILI: Manager yeni surume gecirildi.'
    exit 0
  }

  Log 'Manager control yok; mevcut gorev tetikleniyor.'
  try { & schtasks.exe /Run /TN $TaskName 2>$null | Out-Null } catch {}
  if (Wait-Control 6) { Log 'Manager mevcut gorev ile hazirlandi.'; exit 0 }

  Log 'Manager hala yok; gorev temizden kaydediliyor.'
  Stop-ManagerProcesses
  Remove-Item -LiteralPath $RestartRequestFile -Force -ErrorAction SilentlyContinue
  Register-Task $node
  if (-not (Wait-Control 15)) { throw 'Server Manager control portu 15 saniye icinde hazir olmadi.' }
  Log 'BASARILI: Manager gorevi yeniden kaydedildi ve control portu dogrulandi.'
  exit 0
} catch {
  Log ('HATA: ' + $_.Exception.Message)
  Write-Error $_.Exception.Message
  exit 21
}
