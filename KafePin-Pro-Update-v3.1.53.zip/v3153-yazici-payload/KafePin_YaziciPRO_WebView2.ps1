﻿param(
  [string]$LocalUrl = 'http://127.0.0.1:17891/?v=3153candidate3'
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$SdkVersion = '1.0.4129.50'
$SdkRoot = Join-Path $env:ProgramData ('KafePinPro\WebView2SDK\' + $SdkVersion)
$CoreDll = Join-Path $SdkRoot 'lib\net462\Microsoft.Web.WebView2.Core.dll'
$FormsDll = Join-Path $SdkRoot 'lib\net462\Microsoft.Web.WebView2.WinForms.dll'
$LoaderDir = Join-Path $SdkRoot 'runtimes\win-x64\native'
$NugetUrl = 'https://www.nuget.org/api/v2/package/Microsoft.Web.WebView2/' + $SdkVersion
$RuntimeBootstrapperUrl = 'https://go.microsoft.com/fwlink/p/?LinkId=2124703'
$LogDir = Join-Path $env:ProgramData 'KafePinPro\logs'
$LogFile = Join-Path $LogDir 'v3153-webview2.log'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
function Log([string]$Text) { try { Add-Content -LiteralPath $LogFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Text) -Encoding UTF8 } catch {} }
function Fallback([string]$Reason) {
  Log ('FALLBACK: ' + $Reason)
  try { Start-Process $LocalUrl | Out-Null } catch {}
  exit 31
}
try {
  if (-not (Test-Path -LiteralPath $CoreDll -PathType Leaf) -or -not (Test-Path -LiteralPath $FormsDll -PathType Leaf) -or -not (Test-Path -LiteralPath (Join-Path $LoaderDir 'WebView2Loader.dll') -PathType Leaf)) {
    Log ('WebView2 SDK indiriliyor: ' + $SdkVersion)
    $tmp = Join-Path $env:TEMP ('KafePin-WebView2-' + [guid]::NewGuid().ToString('N'))
    $nupkg = $tmp + '.nupkg'
    $zip = $tmp + '.zip'
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $SdkRoot) | Out-Null
    Invoke-WebRequest -UseBasicParsing -Uri $NugetUrl -OutFile $nupkg -TimeoutSec 90
    Copy-Item -LiteralPath $nupkg -Destination $zip -Force
    if (Test-Path -LiteralPath $SdkRoot) { Remove-Item -LiteralPath $SdkRoot -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $SdkRoot | Out-Null
    Expand-Archive -LiteralPath $zip -DestinationPath $SdkRoot -Force
    Remove-Item -LiteralPath $nupkg,$zip -Force -ErrorAction SilentlyContinue
  }
  if (-not (Test-Path -LiteralPath $CoreDll -PathType Leaf)) { throw 'Microsoft.Web.WebView2.Core.dll bulunamadi.' }
  if (-not (Test-Path -LiteralPath $FormsDll -PathType Leaf)) { throw 'Microsoft.Web.WebView2.WinForms.dll bulunamadi.' }
  $env:PATH = $LoaderDir + ';' + $env:PATH
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  Add-Type -Path $CoreDll
  Add-Type -Path $FormsDll

  # SDK DLL'leri tek başına yeterli değildir; Evergreen Runtime da gerekir.
  try {
    $runtimeVersion = [Microsoft.Web.WebView2.Core.CoreWebView2Environment]::GetAvailableBrowserVersionString()
    Log ('WebView2 Runtime: ' + $runtimeVersion)
  } catch {
    Log 'WebView2 Runtime bulunamadi; Microsoft Evergreen Bootstrapper kuruluyor.'
    $bootstrapper = Join-Path $env:TEMP 'MicrosoftEdgeWebView2Setup.exe'
    Invoke-WebRequest -UseBasicParsing -Uri $RuntimeBootstrapperUrl -OutFile $bootstrapper -TimeoutSec 120
    $proc = Start-Process -FilePath $bootstrapper -ArgumentList @('/silent','/install') -Wait -PassThru
    Remove-Item -LiteralPath $bootstrapper -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    $runtimeVersion = [Microsoft.Web.WebView2.Core.CoreWebView2Environment]::GetAvailableBrowserVersionString()
    Log ('WebView2 Runtime kuruldu: ' + $runtimeVersion + ' exit=' + [string]$proc.ExitCode)
  }

  for ($i=0; $i -lt 25; $i++) {
    try {
      $r = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:17891/api/health' -TimeoutSec 1
      if ($r.StatusCode -ge 200 -and $r.StatusCode -lt 300 -and $r.Content -match '3.1.53-candidate3') { break }
    } catch {}
    Start-Sleep -Milliseconds 400
  }

  [System.Windows.Forms.Application]::EnableVisualStyles()
  $form = New-Object System.Windows.Forms.Form
  $form.Text = 'KafePin Yazıcı PRO 3.1.53 • WhatsApp Web'
  $form.StartPosition = 'CenterScreen'
  $form.WindowState = 'Maximized'
  $form.MinimumSize = New-Object System.Drawing.Size(1000,700)

  $tabs = New-Object System.Windows.Forms.TabControl
  $tabs.Dock = [System.Windows.Forms.DockStyle]::Fill
  $tabs.Font = New-Object System.Drawing.Font('Segoe UI',11)
  $localTab = New-Object System.Windows.Forms.TabPage
  $localTab.Text = '🖨️ Yazıcı PRO'
  $waTab = New-Object System.Windows.Forms.TabPage
  $waTab.Text = '📲 WhatsApp Web'
  [void]$tabs.TabPages.Add($localTab)
  [void]$tabs.TabPages.Add($waTab)
  $form.Controls.Add($tabs)

  $profileDir = Join-Path $env:LOCALAPPDATA 'KafePinPro\WebView2Profile'
  New-Item -ItemType Directory -Force -Path $profileDir | Out-Null
  $localView = New-Object Microsoft.Web.WebView2.WinForms.WebView2
  $localView.Dock = [System.Windows.Forms.DockStyle]::Fill
  $localProps = New-Object Microsoft.Web.WebView2.WinForms.CoreWebView2CreationProperties
  $localProps.UserDataFolder = $profileDir
  $localView.CreationProperties = $localProps
  $waView = New-Object Microsoft.Web.WebView2.WinForms.WebView2
  $waView.Dock = [System.Windows.Forms.DockStyle]::Fill
  $waProps = New-Object Microsoft.Web.WebView2.WinForms.CoreWebView2CreationProperties
  $waProps.UserDataFolder = $profileDir
  $waView.CreationProperties = $waProps
  $localTab.Controls.Add($localView)
  $waTab.Controls.Add($waView)

  $script:KafePinTabs = $tabs
  $script:KafePinWhatsAppTab = $waTab
  $localView.add_CoreWebView2InitializationCompleted({
    param($sender,$args)
    try {
      if ($args.IsSuccess) {
        $sender.CoreWebView2.Settings.IsWebMessageEnabled = $true
        $sender.CoreWebView2.add_WebMessageReceived({
          param($s,$e)
          try {
            $msg = $e.TryGetWebMessageAsString()
            if ($msg -eq 'open-whatsapp') {
              $script:KafePinTabs.SelectedTab = $script:KafePinWhatsAppTab
            }
          } catch {}
        })
      } else {
        Log ('Local WebView2 baslatilamadi: ' + [string]$args.InitializationException)
        try { Start-Process $LocalUrl | Out-Null } catch {}
        try { $form.Close() } catch {}
      }
    } catch { Log ('Local WebView mesaj kurulumu: ' + $_.Exception.Message) }
  })
  $waView.add_CoreWebView2InitializationCompleted({
    param($sender,$args)
    try {
      if ($args.IsSuccess) {
        $sender.CoreWebView2.Settings.AreDefaultContextMenusEnabled = $true
        $sender.CoreWebView2.Settings.AreDevToolsEnabled = $false
      }
    } catch {}
  })

  $localView.Source = [Uri]$LocalUrl
  $waView.Source = [Uri]'https://web.whatsapp.com/'
  $form.Add_FormClosed({
    try { $localView.Dispose() } catch {}
    try { $waView.Dispose() } catch {}
  })
  Log 'WebView2 ana pencere acildi.'
  [void]$form.ShowDialog()
  exit 0
} catch {
  Fallback $_.Exception.Message
}
