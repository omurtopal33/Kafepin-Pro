@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0KafePin_AI_Ayarla.ps1"
