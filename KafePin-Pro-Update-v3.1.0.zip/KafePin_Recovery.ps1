param(
  [string]$InstallRoot = 'C:\KafePin',
  [string]$Reason = 'automatic',
  [switch]$WaitForDownFirst,
  [switch]$LaunchDesktop
)

$ErrorActionPreference = 'SilentlyContinue'
$SystemRoot = Join-Path $env:ProgramData 'KafePinPro'
$LogDir = Join-Path $SystemRoot 'logs'
$LogFile = Join-Path $LogDir 'recovery.log'
$MaintenanceFile = Join-Path $SystemRoot 'maintenance.lock'
$RestoreRequestFile = Join-Path $SystemRoot 'restore-request.json'
$DesktopExe = Join-Path $InstallRoot 'desktop-app\KafePin Pro.exe'
New-Item -ItemType Directory -Force -Path $SystemRoot, $LogDir | Out-Null

function Log([string]$Message) {
  try { Add-Content -LiteralPath $LogFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' [recovery-3.0.51] ' + $Message) -Encoding UTF8 } catch {}
}
function Health {
  try {
    $r = Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:3000/api/health?_recovery=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 2 -Headers @{ 'Cache-Control' = 'no-cache' }
    return ($r.StatusCode -ge 200 -and $r.StatusCode -lt 300)
  } catch { return $false }
}
function Wait-Health([int]$Seconds) {
  for ($i = 0; $i -lt $Seconds; $i++) {
    if (Health) { return $true }
    Start-Sleep -Seconds 1
  }
  return $false
}
function Kick-Manager {
  try {
    & schtasks.exe /Run /TN 'KafePin Pro Server Manager' 2>$null | Out-Null
    Log 'Server Manager gorevi tetiklendi.'
  } catch { Log ('Server Manager tetiklenemedi: ' + $_.Exception.Message) }
}
function Start-Desktop {
  if (-not $LaunchDesktop) { return }
  try {
    if ((Get-Process -Name 'KafePin Pro' -ErrorAction SilentlyContinue).Count -gt 0) { return }
  } catch {}
  if (Test-Path -LiteralPath $DesktopExe) {
    try { Start-Process -FilePath $DesktopExe -WorkingDirectory (Split-Path -Parent $DesktopExe) | Out-Null } catch {}
  }
}

Log ('Kurtarma istegi • ' + $Reason)
if ($WaitForDownFirst) {
  for ($i = 0; $i -lt 20; $i++) {
    if (-not (Health)) { break }
    Start-Sleep -Seconds 1
  }
}

# v3.0.51: Kurtarma motoru node/server.js BASLATMAZ. Tek sahip Server Manager.
# Restore job varsa maintenance.lock'a dokunmaz; Manager job'u kendisi bitirir.
if (-not (Test-Path -LiteralPath $RestoreRequestFile) -and (Test-Path -LiteralPath $MaintenanceFile)) {
  try {
    $age = ((Get-Date) - (Get-Item -LiteralPath $MaintenanceFile).LastWriteTime).TotalSeconds
    if ($age -gt 240) {
      Remove-Item -LiteralPath $MaintenanceFile -Force
      Log 'Stale maintenance.lock temizlendi.'
    }
  } catch {}
}

if (Health) {
  Log 'Sunucu zaten saglikli.'
  Start-Desktop
  exit 0
}

Kick-Manager
if (Wait-Health 45) {
  Log 'BASARILI: Server Manager ile sunucu acildi.'
  Start-Desktop
  exit 0
}

# Tekrar yalnız Manager tetiklenir; direct Node fallback yoktur.
Kick-Manager
if (Wait-Health 30) {
  Log 'BASARILI: Ikinci Manager tetigi ile sunucu acildi.'
  Start-Desktop
  exit 0
}

Log 'BASARISIZ: Server Manager sunucuyu acamadi.'
exit 1
