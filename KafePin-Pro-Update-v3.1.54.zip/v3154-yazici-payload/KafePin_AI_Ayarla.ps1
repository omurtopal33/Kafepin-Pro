﻿$ErrorActionPreference='Stop'
# v3.1.53: ProgramData secret dosyasi icin gerekirse UAC ile yonetici olarak yeniden ac.
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  try {
    Start-Process powershell.exe -Verb RunAs -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $PSCommandPath + '"'))
    exit 0
  } catch {
    Write-Host 'AI anahtari icin yonetici izni gerekli.' -ForegroundColor Red
    Read-Host 'Kapatmak icin Enter'
    exit 21
  }
}
$dir = Join-Path $env:ProgramData 'KafePinPro\secrets'
$file = Join-Path $dir 'openai_api_key.txt'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
Write-Host 'KafePin 3.1.53 - AI anahtar ayari' -ForegroundColor Cyan
Write-Host 'Anahtar arayuzde gosterilmez; bu bilgisayarda ProgramData altinda sunucu tarafinda saklanir.'
$secure = Read-Host 'OpenAI API anahtarini gir' -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try {
  $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
  if ([string]::IsNullOrWhiteSpace($plain)) { throw 'Anahtar bos birakilamaz.' }
  [IO.File]::WriteAllText($file, $plain.Trim(), (New-Object Text.UTF8Encoding($false)))
} finally {
  if ($bstr -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
  $plain = $null
}
try { & icacls.exe $file /inheritance:r /grant:r ($env:USERNAME + ':R') 'SYSTEM:F' 2>$null | Out-Null } catch {}
Write-Host ('Kaydedildi: ' + $file) -ForegroundColor Green
Write-Host 'Yazici PRO yeniden acildiginda AI hazir gorunecek.'
Read-Host 'Kapatmak icin Enter'
