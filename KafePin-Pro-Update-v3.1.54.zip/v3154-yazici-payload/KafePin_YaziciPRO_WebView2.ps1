﻿﻿param(
  [string]$LocalUrl = 'http://127.0.0.1:17891/?v=3154candidate2'
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$SdkVersion = '1.0.4129.50'
$SdkRoot = Join-Path $env:ProgramData ('KafePinPro\WebView2SDK\' + $SdkVersion)
$CoreDll = Join-Path $SdkRoot 'lib\net462\Microsoft.Web.WebView2.Core.dll'
$FormsDll = Join-Path $SdkRoot 'lib\net462\Microsoft.Web.WebView2.WinForms.dll'
$LoaderDir = Join-Path $SdkRoot 'runtimes\win-x64\native'
$NugetUrl = 'https://www.nuget.org/api/v2/package/Microsoft.Web.WebView2/' + $SdkVersion
$RuntimeBootstrapperUrl = 'https://go.microsoft.com/fwlink/p/?LinkId=2124703'
$LogDir = Join-Path $env:ProgramData 'KafePinPro\logs'
$LogFile = Join-Path $LogDir 'v3154-webview2.log'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
function Log([string]$Text) { try { Add-Content -LiteralPath $LogFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Text) -Encoding UTF8 } catch {} }
function Fail([string]$Reason) {
  Log ('HATA: ' + $Reason)
  try { Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show(('WhatsApp Web / WebView2 baslatilamadi.`r`n`r`n' + $Reason + '`r`n`r`nLog: ' + $LogFile),'KafePin Yazici PRO 3.1.54') | Out-Null } catch {}
  exit 31
}
function WaitTask($Task) {
  while (-not $Task.IsCompleted) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 20 }
  if ($Task.IsFaulted) { throw $Task.Exception.GetBaseException().Message }
  return $Task.GetAwaiter().GetResult()
}
try {
  if (-not (Test-Path -LiteralPath $CoreDll -PathType Leaf) -or -not (Test-Path -LiteralPath $FormsDll -PathType Leaf) -or -not (Test-Path -LiteralPath (Join-Path $LoaderDir 'WebView2Loader.dll') -PathType Leaf)) {
    Log ('WebView2 SDK indiriliyor: ' + $SdkVersion)
    $tmp = Join-Path $env:TEMP ('KafePin-WebView2-' + [guid]::NewGuid().ToString('N'))
    $nupkg = $tmp + '.nupkg'; $zip = $tmp + '.zip'
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $SdkRoot) | Out-Null
    Invoke-WebRequest -UseBasicParsing -Uri $NugetUrl -OutFile $nupkg -TimeoutSec 90
    Copy-Item -LiteralPath $nupkg -Destination $zip -Force
    if (Test-Path -LiteralPath $SdkRoot) { Remove-Item -LiteralPath $SdkRoot -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $SdkRoot | Out-Null
    Expand-Archive -LiteralPath $zip -DestinationPath $SdkRoot -Force
    Remove-Item -LiteralPath $nupkg,$zip -Force -ErrorAction SilentlyContinue
  }
  $env:PATH = $LoaderDir + ';' + $env:PATH
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  Add-Type -Path $CoreDll
  Add-Type -Path $FormsDll
  try { $runtimeVersion=[Microsoft.Web.WebView2.Core.CoreWebView2Environment]::GetAvailableBrowserVersionString(); Log ('Runtime: '+$runtimeVersion) }
  catch {
    $bootstrapper=Join-Path $env:TEMP 'MicrosoftEdgeWebView2Setup.exe'
    Invoke-WebRequest -UseBasicParsing -Uri $RuntimeBootstrapperUrl -OutFile $bootstrapper -TimeoutSec 120
    $proc=Start-Process -FilePath $bootstrapper -ArgumentList @('/silent','/install') -Wait -PassThru
    Remove-Item $bootstrapper -Force -ErrorAction SilentlyContinue
    $runtimeVersion=[Microsoft.Web.WebView2.Core.CoreWebView2Environment]::GetAvailableBrowserVersionString(); Log ('Runtime kuruldu: '+$runtimeVersion+' exit='+$proc.ExitCode)
  }
  $ready=$false
  for($i=0;$i -lt 30;$i++){ try{$r=Invoke-RestMethod 'http://127.0.0.1:17891/api/health' -TimeoutSec 1;if($r.ok -and $r.version -eq '3.1.54-candidate2'){$ready=$true;break}}catch{};Start-Sleep -Milliseconds 300 }
  if(-not $ready){throw 'Yazici PRO 3.1.54 servisi hazir degil.'}

  [System.Windows.Forms.Application]::EnableVisualStyles()
  $form=New-Object System.Windows.Forms.Form; $form.Text='KafePin Yazıcı PRO 3.1.54 • WhatsApp Web'; $form.StartPosition='CenterScreen'; $form.WindowState='Maximized'; $form.MinimumSize=New-Object System.Drawing.Size(1000,700)
  $tabs=New-Object System.Windows.Forms.TabControl; $tabs.Dock=[System.Windows.Forms.DockStyle]::Fill; $tabs.Font=New-Object System.Drawing.Font('Segoe UI',11)
  $localTab=New-Object System.Windows.Forms.TabPage; $localTab.Text='🖨️ Yazıcı PRO'
  $waTab=New-Object System.Windows.Forms.TabPage; $waTab.Text='📲 WhatsApp Web'
  [void]$tabs.TabPages.Add($localTab); [void]$tabs.TabPages.Add($waTab); $form.Controls.Add($tabs)
  $localView=New-Object Microsoft.Web.WebView2.WinForms.WebView2; $localView.Dock=[System.Windows.Forms.DockStyle]::Fill
  $waView=New-Object Microsoft.Web.WebView2.WinForms.WebView2; $waView.Dock=[System.Windows.Forms.DockStyle]::Fill
  $localTab.Controls.Add($localView); $waTab.Controls.Add($waView)
  $form.Show(); [System.Windows.Forms.Application]::DoEvents()
  $profileDir=Join-Path $env:LOCALAPPDATA 'KafePinPro\WebView2Profile'; New-Item -ItemType Directory -Force -Path $profileDir | Out-Null
  $envTask=[Microsoft.Web.WebView2.Core.CoreWebView2Environment]::CreateAsync($null,$profileDir,$null); $sharedEnv=WaitTask $envTask
  WaitTask ($localView.EnsureCoreWebView2Async($sharedEnv)) | Out-Null
  WaitTask ($waView.EnsureCoreWebView2Async($sharedEnv)) | Out-Null
  $localView.CoreWebView2.Settings.IsWebMessageEnabled=$true
  $script:KafePinTabs=$tabs; $script:KafePinWhatsAppTab=$waTab
  $localView.CoreWebView2.add_WebMessageReceived({param($s,$e) try{if($e.TryGetWebMessageAsString() -eq 'open-whatsapp'){$script:KafePinTabs.SelectedTab=$script:KafePinWhatsAppTab}}catch{}})
  $waView.CoreWebView2.Settings.AreDefaultContextMenusEnabled=$true; $waView.CoreWebView2.Settings.AreDevToolsEnabled=$false
  $localView.Source=[Uri]$LocalUrl; $waView.Source=[Uri]'https://web.whatsapp.com/'
  Log 'Yazici PRO + WhatsApp Web ayni pencerede baslatildi.'
  [System.Windows.Forms.Application]::Run($form)
  exit 0
} catch { Fail $_.Exception.Message }
