
const HEDEF = 2000;
const VIP_MASALAR = [21,22,23];

const uiState = {
  pendingCount: 0,
  freeCount: 0,
  onlineCount: 0,
  readyCount: 0,
  problemCount: 0,
  bugunNet: 0,
  aktifMasaCount: 0,
  clientOnlineCount: 0,
  clientLastDataText: "-"
};

const refreshLocks = {
  fast: false,
  medium: false,
  slow: false
};

let intervalHandles = [];
let isEditingFee = false;
let isEditingStartTime = false;
let everyCafeManualSafety = { loaded:false, everyCafeEnabled:false, maintenanceEnabled:false };

function isEveryCafeManualLock(){
  return everyCafeManualSafety.everyCafeEnabled && !everyCafeManualSafety.maintenanceEnabled;
}

async function loadMaintenanceMode(){
  const d = await fetchJSON("/admin/maintenance-mode");
  if(!d || !d.ok) return;
  everyCafeManualSafety = {
    loaded:true,
    everyCafeEnabled: !!d.everyCafeEnabled,
    maintenanceEnabled: !!d.enabled
  };
  const text = document.getElementById("maintenanceModeText");
  const button = document.getElementById("maintenanceModeBtn");
  if(text){
    text.textContent = d.everyCafeEnabled
      ? (d.enabled ? "Bakım modu açık: manuel masa işlemleri geçici olarak kullanılabilir." : "EveryCafe aktif: Yeni Müşteri, Session Reset ve Tam Temizle kilitli.")
      : "EveryCafe aktarımı kapalı: manuel masa işlemleri normal şekilde kullanılabilir.";
  }
  if(button){
    button.textContent = d.enabled ? "BAKIM MODUNU KAPAT" : "BAKIM MODUNU AÇ";
    button.className = d.enabled ? "red" : "orange";
  }
}

async function toggleMaintenanceMode(){
  const willEnable = !everyCafeManualSafety.maintenanceEnabled;
  const message = willEnable
    ? "Bakım modu açılsın mı? EveryCafe açıkken yalnızca sorun gidermek için manuel masa işlemlerini kullan."
    : "Bakım modu kapatılsın mı? Manuel masa işlemleri yeniden kilitlenecek.";
  if(!confirm(message)) return;
  const d = await fetchJSON("/admin/maintenance-mode", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({enabled:willEnable})
  });
  if(!d || !d.ok){ alert((d && d.error) || "Bakım modu değiştirilemedi"); return; }
  await loadMaintenanceMode();
  await loadSessions();
}

function isPageHidden(){
  return document.hidden === true;
}

function runGuardedRefresh(key, fn){
  if(refreshLocks[key]) return;
  refreshLocks[key] = true;

  Promise.resolve()
    .then(fn)
    .catch(err => console.log("refresh error:", key, err))
    .finally(() => {
      refreshLocks[key] = false;
    });
}

function clearAllIntervals(){
  intervalHandles.forEach(id => clearInterval(id));
  intervalHandles = [];
}

function registerInterval(fn, ms){
  const id = setInterval(fn, ms);
  intervalHandles.push(id);
  return id;
}



function getPricingModeText(){
  return "Standart";
}

function formatAdjustAmount(v){
  return Number(v).toLocaleString("tr-TR", {
    minimumFractionDigits: Number(v) % 1 !== 0 ? 1 : 0,
    maximumFractionDigits: 2
  });
}

function renderDynamicPricingBadges(){
  const pricingEl = document.getElementById("pricingModeText");
  if(pricingEl) pricingEl.textContent = getPricingModeText();

  const adjEl = document.getElementById("adjustTextInline");
  if(adjEl) adjEl.textContent = "Manuel alana istediğiniz tutarı yazabilirsiniz";
}

function markRefresh(){
  const el = document.getElementById('lastRefreshText');
  if(el) el.textContent = new Date().toLocaleTimeString();
  renderDynamicPricingBadges();
}

function isVipMasa(masa){
  return VIP_MASALAR.includes(parseInt(masa,10));
}




function updateQuickSummary(){
const goalEl = document.getElementById("dailyGoalTop");
if(goalEl){
    const percent = Math.max(0, Math.round((uiState.bugunNet / HEDEF) * 100));
    goalEl.textContent = percent + "%";
    goalEl.className = percent >= 100 ? "statGreen" : "statOrange";
}
const pendingEl = document.getElementById("pendingCount");
if(pendingEl){
    pendingEl.textContent = uiState.pendingCount;
}
const readyEl = document.getElementById("readyCount");
if(readyEl){
    readyEl.textContent = uiState.readyCount;
}

}   // <-- BUNU EKLE

async function fetchJSON(url, options){
  try{
    const r = await fetch(url, { cache:"no-store", ...(options||{}) });
    const txt = await r.text();
    if(!r.ok) throw new Error("HTTP " + r.status + " " + txt.slice(0,120));
    return JSON.parse(txt);
  }catch(e){
    console.log("fetchJSON hata:", url, e);
    return null;
  }
}

let rolloverNextTs = 0;

function formatRolloverDate(ts){
  const n = Number(ts);
  if(!n) return "-";
  return new Date(n).toLocaleString("tr-TR", {
    day:"2-digit", month:"2-digit", year:"numeric",
    hour:"2-digit", minute:"2-digit", second:"2-digit"
  });
}

function updateRolloverCountdown(){
  const el = document.getElementById("rolloverCountdown");
  if(!el || !rolloverNextTs) return;
  const totalSeconds = Math.floor(Math.max(0, rolloverNextTs - Date.now()) / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  el.textContent = `Sonraki devire: ${hours}sa ${minutes}dk ${seconds}sn`;
}

async function loadRolloverStatus(){
  const d = await fetchJSON("/admin/rollover-status");
  const strip = document.getElementById("rolloverStrip");
  const summary = document.getElementById("rolloverSummary");
  if(!strip || !summary) return;

  if(!d || !d.ok){
    strip.classList.add("error");
    summary.textContent = "Devir bilgisi alınamadı";
    document.getElementById("rolloverTelegram").textContent = "Telegram: bilinmiyor";
    return;
  }

  rolloverNextTs = Number(d.nextRolloverTs) || 0;
  updateRolloverCountdown();
  const last = d.last;

  if(!last){
    strip.classList.remove("error");
    summary.textContent = "Henüz kayıtlı gün devri yok";
    document.getElementById("rolloverTables").textContent = "Devreden: -";
    document.getElementById("rolloverRevenue").textContent = "Eski gün cirosu: -";
    document.getElementById("rolloverTelegram").textContent = "Telegram: -";
    document.getElementById("rolloverClosed").style.display = "none";
    return;
  }

  const success = last.status === "success";
  strip.classList.toggle("error", !success);
  summary.textContent = success
    ? `Başarılı • ${formatRolloverDate(last.rolloverTs)}`
    : `Hata • ${formatRolloverDate(last.rolloverTs)}${last.error ? " • " + last.error : ""}`;

  const tables = Array.isArray(last.onlineMasalar) ? last.onlineMasalar : [];
  document.getElementById("rolloverTables").textContent =
    tables.length ? `Devreden ${tables.length} masa: ${tables.join(", ")}` : "Devreden masa: yok";
  const previousMasaRevenue = Number(last.previousDayMasaRevenue);
  const previousProductRevenue = Number(last.previousDayProductRevenue);
  const previousRevenue = Number(last.previousDayRevenue) || 0;
  document.getElementById("rolloverRevenue").textContent =
    Number.isFinite(previousMasaRevenue) && Number.isFinite(previousProductRevenue)
      ? `Eski gün cirosu: ${previousRevenue.toFixed(2)} ₺ (Masa ${previousMasaRevenue.toFixed(2)} ₺ + Ürün ${previousProductRevenue.toFixed(2)} ₺)`
      : `Eski gün cirosu: ${previousRevenue.toFixed(2)} ₺`;
  const telegramText = last.telegramSent || last.telegramStatus === "sent"
    ? "gönderildi"
    : last.telegramStatus === "pending"
      ? "gönderiliyor..."
      : last.telegramStatus === "disabled"
        ? "kapalı"
        : "gönderilemedi";
  document.getElementById("rolloverTelegram").textContent = `Telegram: ${telegramText}`;

  const closedEl = document.getElementById("rolloverClosed");
  const closed = Array.isArray(last.closedMasalar) ? last.closedMasalar : [];
  if(closedEl && closed.length){
    closedEl.style.display = "inline-block";
    closedEl.textContent = closed.map((item) => {
      const closedTime = item.closedAt
        ? new Date(Number(item.closedAt)).toLocaleTimeString("tr-TR", {hour:"2-digit", minute:"2-digit"})
        : "-";
      const hasProductBreakdown = Number.isFinite(Number(item.beforeProduct)) || Number.isFinite(Number(item.afterProduct));
      const before = (hasProductBreakdown ? Number(item.beforeTotal) : Number(item.beforeFee)) || 0;
      const after = (hasProductBreakdown ? Number(item.afterTotal) : Number(item.afterFee)) || 0;
      const total = (hasProductBreakdown ? Number(item.totalWithProducts) : Number(item.totalFee)) || 0;
      const productNote = hasProductBreakdown
        ? ` (Ürün: ${((Number(item.beforeProduct) || 0) + (Number(item.afterProduct) || 0)).toFixed(2)} ₺)`
        : "";
      return `Masa ${item.masa} kapandı ${closedTime} • Eski ${before.toFixed(2)} ₺ + Yeni ${after.toFixed(2)} ₺ = ${total.toFixed(2)} ₺${productNote}`;
    }).join(" | ");
  }else if(closedEl){
    closedEl.style.display = "none";
    closedEl.textContent = "";
  }
}

async function loadDiagnostics(){

  const d = await fetchJSON("/admin/diagnostics");

  const box = document.getElementById("diagnosticsBox");

  if(!d || !d.ok){
    box.innerHTML="<span class='statRed'>Tanı bilgisi alınamadı.</span>";
    return;
  }

  const sync =
    d.ramSessions === d.dbSessions;

  box.innerHTML = `
    <span class="liveChip">🧠 RAM <b>${d.ramSessions}</b></span>
    <span class="liveChip">🗄️ DB <b>${d.dbSessions}</b></span>
    <span class="liveChip">🧹 Cleanup <b>${d.cleanupCount}</b></span>
    <span class="liveChip">✅ Finalize <b>${d.finalizeCount}</b></span>
    <span class="liveChip">📴 Offline kapanış <b>${d.offlineCloseCount}</b></span>
    <span class="liveChip">🔄 RAM / DB <b class="${sync ? "statGreen":"statRed"}">${sync ? "OK":"UYARI"}</b></span>
    <span class="liveChip">📡 Son ping <b>${fmtTime(d.lastPing)}</b></span>
    <span class="liveChip">🧹 Son cleanup <b>Masa ${d.lastCleanupMasa ?? "-"}</b></span>
    <span class="liveChip">✅ Son finalize <b>Masa ${d.lastFinalizeMasa ?? "-"}</b></span>
  `;
}
let lastDailyReportForPrint = null;

async function loadDailyReport(){

    const box = document.getElementById("dailyReport");

    if(!box) return;

   let d = await fetchJSON("/admin/daily-report");

if(!d || !d.report_date){

    d = {
        report_date:"-",
        gercek_gelir:0,
        product_geliri:0,
        product_adedi:0,
        genel_gelir:0,
        nakit_odeme:0,
        kart_odeme:0,
        bekleyen_odeme:0,
        bekleyen_adet:0,
        giderler:0,
        kart_komisyonu:0,
        net_isletme_sonucu:0,
        brut_gelir:0,
        spin_maliyeti:0,
        total_spins:0,
        admin_duzeltmeleri:0,
        ortalama_masa_geliri:0,
        top_reward:"-",
        top_reward_count:0,
        top_masa:"-",
        top_masa_count:0,
        top_revenue_masa:"-",
        reward_list:[]
    };

}

    const rewards = Array.isArray(d.reward_list)
        ? d.reward_list
        : [];
let reportDateText = "-";

if (d.report_ts) {
  reportDateText = new Intl.DateTimeFormat("tr-TR", {
    timeZone: "Europe/Istanbul",
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric"
  }).format(new Date(Number(d.report_ts)));
} else if (d.report_date && d.report_date !== "-") {
  const parts = String(d.report_date).split("-");

  if (parts.length === 3) {
    const localDate = new Date(
      Number(parts[0]),
      Number(parts[1]) - 1,
      Number(parts[2])
    );

    reportDateText = new Intl.DateTimeFormat("tr-TR", {
      weekday: "long",
      day: "2-digit",
      month: "long",
      year: "numeric"
    }).format(localDate);
  }
}
const reportReady = d.report_date && d.report_date !== "-";
lastDailyReportForPrint = {...d, reportDateText, reportReady, rewards};
box.innerHTML = `

<div style="
display:flex;
justify-content:space-between;
align-items:center;
background:#262626;
border:1px solid #444;
border-radius:12px;
padding:14px 18px;
margin-bottom:20px;
font-size:16px;
">

<div>
📅 <b>Son Gün Sonu Raporu</b><br>
<span style="font-size:14px;color:#bbb;">
${escapeHtml(reportDateText)}
</span>
</div>

<div style="text-align:right;">

<div style="
display:inline-block;
padding:6px 12px;
border-radius:20px;
font-size:13px;
font-weight:bold;
background:${reportReady ? "#1f5f33" : "#5f3b1f"};
color:white;
margin-bottom:8px;
">
${reportReady ? "✅ RAPOR HAZIR" : "⏳ RAPOR BEKLENİYOR"}
</div>

<br>

🕖 <b>${escapeHtml(d.created_at || "19:59")}</b>

</div>

</div>

<div class="daily-grid">

            <div class="daily-card">
                <div class="daily-title">🖥️ Masa Gerçek Geliri</div>
                <div class="daily-value daily-green">
                    ${money(d.gercek_gelir)}
                </div>
            </div>

            <div class="daily-card">
                <div class="daily-title">☕ Ürün/Hizmet Geliri</div>
                <div class="daily-value daily-blue">${money(d.product_geliri)}</div>
                <div class="small">${Number(d.product_adedi) || 0} adet</div>
            </div>

            <div class="daily-card">
                <div class="daily-title">💰 Genel Gelir</div>
                <div class="daily-value daily-green">${money(d.genel_gelir)}</div>
            </div>

            <div class="daily-card">
                <div class="daily-title">💵 Nakit</div>
                <div class="daily-value daily-green">${money(d.nakit_odeme)}</div>
            </div>

            <div class="daily-card">
                <div class="daily-title">💳 Kart</div>
                <div class="daily-value daily-blue">${money(d.kart_odeme)}</div>
            </div>

            <div class="daily-card">
                <div class="daily-title">⏳ Bekleyen Ödeme</div>
                <div class="daily-value ${Number(d.bekleyen_odeme) > 0 ? 'statRed' : 'daily-green'}">${money(d.bekleyen_odeme)}</div>
                <div class="small">${Number(d.bekleyen_adet) || 0} hesap</div>
            </div>

            <div class="daily-card">
                <div class="daily-title">🧾 Giderler</div>
                <div class="daily-value statRed">${money(d.giderler)}</div>
            </div>

            <div class="daily-card">
                <div class="daily-title">🏦 Kart Komisyonu (%1,87)</div>
                <div class="daily-value daily-orange">${money(d.kart_komisyonu)}</div>
            </div>

            <div class="daily-card">
                <div class="daily-title">📈 Net İşletme Sonucu</div>
                <div class="daily-value ${Number(d.net_isletme_sonucu) >= 0 ? 'daily-green' : 'statRed'}">${money(d.net_isletme_sonucu)}</div>
            </div>

            <div class="daily-card">
                <div class="daily-title">💵 Brüt Gelir</div>
                <div class="daily-value daily-blue">
                    ${money(d.brut_gelir)}
                </div>
            </div>

            <div class="daily-card">
                <div class="daily-title">🎁 Spin Maliyeti</div>
                <div class="daily-value daily-orange">
                    ${money(d.spin_maliyeti)}
                </div>
            </div>

            <div class="daily-card">
                <div class="daily-title">🎰 Toplam Spin</div>
                <div class="daily-value daily-purple">
                    ${d.total_spins || 0}
                </div>
            </div>

        </div>

        <div class="daily-info">

            <div class="daily-box">

                <h4>📋 Genel Bilgiler</h4>

                <p><b>📅 Rapor Tarihi:</b> ${escapeHtml(reportDateText)}</p>

<p><b>🕖 Oluşturulma:</b> ${escapeHtml(d.created_at || "19:59")}</p>

                <p><b>🛠 Admin Düzeltmeleri:</b> ${money(d.admin_duzeltmeleri)}</p>

                <p><b>📊 Ortalama Masa Geliri:</b> ${money(d.ortalama_masa_geliri)}</p>

            </div>

            <div class="daily-box">

                <h4>🏆 Günün Rekorları</h4>

                <p><b>🎁 En Çok Çıkan Ödül:</b>
                ${escapeHtml(d.top_reward || "-")}
                (${d.top_reward_count || 0})
                </p>

                <p><b>🖥 En Yoğun Masa:</b>
                ${d.top_masa || "-"}
                (${d.top_masa_count || 0})
                </p>

                <p><b>💰 En Çok Kazandıran:</b>
                ${escapeHtml(d.top_revenue_masa || "-")}
                </p>

            </div>

        </div>

        <table class="rewardTable">

            <tr>
                <th>Ödül</th>
                <th>Adet</th>
            </tr>

            ${
                rewards.length
                ? rewards.map(r=>`
                    <tr>
                        <td>${escapeHtml(r.reward)}</td>
                        <td>${r.count}</td>
                    </tr>
                `).join("")
                : `<tr>
                     <td colspan="2">
                        Bugün ödül kaydı yok.
                     </td>
                   </tr>`
            }

        </table>
<div style="
margin-top:18px;
padding:14px;
border-radius:10px;
background:#1f1f1f;
border:1px solid #333;
text-align:center;
font-size:15px;
line-height:1.8;
">

📊 <b>Günün Özeti</b><br><br>

💰 Gerçek Gelir:
<b class="daily-green">${money(d.gercek_gelir)}</b>

&nbsp;&nbsp;|&nbsp;&nbsp;

🎰 Toplam Spin:
<b class="daily-purple">${d.total_spins || 0}</b>

&nbsp;&nbsp;|&nbsp;&nbsp;

🏆 En Yoğun Masa:
<b>${d.top_masa || "-"}</b>

&nbsp;&nbsp;|&nbsp;&nbsp;

🎁 En Çok Çıkan Ödül:
<b>${escapeHtml(d.top_reward || "-")}</b>

</div>
    `;
}

function printGeneralReport(){
  const d = lastDailyReportForPrint;
  if(!d){ alert("Rapor yuklenmedi. Biraz sonra tekrar dene."); return; }
  const printWindow = window.open("", "kafepin_general_report", "width=1000,height=800");
  if(!printWindow){ alert("Rapor penceresi acilamadi. Acilir pencere engelini kapatip tekrar dene."); return; }
  const value = (v) => Number(v || 0).toLocaleString("tr-TR", {minimumFractionDigits:0, maximumFractionDigits:2}) + " TL";
  const text = (v) => escapeHtml(v == null ? "-" : String(v));
  const rows = [
    ["Masa gercek geliri", value(d.gercek_gelir)],
    ["Urun / hizmet geliri", `${value(d.product_geliri)} (${Number(d.product_adedi) || 0} adet)`],
    ["Genel ciro", value(d.genel_gelir)],
    ["Nakit tahsilat", value(d.nakit_odeme)],
    ["Kart tahsilat", value(d.kart_odeme)],
    ["Bekleyen odeme", `${value(d.bekleyen_odeme)} (${Number(d.bekleyen_adet) || 0} hesap)`],
    ["Giderler", value(d.giderler)],
    ["Kart komisyonu", value(d.kart_komisyonu)],
    ["Net isletme sonucu", value(d.net_isletme_sonucu)],
    ["Brut masa geliri", value(d.brut_gelir)],
    ["Cark maliyeti", value(d.spin_maliyeti)],
    ["Toplam spin", String(Number(d.total_spins) || 0)],
    ["Admin duzeltmeleri", value(d.admin_duzeltmeleri)],
    ["Ortalama masa geliri", value(d.ortalama_masa_geliri)]
  ];
  const rewards = Array.isArray(d.rewards) ? d.rewards : [];
  const rewardRows = rewards.map(r => `<tr><td>${text(r.reward)}</td><td>${Number(r.count) || 0}</td></tr>`).join("") || '<tr><td colspan="2">Odul kaydi yok.</td></tr>';
  printWindow.document.open();
  printWindow.document.write(`<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>KafePin Genel Rapor</title><style>
    @page{size:A4;margin:13mm}*{box-sizing:border-box}body{font-family:Arial,Helvetica,sans-serif;color:#151515;font-size:12px;margin:0}h1{font-size:23px;margin:0 0 3px;color:#173f78}h2{font-size:15px;margin:22px 0 8px;color:#173f78;border-bottom:1px solid #b9c7d8;padding-bottom:5px}.meta{color:#555;margin-bottom:16px}.summary{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}.summary div{border:1px solid #c7d3df;border-radius:7px;padding:10px;background:#f5f8fb}.summary b{display:block;font-size:16px;color:#146a38;margin-top:4px}table{width:100%;border-collapse:collapse;margin-top:8px}th{background:#173f78;color:#fff;text-align:left;padding:8px}td{padding:7px 8px;border-bottom:1px solid #d8e0e8}td:last-child{text-align:right;font-weight:bold}.footer{margin-top:22px;padding-top:8px;border-top:1px solid #c7d3df;color:#666;font-size:10px}@media print{body{print-color-adjust:exact;-webkit-print-color-adjust:exact}}
  </style></head><body><h1>KAFEPIN - GENEL GUNLUK RAPOR</h1><div class="meta"><b>Kafe gunu:</b> ${text(d.reportDateText)} &nbsp; | &nbsp; <b>Rapor saati:</b> ${text(d.created_at || "-")}</div>
  <div class="summary"><div>GENEL CIRO<b>${value(d.genel_gelir)}</b></div><div>NET ISLETME SONUCU<b>${value(d.net_isletme_sonucu)}</b></div><div>BEKLEYEN ODEME<b>${value(d.bekleyen_odeme)}</b></div></div>
  <h2>Gelir, Tahsilat ve Gider Ozeti</h2><table><thead><tr><th>Kalem</th><th>Tutar / Bilgi</th></tr></thead><tbody>${rows.map(([label,val]) => `<tr><td>${text(label)}</td><td>${text(val)}</td></tr>`).join("")}</tbody></table>
  <h2>Gun Rekorlari</h2><table><tbody><tr><td>En cok kazandiran masa</td><td>${text(d.top_revenue_masa)}</td></tr><tr><td>En yogun masa</td><td>${text(d.top_masa)} (${Number(d.top_masa_count) || 0})</td></tr><tr><td>En cok cikan odul</td><td>${text(d.top_reward)} (${Number(d.top_reward_count) || 0})</td></tr></tbody></table>
  <h2>Cikan Oduller</h2><table><thead><tr><th>Odul</th><th>Adet</th></tr></thead><tbody>${rewardRows}</tbody></table><div class="footer">KafePin tarafindan olusturuldu. Yazdirma ekranindan PDF olarak kaydedilebilir.</div></body></html>`);
  printWindow.document.close(); printWindow.focus(); setTimeout(()=> printWindow.print(), 300);
}

function getIstanbulMonthValue(){
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone:"Europe/Istanbul", year:"numeric", month:"2-digit"
  }).formatToParts(new Date());
  const value = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${value.year}-${value.month}`;
}

async function printMonthlyReport(){
  const monthInput = document.getElementById("monthlyReportMonth");
  const month = monthInput && monthInput.value ? monthInput.value : getIstanbulMonthValue();
  if(monthInput && !monthInput.value) monthInput.value = month;
  const data = await fetchJSON(`/admin/monthly-report?month=${encodeURIComponent(month)}`);
  if(!data || !data.ok || !data.stats){
    alert((data && data.error) || "Bu ay için rapor verisi bulunamadı.");
    return;
  }
  const d = data.stats;
  const date = new Date(Number(data.startTs) || Date.now());
  const monthText = new Intl.DateTimeFormat("tr-TR", {timeZone:"Europe/Istanbul", month:"long", year:"numeric"}).format(date);
  const printWindow = window.open("", "kafepin_monthly_report", "width=1000,height=800");
  if(!printWindow){ alert("Rapor penceresi acilamadi. Acilir pencere engelini kapatip tekrar dene."); return; }
  const value = (v) => Number(v || 0).toLocaleString("tr-TR", {minimumFractionDigits:0, maximumFractionDigits:2}) + " TL";
  const text = (v) => escapeHtml(v == null ? "-" : String(v));
  const rows = [
    ["Masa gercek geliri", value(d.gercekGelir)],
    ["Urun / hizmet geliri", `${value(d.productGeliri)} (${Number(d.productAdedi) || 0} adet)`],
    ["Genel ciro", value(d.genelGelir)],
    ["Nakit tahsilat", value(d.nakitOdeme)],
    ["Kart tahsilat", value(d.kartOdeme)],
    ["Bekleyen odeme", `${value(d.bekleyenOdeme)} (${Number(d.bekleyenAdet) || 0} hesap)`],
    ["Giderler", value(d.giderler)],
    ["Gercek kart komisyonu", value(d.kartKomisyonu)],
    ["Net isletme sonucu", value(d.netIsletmeSonucu)],
    ["Brut masa geliri", value(d.brutGelir)],
    ["Cark maliyeti", value(d.spinMaliyeti)],
    ["Toplam spin", String(Number(d.totalSpins) || 0)],
    ["Onaylanan odul", String(Number(d.usedRewards) || 0)],
    ["Admin duzeltmeleri", value(d.adminDuzeltmeleri)],
    ["Ortalama masa geliri", value(d.ortalamaMasaGeliri)]
  ];
  const rewardRows = (Array.isArray(d.rewardList) ? d.rewardList : []).map(r => `<tr><td>${text(r.reward)}</td><td>${Number(r.adet) || 0}</td></tr>`).join("") || '<tr><td colspan="2">Odul kaydi yok.</td></tr>';
  printWindow.document.open();
  printWindow.document.write(`<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>KafePin Aylik Rapor</title><style>
    @page{size:A4;margin:13mm}*{box-sizing:border-box}body{font-family:Arial,Helvetica,sans-serif;color:#151515;font-size:12px;margin:0}h1{font-size:23px;margin:0 0 3px;color:#173f78}h2{font-size:15px;margin:22px 0 8px;color:#173f78;border-bottom:1px solid #b9c7d8;padding-bottom:5px}.meta{color:#555;margin-bottom:16px}.summary{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}.summary div{border:1px solid #c7d3df;border-radius:7px;padding:10px;background:#f5f8fb}.summary b{display:block;font-size:16px;color:#146a38;margin-top:4px}table{width:100%;border-collapse:collapse;margin-top:8px}th{background:#173f78;color:#fff;text-align:left;padding:8px}td{padding:7px 8px;border-bottom:1px solid #d8e0e8}td:last-child{text-align:right;font-weight:bold}.footer{margin-top:22px;padding-top:8px;border-top:1px solid #c7d3df;color:#666;font-size:10px}@media print{body{print-color-adjust:exact;-webkit-print-color-adjust:exact}}
  </style></head><body><h1>KAFEPIN - AYLIK RAPOR</h1><div class="meta"><b>Donem:</b> ${text(monthText)}${data.partial ? " (su ana kadar)" : ""} &nbsp; | &nbsp; <b>Kafe gunu siniri:</b> 20:00 - 20:00</div>
  <div class="summary"><div>GENEL CIRO<b>${value(d.genelGelir)}</b></div><div>NET ISLETME SONUCU<b>${value(d.netIsletmeSonucu)}</b></div><div>BEKLEYEN ODEME<b>${value(d.bekleyenOdeme)}</b></div></div>
  <h2>Gelir, Tahsilat ve Gider Ozeti</h2><table><thead><tr><th>Kalem</th><th>Tutar / Bilgi</th></tr></thead><tbody>${rows.map(([label,val]) => `<tr><td>${text(label)}</td><td>${text(val)}</td></tr>`).join("")}</tbody></table>
  <h2>Ay Rekorlari</h2><table><tbody><tr><td>En cok kazandiran masa</td><td>${text(d.topRevenueMasaText)}</td></tr><tr><td>En yogun masa</td><td>${text(d.topMasa && d.topMasa.masa)} (${Number(d.topMasa && d.topMasa.adet) || 0})</td></tr><tr><td>En cok cikan odul</td><td>${text(d.topReward && d.topReward.reward)} (${Number(d.topReward && d.topReward.adet) || 0})</td></tr></tbody></table>
  <h2>Cikan Oduller</h2><table><thead><tr><th>Odul</th><th>Adet</th></tr></thead><tbody>${rewardRows}</tbody></table><div class="footer">KafePin tarafindan olusturuldu. Yazdirma ekranindan PDF olarak kaydedilebilir.</div></body></html>`);
  printWindow.document.close(); printWindow.focus(); setTimeout(()=> printWindow.print(), 300);
}

function getIstanbulYear(){
  return Number(new Intl.DateTimeFormat("en-CA", {
    timeZone:"Europe/Istanbul", year:"numeric"
  }).format(new Date()));
}

async function printYearlyReport(){
  const yearInput = document.getElementById("yearlyReportYear");
  const year = Number(yearInput && yearInput.value) || getIstanbulYear();
  if(yearInput && !yearInput.value) yearInput.value = year;
  if(year < 2020 || year > 2100){ alert("Geçerli bir yıl seç."); return; }
  const data = await fetchJSON(`/admin/yearly-report?year=${encodeURIComponent(year)}`);
  if(!data || !data.ok || !data.stats){
    alert((data && data.error) || "Bu yıl için rapor verisi bulunamadı.");
    return;
  }
  const d = data.stats;
  const printWindow = window.open("", "kafepin_yearly_report", "width=1000,height=800");
  if(!printWindow){ alert("Rapor penceresi açılamadı. Açılır pencere engelini kapatıp tekrar dene."); return; }
  const value = (v) => Number(v || 0).toLocaleString("tr-TR", {minimumFractionDigits:0, maximumFractionDigits:2}) + " TL";
  const text = (v) => escapeHtml(v == null ? "-" : String(v));
  const rows = [
    ["Masa gerçek geliri", value(d.gercekGelir)],
    ["Ürün / hizmet geliri", `${value(d.productGeliri)} (${Number(d.productAdedi) || 0} adet)`],
    ["Genel ciro", value(d.genelGelir)],
    ["Nakit tahsilat", value(d.nakitOdeme)],
    ["Kart tahsilat", value(d.kartOdeme)],
    ["Bekleyen ödeme", `${value(d.bekleyenOdeme)} (${Number(d.bekleyenAdet) || 0} hesap)`],
    ["Giderler", value(d.giderler)],
    ["Gerçek kart komisyonu", value(d.kartKomisyonu)],
    ["Net işletme sonucu", value(d.netIsletmeSonucu)],
    ["Brüt masa geliri", value(d.brutGelir)],
    ["Çark maliyeti", value(d.spinMaliyeti)],
    ["Toplam spin", String(Number(d.totalSpins) || 0)],
    ["Onaylanan ödül", String(Number(d.usedRewards) || 0)],
    ["Admin düzeltmeleri", value(d.adminDuzeltmeleri)],
    ["Ortalama masa geliri", value(d.ortalamaMasaGeliri)]
  ];
  printWindow.document.open();
  printWindow.document.write(`<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>KafePin Yıllık Rapor</title><style>
    @page{size:A4;margin:13mm}*{box-sizing:border-box}body{font-family:Arial,Helvetica,sans-serif;color:#151515;font-size:12px;margin:0}h1{font-size:23px;margin:0 0 3px;color:#173f78}h2{font-size:15px;margin:22px 0 8px;color:#173f78;border-bottom:1px solid #b9c7d8;padding-bottom:5px}.meta{color:#555;margin-bottom:16px}.summary{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}.summary div{border:1px solid #c7d3df;border-radius:7px;padding:10px;background:#f5f8fb}.summary b{display:block;font-size:16px;color:#146a38;margin-top:4px}table{width:100%;border-collapse:collapse;margin-top:8px}th{background:#173f78;color:#fff;text-align:left;padding:8px}td{padding:7px 8px;border-bottom:1px solid #d8e0e8}td:last-child{text-align:right;font-weight:bold}.footer{margin-top:22px;padding-top:8px;border-top:1px solid #c7d3df;color:#666;font-size:10px}@media print{body{print-color-adjust:exact;-webkit-print-color-adjust:exact}}
  </style></head><body><h1>KAFEPIN - YILLIK RAPOR</h1><div class="meta"><b>Dönem:</b> ${text(year)}${data.partial ? " (şu ana kadar)" : ""} &nbsp; | &nbsp; <b>Kafe günü sınırı:</b> 20:00 - 20:00</div>
  <div class="summary"><div>GENEL CIRO<b>${value(d.genelGelir)}</b></div><div>NET İŞLETME SONUCU<b>${value(d.netIsletmeSonucu)}</b></div><div>BEKLEYEN ÖDEME<b>${value(d.bekleyenOdeme)}</b></div></div>
  <h2>Gelir, Tahsilat ve Gider Özeti</h2><table><thead><tr><th>Kalem</th><th>Tutar / Bilgi</th></tr></thead><tbody>${rows.map(([label,val]) => `<tr><td>${text(label)}</td><td>${text(val)}</td></tr>`).join("")}</tbody></table>
  <h2>Yıl Rekorları</h2><table><tbody><tr><td>En çok kazandıran masa</td><td>${text(d.topRevenueMasaText)}</td></tr><tr><td>En yoğun masa</td><td>${text(d.topMasa && d.topMasa.masa)} (${Number(d.topMasa && d.topMasa.adet) || 0})</td></tr><tr><td>En çok çıkan ödül</td><td>${text(d.topReward && d.topReward.reward)} (${Number(d.topReward && d.topReward.adet) || 0})</td></tr></tbody></table><div class="footer">KafePin tarafından oluşturuldu. Yazdırma ekranından PDF olarak kaydedilebilir.</div></body></html>`);
  printWindow.document.close(); printWindow.focus(); setTimeout(()=> printWindow.print(), 300);
}

function getIstanbulDateValue(){
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone:"Europe/Istanbul", year:"numeric", month:"2-digit", day:"2-digit"
  }).formatToParts(new Date());
  const value = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${value.year}-${value.month}-${value.day}`;
}

async function printFinancialRangeReport(){
  const startInput = document.getElementById("financialReportStart");
  const endInput = document.getElementById("financialReportEnd");
  const today = getIstanbulDateValue();
  const start = startInput && startInput.value ? startInput.value : today;
  const end = endInput && endInput.value ? endInput.value : start;
  if(startInput && !startInput.value) startInput.value = start;
  if(endInput && !endInput.value) endInput.value = end;
  if(end < start){ alert("Bitiş tarihi başlangıçtan önce olamaz."); return; }
  const data = await fetchJSON(`/admin/financial-range-report?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`);
  if(!data || !data.ok || !data.stats){
    alert((data && data.error) || "Mali rapor oluşturulamadı.");
    return;
  }
  const d = data.stats;
  const vat = data.vat || {};
  const vat20 = vat.rate20 || {};
  const vat10 = vat.rate10 || {};
  const printWindow = window.open("", "kafepin_financial_report", "width=1000,height=800");
  if(!printWindow){ alert("Rapor penceresi açılamadı. Açılır pencere engelini kapatıp tekrar dene."); return; }
  const moneyText = (v) => Number(v || 0).toLocaleString("tr-TR", {minimumFractionDigits:2, maximumFractionDigits:2}) + " TL";
  const text = (v) => escapeHtml(v == null ? "-" : String(v));
  const line = (name, value, strong=false) => `<div class="line${strong ? " strong" : ""}"><span>${text(name)}</span><b>${text(value)}</b></div>`;
  printWindow.document.open();
  printWindow.document.write(`<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>KafePin Mali Rapor</title><style>
    @page{size:A4 portrait;margin:8mm}*{box-sizing:border-box}body{width:auto;margin:0;color:#151515;background:#fff;font-family:Arial,Helvetica,sans-serif;font-size:10px;font-weight:700}.center{text-align:center}.title{font-size:21px;font-weight:900;margin:3px 0}.small{font-size:9px;font-weight:700;color:#555}.rule{border-top:1px solid #aebdcb;margin:8px 0}.section{font-size:12px;font-weight:900;color:#173f78;margin:8px 0 4px;border-bottom:1px solid #b9c7d8;padding-bottom:4px}.line{display:grid;grid-template-columns:minmax(0,1fr) 155px;gap:12px;align-items:baseline;margin:0;border-bottom:1px solid #e0e6ec;padding:4px 7px;min-height:20px}.line:nth-child(even){background:#f5f8fb}.line span{min-width:0;font-weight:800}.line b{text-align:right;white-space:nowrap;font-size:10px;font-weight:900}.strong{font-size:11px;font-weight:900;background:#eaf3ec!important;border:1px solid #a7c7ac;margin-top:3px}.strong b{font-size:11px}.footer{text-align:center;font-size:9px;font-weight:700;color:#666;margin-top:10px}@media print{body{print-color-adjust:exact;-webkit-print-color-adjust:exact}}
  </style></head><body><div class="center"><div class="title">KAFEPIN</div><b>MALI RAPOR</b><div class="small">${text(data.startLabel)} 00:00 — ${text(data.endLabel)} 23:59</div><div class="small">Yazdırma: ${text(new Date().toLocaleString("tr-TR"))}</div></div><div class="rule"></div>
  <div class="section">GELIR</div>${line("Oturum geliri", moneyText(d.gercekGelir))}${line("Urun / hizmet", moneyText(d.productGeliri))}${line("Urun adedi", String(Number(d.productAdedi) || 0))}${line("GENEL CIRO", moneyText(d.genelGelir), true)}
  <div class="rule"></div><div class="section">KDV OZETI (DAHIL)</div>${line("%20 matrah", moneyText(vat20.matrah))}${line("%20 KDV", moneyText(vat20.kdv))}${line("%20 toplam", moneyText(vat20.toplam))}${line("%10 matrah", moneyText(vat10.matrah))}${line("%10 KDV", moneyText(vat10.kdv))}${line("%10 toplam", moneyText(vat10.toplam))}${line("TOPLAM KDV", moneyText(vat.toplamKdv), true)}
  <div class="rule"></div><div class="section">TAHSILAT</div>${line("Nakit", moneyText(d.nakitOdeme))}${line("Kart", moneyText(d.kartOdeme))}${line("Bekleyen", moneyText(d.bekleyenOdeme))}${line("Bekleyen hesap", String(Number(d.bekleyenAdet) || 0))}
  <div class="rule"></div><div class="section">GIDER VE SONUC</div>${line("Giderler", moneyText(d.giderler))}${line("Kart komisyonu", moneyText(d.kartKomisyonu))}${line("Cark maliyeti", moneyText(d.spinMaliyeti))}${line("NET ISLETME SONUCU", moneyText(d.netIsletmeSonucu), true)}
  <div class="rule"></div><div class="section">DIGER</div>${line("Toplam spin", String(Number(d.totalSpins) || 0))}${line("Onaylanan odul", String(Number(d.usedRewards) || 0))}${line("Admin duzeltmesi", moneyText(d.adminDuzeltmeleri))}${line("Ort. masa geliri", moneyText(d.ortalamaMasaGeliri))}
  <div class="rule"></div><div class="footer">Takvim günü hesabı 00:00 — 23:59<br>KafePin tarafından oluşturuldu</div></body></html>`);
  printWindow.document.close();
  printWindow.addEventListener("afterprint", () => printWindow.close(), {once:true});
  printWindow.focus();
  setTimeout(()=> printWindow.print(), 300);
}

async function printProfitLossReport(){
  const startInput = document.getElementById("financialReportStart");
  const endInput = document.getElementById("financialReportEnd");
  const today = getIstanbulDateValue();
  const start = startInput && startInput.value ? startInput.value : today;
  const end = endInput && endInput.value ? endInput.value : start;
  if(end < start){ alert("Bitiş tarihi başlangıçtan önce olamaz."); return; }
  const data = await fetchJSON(`/admin/financial-range-report?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`);
  if(!data || !data.ok || !data.stats){
    alert((data && data.error) || "Kâr / zarar raporu oluşturulamadı.");
    return;
  }
  const d = data.stats;
  const toplamGelir = (Number(d.gercekGelir) || 0) + (Number(d.productGeliri) || 0);
  const giderToplami = (Number(d.giderler) || 0) + (Number(d.kartKomisyonu) || 0);
  const net = Number(d.netIsletmeSonucu) || 0;
  const printWindow = window.open("", "kafepin_profit_loss_report", "width=900,height=720");
  if(!printWindow){ alert("Rapor penceresi açılamadı. Açılır pencere engelini kapatıp tekrar dene."); return; }
  const moneyText = (v) => Number(v || 0).toLocaleString("tr-TR", {minimumFractionDigits:2, maximumFractionDigits:2}) + " TL";
  const text = (v) => escapeHtml(v == null ? "-" : String(v));
  const row = (name, value, type="") => `<tr class="${type}"><td>${text(name)}</td><td>${text(value)}</td></tr>`;
  printWindow.document.open();
  printWindow.document.write(`<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>KafePin Kâr Zarar Raporu</title><style>
    @page{size:A4 portrait;margin:18mm}*{box-sizing:border-box}body{font-family:Arial,Helvetica,sans-serif;color:#151515;margin:0;font-size:13px;font-weight:700}h1{margin:0;color:#173f78;font-size:26px}.meta{margin:6px 0 20px;color:#555}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.box{border:1px solid #cbd6e0;border-radius:8px;padding:14px}.box h2{font-size:15px;color:#173f78;margin:0 0 10px;border-bottom:1px solid #d6e0e9;padding-bottom:6px}table{width:100%;border-collapse:collapse}td{padding:9px 7px;border-bottom:1px solid #e0e6ec}td:last-child{text-align:right;font-weight:900;white-space:nowrap}.income td:last-child{color:#16733a}.expense td:last-child{color:#b2293c}.total td{font-size:16px;background:#eef6ef;border-top:2px solid #79aa81;border-bottom:2px solid #79aa81}.loss td:last-child{color:#bd2439}.gain td:last-child{color:#16733a}.footer{margin-top:22px;color:#666;font-size:10px;border-top:1px solid #d5dce4;padding-top:8px}@media print{body{print-color-adjust:exact;-webkit-print-color-adjust:exact}}
  </style></head><body><h1>KAFEPIN — KÂR / ZARAR RAPORU</h1><div class="meta"><b>Dönem:</b> ${text(start)} 00:00 — ${text(end)} 23:59</div><div class="grid"><section class="box"><h2>GELİRLER</h2><table><tbody>${row("Oturum geliri", moneyText(d.gercekGelir), "income")}${row("Ürün / hizmet geliri", moneyText(d.productGeliri), "income")}${row("TOPLAM GELİR", moneyText(toplamGelir), "total")}</tbody></table></section><section class="box"><h2>GİDERLER</h2><table><tbody>${row("İşletme giderleri", moneyText(d.giderler), "expense")}${row("Kart komisyonu", moneyText(d.kartKomisyonu), "expense")}${row("Toplam gider", moneyText(giderToplami), "expense")}</tbody></table></section></div><section class="box" style="margin-top:14px"><h2>NET SONUÇ</h2><table><tbody>${row(net >= 0 ? "NET KÂR" : "NET ZARAR", moneyText(net), `total ${net >= 0 ? "gain" : "loss"}`)}</tbody></table></section><div class="footer">Çark maliyeti, masa gerçek gelirinin içinde düşülmüş olarak hesaplanır. Takvim günü hesabı: 00:00 — 23:59.</div></body></html>`);
  printWindow.document.close();
  printWindow.addEventListener("afterprint", () => printWindow.close(), {once:true});
  printWindow.focus();
  setTimeout(()=> printWindow.print(), 300);
}

function escapeHtml(s){
  return String(s || "")
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#039;");
}

function money(v){
  return `${Number(v || 0).toLocaleString("tr-TR", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  })} ₺`;
}

let productCatalog = [];
let productCategories = [];
let selectedProductCategory = "";

function syncProductSaleMode(){
  const direct = document.getElementById("productDirectSale").checked;
  const masaInput = document.getElementById("productSaleMasa");
  const paymentInput = document.getElementById("productDirectPayment");
  const customBox = document.getElementById("customDirectSaleBox");
  const modeLabel = document.getElementById("productSaleModeLabel");
  masaInput.disabled = direct;
  masaInput.style.opacity = direct ? ".45" : "1";
  paymentInput.disabled = !direct;
  paymentInput.style.opacity = direct ? "1" : ".45";
  if(modeLabel) modeLabel.textContent = direct ? "Masasız doğrudan satış" : "Masa hesabına manuel satış";
  if(customBox) customBox.style.display = direct ? "flex" : "none";
}

function setProductNotice(text, ok=true){
  const el = document.getElementById("productSaleNotice");
  if(!el) return;
  el.textContent = text || "";
  el.style.color = ok ? "#65e69a" : "#ff6b6b";
}

async function loadProductCatalog(){
  const d = await fetchJSON("/admin/products?all=1");
  if(!d || !d.ok){
    setProductNotice((d && d.error) || "Ürünler yüklenemedi", false);
    return;
  }

  productCatalog = d.list || [];
  productCategories = [...new Set([
    ...(d.categories || []),
    ...productCatalog.map(x => String(x.category || "").trim()).filter(Boolean)
  ])];

  const activeCategories = productCategories.filter(category =>
    productCatalog.some(product => product.active && product.category === category)
  );
  if(!selectedProductCategory || !activeCategories.includes(selectedProductCategory)){
    selectedProductCategory = activeCategories[0] || productCategories[0] || "";
  }

  document.getElementById("productCategoryOptions").innerHTML = productCategories
    .map(category => `<option value="${escapeHtml(category)}"></option>`)
    .join("");

  renderProductCategoryTabs();
  renderProductSaleGrid();
  renderProductManagement();
}

function renderProductCategoryTabs(){
  const tabs = document.getElementById("productCategoryTabs");
  const categories = productCategories.filter(category =>
    productCatalog.some(product => product.active && product.category === category)
  );
  tabs.innerHTML = categories.map((category, index) => `
    <button class="product-tab ${category === selectedProductCategory ? "active" : ""}"
      onclick="selectProductCategoryByIndex(${index})">
      ${escapeHtml(category)}
    </button>
  `).join("");
  tabs.dataset.categories = JSON.stringify(categories);
}

function selectProductCategoryByIndex(index){
  const tabs = document.getElementById("productCategoryTabs");
  const categories = JSON.parse(tabs.dataset.categories || "[]");
  selectProductCategory(categories[index] || "");
}

function selectProductCategory(category){
  selectedProductCategory = category;
  renderProductCategoryTabs();
  renderProductSaleGrid();
}

function renderProductSaleGrid(){
  const grid = document.getElementById("productSaleGrid");
  const list = productCatalog.filter(product =>
    product.active && product.category === selectedProductCategory
  );
  if(!list.length){
    grid.innerHTML = `<div class="small">Bu kategoride aktif ürün yok.</div>`;
    return;
  }

  grid.innerHTML = list.map(product => `
    <button class="product-button ${Number(product.price) > 0 ? "" : "no-price"}"
      onclick="addProductSale(${product.id})">
      <span class="product-name">${escapeHtml(product.name)}</span>
      <span class="product-price">${Number(product.price) > 0 ? money(product.price) : "FİYAT GİR"}</span>
    </button>
  `).join("");
}

async function addProductSale(productId){
  const direct = document.getElementById("productDirectSale").checked;
  const masa = parseInt(document.getElementById("productSaleMasa").value, 10) || 0;
  const quantity = Math.max(1, parseInt(document.getElementById("productSaleQty").value, 10) || 1);
  const paymentMethod = document.getElementById("productDirectPayment").value;

  if(!direct && (!masa || masa < 1 || masa > 23)){
    setProductNotice("Önce masa numarasını gir.", false);
    document.getElementById("productSaleMasa").focus();
    return;
  }

  const product = productCatalog.find(x => Number(x.id) === Number(productId));
  if(!product) return;

  const d = await fetchJSON("/admin/product-sales/add", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({ productId, masa, quantity, direct, paymentMethod })
  });
  if(!d || !d.ok){
    setProductNotice((d && d.error) || "Satış eklenemedi", false);
    return;
  }

  setProductNotice(`✓ ${quantity}x ${product.name} eklendi • ${money(d.total)}`, true);
  document.getElementById("productSaleQty").value = "1";
  await Promise.all([loadProductSalesSummary(), loadSessions()]);
}

async function addCustomDirectSale(){
  const nameInput = document.getElementById("customDirectProductName");
  const priceInput = document.getElementById("customDirectProductPrice");
  const qtyInput = document.getElementById("customDirectProductQty");
  const name = nameInput.value.trim();
  const unitPrice = Number(priceInput.value);
  const quantity = Math.max(1, parseInt(qtyInput.value, 10) || 1);
  const paymentMethod = document.getElementById("productDirectPayment").value;

  if(!name){
    setProductNotice("Liste dışı ürün/hizmet adını gir.", false);
    nameInput.focus();
    return;
  }
  if(!Number.isFinite(unitPrice) || unitPrice <= 0){
    setProductNotice("Geçerli bir birim fiyat gir.", false);
    priceInput.focus();
    return;
  }

  const d = await fetchJSON("/admin/product-sales/add-custom-direct", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({ name, unitPrice, quantity, paymentMethod })
  });
  if(!d || !d.ok){
    setProductNotice((d && d.error) || "Serbest satış eklenemedi", false);
    return;
  }

  setProductNotice(`✓ ${quantity}x ${name} eklendi • ${money(d.total)}`, true);
  nameInput.value = "";
  priceInput.value = "";
  qtyInput.value = "1";
  await Promise.all([loadProductSalesSummary(), loadPaymentSummary(), loadDashboardStats(), loadSessions()]);
}

async function addHistoryMemberIncome(){
  const date = document.getElementById("memberIncomeDate")?.value || "";
  const amount = Number(document.getElementById("memberIncomeAmount")?.value);
  if(!date || !Number.isFinite(amount) || amount <= 0){
    alert("Tarih ve geçerli tutar gir.");
    return;
  }
  if(!confirm(`${date} tarihine ${money(amount)} nakit EveryCafe Üye Geliri eklensin mi?`)) return;
  const d = await fetchJSON("/admin/product-sales/add-history-member-income", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({date, amount, paymentMethod:"CASH"})
  });
  if(!d || !d.ok){ alert((d && d.error) || "Üye geliri eklenemedi"); return; }
  alert(`✓ ${money(d.total)} nakit üye geliri ${date} tarihine eklendi.`);
  await Promise.all([loadProductSalesSummary(), loadProductSalesHistory(), loadPaymentSummary(), loadDashboardStats(), loadStats(), loadAccountingSummary()]);
}

async function loadEveryCafeStatus(){
  const box = document.getElementById("everyCafeStatus");
  const dashStatus = document.getElementById("dashEveryCafeStatus");
  const dashDetail = document.getElementById("dashEveryCafeDetail");
  const panelStatus = document.getElementById("everyCafePanelStatus");
  const panelDetail = document.getElementById("everyCafePanelDetail");
  const activeCount = document.getElementById("everyCafeActiveCount");
  const todayCount = document.getElementById("everyCafeTodayCount");
  const todayTotal = document.getElementById("everyCafeTodayTotal");
  const todayCash = document.getElementById("everyCafeTodayCash");
  const todayCard = document.getElementById("everyCafeTodayCard");
  const mismatchCount = document.getElementById("everyCafeMismatchCount");
  const lastImport = document.getElementById("everyCafeLastImport");
  const activeLiveTotal = document.getElementById("everyCafeActiveLiveTotal");
  const endingSoon = document.getElementById("everyCafeEndingSoon");
  const giftedCount = document.getElementById("everyCafeGiftedCount");
  const todayProduct = document.getElementById("everyCafeTodayProduct");
  const activeProductTables = document.getElementById("everyCafeActiveProductTables");
  const nextEnd = document.getElementById("everyCafeNextEnd");
  const todayTableRevenue = document.getElementById("everyCafeTodayTableRevenue");
  const activeTimedCount = document.getElementById("everyCafeActiveTimedCount");
  const activeUntimedCount = document.getElementById("everyCafeActiveUntimedCount");
  const activeFreeCount = document.getElementById("everyCafeActiveFreeCount");
  const memberToday = document.getElementById("everyCafeMemberToday");
  const memberTodayCount = document.getElementById("everyCafeMemberTodayCount");
  const memberCash = document.getElementById("everyCafeMemberCash");
  const memberCard = document.getElementById("everyCafeMemberCard");
  const memberAllTime = document.getElementById("everyCafeMemberAllTime");
  const memberAllTimeCount = document.getElementById("everyCafeMemberAllTimeCount");
  const memberMonth = document.getElementById("everyCafeMemberMonth");
  const memberMonthCount = document.getElementById("everyCafeMemberMonthCount");
  const memberLatest = document.getElementById("everyCafeMemberLatest");
  const memberLatestDetail = document.getElementById("everyCafeMemberLatestDetail");
  const memberRecent = document.getElementById("everyCafeMemberRecent");
  const directToday = document.getElementById("everyCafeDirectToday");
  const directTodayDetail = document.getElementById("everyCafeDirectTodayDetail");
  const directAllTime = document.getElementById("everyCafeDirectAllTime");
  const directAllTimeDetail = document.getElementById("everyCafeDirectAllTimeDetail");
  if(!box) return;
  const [d, audit] = await Promise.all([
    fetchJSON("/admin/everycafe/status"),
    fetchJSON("/admin/everycafe/payment-audit")
  ]);
  if(!d || !d.ok){
    box.innerHTML = `<span class="statRed">Bağlantı kurulamadı: ${escapeHtml((d && d.error) || "bilinmeyen hata")}</span>`;
    if(dashStatus) dashStatus.textContent = "Bağlantı yok";
    if(dashDetail) dashDetail.textContent = "EveryCafe okunamadı";
    if(panelStatus) panelStatus.textContent = "🔴 Bağlantı kurulamadı";
    if(panelDetail) panelDetail.textContent = (d && d.error) || "EveryCafe okunamadı";
    if(mismatchCount){ mismatchCount.textContent = "Bağlantı yok"; mismatchCount.className = "value statRed"; }
    return;
  }
  const t = d.today || {};
  const mismatch = Number(audit && audit.ok && (audit.issues || []).length) || 0;
  const latest = (d.recent || []).slice(-3).reverse().map(row =>
    `Masa ${row.masa} • ${money(row.total)} (${row.method === "CARD" ? "Kart" : row.method === "CASH" ? "Nakit" : "Bekliyor"})`
  ).join(" &nbsp;|&nbsp; ") || "Henüz kapanmış masa bulunamadı";
  box.innerHTML = `${d.enabled ? '<span class="statGreen">● Canlı aktarım açık</span>' : '<span class="statWarn">● Test henüz başlatılmadı</span>'} • Aktarılan: <b>${Number(d.importedCount)||0}</b> oturum${d.lastCheck ? ` • Son kontrol: ${fmtDateTime(d.lastCheck)}` : ""}${d.lastImport ? ` • Son tahsilat aktarımı: ${fmtDateTime(d.lastImport)}` : ""}<br><span class="small">Son EveryCafe kapanışları: ${latest}</span>`;
  if(dashStatus){
    dashStatus.textContent = d.enabled ? `● Aktif • ${Number(d.activeCount)||0} masa` : "● Kapalı";
    dashStatus.className = `value ${d.enabled ? "statGreen" : "statOrange"}`;
  }
  if(dashDetail){
    dashDetail.textContent = `Bugün ${Number(t.count)||0} oturum • ${money(t.total)} | N: ${money(t.cash)} • K: ${money(t.card)}${mismatch ? ` • ⚠️ ${mismatch} fark` : " • ✅ Uyumlu"}`;
  }
  if(panelStatus){
    panelStatus.innerHTML = d.enabled
      ? `<span class="statGreen">● Canlı aktarım açık</span> • ${Number(d.activeCount)||0} aktif masa`
      : '<span class="statWarn">● Aktarım kapalı</span>';
  }
  if(panelDetail){
    panelDetail.textContent = `Bugün: ${Number(t.count)||0} oturum • ${money(t.total)} | Nakit: ${money(t.cash)} • Kart: ${money(t.card)}${d.lastCheck ? ` • Son kontrol: ${fmtDateTime(d.lastCheck)}` : ""}${d.lastImport ? ` • Son tahsilat: ${fmtDateTime(d.lastImport)}` : ""}${mismatch ? ` • ⚠️ ${mismatch} uyuşmazlık` : " • ✅ Uyumlu"}`;
  }
  if(activeCount) activeCount.textContent = Number(d.activeCount) || 0;
  if(todayCount) todayCount.textContent = Number(t.count) || 0;
  if(todayTotal) todayTotal.textContent = money(t.total);
  if(todayCash) todayCash.textContent = money(t.cash);
  if(todayCard) todayCard.textContent = money(t.card);
  if(todayProduct) todayProduct.textContent = money(t.product);
  if(todayTableRevenue) todayTableRevenue.textContent = money(Math.max(0, (Number(t.sessionTotal) || 0) - (Number(t.product) || 0)));
  const direct = d.directSales || {};
  const directTodayData = direct.today || {};
  const directAllTimeData = direct.allTime || {};
  if(directToday) directToday.textContent = money(directTodayData.total);
  if(directTodayDetail) directTodayDetail.textContent = `${Number(directTodayData.count)||0} işlem • N: ${money(directTodayData.cash)} • K: ${money(directTodayData.card)}`;
  if(directAllTime) directAllTime.textContent = money(directAllTimeData.total);
  if(directAllTimeDetail) directAllTimeDetail.textContent = `${Number(directAllTimeData.count)||0} işlem • N: ${money(directAllTimeData.cash)} • K: ${money(directAllTimeData.card)}`;
  const active = d.active || {};
  if(activeLiveTotal) activeLiveTotal.textContent = money(active.liveTotal);
  if(endingSoon) endingSoon.textContent = Number(active.endingSoonCount) || 0;
  if(giftedCount) giftedCount.textContent = Number(active.giftedCount) || 0;
  const activeRows = Array.isArray(active.rows) ? active.rows : [];
  if(activeTimedCount) activeTimedCount.textContent = activeRows.filter(row => Number(row.end) > Number(row.start)).length;
  if(activeUntimedCount) activeUntimedCount.textContent = activeRows.filter(row => !(Number(row.end) > Number(row.start))).length;
  if(activeFreeCount) activeFreeCount.textContent = activeRows.filter(row => !!row.free).length;
  if(activeProductTables) activeProductTables.textContent = activeRows.filter(row => Number(row.productTotal) > 0).length;
  if(nextEnd){
    const next = activeRows.filter(row => Number(row.end) > Date.now()).sort((a,b) => Number(a.end) - Number(b.end))[0];
    nextEnd.textContent = next ? `${Math.max(0, Math.ceil((Number(next.end) - Date.now()) / 60000))} dk` : "-";
  }
  const member = d.memberIncome || {};
  const memberTodayData = member.today || {};
  const memberAllTimeData = member.allTime || {};
  const memberMonthData = member.month || {};
  if(memberToday) memberToday.textContent = money(memberTodayData.total);
  if(memberTodayCount) memberTodayCount.textContent = `${Number(memberTodayData.count)||0} tahsilat`;
  if(memberCash) memberCash.textContent = money(memberTodayData.cash);
  if(memberCard) memberCard.textContent = money(memberTodayData.card);
  if(memberAllTime) memberAllTime.textContent = money(memberAllTimeData.total);
  if(memberAllTimeCount) memberAllTimeCount.textContent = `${Number(memberAllTimeData.count)||0} tahsilat`;
  if(memberMonth) memberMonth.textContent = money(memberMonthData.total);
  if(memberMonthCount) memberMonthCount.textContent = `${Number(memberMonthData.count)||0} tahsilat`;
  const latestMember = Array.isArray(member.recent) ? member.recent[0] : null;
  if(memberLatest) memberLatest.textContent = latestMember ? money(latestMember.total) : "-";
  if(memberLatestDetail) memberLatestDetail.textContent = latestMember ? `${latestMember.payment_method === "CARD" ? "Kart" : "Nakit"} • ${fmtDateTime(latestMember.time)}` : "Henüz kayıt yok";
  if(memberRecent){
    const items = Array.isArray(member.recent) ? member.recent : [];
    memberRecent.innerHTML = items.length ? items.map(row => `<div class="product-recent-row"><div><b>${escapeHtml(String(row.note || "EveryCafe Üye Bakiyesi").replace(/^EveryCafe üye bakiyesi\s*•?\s*/, "")) || "Üye Bakiyesi"}</b><div class="small">${fmtDateTime(row.time)} • ${row.payment_method === "CARD" ? "Kart" : "Nakit"}</div></div><b class="statGreen">${money(row.total)}</b></div>`).join("") : '<div class="small" style="padding:10px;">Henüz aktarılmış üye geliri yok.</div>';
  }
  if(mismatchCount){
    mismatchCount.textContent = mismatch ? `⚠️ ${mismatch} fark` : "✅ Uyumlu";
    mismatchCount.className = `value ${mismatch ? "statRed" : "statGreen"}`;
  }
  if(lastImport) lastImport.textContent = d.lastCheck ? `Son kontrol: ${fmtDateTime(d.lastCheck)}` : (d.lastImport ? `Son tahsilat: ${fmtDateTime(d.lastImport)}` : "Henüz kontrol edilmedi");
}

async function loadEveryCafeDaySplits(){
  const box = document.getElementById("everyCafeDaySplitBox");
  if(!box) return;
  const d = await fetchJSON("/admin/everycafe/day-splits");
  if(!d || !d.ok){
    box.innerHTML = `<div class="small statRed" style="padding:10px;">Devirli oturumlar okunamadı.</div>`;
    return;
  }
  const rows = d.rows || [];
  if(!rows.length){
    box.innerHTML = `<div class="small" style="padding:10px;color:#8dffc1;">20:00 sınırını geçen EveryCafe oturumu yok.</div>`;
    return;
  }
  box.innerHTML = `<table class="payment-table">
    <tr><th>Masa</th><th>Başlangıç</th><th>Kapanış</th><th>20:00 Öncesi</th><th>20:00 Sonrası</th><th>Toplam</th><th>Ödeme</th></tr>
    ${rows.map(row => `<tr>
      <td><b>Masa ${Number(row.masa)||"-"}</b></td>
      <td>${fmtDateTime(row.start)}</td>
      <td>${fmtDateTime(row.end)}</td>
      <td class="statOrange"><b>${money(row.before)}</b></td>
      <td class="statGreen"><b>${money(row.after)}</b></td>
      <td><b>${money(row.total)}</b></td>
      <td>${row.method === "CASH" ? "Nakit" : row.method === "CARD" ? "Kart" : "Bekliyor"}</td>
    </tr>`).join("")}
  </table>`;
}

async function startEveryCafeTest(){
  if(!confirm("Canlı test başlasın mı? Yalnız bu andan sonra EveryCafe'de kapanan ve tahsil edilmiş, KafePin oturumuyla eşleşen masalar aktarılır; eski kayıtlar alınmaz.")) return;
  const d = await fetchJSON("/admin/everycafe/start-test", {method:"POST"});
  if(!d || !d.ok){ alert((d && d.error) || "Test başlatılamadı"); return; }
  alert("Canlı test başladı. EveryCafe'de yeni bir masayı kapatıp tahsil ettiğinde, KafePin'deki aynı masa oturumuyla doğrulanır ve en geç 30 saniye içinde aktarılır.");
  await Promise.all([loadEveryCafeStatus(), loadEveryCafeDaySplits()]);
}

async function syncEveryCafeNow(){
  const d = await fetchJSON("/admin/everycafe/sync-now", {method:"POST"});
  if(!d || !d.ok){ alert((d && d.error) || "EveryCafe kontrol edilemedi"); return; }
  if(d.reason === "disabled") alert("Önce CANLI TESTİ BAŞLAT düğmesine bas.");
  else alert(`${Number(d.activeSynced)||0} aktif masa kontrol edildi • ${Number(d.imported)||0} yeni kapanış aktarıldı.`);
  await Promise.all([loadEveryCafeStatus(), loadEveryCafeDaySplits(), loadProductSalesSummary(), loadPaymentSummary(), loadDashboardStats(), loadAccountingSummary(), loadLiveLog()]);
}

async function stopEveryCafeSync(){
  if(!confirm("EveryCafe canlı aktarımı durdurulsun mu?")) return;
  const d = await fetchJSON("/admin/everycafe/stop", {method:"POST"});
  if(!d || !d.ok){ alert((d && d.error) || "Aktarım durdurulamadı"); return; }
  await Promise.all([loadEveryCafeStatus(), loadEveryCafeDaySplits()]);
}

async function loadProductSalesSummary(){
  const d = await fetchJSON("/admin/product-sales/summary");
  if(!d || !d.ok) return;

  const todayDash = document.getElementById("dashProductToday");
  const todayCountDash = document.getElementById("dashProductTodayCount");
  const allTimeDash = document.getElementById("dashProductAllTime");
  const allTimeCountDash = document.getElementById("dashProductAllTimeCount");
  if(todayDash) todayDash.textContent = money(d.total);
  if(todayCountDash) todayCountDash.textContent = `${Number(d.todayQuantity) || 0} ürün/hizmet`;
  if(allTimeDash) allTimeDash.textContent = money(d.allTimeTotal);
  if(allTimeCountDash) allTimeCountDash.textContent = `${Number(d.allTimeQuantity) || 0} ürün/hizmet`;
  const directTodayDash = document.getElementById("dashDirectSalesToday");
  const directMonthDash = document.getElementById("dashDirectSalesMonth");
  const directAllTimeDash = document.getElementById("dashDirectSalesAllTime");
  if(directTodayDash) directTodayDash.textContent = money(d.directTotal);
  if(directMonthDash) directMonthDash.textContent = money(d.monthDirectTotal);
  if(directAllTimeDash) directAllTimeDash.textContent = money(d.allTimeDirectTotal);

  // Gelir özetini üç net gruba ayırıyoruz:
  // 1) aktif masa hariç kayıtlı gelir, 2) açık masalarda biriken tutar, 3) canlı genel toplam.
  const everyCafeDirectTotal = Number(d.everyCafeDirectTotal) || 0;
  const everyCafeMemberTotal = Number(d.everyCafeMemberTotal) || 0;
  const kafePinDirectTotal = Number(d.directTotal) || 0;
  const totalProductRevenue = Number(d.total) || 0;
  const tableProductTotal = Math.max(0, totalProductRevenue - kafePinDirectTotal - everyCafeDirectTotal - everyCafeMemberTotal);
  const sessionRevenue = Number(d.sessionTotal) || 0;
  const openSessionTotal = Number(d.openSessionTotal) || 0;

  const openTableProductTotal = Object.values(d.tableTotals || {})
    .reduce((sum, value) => sum + (Number(value) || 0), 0);
  const closedTableProductTotal = Math.max(0, tableProductTotal - openTableProductTotal);

  const recordedRevenue =
    sessionRevenue +
    closedTableProductTotal +
    kafePinDirectTotal +
    everyCafeDirectTotal +
    everyCafeMemberTotal;

  const liveOpenTotal = openSessionTotal + openTableProductTotal;
  const liveGrandTotal = recordedRevenue + liveOpenTotal;

  const openFeeByMasa = {};
  (Array.isArray(d.openSessionDetails) ? d.openSessionDetails : []).forEach((row) => {
    const masa = String(Number(row.masa) || 0);
    if(masa !== "0") openFeeByMasa[masa] = Number(row.fee) || 0;
  });

  const liveMasaKeys = Array.from(new Set([
    ...Object.keys(openFeeByMasa),
    ...Object.keys(d.tableTotals || {})
  ])).sort((a,b) => Number(a) - Number(b));

  const activeAccounts = liveMasaKeys.map((masa) => {
    const pc = Number(openFeeByMasa[masa]) || 0;
    const urun = Number((d.tableTotals || {})[masa]) || 0;
    const toplam = pc + urun;
    const urunText = urun > 0 ? ` + Ürün ${money(urun)}` : "";
    return `Masa ${masa}: PC ${money(pc)}${urunText} = ${money(toplam)}`;
  }).join(" • ");

  document.getElementById("productSalesSummary").innerHTML = `
    <div class="product-summary-card" style="grid-column:1/-1;border-color:#2f6b4f;background:#0f1d17">
      <div class="label" style="color:#78e6ad;font-weight:900">✅ BUGÜN KAYITLI GELİR • AKTİF MASA HARİÇ</div>
      <div class="small" style="margin-top:5px">Kapanmış masa ücretleri ve aktif masa hesabında beklemeyen satışlar.</div>
    </div>

    <div class="product-summary-card">
      <div class="label">🖥️ Kapanmış PC / Masa Geliri</div>
      <div class="amount" style="color:#65e69a">${money(sessionRevenue)}</div>
      <div class="small">Kapanmış oturumların bilgisayar kullanım ücreti</div>
    </div>
    <div class="product-summary-card">
      <div class="label">🍽️ Kapanmış Masaya Yazılan Ürün</div>
      <div class="amount" style="color:#ffd166">${money(closedTableProductTotal)}</div>
      <div class="small">Masaya yazılan toplam: ${money(tableProductTotal)} • açık masada: ${money(openTableProductTotal)}</div>
    </div>
    <div class="product-summary-card">
      <div class="label">🧾 KafePin Doğrudan Satış</div>
      <div class="amount" style="color:#7ed6ff">${money(kafePinDirectTotal)}</div>
      <div class="small">Masaya yazılmadan KafePin'den yapılan satış</div>
    </div>
    <div class="product-summary-card">
      <div class="label">🏪 EveryCafe Doğrudan Satış</div>
      <div class="amount" style="color:#a98cff">${money(everyCafeDirectTotal)}</div>
      <div class="small">EveryCafe “Doğrudan Satış” kaynağı</div>
    </div>
    <div class="product-summary-card">
      <div class="label">👤 EveryCafe Üye / Bakiye</div>
      <div class="amount" style="color:#8fd3ff">${money(everyCafeMemberTotal)}</div>
      <div class="small">Üye veya bakiye üzerinden gelen satış</div>
    </div>
    <div class="product-summary-card" style="border-color:#2f6b4f">
      <div class="label">✅ Aktif Masa Hariç Toplam</div>
      <div class="amount" style="color:#65e69a">${money(recordedRevenue)}</div>
      <div class="small">PC + kapanmış masa ürünü + doğrudan satışlar</div>
    </div>

    <div class="product-summary-card" style="grid-column:1/-1;border-color:#8a6620;background:#211b0f;margin-top:4px">
      <div class="label" style="color:#ffd166;font-weight:900">🟠 AÇIK MASALAR • HENÜZ KAPANMAMIŞ</div>
      <div class="small" style="margin-top:5px">Bilgisayar kullanım ücreti ile açık masaya yazılmış ürünler birlikte gösterilir.</div>
    </div>
    <div class="product-summary-card">
      <div class="label">🖥️ Açık Masa PC / Süre</div>
      <div class="amount" style="color:#65e69a">${money(openSessionTotal)}</div>
      <div class="small">Canlı bilgisayar kullanım ücreti</div>
    </div>
    <div class="product-summary-card">
      <div class="label">🍽️ Açık Masaya Yazılan Ürün</div>
      <div class="amount" style="color:#ffd166">${money(openTableProductTotal)}</div>
      <div class="small">Henüz açık hesapta duran ürün/hizmet</div>
    </div>
    <div class="product-summary-card" style="grid-column:1/-1;border-color:#8a6620">
      <div class="label">💰 Aktif Masalarda Biriken Toplam</div>
      <div class="amount" style="color:#ffd166">${money(liveOpenTotal)}</div>
      <div class="small">${activeAccounts ? escapeHtml(activeAccounts) : "Şu anda açık masa borcu yok."}</div>
    </div>

    <div class="product-summary-card" style="grid-column:1/-1;border-color:#7456c9;background:#171326;margin-top:4px">
      <div class="label" style="color:#b99cff;font-weight:900">🔵 BUGÜN CANLI TOPLAM</div>
      <div class="amount" style="color:#b08cff;font-size:28px">${money(liveGrandTotal)}</div>
      <div class="small">Kontrol: ${money(recordedRevenue)} kayıtlı + ${money(liveOpenTotal)} açık masa = <b>${money(liveGrandTotal)}</b></div>
    </div>
  `;

  const recent = d.list || [];
  document.getElementById("productRecentSales").innerHTML = recent.length
    ? recent.slice(0,30).map(sale => `
      <div class="product-recent-row">
        <div>
          <b>${sale.quantity}x ${escapeHtml(sale.product_name)}</b>
          <div class="small">${sale.external_source === "EVERYCAFE_DIRECT" ? "EveryCafe doğrudan satış" : sale.sale_type === "DIRECT" ? "KafePin doğrudan satış" : `Masa ${sale.masa}`} • ${fmtTime(sale.time)} • ${sale.payment_method === "CARD" ? "Kart" : sale.payment_method === "CASH" ? "Nakit" : "Bekliyor"}</div>
        </div>
        <b>${money(sale.total)}</b>
        <button class="red btnSm" onclick="voidProductSale(${sale.id})">İptal</button>
      </div>
    `).join("")
    : `<div class="small" style="padding:12px;">Bugün ürün veya hizmet satışı yok.</div>`;
}

async function loadProductSalesHistory(){
  const dateInput = document.getElementById("productHistoryDate");
  if(dateInput && !dateInput.value){
    const today = new Date();
    dateInput.value = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,"0")}-${String(today.getDate()).padStart(2,"0")}`;
  }
  const selectedDate = dateInput?.value || "";
  const monthInput = document.getElementById("productHistoryMonth");
  if(monthInput && !monthInput.value){
    const now = new Date();
    monthInput.value = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}`;
  }
  const selectedMonth = monthInput?.value || "";
  const reconciliation = document.getElementById("productDayReconciliation");
  const periodReconciliation = document.getElementById("productPeriodReconciliation");
  const d = await fetchJSON(`/admin/product-sales/list?date=${encodeURIComponent(selectedDate)}&month=${encodeURIComponent(selectedMonth)}`);
  if(!d || !d.ok){
    if(reconciliation){
      reconciliation.innerHTML = `<div class="small statRed" style="padding:12px;">Günlük aktarım kontrolü yüklenemedi.</div>`;
    }
    if(periodReconciliation){
      periodReconciliation.innerHTML = `<div class="small statRed" style="padding:12px;">Aylık aktarım kontrolü yüklenemedi.</div>`;
    }
    return;
  }
  const everyCafeTotal = Number(d.everyCafeTotal) || 0;
  const kafePinTableTotal = Number(d.kafePinTableTotal) || 0;
  const difference = Math.round((kafePinTableTotal - everyCafeTotal) * 100) / 100;
  if(reconciliation){
    reconciliation.innerHTML = `
      <div class="product-summary-card"><div class="label">EveryCafe Aktarımı</div><div class="amount" style="color:#7ed6ff">${money(everyCafeTotal)}</div><div class="small">Masa + ürün + üye + doğrudan satış</div></div>
      <div class="product-summary-card"><div class="label">KafePin Aktarımı</div><div class="amount" style="color:#65e69a">${money(kafePinTableTotal)}</div><div class="small">Masa + ürün + üye + doğrudan satış</div></div>
      <div class="product-summary-card"><div class="label">Aktarım Kontrolü</div><div class="amount ${Math.abs(difference) < 0.01 ? "statGreen" : "statRed"}">${Math.abs(difference) < 0.01 ? "✓ Uyumlu" : money(difference)}</div><div class="small">Yalnız kapanıp aktarılan masa ve satışlar karşılaştırılır</div></div>
    `;
  }
  if(periodReconciliation){
    const renderPeriod = (title, everyCafe, kafePin) => {
      const difference = Math.round((kafePin - everyCafe) * 100) / 100;
      return `<div class="product-summary-card"><div class="label">${title}</div><div class="small">EveryCafe: <b class="statBlue">${money(everyCafe)}</b> • KafePin: <b class="statGreen">${money(kafePin)}</b></div><div class="amount ${Math.abs(difference) < 0.01 ? "statGreen" : "statRed"}" style="font-size:20px;">${Math.abs(difference) < 0.01 ? "✓ Uyumlu" : `Fark: ${money(difference)}`}</div><div class="small">Masa + ürün + üye + EveryCafe doğrudan satış</div></div>`;
    };
    periodReconciliation.innerHTML = renderPeriod("Seçilen Ay", Number(d.monthEveryCafeTotal)||0, Number(d.monthKafePinTableTotal)||0) + renderPeriod("Tüm Zamanlar", Number(d.allTimeEveryCafeTotal)||0, Number(d.allTimeKafePinTableTotal)||0);
  }
}

async function loadPaymentSummary(){
  const [d, accountingData] = await Promise.all([
    fetchJSON("/admin/payments/summary"),
    fetchJSON("/admin/accounting/summary")
  ]);
  if(!d || !d.ok) return;

  const setText = (id, value) => {
    const el = document.getElementById(id);
    if(el) el.textContent = value;
  };
  setText("payTodayCash", money(d.todayCash));
  setText("payTodayCard", money(d.todayCard));
  setText("payTodayPending", money(d.todayPending));
  setText("dashTodayCash", money(d.todayCash));
  setText("dashTodayCard", money(d.todayCard));
  setText("dashTodayPendingPayment", money(d.todayPending));
  const todayCollected = (Number(d.todayCash)||0) + (Number(d.todayCard)||0);
  const todayAccounting = accountingData && accountingData.ok ? (accountingData.today || {}) : {};
  setText("payTodayRevenue", money(todayAccounting.genelGelir));
  const todayCommission = Number(d.todayCardCommission) || 0;
  const todayNetCollected = todayCollected - todayCommission;
  setText("payTodayTotal", money(todayCollected));
  setText("payTodayCommission", money(todayCommission));
  setText("dashTodayCommission", money(todayCommission));
  setText("payTodayNetCollected", money(todayNetCollected));
  setText("payAllCash", money(d.allTimeCash));
  setText("payAllCard", money(d.allTimeCard));
  setText("payPendingCount", `${Number(d.pendingCount)||0} hesap`);
  setText("dashPendingPaymentCount", `${Number(d.pendingCount)||0} hesap`);

  const paymentBadge = document.getElementById("paymentBadge");
  if(paymentBadge){
    const pendingCount = Number(d.pendingCount) || 0;
    paymentBadge.textContent = `Ödeme Bekliyor: ${pendingCount}`;
    paymentBadge.style.display = pendingCount > 0 ? "block" : "none";
    paymentBadge.style.animation = pendingCount > 0 ? "pulseBadge .9s infinite" : "none";
  }

  const box = document.getElementById("pendingPaymentsBox");
  const pending = d.pending || [];
  box.innerHTML = pending.length ? `
    <table class="payment-table">
      <tr><th>Saat</th><th>Masa</th><th>Bilgisayar</th><th>Ürün</th><th>Toplam</th><th>İşlem</th></tr>
      ${pending.map(payment => `
        <tr>
          <td>${fmtDateTime(payment.created_at)}</td>
          <td>${payment.masa ? `Masa ${payment.masa}` : "Doğrudan"}</td>
          <td>${money(payment.computer_amount)}</td>
          <td>${money(payment.product_amount)}</td>
          <td><b>${money(payment.total_amount)}</b></td>
          <td>
            <button class="greenBtn btnSm" onclick="setPendingPaymentMethod(${payment.id},'CASH')">NAKİT</button>
            <button class="blueBtn btnSm" onclick="setPendingPaymentMethod(${payment.id},'CARD')">KART</button>
          </td>
        </tr>
      `).join("")}
    </table>
  ` : `<div class="small" style="padding:12px;color:#65e69a;">Bekleyen ödeme yok.</div>`;

  const historyBox = document.getElementById("paymentHistoryBox");
  const recent = (d.recent || []).slice(0, 30);
  if(historyBox){
    historyBox.innerHTML = recent.length ? `
      <table class="payment-table">
        <tr><th>Saat</th><th>Masa</th><th>Bilgisayar</th><th>Ürün</th><th>Toplam</th><th>Kayıt</th><th>Düzelt</th></tr>
        ${recent.map(payment => `
          <tr>
            <td>${fmtDateTime(payment.created_at)}</td>
            <td>${payment.masa ? `Masa ${payment.masa}` : "Doğrudan"}</td>
            <td>${money(payment.computer_amount)}</td>
            <td>${money(payment.product_amount)}</td>
            <td><b>${money(payment.total_amount)}</b></td>
            <td>${payment.method === "CASH" ? "Nakit" : payment.method === "CARD" ? "Kart" : "Bekliyor"}</td>
            <td>
              <button class="greenBtn btnSm" ${payment.method === "CASH" ? "disabled" : ""} onclick="setPendingPaymentMethod(${payment.id},'CASH')">NAKİT</button>
              <button class="blueBtn btnSm" ${payment.method === "CARD" ? "disabled" : ""} onclick="setPendingPaymentMethod(${payment.id},'CARD')">KART</button>
            </td>
          </tr>
        `).join("")}
      </table>
    ` : `<div class="small" style="padding:12px;">Henüz ödeme kaydı yok.</div>`;
  }
}

async function loadCashReconciliation(){
  const box = document.getElementById("cashReconciliationAlert");
  const sideBadge = document.getElementById("cashMismatchBadge");
  if(!box) return;
  const [d, everyCafeAudit] = await Promise.all([
    fetchJSON("/admin/payments/reconciliation"),
    fetchJSON("/admin/everycafe/payment-audit")
  ]);
  if(!d || !d.ok){
    if(sideBadge){ sideBadge.style.display="none"; sideBadge.style.animation="none"; }
    box.style.background = "#4a3515";
    box.style.borderColor = "#d28b24";
    box.style.color = "#ffd58a";
    box.innerHTML = "⚠️ Kasa uyum kontrolü yapılamadı. Sunucu bağlantısını kontrol et.";
    return;
  }

  const issues = [
    ...(d.issues || []),
    ...((everyCafeAudit && everyCafeAudit.ok && everyCafeAudit.issues) || [])
  ];
  const issueCount = issues.length;

  if(issueCount === 0){
    if(sideBadge){ sideBadge.style.display="none"; sideBadge.style.animation="none"; }
    box.style.background = "#123523";
    box.style.borderColor = "#2da86b";
    box.style.color = "#8dffc1";
    box.innerHTML = `✅ Kasa kayıtları uyumlu <span class="small">• Son 7 iş günü • ${Number(d.checkedPayments)||0} ödeme, ${Number(d.checkedSales)||0} satış kontrol edildi</span>`;
    return;
  }

  box.style.background = "#4a171d";
  if(sideBadge){ sideBadge.textContent=`Kasa Uyarısı: ${issueCount}`; sideBadge.style.display="block"; sideBadge.style.animation="pulseBadge .9s infinite"; }
  box.style.borderColor = "#ff4d62";
  box.style.color = "#ffb3bc";
  box.innerHTML = `
    <div style="font-size:17px;margin-bottom:7px;">🚨 KASA / GELİR UYUŞMAZLIĞI: ${issueCount}</div>
    ${issues.slice(0,5).map(issue => `<div class="small" style="color:#ffd5da;margin:5px 0;">• ${escapeHtml(issue.text)}${Number(issue.everyCafePaymentId) > 0 ? ` <button class="redBtn btnSm" style="margin-left:7px;" onclick="voidEveryCafeImport(${Number(issue.everyCafePaymentId)})">EVERYCAFE KAYDINI SİL</button>` : ""}</div>`).join("")}
    ${issueCount > 5 ? `<div class="small" style="margin-top:5px;">İlk 5 sorun gösteriliyor.</div>` : ""}
  `;
}

async function voidEveryCafeImport(paymentId){
  if(!confirm("EveryCafe ile uyuşmayan bu kapanış kaydı silinsin mi? Bilgisayar ücreti, ürünler ve ödeme kaydı KafePin gelir/kasasından kaldırılır. EveryCafe'ye hiçbir şey yazılmaz.")) return;
  const d = await fetchJSON("/admin/everycafe/void-import", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({paymentId})
  });
  if(!d || !d.ok){ alert(d?.error || "Kayıt silinemedi"); return; }
  alert(`✅ Masa ${d.masa} için ${money(d.removed)} tutarındaki EveryCafe aktarımı silindi.`);
  await refreshFastNow();
  await refreshMediumNow();
  await refreshSlowNow();
}

function renderCardSettlements(rows){
  const box = document.getElementById("cardSettlementBox");
  if(!box) return;
  const list = (rows || []).slice(0, 14);
  if(!list.length){
    box.innerHTML = `<div class="small" style="padding:10px;">Kart tahsilatı yok.</div>`;
    return;
  }
  box.innerHTML = `<table class="payment-table">
    <tr><th>Kart işlem günü</th><th>İşlem</th><th>Brüt</th><th>Tahmini net</th><th>Bankaya geçen net</th><th>Gerçek komisyon</th><th>Durum</th><th>İşlem</th></tr>
    ${list.map(row => {
      const expectedNet = Number(row.expectedNet) || 0;
      const actualNet = Number(row.actualNet) || 0;
      const commission = Number(row.commission) || 0;
      const confirmed = !!row.confirmed;
      const difference = confirmed ? actualNet - expectedNet : 0;
      const status = confirmed
        ? `<span class="statGreen">✅ Doğrulandı</span>${difference ? `<div class="small ${difference < 0 ? "statRed" : "statGreen"}">Fark: ${money(difference)}</div>` : ""}`
        : row.settled
          ? `<span class="statOrange">⚠️ Banka tutarını gir</span>`
          : `<span class="small">⏳ ${fmtDateTime(row.settlementAt)}</span>`;
      return `<tr>
        <td>${escapeHtml(row.key)}</td>
        <td>${Number(row.paymentCount)||0} adet</td>
        <td><b>${money(row.gross)}</b></td>
        <td>${money(expectedNet)}</td>
        <td><input id="settlementNet-${row.key}" type="number" min="0.01" step="0.01" value="${confirmed ? actualNet.toFixed(2) : expectedNet.toFixed(2)}" style="width:105px;"></td>
        <td class="${confirmed ? "statGreen" : "statOrange"}">${money(commission)}</td>
        <td>${status}</td>
        <td>
          <button class="greenBtn btnSm" onclick="confirmCardSettlement('${row.key}')">DOĞRULA</button>
          ${confirmed ? `<button class="darkBtn btnSm" onclick="clearCardSettlement('${row.key}')">GERİ AL</button>` : ""}
        </td>
      </tr>`;
    }).join("")}
  </table>`;
}

async function confirmCardSettlement(key){
  const input = document.getElementById(`settlementNet-${key}`);
  const actualNet = Number(input?.value);
  if(!Number.isFinite(actualNet) || actualNet <= 0){ alert("Bankaya geçen net tutarı gir"); return; }
  const d = await fetchJSON("/admin/card-settlements/confirm", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({ settlementKey:key, actualNet })
  });
  if(!d || !d.ok){ alert(d?.error || "Kart yatırımı doğrulanamadı"); return; }
  await loadAccountingSummary();
  await loadCashReconciliation();
}

async function clearCardSettlement(key){
  if(!confirm(`${key} kart yatırımı doğrulamasını kaldırmak istiyor musun?`)) return;
  const d = await fetchJSON("/admin/card-settlements/clear", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({ settlementKey:key })
  });
  if(!d || !d.ok){ alert(d?.error || "Doğrulama kaldırılamadı"); return; }
  await loadAccountingSummary();
  await loadCashReconciliation();
}

let accountingRecentRows = [];

async function loadAccountingSummary(){
  const d = await fetchJSON("/admin/accounting/summary");
  if(!d || !d.ok) return;
  const balances = d.balances || {};
  const today = d.today || {};
  const month = d.month || {};
  const allTime = d.allTime || {};
  const setText = (id, value) => {
    const el = document.getElementById(id);
    if(el) el.textContent = value;
  };
  setText("accountingCashBalance", money(balances.cash));
  setText("accountingMainBankBalance", money(balances.mainBank));
  setText("accountingPosBankBalance", money(balances.posBank));
  setText("accountingPersonalCardDebt", money(balances.personalCardDebt));
  setText("accountingTotalAssets", money(balances.totalAssets));
  setText("dashTotalAssets", money(balances.totalAssets));
  setText("accountingUnsettledCard", money(balances.unsettledCardNet));
  setText("accountingNextSettlement", Number(balances.nextSettlementAt) > 0 ? `Hesaba geçiş: ${fmtDateTime(balances.nextSettlementAt)}` : "Bekleyen kart tahsilatı yok");
  setText("accountingTodayExpense", money(today.giderler));
  setText("accountingTodayRevenue", money(today.genelGelir));
  setText("accountingTodayCommission", money(today.kartKomisyonu));
  setText("accountingTodayNet", money(today.netIsletmeSonucu));
  setText("accountingMonthExpense", money(month.giderler));
  setText("accountingMonthRevenue", money(month.genelGelir));
  setText("accountingMonthCommission", money(month.kartKomisyonu));
  setText("accountingMonthNet", money(month.netIsletmeSonucu));
  setText("accountingNetCapital", money((Number(balances.capitalCash)||0) + (Number(balances.capitalCard)||0)));
  setText("accountingAllExpense", money(allTime.giderler));
  setText("accountingAllRevenue", money(allTime.genelGelir));
  setText("accountingAllCommission", money(allTime.kartKomisyonu));
  setText("accountingAllNet", money(allTime.netIsletmeSonucu));
  const allTimeRevenue = Number(allTime.genelGelir) || 0;
  const allTimeMargin = allTimeRevenue > 0 ? ((Number(allTime.netIsletmeSonucu) || 0) / allTimeRevenue) * 100 : 0;
  setText("accountingAllMargin", `${allTimeMargin.toFixed(1)}%`);
  renderCardSettlements(d.cardSettlements || []);

  const box = document.getElementById("accountingRecentBox");
  if(!box) return;
  const rows = d.recent || [];
  accountingRecentRows = rows;
  renderAccountTransfers(d.recentTransfers || []);
  const typeText = type => type === "EXPENSE" ? "Gider" : type === "CAPITAL_IN" ? "Başlangıç Bakiyesi" : "Bakiye Düşürme";
  const accountText = row => {
    const account = String(row.account || "") || (row.method === "CASH" ? "CASH" : "MAIN_BANK");
    return account === "CASH" ? "Nakit Kasa" : account === "POS_BANK" ? "POS Bankası" : account === "PERSONAL_CARD" ? "Kişisel Kart Borcu" : "Ana Banka";
  };
  box.innerHTML = rows.length ? `
    <table class="payment-table">
      <tr><th>Tarih</th><th>Tür</th><th>Kategori</th><th>Ödeme</th><th>Açıklama</th><th>Tutar</th><th>İşlem</th></tr>
      ${rows.slice(0,50).map(row => `
        <tr>
          <td>${fmtDateTime(row.time)}</td>
          <td>${typeText(row.type)}</td>
          <td>${escapeHtml(row.category)}</td>
          <td>${accountText(row)}</td>
          <td>${escapeHtml(row.note || "-")}</td>
          <td><b>${money(row.amount)}</b></td>
          <td>
            <button class="blueBtn btnSm" onclick="editAccountingEntry(${row.id})">DÜZENLE</button>
            <button class="red btnSm" onclick="voidAccountingEntry(${row.id})">SİL</button>
          </td>
        </tr>`).join("")}
    </table>` : `<div class="small" style="padding:12px;">Henüz başlangıç bakiyesi veya gider kaydı yok.</div>`;
}

function renderAccountTransfers(transfers){
  const box = document.getElementById("accountingTransferBox");
  if(!box) return;
  const accountText = account => account === "CASH" ? "Nakit Kasa" : account === "POS_BANK" ? "POS Bankası" : account === "PERSONAL_CARD" ? "Kişisel Kart Borcu" : "Ana Banka";
  box.innerHTML = transfers.length ? `<table class="payment-table">
    <tr><th>Tarih</th><th>Kaynak</th><th>Hedef</th><th>Açıklama</th><th>Tutar</th><th>İşlem</th></tr>
    ${transfers.slice(0,50).map(row => `<tr><td>${fmtDateTime(row.time)}</td><td>${accountText(row.from_account)}</td><td>${accountText(row.to_account)}</td><td>${escapeHtml(row.note || "-")}</td><td><b>${money(row.amount)}</b></td><td><button class="red btnSm" onclick="voidAccountTransfer(${row.id})">SİL</button></td></tr>`).join("")}
  </table>` : `<div class="small" style="padding:10px;">Henüz virman kaydı yok.</div>`;
}

async function addAccountTransfer(){
  const fromAccount = document.getElementById("transferFromAccount").value;
  const toAccount = document.getElementById("transferToAccount").value;
  const amount = Number(document.getElementById("transferAmount").value) || 0;
  const note = document.getElementById("transferNote").value.trim();
  if(fromAccount === toAccount){ alert("Kaynak ve hedef hesap aynı olamaz."); return; }
  if(amount <= 0){ alert("0'dan büyük tutar gir."); return; }
  if(!confirm(`${money(amount)} seçilen hesaplar arasında aktarılsın mı?`)) return;
  const d = await fetchJSON("/admin/accounting/transfer", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({fromAccount,toAccount,amount,note})});
  if(!d || !d.ok){ alert((d && d.error) || "Virman yapılamadı"); return; }
  document.getElementById("transferAmount").value = "";
  document.getElementById("transferNote").value = "";
  await Promise.all([loadAccountingSummary(),loadLiveLog()]);
}

async function voidAccountTransfer(id){
  if(!confirm("Bu virman kaydı silinsin mi? Hesap bakiyeleri eski haline döner.")) return;
  const d = await fetchJSON("/admin/accounting/transfer-void", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id})});
  if(!d || !d.ok){ alert((d && d.error) || "Virman silinemedi"); return; }
  await loadAccountingSummary();
}

async function addAccountingEntry(){
  const editId = Number(document.getElementById("accountingEditId").value) || 0;
  const type = document.getElementById("accountingType").value;
  const category = document.getElementById("accountingCategory").value.trim();
  const amount = Number(document.getElementById("accountingAmount").value) || 0;
  const account = document.getElementById("accountingAccount").value;
  const note = document.getElementById("accountingNote").value.trim();
  if(!category || amount <= 0){
    alert("Kategori ve 0'dan büyük tutar gir.");
    return;
  }
  const label = type === "EXPENSE" ? "gider" : type === "CAPITAL_IN" ? "başlangıç bakiyesi" : "bakiye düşürme";
  if(!confirm(`${money(amount)} ${label} ${editId ? "güncellensin" : "kaydedilsin"} mi?`)) return;
  const d = await fetchJSON(editId ? "/admin/accounting/update" : "/admin/accounting/add", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({ id:editId, type, category, amount, account, note })
  });
  if(!d || !d.ok){ alert((d && d.error) || "Kayıt eklenemedi"); return; }
  document.getElementById("accountingAmount").value = "";
  document.getElementById("accountingNote").value = "";
  cancelAccountingEdit();
  await Promise.all([loadAccountingSummary(), loadStats(), loadDashboardStats(), loadLiveLog()]);
}

function editAccountingEntry(id){
  const row = accountingRecentRows.find(item => Number(item.id) === Number(id));
  if(!row) return;
  const account = String(row.account || "") || (row.method === "CASH" ? "CASH" : "MAIN_BANK");
  document.getElementById("accountingEditId").value = String(row.id);
  document.getElementById("accountingType").value = row.type;
  document.getElementById("accountingCategory").value = row.category || "";
  document.getElementById("accountingAmount").value = Number(row.amount) || 0;
  document.getElementById("accountingAccount").value = account;
  document.getElementById("accountingNote").value = row.note || "";
  document.getElementById("accountingSaveBtn").textContent = "DEĞİŞİKLİĞİ KAYDET";
  document.getElementById("accountingCancelEditBtn").style.display = "inline-block";
  document.getElementById("section-accounting").scrollIntoView({behavior:"smooth",block:"start"});
}

function cancelAccountingEdit(){
  const id = document.getElementById("accountingEditId");
  if(id) id.value = "0";
  const save = document.getElementById("accountingSaveBtn");
  if(save) save.textContent = "KAYDET";
  const cancel = document.getElementById("accountingCancelEditBtn");
  if(cancel) cancel.style.display = "none";
  const category = document.getElementById("accountingCategory");
  if(category) category.value = "Kişisel Kasa Gideri";
}

async function voidAccountingEntry(id){
  if(!confirm("Bu bakiye/gider kaydı silinsin mi?")) return;
  const d = await fetchJSON("/admin/accounting/void", {
    method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ id })
  });
  if(!d || !d.ok){ alert((d && d.error) || "Kayıt iptal edilemedi"); return; }
  await Promise.all([loadAccountingSummary(), loadStats(), loadDashboardStats()]);
}

async function loadDailyPaymentComparison(){
  const box = document.getElementById("dailyPaymentComparisonBox");
  if(!box) return;
  const d = await fetchJSON("/admin/payments/daily-comparison?days=7");
  if(!d || !d.ok){
    box.innerHTML = `<div class="small statRed" style="padding:12px;">Karşılaştırma yüklenemedi.</div>`;
    return;
  }
  box.innerHTML = `
    <table class="payment-table">
      <tr><th>İş Günü (20:00)</th><th>Ürün/Hizmet</th><th>Nakit</th><th>Kart</th><th>Bekleyen</th><th>Tahsil Edilen</th></tr>
      ${(d.rows || []).map(row => `
        <tr>
          <td>${escapeHtml(row.dateLabel)}</td>
          <td><b>${money(row.productRevenue)}</b><div class="small">${Number(row.productQuantity)||0} adet</div></td>
          <td>${money(row.cash)}</td>
          <td>${money(row.card)}</td>
          <td class="${Number(row.pending) > 0 ? "statRed" : ""}">${money(row.pending)}${Number(row.pendingCount) > 0 ? ` (${row.pendingCount})` : ""}</td>
          <td><b>${money(row.collected)}</b></td>
        </tr>
      `).join("")}
    </table>`;
}

async function setPendingPaymentMethod(id, method){
  const label = method === "CASH" ? "Nakit" : "Kart";
  if(!confirm(`Bu ödeme ${label} olarak kaydedilsin mi?`)) return;
  const d = await fetchJSON("/admin/payments/set-method", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({ id, method })
  });
  if(!d || !d.ok){
    alert((d && d.error) || "Ödeme güncellenemedi");
    return;
  }
  await Promise.all([loadPaymentSummary(), loadProductSalesSummary(), loadDailyPaymentComparison(), loadCashReconciliation(), loadAccountingSummary()]);
}

async function voidProductSale(id){
  if(!confirm("Bu satış iptal edilsin mi?")) return;
  const d = await fetchJSON("/admin/product-sales/void", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({ id })
  });
  if(!d || !d.ok){
    alert((d && d.error) || "Satış iptal edilemedi");
    return;
  }
  await Promise.all([loadProductSalesSummary(), loadSessions()]);
}

function renderProductManagement(){
  const box = document.getElementById("productManagementList");
  if(!productCatalog.length){
    box.innerHTML = `<div class="small" style="padding:12px;">Ürün yok.</div>`;
    return;
  }
  box.innerHTML = `
    <table class="product-admin-table">
      <tr><th>Ürün/Hizmet</th><th>Kategori</th><th>Fiyat</th><th>Aktif</th><th>İşlem</th></tr>
      ${productCatalog.map(product => `
        <tr>
          <td><input id="productName_${product.id}" value="${escapeHtml(product.name)}"></td>
          <td><input id="productCategory_${product.id}" list="productCategoryOptions" value="${escapeHtml(product.category)}"></td>
          <td><input id="productPrice_${product.id}" type="number" min="0" step="0.01" value="${Number(product.price) || 0}"></td>
          <td><input id="productActive_${product.id}" type="checkbox" style="width:auto;transform:scale(1.2)" ${product.active ? "checked" : ""}></td>
          <td>
            <button class="greenBtn btnSm" onclick="saveProductCatalogItem(${product.id})">Kaydet</button>
            <button class="red btnSm" onclick="deleteProductCatalogItem(${product.id})">Sil</button>
          </td>
        </tr>
      `).join("")}
    </table>
  `;
}

async function saveProductCatalogItem(id){
  const name = document.getElementById(`productName_${id}`).value.trim();
  const category = document.getElementById(`productCategory_${id}`).value.trim();
  const price = Number(document.getElementById(`productPrice_${id}`).value);
  const active = document.getElementById(`productActive_${id}`).checked;
  const d = await fetchJSON("/admin/products/save", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({ id, name, category, price, active })
  });
  if(!d || !d.ok){
    alert((d && d.error) || "Ürün kaydedilemedi");
    return;
  }
  await loadProductCatalog();
}

async function addProductCatalogItem(){
  const nameEl = document.getElementById("newProductName");
  const categoryEl = document.getElementById("newProductCategory");
  const priceEl = document.getElementById("newProductPrice");
  const name = nameEl.value.trim();
  const category = categoryEl.value.trim();
  const price = Number(priceEl.value);
  if(!name || !category || !Number.isFinite(price) || price < 0){
    alert("Ürün adı, kategori ve geçerli fiyat gir.");
    return;
  }
  const d = await fetchJSON("/admin/products/save", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({ name, category, price, active:true })
  });
  if(!d || !d.ok){
    alert((d && d.error) || "Ürün eklenemedi");
    return;
  }
  nameEl.value = "";
  priceEl.value = "";
  await loadProductCatalog();
}

async function deleteProductCatalogItem(id){
  const product = productCatalog.find(x => Number(x.id) === Number(id));
  if(!confirm(`${product ? product.name : "Ürün"} silinsin mi? Eski satış kayıtları korunur.`)) return;
  const d = await fetchJSON("/admin/products/delete", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({ id })
  });
  if(!d || !d.ok){
    alert((d && d.error) || "Ürün silinemedi");
    return;
  }
  await loadProductCatalog();
}

function fmtTime(ts){
  if(!ts) return "-";
  try{
    return new Date(ts).toLocaleTimeString();
  }catch{
    return "-";
  }
}

function fmtDateTime(ts){
  if(!ts) return "-";
  try{
    return new Date(ts).toLocaleString();
  }catch{
    return "-";
  }
}

function showPendingRewardWarning(d){
  if(!d) return false;

  if(d.code === "PENDING_REWARD_APPROVAL"){
    const masa = d.pendingReward?.masa || "?";
    const reward = d.pendingReward?.reward || "ödül";

    alert(
      "⚠ Bekleyen ödül onayı var!\n\n" +
      "Masa: " + masa + "\n" +
      "Ödül: " + reward + "\n\n" +
      "Önce 'Kazanan Ödüller' bölümünden ödülü ONAYLA."
    );

    const el = document.getElementById("spinCard");
    if(el) el.scrollIntoView({behavior:"smooth", block:"start"});
    return true;
  }

  return false;
}

function getSessionStatusInfo(s){
  const isClosed = !!(s.end_time && s.end_time > 0);
  const started = !!s.started;

  let cls = "kapali";
  let durum = "Session Yok";
  let isProblem = false;

  if(s.free){
    cls = "kullanildi";
    durum = "Ücretsiz";
    return { cls, durum, isProblem, isClosed };
  }

  if(!started){
    cls = "kapali";
    durum = "Session Yok";
    return { cls, durum, isProblem, isClosed };
  }

  if(started && !s.start_time){
    cls = "kapali";
    durum = "Session Verisi Eksik";
    isProblem = true;
    return { cls, durum, isProblem, isClosed };
  }

  if(s.online){
    cls = "bagli";
    durum = s.zeroed === 1 ? "Bağlı (0₺ uygulandı)" : "Bağlı";
    if(s.zeroed === 1) isProblem = true;
    return { cls, durum, isProblem, isClosed };
  }

  if(isClosed){
    cls = "kapali";
    durum = "Normal Kapandı";
    return { cls, durum, isProblem, isClosed };
  }

  cls = "bekliyor";
  durum = "Bağlantı Koptu";
  isProblem = true;
  return { cls, durum, isProblem, isClosed };
}

function getSessionActionAdvice(s){
  const info = getSessionStatusInfo(s);

  if(s.free) return { text: "-", className: "" };
if(info.durum === "Bağlantı Koptu"){
  return { text: "YENİ MÜŞTERİ işlemi önerilir", className: "statOrange" };
}
  if(info.durum === "Bağlı (0₺ uygulandı)"){
    return { text: "Ücreti kontrol et / SESSION RESET", className: "statRed" };
  }
  if(info.durum === "Session Verisi Eksik"){
    return { text: "SESSION RESET önerilir", className: "statRed" };
  }

  return { text: "-", className: "" };
}

let freeList = [];

async function loadFreeMasalar(){
  const d = await fetchJSON("/admin/free-masalar");
  if(!d){
    document.getElementById("freeSummary").innerHTML = `<span class="statRed">Ücretsiz masalar yüklenemedi.</span>`;
    return;
  }

  freeList = d.list || [];
  uiState.freeCount = freeList.length;
  updateQuickSummary();

  const count = freeList.length;
  const summary = count > 0
    ? `Şu an <b>${count}</b> ücretsiz masa var: ` + freeList.map(m=>`<span class="pill"><b>${m}</b></span>`).join(" ")
    : `Şu an ücretsiz masa yok.`;
  document.getElementById("freeSummary").innerHTML = summary;

  const show = document.getElementById("freeShowListChk")?.checked;
  const box = document.getElementById("freeBox");
  if(!show){
    box.innerHTML = "";
    return;
  }

  const isFree = (m) => freeList.includes(m);

  box.innerHTML = `
    <div class="tableWrap">
      <table>
        <tr><th>Masa</th><th>Durum</th><th>İşlem</th></tr>
        ${Array.from({length:23}, (_,i)=>i+1).map(m=>{
          const free = isFree(m);
          return `
            <tr class="${free ? "kullanildi" : ""}">
              <td>${m}</td>
              <td>${free ? "<b>ÜCRETSİZ</b>" : "Normal"}</td>
              <td>
                ${free
                  ? `<button class="orange" onclick="setFreeMasa(${m},0)">Kapat</button>`
                  : `<button class="red" onclick="setFreeMasa(${m},1)">Ücretsiz Yap</button>`}
              </td>
            </tr>
          `;
        }).join("")}
      </table>
    </div>
  `;
}

async function setFreeMasa(masa, enabled){
  const d = await fetchJSON("/admin/free-masa",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ masa, enabled })
  });

  if(!d || !d.ok){
    alert((d && d.error) ? d.error : "İşlem başarısız");
    return;
  }

  await refreshMediumNow();
  await refreshFastNow();

}

async function quickFree(enabled){
  const inp = document.getElementById("freeMasaInput");
  const masa = parseInt(inp.value, 10);

  if(!masa || masa < 1 || masa > 23){
    alert("Masa 1-23 arası olmalı");
    return;
  }

  await setFreeMasa(masa, enabled);
  inp.value = "";
  inp.focus();
}

async function loadTodayGivenRewards(){
  const d = await fetchJSON("/admin/today-given-rewards");
  const box = document.getElementById("todayGivenRewards");

  if(!d || !d.ok){
    box.innerHTML = `<span class="statRed">Bugün verilen ödüller yüklenemedi.</span>`;
    return;
  }

  const rawList = d.list || [];
  const list = rawList.filter(x => {
    const r = String(x.reward || "").trim().toLocaleLowerCase("tr-TR");
    return r !== "şansına küs" &&
           r !== "bir dahaki sefere" &&
           r !== "tekrar dene :)";
  });

  if(!list.length){
    box.innerHTML = `<div class="small">Bugün henüz onaylanmış gerçek ödül yok.</div>`;
    return;
  }

  const total = list.reduce((a,b)=> a + (parseInt(b.adet,10) || 0), 0);

  box.innerHTML = `
    <div class="small" style="margin-bottom:8px;">Toplam verilen / onaylanan gerçek ödül: <b>${total}</b></div>
    <div class="tableWrap">
      <table>
        <tr><th>Ödül</th><th>Adet</th></tr>
        ${list.map(x=>`
          <tr>
            <td title="${escapeHtml(x.reward)}">${escapeHtml(x.reward)}</td>
            <td><b>${x.adet}</b></td>
          </tr>
        `).join("")}
      </table>
    </div>
  `;
}

async function loadTodayEmptyRewards(){
  const d = await fetchJSON("/admin/today-empty-rewards");
  const box = document.getElementById("todayEmptyRewards");

  if(!d || !d.ok){
    box.innerHTML = `<span class="statRed">Bugün boş ödüller yüklenemedi.</span>`;
    return;
  }

  const list = d.list || [];

  if(!list.length){
    box.innerHTML = `<div class="small">Bugün boş ödül çıkmamış.</div>`;
    return;
  }

  const total = list.reduce((sum, x) => sum + (parseInt(x.adet, 10) || 0), 0);

  box.innerHTML = `
    <div class="small" style="margin-bottom:8px;">
      Toplam boş sonuç: <b>${total}</b>
    </div>
    <div class="tableWrap">
      <table>
        <tr><th>Boş Sonuç</th><th>Adet</th></tr>
        ${list.map(x => `
          <tr>
            <td title="${escapeHtml(x.reward)}">${escapeHtml(x.reward)}</td>
            <td><b>${parseInt(x.adet, 10) || 0}</b></td>
          </tr>
        `).join("")}
      </table>
    </div>
  `;
}
async function loadLiveLog() {

  const d = await fetchJSON("/admin/live-log");

  const box = document.getElementById("liveLogBox");

  if (!box) return;

  if (!d || !d.ok) {
    box.innerHTML = `<span class="statRed">Log yüklenemedi.</span>`;
    return;
  }

  if (!d.list.length) {
    box.innerHTML = `<div class="small">Henüz kayıt yok.</div>`;
    return;
  }

  box.innerHTML = `
    <div class="tableWrap">
      <table>
        <tr>
          <th>Saat</th>
          <th>Olay</th>
        </tr>

        ${d.list.map(x => `
          <tr>
            <td>${new Date(x.time).toLocaleTimeString()}</td>
            <td>${escapeHtml(x.text)}</td>
          </tr>
        `).join("")}

      </table>
    </div>
  `;
}

function passesGlobalFilter() {
  return true;
}
async function loadAktifMasalar(){
  const data = await fetchJSON("/api/masalar");
  if(!data){
    document.getElementById("aktifMasalar").innerHTML = `<span class="statRed">Masalar yüklenemedi.</span>`;
    document.getElementById("aktifMasalarSummary").innerHTML = `<span class="statRed">Özet yüklenemedi.</span>`;
    document.getElementById("aktifMasalarCards").innerHTML = ``;
    return;
  }

  uiState.onlineCount = (data || []).filter(m => m.online).length;
  uiState.clientOnlineCount = uiState.onlineCount;
  uiState.clientLastDataText = new Date().toLocaleTimeString();
  uiState.readyCount = (data || []).filter(m => m.durum === 'hazir').length;

  const filtered = (data || []).filter(m => m.online);
  uiState.aktifMasaCount = filtered.length;

  const shown = filtered.filter(m => passesGlobalFilter(m.masa, false));

  document.getElementById("aktifMasalarSummary").innerHTML = `
    Toplam online: <b>${uiState.onlineCount}</b> | Ping alan masa: <b>${filtered.length}</b> | Hazır: <b>${uiState.readyCount}</b> | Gösterilen: <b>${shown.length}</b>
  `;

  if(!filtered.length){
    document.getElementById("aktifMasalar").innerHTML = "Online / ping alan masa yok";
    document.getElementById("aktifMasalarCards").innerHTML = '';
    updateQuickSummary();
    return;
  }

  document.getElementById('aktifMasalarCards').innerHTML = shown.slice(0,8).map(m=>{
    const dk = Math.floor((m.kalan || 0) / 60000);

    let stateClass = 'off';
    let stateText = 'Bağlı';

    if(m.durum === 'hazir'){
      stateClass = 'ready';
      stateText = 'Hazır';
    }else if(m.durum === 'bekliyor'){
      stateClass = dk <= 2 ? 'warn' : 'wait';
      stateText = dk <= 2 ? 'Yaklaşıyor' : 'Bekliyor';
    }else if(m.durum === 'bagli'){
      stateClass = 'off';
      stateText = 'Bağlı';
    }

    return `
      <div class="masaMiniCard">
        <div class="top">
          <div class="no">Masa ${m.masa}${isVipMasa(m.masa) ? '<span class="vipTag">VIP</span>' : ''}</div>
          <div class="state ${stateClass}">${stateText}</div>
        </div>
        <div class="meta">
          Durum: <b>${m.durum}</b><br>
          Kalan süre: <b>${m.durum === 'hazir' ? '0 dk' : (dk > 0 ? dk + ' dk' : '-')}</b><br>
          Online: <b>${m.online ? 'Evet' : 'Hayır'}</b>
        </div>
      </div>
    `;
  }).join('');

  const html = `
    <div class="tableWrap">
      <table>
        <tr><th>Masa</th><th>Kalan Süre</th><th>Çark</th><th>Durum</th><th>İşlem</th></tr>
        ${shown.map(m=>{
          const dk = Math.floor((m.kalan || 0) / 60000);

          let cls = "bagli";
          let kalanTxt = "-";
          let carkText = '<span class="statOrange">🟡 Bağlı</span>';
          let durumText = "Bağlı";

          if(m.durum === "hazir"){
            cls = "hazir";
            kalanTxt = "0 dk";
            carkText = '<span class="statGreen">🎯 Hazır</span>';
            durumText = "Hazır";
          }else if(m.durum === "bekliyor"){
            cls = "bekliyor";
            kalanTxt = dk + " dk";
            carkText = dk <= 2
              ? '<span class="statOrange">⚠️ Yaklaşıyor</span>'
              : '<span class="statBlue">⏳ Bekliyor</span>';
            durumText = "Bekliyor";
          }else if(m.durum === "bagli"){
            cls = "bagli";
            kalanTxt = "-";
            carkText = '<span class="statOrange">🟡 Bağlı</span>';
            durumText = "Süre başlatılmamış / bağlı";
          }

          return `
            <tr class="${cls}">
              <td>${m.masa}${isVipMasa(m.masa) ? '<span class="vipTag">VIP</span>' : ''}</td>
              <td>${kalanTxt}</td>
              <td>${carkText}</td>
              <td>${durumText}</td>
              <td>
                <button class="red" onclick="resetMasa(${m.masa})">Sıfırla</button>
                ${m.durum === "bekliyor" ? `<button class="orange" onclick="forceReady(${m.masa})">ACİL HAZIR</button>` : ""}
              </td>
            </tr>
          `;
        }).join("")}
      </table>
    </div>
  `;

  document.getElementById("aktifMasalar").innerHTML = html;
  updateQuickSummary();
}

async function resetMasa(masa){
  if(!confirm("Masa sıfırlansın mı?\n(Not: Bugünkü haklar da sıfırlanır)")) return;

  const d = await fetchJSON("/admin/reset-masa",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({ masa })
  });

  if(!d || !d.ok){
    if(showPendingRewardWarning(d)) return;
    alert((d && d.error) ? d.error : "Reset başarısız");
    return;
  }

  await refreshFastNow();
  await refreshMediumNow();
}

async function forceReady(masa){
  const d = await fetchJSON("/admin/force-ready",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ masa })
  });

  if(!d || !d.ok){
    alert((d && d.error) ? d.error : "Acil hazır başarısız");
    return;
  }

  alert("✅ Masa " + masa + " ACİL HAZIR yapıldı.");
  await loadAktifMasalar();
}

async function feeZero(masa){
  if(!confirm("Bu masanın ücretini şu anki değerinden 0₺ yapmak istiyor musun?")) return;

  const d = await fetchJSON("/admin/fee-zero",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ masa })
  });

  if(!d || !d.ok){
    alert((d && d.error) ? d.error : "0₺ yapma başarısız");
    return;
  }

  if(d.amount === 0){
    alert("✅ " + (d.msg || "Zaten 0₺"));
  }else{
    alert(`✅ Masa ${masa} 0₺ yapıldı (${d.amount} ₺ düzeltme)`);
  }

  await refreshFastNow();
}

async function feeAdjust(masa, amount){
  const signText = amount > 0 ? `+${amount}` : `${amount}`;
  if(!confirm(`Masa ${masa} için ${signText} ₺ manuel düzeltme uygulansın mı?`)) return;

  const d = await fetchJSON("/admin/fee-adjust",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ masa, amount })
  });

  if(!d || !d.ok){
    alert((d && d.error) ? d.error : "Manuel düzeltme başarısız");
    return;
  }

  alert(`✅ Masa ${masa} için ${signText} ₺ düzeltme işlendi.`);
  await refreshFastNow();
}

async function sessionReset(masa){
  if(isEveryCafeManualLock()){
    alert("EveryCafe aktarımı açık. SESSION RESET için önce Sistem bölümünden Bakım Modu'nu aç.");
    return;
  }
  if(!confirm("Bu masanın session'ı kapatılsın mı?\n(Bunu masayı kapattıktan sonra basman önerilir)")) return;

  const d = await fetchJSON("/admin/session-reset",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ masa })
  });

  if(!d || !d.ok){
    if(showPendingRewardWarning(d)) return;
    alert((d && d.error) ? d.error : "Session reset başarısız");
    return;
  }

  alert("✅ Masa " + masa + " session resetlendi.");
  await refreshFastNow();
  await refreshMediumNow();
}

async function yeniMusteri(masa){
  if(isEveryCafeManualLock()){
    alert("EveryCafe aktarımı açık. Masa kapanışını EveryCafe yapar. Manuel Yeni Müşteri için önce Bakım Modu'nu aç.");
    return;
  }
  const preview = await fetchJSON(`/admin/payment-preview?masa=${masa}`);
  if(!preview || !preview.ok){
    alert((preview && preview.error) || "Hesap bilgisi alınamadı");
    return;
  }

  let paymentMethod = "PENDING";
  if(Number(preview.total) > 0){
    const choice = prompt(
      `Masa ${masa} hesap özeti:\n\n` +
      `Bilgisayar: ${money(preview.computerAmount)}\n` +
      `Ürün/Hizmet: ${money(preview.productAmount)}\n` +
      `TOPLAM: ${money(preview.total)}\n\n` +
      `Nakit için N, Kart için K yaz.`,
      "N"
    );
    if(choice === null) return;
    const normalized = String(choice).trim().toLocaleUpperCase("tr-TR");
    if(normalized === "N" || normalized === "NAKİT" || normalized === "NAKIT") paymentMethod = "CASH";
    else if(normalized === "K" || normalized === "KART") paymentMethod = "CARD";
    else {
      alert("Nakit için N, Kart için K yazmalısın.");
      return;
    }
  }

if(!confirm(`Masa ${masa} için:

Toplam hesap: ${money(preview.total)}
Ödeme: ${Number(preview.total) > 0 ? (paymentMethod === "CASH" ? "NAKİT" : "KART") : "ÖDEME YOK"}

Gelir kaydedilecek, oturum kapanacak ve masa temizlenecek.

Devam edilsin mi?`)) return;
  const d = await fetchJSON("/admin/new-customer", {
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ masa, paymentMethod })
  });

  if(!d || !d.ok){
    if(showPendingRewardWarning(d)) return;
    alert((d && d.error) ? d.error : "Yeni müşteri işlemi başarısız");
    return;
  }

  alert("✅ Yeni müşteri için masa tamamen temizlendi.");
  await refreshFastNow();
  await refreshMediumNow();
}

async function hardResetMasa(masa){
  if(isEveryCafeManualLock()){
    alert("EveryCafe aktarımı açık. TAM TEMİZLE için önce Sistem bölümünden Bakım Modu'nu aç.");
    return;
  }
  if(!confirm(
    "Masa " + masa + " tamamen temizlensin mi?\n\n" +
    "Bu işlem:\n" +
    "- session kaydını siler\n" +
    "- kilitleri siler\n" +
    "- force new session kaydını siler\n" +
    "- bekleyen spinleri siler\n" +
    "- masayı veritabanından tamamen temizler\n\n" +
    "Devam edilsin mi?"
  )) return;

  const d = await fetchJSON("/admin/hard-reset-masa",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ masa })
  });

  if(!d || !d.ok){
    alert((d && d.error) ? d.error : "Tam temizleme başarısız");
    return;
  }

  alert("✅ Masa " + masa + " tamamen temizlendi.");
  await refreshFastNow();
  await refreshMediumNow();
}

function pickStat(obj, primaryKey, fallbackKey){
  if(obj && obj[primaryKey] !== undefined && obj[primaryKey] !== null) return obj[primaryKey];
  if(obj && fallbackKey && obj[fallbackKey] !== undefined && obj[fallbackKey] !== null) return obj[fallbackKey];
  return 0;
}

async function quickFreeNewCustomer(){
  const inp = document.getElementById("freeMasaInput");
  let masa = parseInt(inp.value, 10);

  // Listede yalnızca bir ücretsiz masa varsa numarayı tekrar yazmayı gerektirme.
  if((!masa || masa < 1 || masa > 23) && freeList.length === 1){
    masa = Number(freeList[0]);
  }

  if(!masa || masa < 1 || masa > 23){
    alert("Masa 1-23 arası olmalı");
    return;
  }

  if(!freeList.includes(masa)){
    alert(`Masa ${masa} şu an ücretsiz değil.`);
    return;
  }

  inp.value = String(masa);
  await yeniMusteri(masa);
}

function setHealthValue(id, text, state){
  const el = document.getElementById(id);
  if(!el) return;
  el.textContent = text;
  el.classList.remove("health-ok", "health-bad", "health-warn");
  el.classList.add(state === "ok" ? "health-ok" : state === "warn" ? "health-warn" : "health-bad");
}

function formatUptime(seconds){
  const total = Math.max(0, Number(seconds) || 0);
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  if(days) return `${days}g ${hours}sa`;
  if(hours) return `${hours}sa ${minutes}dk`;
  return `${minutes} dk`;
}

async function loadSystemHealth(){
  const d = await fetchJSON("/admin/system-health");
  if(!d){
    ["healthServer","healthDatabase","healthTelegram","healthTailscale"].forEach(id => setHealthValue(id,"Ulaşılamıyor","bad"));
    return;
  }

  setHealthValue("healthServer", d.server?.ok ? `Çalışıyor • ${formatUptime(d.server.uptimeSeconds)}` : "Sorun var", d.server?.ok ? "ok" : "bad");
  setHealthValue("healthDatabase", d.database?.ok ? "Bağlı" : "Hata", d.database?.ok ? "ok" : "bad");
  setHealthValue("healthTelegram", d.telegram?.detail || "Bilinmiyor", d.telegram?.ok ? "ok" : (d.telegram?.enabled ? "warn" : "bad"));
  setHealthValue("healthTailscale", d.tailscale?.detail || "Bilinmiyor", d.tailscale?.online ? "ok" : "warn");
}

function comparisonChangeText(percent){
  if(percent === null || percent === undefined || !Number.isFinite(Number(percent))) return "Karşılaştırma için veri yok";
  const value = Number(percent);
  if(Math.abs(value) < 0.05) return "Bugün aynı seviyede";
  return `Bugün %${Math.abs(value).toFixed(1).replace(".",",")} ${value > 0 ? "daha yüksek" : "daha düşük"}`;
}

async function loadDailyComparison(){
  const d = await fetchJSON("/admin/daily-comparison");
  if(!d || !d.ok) return;

  document.getElementById("compareToday").textContent = money(d.today?.revenue || 0);
  document.getElementById("compareYesterday").textContent = money(d.yesterday?.revenue || 0);
  document.getElementById("compareLastWeek").textContent = money(d.lastWeekSameDay?.revenue || 0);
  document.getElementById("compareTodaySessions").textContent = `${Number(d.today?.sessions || 0)} oturum`;
  document.getElementById("compareYesterdayChange").textContent = comparisonChangeText(d.versusYesterdayPercent);
  document.getElementById("compareLastWeekChange").textContent = comparisonChangeText(d.versusLastWeekPercent);

  const p = d.versusYesterdayPercent;
  const summary = document.getElementById("compareSummary");
  summary.textContent = p === null || p === undefined ? "Yeni veri" : Number(p) >= 0 ? "Yükseliş ↗" : "Düşüş ↘";
  summary.className = `value ${p === null || p === undefined ? "health-warn" : Number(p) >= 0 ? "health-ok" : "health-bad"}`;
}

async function loadDashboardStats(){

  const [d, accountingData, statsData, liveData, productData] = await Promise.all([
    fetchJSON("/admin/dashboard-stats"),
    fetchJSON("/admin/accounting/summary"),
    fetchJSON("/admin/stats"),
    fetchJSON("/debug/live"),
    fetchJSON("/admin/product-sales/summary")
  ]);
window.dashboardStats = d;
console.log(d);

  if(!d || !d.ok) return;

  document.getElementById("dashTotalSessions").textContent =
    d.totalSessions;

  const accountingToday = accountingData && accountingData.ok ? (accountingData.today || {}) : {};
  const accountingAllTime = accountingData && accountingData.ok ? (accountingData.allTime || {}) : {};
  const dashboardGeneralRevenue = accountingData && accountingData.ok ? (Number(accountingToday.genelGelir) || 0) : d.totalRevenue;
  const dashboardSessionRevenue = accountingData && accountingData.ok
    ? (Number(accountingToday.gercekGelir) || 0)
    : (Number(d.totalRevenue) || 0);
  const dashboardDirectRevenue = productData && productData.ok
    ? (Number(productData.directTotal) || 0)
    : 0;
  const dashboardEveryCafeDirectRevenue = productData && productData.ok
    ? (Number(productData.everyCafeDirectTotal) || 0)
    : 0;
  const dashboardEveryCafeMemberRevenue = productData && productData.ok
    ? (Number(productData.everyCafeMemberTotal) || 0)
    : 0;
  const dashboardProductRevenue = productData && productData.ok
    ? Math.max(0, (Number(productData.total) || 0) - dashboardDirectRevenue - dashboardEveryCafeDirectRevenue - dashboardEveryCafeMemberRevenue)
    : 0;
  const dashboardDirectSaleCount = productData && productData.ok
    ? (productData.list || []).filter(sale => sale.sale_type === "DIRECT" && !["EVERYCAFE_DIRECT", "EVERYCAFE_MEMBER"].includes(String(sale.external_source || ""))).length
    : 0;
  const dashboardAverageAccount = dashboardGeneralRevenue /
    Math.max(1, (Number(d.totalSessions) || 0) + dashboardDirectSaleCount);
  const dashboardAllSessionRevenue = accountingData && accountingData.ok
    ? (Number(accountingAllTime.gercekGelir) || 0)
    : (Number(d.allTimeRevenue) || 0);
  const dashboardAllDirectRevenue = productData && productData.ok
    ? (Number(productData.allTimeDirectTotal) || 0)
    : 0;
  // EveryCafe ciroyu manuel KafePin doğrudan satışından ayırmak için
  // bu iki değer yalnızca bilgilendirme/karşılaştırma kartlarında kullanılır.
  const everyCafeTodayRevenue = Math.max(0, dashboardGeneralRevenue - dashboardDirectRevenue);
  const everyCafeAllTimeRevenue = Math.max(0, (accountingData && accountingData.ok ? Number(accountingAllTime.genelGelir) || 0 : Number(d.allTimeRevenue) || 0) - dashboardAllDirectRevenue);
  const dashboardAllProductRevenue = accountingData && accountingData.ok
    ? Math.max(0, (Number(accountingAllTime.productGeliri) || 0) - dashboardAllDirectRevenue)
    : 0;
  const dashboardExpense = Number(accountingToday.giderler) || 0;
  const dashboardNet = accountingData && accountingData.ok ? (Number(accountingToday.netIsletmeSonucu) || 0) : dashboardGeneralRevenue;
  // Genel ciro kartı, KafePin'deki bütün gelirleri gösterir. EveryCafe ile
  // birebir karşılaştırma ise Ürün/Satış Geçmişi alanında, doğrudan satışlar
  // hariç ayrı olarak gösterilir.
  const dashboardAllRevenue = accountingData && accountingData.ok
    ? (Number(accountingAllTime.genelGelir) || 0)
    : (Number(d.allTimeRevenue) || 0);
  const dashboardAllExpense = Number(accountingAllTime.giderler) || 0;
  const dashboardAllNet = accountingData && accountingData.ok ? (Number(accountingAllTime.netIsletmeSonucu) || 0) : dashboardAllRevenue;
  d.totalRevenue = dashboardGeneralRevenue;
  d.allTimeRevenue = dashboardAllRevenue;
  document.getElementById("dashRevenue").textContent = money(dashboardGeneralRevenue);
  document.getElementById("dashSessionRevenue").textContent = money(dashboardSessionRevenue);
  document.getElementById("dashTableProductRevenue").textContent = money(dashboardProductRevenue);
  document.getElementById("dashDirectRevenue").textContent = money(dashboardDirectRevenue);
  document.getElementById("dashTodayProductQuantity").textContent = Number(productData?.todayQuantity) || 0;
  document.getElementById("dashTodayDirectSaleCount").textContent = dashboardDirectSaleCount;
  document.getElementById("dashTodayAverageAccount").textContent = money(dashboardAverageAccount);
  document.getElementById("dashTodayExpense").textContent = money(dashboardExpense);
  const netEl = document.getElementById("dashTodayNetProfit");
  netEl.textContent = money(dashboardNet);
  netEl.classList.toggle("statRed", dashboardNet < 0);
  netEl.classList.toggle("statGreen", dashboardNet >= 0);
  const dashboardAllNetEl = document.getElementById("dashAllTimeNetProfit");
  dashboardAllNetEl.textContent = money(dashboardAllNet);
  dashboardAllNetEl.classList.toggle("statRed", dashboardAllNet < 0);
  dashboardAllNetEl.classList.toggle("statGreen", dashboardAllNet >= 0);
  const todaySpinCount = Number(statsData?.bugunToplam) || 0;
  const approvedRewardCount = Number(statsData?.bugunOnaylananOdul) || 0;
  const todaySpinCost = Number(statsData?.bugunSpinMaliyeti ?? statsData?.bugunMaliyet) || 0;
  const lastHourRevenue = Number(liveData?.thisHourRevenue) || 0;
  const dailyGoalPercent = Math.max(0, Math.round((dashboardGeneralRevenue / HEDEF) * 100));
  document.getElementById("dashTodaySpins").textContent = todaySpinCount;
  document.getElementById("dashTodayApprovedRewards").textContent = approvedRewardCount;
  document.getElementById("dashTodaySpinCost").textContent = money(todaySpinCost);
  document.getElementById("dashLastHourRevenue").textContent = money(lastHourRevenue);
  document.getElementById("dashDailyGoal").textContent = `${dailyGoalPercent}%`;
  document.getElementById("dashDailyGoalAmount").textContent = `${money(dashboardGeneralRevenue)} / ${money(HEDEF)}`;

  document.getElementById("dashAvgFee").textContent =
    money(d.avgFee);

  document.getElementById("dashAvgMinutes").textContent =
    Math.round(d.avgMinutes) + " dk";

  document.getElementById("dashBusy").textContent =
    d.busiestTable
      ? "Masa " + d.busiestTable + " (" + Math.round(d.busiestMinutes || 0) + " dk)"
      : "-";

  document.getElementById("dashBestRevenue").textContent =
    d.bestRevenueTable
      ? "Masa " + d.bestRevenueTable + " (" + money(d.bestRevenue) + ")"
      : "-";
document.getElementById("onlineCount").textContent =
    d.onlineCount;

document.getElementById("freeCount").textContent =
    d.freeCount;
// ===== Tüm Zamanlar =====

document.getElementById("allTimeSessions").textContent =
    d.allTimeSessions;

document.getElementById("allTimeRevenue").textContent =
    money(d.allTimeRevenue);
document.getElementById("allTimeProductRevenue").textContent = money(accountingAllTime.productGeliri);
document.getElementById("allTimeCashCollected").textContent = money(accountingAllTime.nakitOdeme);
document.getElementById("allTimeCardCollected").textContent = money(accountingAllTime.kartOdeme);
document.getElementById("allTimeCardCommission").textContent = money(accountingAllTime.kartKomisyonu);

document.getElementById("allTimeAvgFee").textContent =
    money(d.allTimeAvgFee);

document.getElementById("allTimeAvgMinutes").textContent =
    Math.round(d.allTimeAvgMinutes) + " dk";

document.getElementById("allTimeBusy").textContent =
    d.allTimeBusyTable
      ? "Masa " + d.allTimeBusyTable + " (" + d.allTimeBusyCount + ")"
      : "-";

document.getElementById("allTimeBestRevenue").textContent =
    d.allTimeBestRevenueTable
      ? "Masa " + d.allTimeBestRevenueTable + " (" + money(d.allTimeBestRevenue) + ")"
      : "-";

document.getElementById("allTimeMaxFee").textContent =
    money(d.allTimeMaxFee);

document.getElementById("longestSession").textContent =
    d.longestSessionTable
      ? "Masa " + d.longestSessionTable + " (" + d.longestSessionMinutes + " dk)"
      : "-";

document.getElementById("thisMonthRevenue").textContent =
    money(d.thisMonthRevenue);

document.getElementById("last30Revenue").textContent =
    money(d.last30Revenue);

document.getElementById("bestDailyRevenue").textContent =
    d.bestDailyRevenue
      ? money(d.bestDailyRevenue) + " (" + d.bestDailyRevenueDate + ")"
      : "-";

document.getElementById("avgLeader").textContent =
    d.avgLeaderTable
      ? "Masa " + d.avgLeaderTable + " (" + d.avgLeaderMinutes + " dk)"
      : "-";
// ===== Üst Bilgi Çubuğu =====

document.getElementById("gelirChip").textContent =
    money(d.allTimeRevenue);
document.getElementById("sessionChip").textContent =
    d.allTimeSessions + " Oturum";

document.getElementById("masaChip").textContent =
    "🟢 " + d.onlineCount + " Online • 🔴 " + d.offlineCount + " Offline";
document.getElementById("allTimeSessions").textContent =
    d.allTimeSessions;

document.getElementById("allTimeRevenue").textContent =
    money(d.allTimeRevenue);

document.getElementById("allTimeAvgFee").textContent =
    money(d.allTimeAvgFee);

document.getElementById("allTimeAvgMinutes").textContent =
    Math.round(d.allTimeAvgMinutes) + " dk";

document.getElementById("allTimeBusy").textContent =
    d.allTimeBusyTable
      ? "Masa " + d.allTimeBusyTable + " (" + d.allTimeBusyCount + ")"
      : "-";

document.getElementById("allTimeBestRevenue").textContent =
    d.allTimeBestRevenueTable
      ? "Masa " + d.allTimeBestRevenueTable + " (" + money(d.allTimeBestRevenue) + ")"
      : "-";

document.getElementById("allTimeMaxFee").textContent =
    money(d.allTimeMaxFee);
document.getElementById("longestSession").textContent =
    d.longestSessionTable
        ? "Masa " + d.longestSessionTable + " (" +
          Math.floor(d.longestSessionMinutes / 60) + "s " +
          (d.longestSessionMinutes % 60) + "dk)"
        : "-";

document.getElementById("thisMonthRevenue").textContent =
    money(d.thisMonthRevenue);

document.getElementById("last30Revenue").textContent =
    money(d.last30Revenue);
document.getElementById("bestDailyRevenue").innerHTML =
    d.bestDailyRevenue > 0
        ? `<div>${money(d.bestDailyRevenue)}</div>
           <small style="font-size:12px;color:#888;">${d.bestDailyRevenueDate}</small>`
        : "-";
document.getElementById("avgLeader").innerHTML =
    d.avgLeaderTable
        ? `<div>Masa ${d.avgLeaderTable}</div>
           <small style="font-size:12px;color:#888;">${d.avgLeaderMinutes} dk ort.</small>`
        : "-";
document.getElementById("allTimeRevenue").textContent = money(dashboardAllRevenue);
document.getElementById("allTimeSessionRevenue").textContent = money(dashboardAllSessionRevenue);
document.getElementById("allTimeTableProductRevenue").textContent = money(dashboardAllProductRevenue);
document.getElementById("allTimeDirectRevenue").textContent = money(dashboardAllDirectRevenue);
document.getElementById("allTimeProductQuantity").textContent = Number(productData?.allTimeQuantity) || 0;
const allTimeProductShare = dashboardAllRevenue > 0
  ? ((Number(accountingAllTime.productGeliri) || 0) / dashboardAllRevenue) * 100
  : 0;
const allTimeSessionShare = dashboardAllRevenue > 0
  ? (dashboardAllSessionRevenue / dashboardAllRevenue) * 100
  : 0;
document.getElementById("allTimeProductShare").textContent = `${allTimeProductShare.toFixed(1)}%`;
document.getElementById("allTimeSessionShare").textContent = `${allTimeSessionShare.toFixed(1)}%`;
document.getElementById("allTimeExpense").textContent = money(dashboardAllExpense);
const allNetEl = document.getElementById("allTimeNetProfit");
allNetEl.textContent = money(dashboardAllNet);
allNetEl.classList.toggle("statRed", dashboardAllNet < 0);
}
function openDashboardModal(type){

    const d = window.dashboardStats || {};

    const title = document.getElementById("dashModalTitle");
    const body = document.getElementById("dashModalBody");

    if(!title || !body || !dashModal) return;

    switch(type){

case "revenue":

    title.innerHTML = "💰 Toplam Gelir";

    body.innerHTML = `
        <div style="font-size:36px;font-weight:bold;color:#2ecc71;margin-bottom:18px;">
            ${money(d.allTimeRevenue || 0)}
        </div>

        <hr style="border-color:#2b3648">

        <p><b>💵 Bugünkü Gelir:</b> ${money(d.totalRevenue || 0)}</p>

        <p><b>🏆 Tüm Zamanlar Gelir:</b> ${money(d.allTimeRevenue || 0)}</p>

        <p><b>📅 Bu Ay:</b> ${money(d.thisMonthRevenue || 0)}</p>

        <p><b>📈 Son 30 Gün:</b> ${money(d.last30Revenue || 0)}</p>

        <p><b>🎮 Toplam Oturum:</b> ${d.allTimeSessions || 0}</p>

        <p><b>💎 En Yüksek Masa Geliri:</b> ${money(d.allTimeMaxFee || 0)}</p>
    `;

    break;

        case "sessions":

            title.innerHTML = "🎮 Toplam Oturum";

            body.innerHTML = `
<div style="font-size:36px;font-weight:bold;color:#7d8bff;margin-bottom:18px;">
    ${d.allTimeSessions || 0}
</div>

<hr>

<p><b>Bugünkü:</b> ${d.totalSessions || 0}</p>
<p><b>Ortalama Ücret:</b> ${money(d.allTimeAvgFee || 0)}</p>
<p><b>Ortalama Süre:</b> ${Math.round(d.allTimeAvgMinutes || 0)} dk</p>

                <hr style="border-color:#2b3648">

                <p><b>Ortalama Ücret:</b> ${money(d.avgFee || 0)}</p>
                <p><b>Ortalama Süre:</b> ${Math.round(d.avgMinutes || 0)} dk</p>
            `;
            break;

case "avgFee":

    title.innerHTML = "📊 Ortalama Ücret";

    body.innerHTML = `
        <div style="font-size:36px;font-weight:bold;color:#4aa3ff;margin-bottom:18px;">
            ${money(d.allTimeAvgFee || 0)}
        </div>

        <hr style="border-color:#2b3648">

        <p><b>Bugünkü Ortalama:</b> ${money(d.avgFee || 0)}</p>
        <p><b>Tüm Zamanlar Ortalama:</b> ${money(d.allTimeAvgFee || 0)}</p>
    `;
    break;

        case "avgMinute":

            title.innerHTML = "⏱ Ortalama Süre";

            body.innerHTML = `
                <div style="font-size:36px;font-weight:bold;color:#c78cff;margin-bottom:18px;">
                    ${Math.round(d.avgMinutes || 0)} dk
                </div>

                <hr style="border-color:#2b3648">

                <p><b>Bugünkü Ortalama:</b> ${Math.round(d.avgMinutes || 0)} dk</p>
                <p><b>Tüm Zamanlar Ortalama:</b> ${Math.round(d.allTimeAvgMinutes || 0)} dk</p>
                <p><b>En Uzun Oturum:</b> ${d.longestSessionMinutes || 0} dk</p>
            `;
            break;

        case "busy":

            title.innerHTML = "🏆 En Yoğun Masa";

            body.innerHTML = `
                <div style="font-size:34px;font-weight:bold;color:#ffb347;margin-bottom:15px;">
                    Masa ${d.allTimeBusyTable || "-"}
                </div>

                <hr style="border-color:#2b3648">

                <p><b>Tüm Zamanlar Oturum:</b> ${d.allTimeBusyCount || 0}</p>
                <p><b>Bugünkü Lider:</b> Masa ${d.busiestTable || "-"} (${d.busiestCount || 0} oturum)</p>
            `;
            break;


case "bestRevenue":

    title.innerHTML = "💵 En Çok Kazandıran Masa";

    body.innerHTML = `
        <div style="font-size:34px;font-weight:bold;color:#2ecc71;margin-bottom:15px;">
            Masa ${d.allTimeBestRevenueTable || "-"}
        </div>

        <hr style="border-color:#2b3648">

        <p><b>Tüm Zamanlar Gelir:</b> ${money(d.allTimeBestRevenue || 0)}</p>
        <p><b>Bugünkü Lider:</b> Masa ${d.bestRevenueTable || "-"} (${money(d.bestRevenue || 0)})</p>
    `;
    break;


case "online":

    title.innerHTML = "🟢 Online Masalar";

    body.innerHTML = `
        <div style="font-size:40px;font-weight:bold;color:#2ecc71;margin-bottom:15px;">
            ${d.onlineCount || 0}
        </div>

        <hr style="border-color:#2b3648">

        ${
            d.onlineMasalar?.length
                ? d.onlineMasalar.map(m => `
                    <div class="dashRow">🟢 Masa ${m}</div>
                  `).join("")
                : "<i>Online masa yok.</i>"
        }
    `;
    break;
case "maxFee":

    title.innerHTML = "💎 En Yüksek Masa Geliri";

    body.innerHTML = `
        <div style="font-size:36px;font-weight:bold;color:#4aa3ff;margin-bottom:18px;">
            ${money(d.allTimeMaxFee || 0)}
        </div>

        <hr style="border-color:#2b3648">

        <p><b>Tüm Zamanlar En Yüksek Masa Geliri:</b> ${money(d.allTimeMaxFee || 0)}</p>

        <p class="small">Oturum ücreti + o oturumda masaya eklenen ürünler.</p>

        <p><b>Ortalama Ücret:</b> ${money(d.allTimeAvgFee || 0)}</p>

        <p><b>Toplam Gelir:</b> ${money(d.allTimeRevenue || 0)}</p>
    `;
    break;


case "offline":

    title.innerHTML = "🔴 Offline Masalar";

    body.innerHTML = `
        <div style="font-size:40px;font-weight:bold;color:#ff5a5a;margin-bottom:15px;">
            ${d.offlineCount || 0}
        </div>

        <hr style="border-color:#2b3648">

        ${
            d.offlineMasalar?.length
                ? d.offlineMasalar.map(m => `
                    <div class="dashRow">🔴 Masa ${m}</div>
                  `).join("")
                : "<i>Offline masa yok.</i>"
        }
    `;
    break;


case "free":

    title.innerHTML = "🆓 Ücretsiz Masalar";

    body.innerHTML = `
        <div style="
            font-size:42px;
            font-weight:bold;
            color:#4aa3ff;
            margin-bottom:18px;
            text-align:center;
        ">
            ${d.freeCount || 0}
        </div>

        <hr style="border-color:#2b3648">

        <div style="line-height:1.9;font-size:15px;">

            <p>🆓 <b>Toplam Ücretsiz Masa:</b> ${d.freeCount || 0}</p>

            <p>🟢 <b>Online Ücretli Masa:</b> ${d.onlineCount || 0}</p>

            <p>🔴 <b>Offline Ücretli Masa:</b> ${d.offlineCount || 0}</p>

            <p>🎮 <b>Toplam Oturum:</b> ${d.allTimeSessions || 0}</p>

            <p>💰 <b>Toplam Gelir:</b> ${money(d.allTimeRevenue || 0)}</p>

        </div>
    `;

    break;
case "longestSession":

    title.innerHTML = "🔥 En Uzun Oturum";

    body.innerHTML = `
        <div style="font-size:34px;font-weight:bold;color:#ff6b6b;margin-bottom:15px;">
            ${d.longestSessionMinutes || 0} dk
        </div>

        <hr style="border-color:#2b3648">

        <p><b>Masa:</b> ${d.longestSessionTable || "-"}</p>
    `;
    break;

case "thisMonthRevenue":

    title.innerHTML = "📅 Bu Ay Geliri";

    body.innerHTML = `
        <div style="font-size:36px;font-weight:bold;color:#2ecc71">
            ${money(d.thisMonthRevenue || 0)}
        </div>
    `;
    break;

case "last30Revenue":

    title.innerHTML = "📈 Son 30 Gün";

    body.innerHTML = `
        <div style="font-size:36px;font-weight:bold;color:#4aa3ff">
            ${money(d.last30Revenue || 0)}
        </div>
    `;
    break;

case "bestDailyRevenue":

    title.innerHTML = "🥇 Rekor Günlük Gelir";

    body.innerHTML = `
        <div style="font-size:36px;font-weight:bold;color:#ffb347">
            ${money(d.bestDailyRevenue || 0)}
        </div>

        <hr style="border-color:#2b3648">

        <p>${d.bestDailyRevenueDate || "-"}</p>
    `;
    break;

case "avgLeader":

    title.innerHTML = "⏱ Ortalama Süre Lideri";

    body.innerHTML = `
        <div style="font-size:34px;font-weight:bold;color:#b388ff">
            Masa ${d.avgLeaderTable || "-"}
        </div>

        <hr style="border-color:#2b3648">

        <p>Ortalama Süre: ${d.avgLeaderMinutes || 0} dk</p>
    `;
    break;
        default:

            title.innerHTML = "Bilgi";

            body.innerHTML = `
                <div style="font-size:18px;">
                    Bu kart için detay ekranı hazırlanıyor.
                </div>
            `;
    }

    dashModal.classList.add("show");
}
async function loadStats(){
  const [s, productData, paymentData, accountingData] = await Promise.all([
    fetchJSON("/admin/stats"),
    fetchJSON("/admin/product-sales/summary"),
    fetchJSON("/admin/payments/summary"),
    fetchJSON("/admin/accounting/summary")
  ]);
  if(!s){
    document.getElementById("stats").innerHTML =
      `<span class="statRed">İstatistik yüklenemedi.</span>`;
    return;
  }

  const brutToplam = pickStat(s, "brutGelir", "realBrutGelir");
  const brutBugun = pickStat(s, "bugunBrutGelir", "bugunRealBrutGelir");
  const brutDun = pickStat(s, "dunBrutGelir", "dunRealBrutGelir");
  const brutHafta = pickStat(s, "haftaBrutGelir", "haftaRealBrutGelir");
  const brutAy = pickStat(s, "ayBrutGelir", "ayRealBrutGelir");

  const adminToplam = pickStat(s, "adminDuzeltmeleri", null);
  const adminBugun = pickStat(s, "bugunAdminDuzeltmeleri", null);
  const adminDun = pickStat(s, "dunAdminDuzeltmeleri", null);
  const adminHafta = pickStat(s, "haftaAdminDuzeltmeleri", null);
  const adminAy = pickStat(s, "ayAdminDuzeltmeleri", null);

  const spinToplam = pickStat(s, "spinMaliyeti", "spinCostTotal");
  const spinBugun = pickStat(s, "bugunSpinMaliyeti", "spinCostToday");
  const spinDun = pickStat(s, "dunSpinMaliyeti", "spinCostYesterday");
  const spinHafta = pickStat(s, "haftaSpinMaliyeti", "spinCostWeek");
  const spinAy = pickStat(s, "aySpinMaliyeti", "spinCostMonth");

  const gercekToplam = pickStat(s, "gercekGelir", "realGelir");
  const gercekBugun = pickStat(s, "bugunGercekGelir", "bugunRealGelir");
  const gercekDun = pickStat(s, "dunGercekGelir", "dunRealGelir");
  const gercekHafta = pickStat(s, "haftaGercekGelir", "haftaRealGelir");
  const gercekAy = pickStat(s, "ayGercekGelir", "ayRealGelir");

  const productToday = productData && productData.ok ? (Number(productData.total) || 0) : 0;
  const productAllTime = productData && productData.ok ? (Number(productData.allTimeTotal) || 0) : 0;
  const productTodayQuantity = productData && productData.ok ? (Number(productData.todayQuantity) || 0) : 0;
  const productAllTimeQuantity = productData && productData.ok ? (Number(productData.allTimeQuantity) || 0) : 0;
  const generalToday = gercekBugun + productToday;
  const generalAllTime = gercekToplam + productAllTime;
  const todayCash = paymentData && paymentData.ok ? (Number(paymentData.todayCash) || 0) : 0;
  const todayCard = paymentData && paymentData.ok ? (Number(paymentData.todayCard) || 0) : 0;
  const todayPending = paymentData && paymentData.ok ? (Number(paymentData.todayPending) || 0) : 0;
  const allTimeCash = paymentData && paymentData.ok ? (Number(paymentData.allTimeCash) || 0) : 0;
  const allTimeCard = paymentData && paymentData.ok ? (Number(paymentData.allTimeCard) || 0) : 0;
  const allTimePending = paymentData && paymentData.ok ? (Number(paymentData.allTimePending) || 0) : 0;
  const accountingTodayStats = accountingData && accountingData.ok ? (accountingData.today || {}) : {};
  const accountingMonthStats = accountingData && accountingData.ok ? (accountingData.month || {}) : {};
  const accountingAllStats = accountingData && accountingData.ok ? (accountingData.allTime || {}) : {};
  const expenseToday = Number(accountingTodayStats.giderler) || 0;
  const expenseMonth = Number(accountingMonthStats.giderler) || 0;
  const expenseAllTime = Number(accountingAllStats.giderler) || 0;
  const commissionToday = Number(accountingTodayStats.kartKomisyonu) || 0;
  const commissionMonth = Number(accountingMonthStats.kartKomisyonu) || 0;
  const commissionAllTime = Number(accountingAllStats.kartKomisyonu) || 0;
  const netResultToday = accountingData && accountingData.ok ? (Number(accountingTodayStats.netIsletmeSonucu) || 0) : generalToday;
  const netResultMonth = accountingData && accountingData.ok ? (Number(accountingMonthStats.netIsletmeSonucu) || 0) : 0;
  const netResultAllTime = accountingData && accountingData.ok ? (Number(accountingAllStats.netIsletmeSonucu) || 0) : generalAllTime;

  uiState.bugunNet = generalToday || 0;
  updateQuickSummary();

  const netKar = s.kar || 0;
  const bugunKar = s.bugunKar || 0;
  const karClass = netKar >= 0 ? "statGreen" : "statRed";
  const bugunKarClass = bugunKar >= 0 ? "statGreen" : "statRed";
  const testTag = s.testMode ? `<span class="vipTag">TEST</span>` : "";

 
  document.getElementById("stats").innerHTML = `
  <div class="kpiRow">
    <div class="kpi">
      <div class="kpiLabel">Gider (Bugün)</div>
      <div class="kpiValue statRed">${money(expenseToday)}</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Net Sonuç (Bugün)</div>
      <div class="kpiValue ${netResultToday >= 0 ? 'statGreen' : 'statRed'}">${money(netResultToday)}</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Gider (Bu Ay)</div>
      <div class="kpiValue statRed">${money(expenseMonth)}</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Net Sonuç (Bu Ay)</div>
      <div class="kpiValue ${netResultMonth >= 0 ? 'statGreen' : 'statRed'}">${money(netResultMonth)}</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Masa Geliri (Bugün)</div>
      <div class="kpiValue statGreen">${money(gercekBugun)}</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Masa Geliri (Tüm Zamanlar)</div>
      <div class="kpiValue statGreen">${money(gercekToplam)}</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Ürün/Hizmet Geliri (Bugün)</div>
      <div class="kpiValue statBlue">${money(productToday)}</div>
      <div class="small">${productTodayQuantity} adet</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Ürün/Hizmet (Tüm Zamanlar)</div>
      <div class="kpiValue statBlue">${money(productAllTime)}</div>
      <div class="small">${productAllTimeQuantity} adet</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Genel Gelir (Bugün)</div>
      <div class="kpiValue statGreen">${money(generalToday)}</div>
      <div class="small">Masa + ürün/hizmet</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Genel Gelir (Tüm Zamanlar)</div>
      <div class="kpiValue statGreen">${money(generalAllTime)}</div>
      <div class="small">Masa + ürün/hizmet</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Nakit Tahsilat (Bugün)</div>
      <div class="kpiValue statGreen">${money(todayCash)}</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Kart Tahsilat (Bugün)</div>
      <div class="kpiValue statBlue">${money(todayCard)}</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Bekleyen Ödeme</div>
      <div class="kpiValue ${todayPending > 0 ? 'statRed' : 'statGreen'}">${money(todayPending)}</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Brüt Gelir (Bugün)</div>
      <div class="kpiValue statBlue">${money(brutBugun)}</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Admin Düzeltmesi (Bugün)</div>
      <div class="kpiValue ${adminBugun >= 0 ? 'statGreen' : 'statRed'}">${money(adminBugun)}</div>
    </div>
    <div class="kpi">
<div class="kpiLabel">Çark Maliyeti (Bugün)</div>
<div class="kpiValue statOrange">${money(s.bugunMaliyet || 0)}</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Bugün Spin</div>
      <div class="kpiValue">${parseInt(s.bugunToplam || 0,10)}</div>
    </div>
    <div class="kpi">
      <div class="kpiLabel">Net Kâr Marjı (Tüm Zamanlar)</div>
      <div class="kpiValue ${netResultAllTime >= 0 ? 'statGreen' : 'statRed'}">${generalAllTime > 0 ? ((netResultAllTime / generalAllTime) * 100).toFixed(1) : '0.0'}%</div>
    </div>
  </div>

      <hr>

<b>🎰 ÇARK ÖZETİ</b><br><br>

<b>Toplam Spin:</b> ${s.toplam || 0}<br>
<b>Bugünkü Spin:</b> ${s.bugunToplam || 0}<br>
<b>İçecek Ödülü:</b> ${s.icecek || 0}<br>
<b>Süre Ödülü:</b> ${s.dakika || 0}<br><br>

<b>Çark Geliri (Toplam):</b>
<span class="statBlue">${money(s.gelir || 0)}</span><br>

<b>Çark Geliri (Bugün):</b>
<span class="statBlue">${money(s.bugunGelir || 0)}</span><br><br>

<b>Çark Maliyeti (Toplam):</b>
<span class="statOrange">${money(s.toplamMaliyet || 0)}</span><br>

<b>Çark Maliyeti (Bugün):</b>
<span class="statOrange">${money(s.bugunMaliyet || 0)}</span><br><br>

<b>Çark Net Kar (Toplam):</b>
<span class="${karClass}">${money(netKar)}</span><br>

<b>Çark Net Kar (Bugün):</b>
<span class="${bugunKarClass}">${money(bugunKar)}</span><br>

<hr>

<b>💰 MASA GELİRİ</b><br><br>

<b>Brüt Gelir (Bugün):</b>
<span class="statBlue">${money(brutBugun)}</span><br>

<b>Brüt Gelir (Dün):</b>
<span class="statBlue">${money(brutDun)}</span><br>

<b>Brüt Gelir (Bu Hafta):</b>
<span class="statBlue">${money(brutHafta)}</span><br>

<b>Brüt Gelir (Bu Ay):</b>
<span class="statBlue">${money(brutAy)}</span><br><br>

<b>Admin Düzeltmesi (Bugün):</b>
<span class="${adminBugun >= 0 ? 'statGreen' : 'statRed'}">${money(adminBugun)}</span><br>

<b>Admin Düzeltmesi (Dün):</b>
<span class="${adminDun >= 0 ? 'statGreen' : 'statRed'}">${money(adminDun)}</span><br>

<b>Admin Düzeltmesi (Bu Hafta):</b>
<span class="${adminHafta >= 0 ? 'statGreen' : 'statRed'}">${money(adminHafta)}</span><br>

<b>Admin Düzeltmesi (Bu Ay):</b>
<span class="${adminAy >= 0 ? 'statGreen' : 'statRed'}">${money(adminAy)}</span><br><br>

<b>Masa Gerçek Geliri (Bugün):</b>
<span class="statGreen">${money(gercekBugun)}</span><br>

<b>Masa Gerçek Geliri (Dün):</b>
<span class="statGreen">${money(gercekDun)}</span><br>

<b>Masa Gerçek Geliri (Bu Hafta):</b>
<span class="statGreen">${money(gercekHafta)}</span><br>

<b>Masa Gerçek Geliri (Bu Ay):</b>
<span class="statGreen">${money(gercekAy)}</span><br><br>

<hr>

<b>🛒 ÜRÜN / HİZMET GELİRİ</b><br><br>

<b>Ürün/Hizmet Geliri (Bugün):</b>
<span class="statBlue">${money(productToday)}</span>
<span class="small">• ${productTodayQuantity} adet</span><br>

<b>Ürün/Hizmet Geliri (Tüm Zamanlar):</b>
<span class="statBlue">${money(productAllTime)}</span>
<span class="small">• ${productAllTimeQuantity} adet</span><br><br>

<hr>

<b>💰 GENEL GELİR</b><br><br>

<b>Genel Gelir (Bugün):</b>
<span class="statGreen">${money(generalToday)}</span><br>

<b>Genel Gelir (Tüm Zamanlar):</b>
<span class="statGreen">${money(generalAllTime)}</span><br>

<span class="small">Genel Gelir = Masa Gerçek Geliri + Ürün/Hizmet Geliri</span><br><br>

<hr>

<b>🧾 KASA / TAHSİLAT</b><br><br>

<b>Nakit (Bugün):</b> <span class="statGreen">${money(todayCash)}</span><br>
<b>Kart (Bugün):</b> <span class="statBlue">${money(todayCard)}</span><br>
<b>Tahsil Edilen (Bugün):</b> <span class="statGreen">${money(todayCash + todayCard)}</span><br>
<b>Bekleyen (Bugün):</b> <span class="${todayPending > 0 ? 'statRed' : 'statGreen'}">${money(todayPending)}</span><br><br>

<b>Nakit (Tüm Zamanlar):</b> <span class="statGreen">${money(allTimeCash)}</span><br>
<b>Kart (Tüm Zamanlar):</b> <span class="statBlue">${money(allTimeCard)}</span><br>
<b>Tahsil Edilen (Tüm Zamanlar):</b> <span class="statGreen">${money(allTimeCash + allTimeCard)}</span><br>
<b>Bekleyen (Tüm Zamanlar):</b> <span class="${allTimePending > 0 ? 'statRed' : 'statGreen'}">${money(allTimePending)}</span><br><br>

<hr>

<b>📊 GİDER / NET KÂR ÖZETİ</b><br><br>

<b>Gider (Bugün):</b> <span class="statRed">${money(expenseToday)}</span><br>
<b>Kart Komisyonu (Bugün):</b> <span class="statOrange">${money(commissionToday)}</span><br>
<b>Net Kâr (Bugün):</b> <span class="${netResultToday >= 0 ? 'statGreen' : 'statRed'}">${money(netResultToday)}</span><br><br>

<b>Gider (Bu Ay):</b> <span class="statRed">${money(expenseMonth)}</span><br>
<b>Kart Komisyonu (Bu Ay):</b> <span class="statOrange">${money(commissionMonth)}</span><br>
<b>Net Kâr (Bu Ay):</b> <span class="${netResultMonth >= 0 ? 'statGreen' : 'statRed'}">${money(netResultMonth)}</span><br><br>

<b>Gider (Tüm Zamanlar):</b> <span class="statRed">${money(expenseAllTime)}</span><br>
<b>Kart Komisyonu (Tüm Zamanlar):</b> <span class="statOrange">${money(commissionAllTime)}</span><br>
<b>Net Kâr (Tüm Zamanlar):</b> <span class="${netResultAllTime >= 0 ? 'statGreen' : 'statRed'}">${money(netResultAllTime)}</span><br><br>

<div class="small">
  Formül:<br>
  <b>Gerçek Gelir = Brüt Gelir + Admin Düzeltmeleri - Çark Maliyeti</b><br>
  <b>Net Kâr = Masa Gerçek Geliri + Ürün/Hizmet Geliri - Giderler - Kart Komisyonu</b>
</div>

      <div class="small" style="margin-top:6px;">Aktif Çark Süresi: <b>${s.spinSure || 45} dk</b> ${testTag}</div>
    `;

  // Üstteki KPI'lar hızlı bakış içindir. Eski düz metin raporunu burada
  // okunabilir, karşılaştırmalı bölüm kartlarına dönüştürüyoruz.
  const statsEl = document.getElementById("stats");
  const kpiRow = statsEl.querySelector(".kpiRow");
  [...statsEl.childNodes].forEach(node => {
    if(node !== kpiRow) node.remove();
  });
  const line = (label, value, cls = "") => `<div class="statsDetailLine"><span>${label}</span><b class="${cls}">${value}</b></div>`;
  statsEl.insertAdjacentHTML("beforeend", `
    <div class="statsDetailGrid">
      <section class="statsDetailSection">
        <h3>🎰 Çark Özeti</h3>
        <div class="statsDetailLines">
          ${line("Bugünkü spin", String(s.bugunToplam || 0))}
          ${line("Toplam spin", String(s.toplam || 0))}
          ${line("İçecek ödülü", String(s.icecek || 0))}
          ${line("Süre ödülü", String(s.dakika || 0))}
          ${line("Bugünkü çark maliyeti", money(s.bugunMaliyet || 0), "statOrange")}
          ${line("Toplam çark net kârı", money(netKar), karClass)}
        </div>
      </section>
      <section class="statsDetailSection">
        <h3>💰 Masa Geliri</h3>
        <div class="statsDetailLines">
          ${line("Brüt gelir • Bugün", money(brutBugun), "statBlue")}
          ${line("Brüt gelir • Dün", money(brutDun), "statBlue")}
          ${line("Brüt gelir • Bu hafta", money(brutHafta), "statBlue")}
          ${line("Brüt gelir • Bu ay", money(brutAy), "statBlue")}
          ${line("Masa gerçek geliri • Bugün", money(gercekBugun), "statGreen")}
          ${line("Masa gerçek geliri • Tüm zamanlar", money(gercekToplam), "statGreen")}
        </div>
      </section>
      <section class="statsDetailSection">
        <h3>🛒 Ürün ve Genel Gelir</h3>
        <div class="statsDetailLines">
          ${line("Ürün/hizmet • Bugün", `${money(productToday)} • ${productTodayQuantity} adet`, "statBlue")}
          ${line("Ürün/hizmet • Tüm zamanlar", `${money(productAllTime)} • ${productAllTimeQuantity} adet`, "statBlue")}
          ${line("Genel gelir • Bugün", money(generalToday), "statGreen")}
          ${line("Genel gelir • Tüm zamanlar", money(generalAllTime), "statGreen")}
        </div>
      </section>
      <section class="statsDetailSection">
        <h3>🧾 Kasa ve Kâr</h3>
        <div class="statsDetailLines">
          ${line("Nakit / Kart • Bugün", `${money(todayCash)} / ${money(todayCard)}`, "statGreen")}
          ${line("Bekleyen ödeme", money(todayPending), todayPending > 0 ? "statRed" : "statGreen")}
          ${line("Gider / Komisyon • Bugün", `${money(expenseToday)} / ${money(commissionToday)}`, "statRed")}
          ${line("Net sonuç • Bugün", money(netResultToday), netResultToday >= 0 ? "statGreen" : "statRed")}
          ${line("Net sonuç • Bu ay", money(netResultMonth), netResultMonth >= 0 ? "statGreen" : "statRed")}
          ${line("Net sonuç • Tüm zamanlar", money(netResultAllTime), netResultAllTime >= 0 ? "statGreen" : "statRed")}
        </div>
      </section>
    </div>
    <div class="small" style="margin-top:12px;">Masa gerçek geliri = brüt gelir + admin düzeltmeleri − çark maliyeti. Net sonuç = masa gerçek geliri + ürün/hizmet geliri − giderler − kart komisyonu.</div>
  `);
}

async function loadTodaySpins(){
  const d = await fetchJSON("/admin/today-spins");
  if(!d){
    document.getElementById("hakInfo").innerHTML = `<span class="statRed">Haklar yüklenemedi.</span>`;
    return;
  }

  const start = new Date(d.start || Date.now());
  document.getElementById("hakInfo").innerHTML =
    "Gün başlangıcı (kafe): " + start.toLocaleString() + " | Limit: " + d.limit;

  const list = d.list || [];
  list.sort((a,b)=> (b.used - a.used) || (a.masa - b.masa));

  const onlyUsed = document.getElementById("hakOnlyUsedChk")?.checked;
  const shown = onlyUsed ? list.filter(x => (x.used || 0) > 0) : list;

  if(!shown.length){
    document.getElementById("hakList").innerHTML =
      `<div class="small">${onlyUsed ? "Bugün hiç kullanım yok." : "Kayıt yok."}</div>`;
    return;
  }

  document.getElementById("hakList").innerHTML = `
    <div class="tableWrap">
      <table>
        <tr><th>Masa</th><th>VIP</th><th>Bugün Kullanım</th><th>Kalan Hak</th><th>Durum</th></tr>
        ${shown.map(x=>{
          const vip = x.isVip ? `<span class="vipTag">VIP</span>` : "";
          const durum = x.left > 0 ? "Devam" : "Bitti";
          const rowCls = x.left > 0 ? "bekliyor" : "kullanildi";
          return `
            <tr class="${rowCls}">
              <td>${x.masa}</td>
              <td>${vip}</td>
              <td><b>${x.used}</b> / ${x.limit}</td>
              <td><b>${x.left}</b></td>
              <td>${durum}</td>
            </tr>
          `;
        }).join("")}
      </table>
    </div>
  `;
}

async function loadSessions(){
  const [list, productData] = await Promise.all([
    fetchJSON("/admin/sessions"),
    fetchJSON("/admin/product-sales/summary")
  ]);
  if(!list){
    document.getElementById("realBox").innerHTML = `<span class="statRed">Sessions yüklenemedi.</span>`;
    document.getElementById("sessionList").innerHTML = "";
    return;
  }

  const onlineCount = list.filter(x => x.online).length;
  const tableProductTotals = productData?.ok ? (productData.tableTotals || {}) : {};
  const onlyOnline = document.getElementById("onlyOnlineChk")?.checked;
  const baseList = onlyOnline ? list.filter(x => x.online) : list;

  uiState.problemCount = list.filter(s => getSessionStatusInfo(s).isProblem).length;

  const shownList = baseList.filter(s => {
    const info = getSessionStatusInfo(s);
    return passesGlobalFilter(s.masa, info.isProblem);
  });

  document.getElementById("realBox").innerHTML = `
    <b>Online Masa:</b> ${onlineCount} / ${list.length}
    <div class="small" style="margin-top:6px;">
      Gösterilen: <b>${shownList.length}</b> ${onlyOnline ? "(sadece bağlı)" : "(tümü)"} &nbsp;|&nbsp;
      Problemli: <b>${uiState.problemCount}</b>
    </div>
    <div class="small" style="margin-top:6px;">
      <b>Gerçek masa geliri = Brüt + Düzeltme</b> &nbsp;|&nbsp;
      <b>Toplam hesap = Gerçek masa geliri + Ürün/Hizmet</b>
    </div>
  `;

  if(!shownList.length){
    document.getElementById("sessionList").innerHTML = `<div class="small">Şu an gösterilecek masa yok.</div>`;
    updateQuickSummary();
    return;
  }

  document.getElementById("sessionList").innerHTML = `
    <div class="tableWrap">
      <table>
        <tr>
          <th>Masa</th>
          <th>Durum</th>
          <th>Öneri</th>
          <th>Başlangıç</th>
          <th>Son Ping</th>
          <th>Kapanış</th>
          <th>Dakika</th>
          <th>Brüt</th>
          <th>Düzeltme</th>
          <th>Gerçek</th>
          <th>Ürün/Hizmet</th>
          <th>Toplam Hesap</th>
          <th>İşlem</th>
        </tr>
        ${shownList.map(s=>{
          const info = getSessionStatusInfo(s);
          const advice = getSessionActionAdvice(s);

          const brut = typeof s.fee === "number" ? s.fee : 0;
          const adj = typeof s.adj === "number" ? s.adj : 0;
          const gercek = typeof s.feeAdj === "number" ? s.feeAdj : brut;
          const productAmount = Number(tableProductTotals[s.masa]) || 0;
          const totalAccount = Math.max(0, gercek) + productAmount;

const brutText = s.free
  ? "<b>0 ₺ (FREE)</b>"
  : `<b>${money(brut)}</b>${info.isClosed ? ` <span class="small">(sabit)</span>` : ""}`;

const adjText = s.free
  ? "-"
  : `<span class="${adj >= 0 ? 'statGreen' : 'statRed'}"><b>${adj > 0 ? '+' : '-'}${money(Math.abs(adj))}</b></span>`;

const gercekText = s.free
  ? "<b>0 ₺ (FREE)</b>"
  : `<b>${money(gercek)}</b>${info.isClosed ? ` <span class="small">(tahsil)</span>` : ""}`;

          const isZeroed = s.zeroed === 1;
          const showReset = info.isProblem;

const smartInputId = "smartFee_" + s.masa;

const smartFeeHtml = !s.free ? `
  <div style="margin-top:6px;">
    <input 
  id="${smartInputId}" 
  type="text" 
  placeholder="+10 / -10 / 60"
  style="width:110px"
  onfocus="isEditingFee = true"
  onblur="isEditingFee = false"
>
    <button class="purpleBtn btnSm" onclick="smartFee(${s.masa}, ${gercek}, '${smartInputId}')">UYGULA</button>
  </div>
` : "";

          const btn = s.free ? `
            ${s.online ? `<button class="greenBtn btnSm" onclick="yeniMusteri(${s.masa})">YENİ MÜŞTERİ</button>` : ""}
          ` : `
            ${s.online ? `<button class="orange btnSm" onclick="feeZero(${s.masa})">0₺ yap</button>` : ""}
            ${showReset ? `<button class="red btnSm" onclick="sessionReset(${s.masa})">SESSION RESET</button>` : ""}
            ${s.online ? `<button class="greenBtn btnSm" onclick="yeniMusteri(${s.masa})">YENİ MÜŞTERİ</button>` : ""}
            <button class="darkBtn btnSm" onclick="hardResetMasa(${s.masa})">TAM TEMİZLE</button>
${smartFeeHtml}
          `;


          return `
            <tr class="${info.cls} ${info.isProblem ? 'problemRow' : ''}">
              <td data-label="Masa">${s.masa}${isVipMasa(s.masa) ? '<span class="vipTag">VIP</span>' : ''}</td>
              <td data-label="Durum">${info.durum}${isZeroed ? ' <span class="pill">0₺ uygulanmış</span>' : ''}</td>
              <td data-label="Öneri" class="adviceCell ${advice.className || ''}">${advice.text}</td>
<td data-label="Başlangıç">
    <div>${fmtTime(s.start_time)}</div>

    <div style="margin-top:5px;display:flex;gap:4px;align-items:center;">
        <input
            id="start_${s.masa}"
            type="time"
            step="1"
            value="${fmtTime(s.start_time)}"
            style="
                width:95px;
                font-size:11px;
                padding:3px;
            ">

        <button
            class="purpleBtn btnSm"
            onclick="setStartTime(${s.masa})">
            Kaydet
        </button>
    </div>
</td>
              <td data-label="Son Ping">${fmtTime(s.last_seen)}</td>
              <td data-label="Kapanış">${info.isClosed ? fmtTime(s.end_time) : "-"}</td>
              <td data-label="Dakika">${s.minutes || 0} dk</td>
              <td data-label="Brüt">${brutText}</td>
              <td data-label="Düzeltme">${adjText}</td>
              <td data-label="Gerçek">${gercekText}</td>
              <td data-label="Ürün/Hizmet"><b>${money(productAmount)}</b></td>
              <td data-label="Toplam Hesap"><b class="statGreen">${money(totalAccount)}</b></td>
              <td data-label="İşlem" class="actionCell">${btn}</td>
            </tr>
          `;
        }).join("")}
      </table>
    </div>
  `;
  if(isEveryCafeManualLock()){
    document.querySelectorAll('#sessionList button[onclick^="yeniMusteri"], #sessionList button[onclick^="sessionReset"], #sessionList button[onclick^="hardResetMasa"]').forEach(button => {
      button.disabled = true;
      button.title = "EveryCafe aktif. Bakım Modu ile geçici olarak açılır.";
      button.style.opacity = ".42";
      button.style.cursor = "not-allowed";
      if(!button.textContent.includes("🔒")) button.textContent += " 🔒";
    });
  }
document.getElementById("problemCount").textContent =
    uiState.problemCount;
  updateQuickSummary();
}

async function loadSessionHistory(){
  const box = document.getElementById("sessionHistoryBox");
  if(!box) return;

  const masaFilter = parseInt(document.getElementById("historyMasaFilter")?.value || "",10);
  const limit = parseInt(document.getElementById("historyLimitFilter")?.value || "50",10);
  const day = document.getElementById("historyDayFilter")?.value || "today";
  const showZero = document.getElementById("historyShowZeroChk")?.checked === true;

  const d = await fetchJSON("/admin/session-history");

  if(!d || !d.ok){
    box.innerHTML = `<span class="statRed">Geçmiş yüklenemedi.</span>`;
    return;
  }

  let list = d.list || [];

  const now = new Date();
  const yesterday = new Date();
  yesterday.setDate(now.getDate()-1);

  function sameDay(a,b){
    return a.toDateString() === b.toDateString();
  }

  if(day === "today"){
    list = list.filter(x => x.start_time && sameDay(new Date(x.start_time), now));
  } else if(day === "yesterday"){
    list = list.filter(x => x.start_time && sameDay(new Date(x.start_time), yesterday));
  } else if(day === "7"){
    const last7 = new Date();
    last7.setDate(now.getDate()-7);
    list = list.filter(x => new Date(x.start_time) >= last7);
  }

  if(masaFilter){
    list = list.filter(x => parseInt(x.masa) === masaFilter);
  }

  const zeroCount = list.filter(x => Math.abs(Number(x.fee) || 0) < 0.005).length;

  if(!showZero){
    list = list.filter(x => Math.abs(Number(x.fee) || 0) >= 0.005);
  }

  list = list.slice(0, limit);

  if(!list.length){
    box.innerHTML = `
      <div class="small">
        Gösterilecek kayıt yok.
        ${!showZero && zeroCount > 0
          ? `<span class="statOrange">(${zeroCount} adet 0 TL kayıt gizlendi)</span>`
          : ""}
      </div>
    `;
    return;
  }

  const sessionTotal = row => (Number(row.fee) || 0) + (Number(row.product_total) || 0);
  const toplam = list.reduce((a,b)=>a + sessionTotal(b),0);

  box.innerHTML = `
    <div class="small" style="margin-bottom:8px;">
      Kayıt: <b>${list.length}</b> |
      Toplam: <span class="statGreen">${money(toplam)}</span>
      ${!showZero && zeroCount > 0
        ? ` | <span class="statOrange">0 TL gizlenen: <b>${zeroCount}</b></span>`
        : ""}
    </div>

    <div class="tableWrap">
      <table>
        <tr>
          <th>Masa</th>
          <th>Başlangıç</th>
          <th>Bitiş</th>
          <th>Dakika</th>
<th>Oturum</th>
<th>Ürün/Hizmet</th>
<th>Toplam Gelir</th>
<th>Düzeltme</th>
<th>Kapanış</th>
<th>İşlem</th>
        </tr>

${list.map(s=>`
  <tr>
    <td>${s.masa}</td>
    <td>${fmtDateTime(s.start_time)}</td>
    <td>${fmtDateTime(s.end_time)}</td>
    <td>${s.minutes} dk</td>

    <td>
      <b>${money(s.fee)}</b>
    </td>

    <td>
      <b>${money(s.product_total || 0)}</b>
    </td>

    <td>
      <b class="statGreen">${money(sessionTotal(s))}</b>
    </td>

    <td>
      ${s.adjustment
        ? `<span class="${s.adjustment >= 0 ? 'statGreen' : 'statRed'}">
            ${money(s.adjustment)}
          </span>`
        : "-"}
    </td>

    <td>${s.close_reason || "-"}</td>

    <td>
      <button class="red btnSm" onclick="deleteSessionHistory(${s.id})">
        Sil
      </button>
    </td>
  </tr>
`).join("")}
      </table>
    </div>
  `;
}

let lastWinId = 0;

function playWinSound(text){
  const t = (text || "").toLowerCase();
  if(
    t.includes("dakika") ||
    t.includes("soda") ||
    t.includes("kola") ||
    t.includes("çay") ||
    t.includes("crax") ||
    t.includes("enerji") ||
    t.includes("gofret")
  ){
    const s = document.getElementById("winSound");
    s.currentTime = 0;
    s.play().catch(()=>{});
  }
}

async function loadSpins(){
  const data = await fetchJSON("/admin/list");
  const badge = document.getElementById("badge");

  if(!data){
    document.getElementById("spinList").innerHTML = `<span class="statRed">Spin listesi yüklenemedi.</span>`;
    badge.innerHTML = "Bekleyen: ?";
    badge.style.animation = "none";
    return;
  }

  if(!data.length){
    document.getElementById("spinList").innerHTML = "Kayıt yok";
    badge.innerHTML = "Bekleyen: 0";
    badge.style.animation = "none";
    uiState.pendingCount = 0;
    updateQuickSummary();
    return;
  }

  data.sort((a,b)=>{
    const au = a.used ? 1 : 0;
    const bu = b.used ? 1 : 0;
    if(au !== bu) return au - bu;
    return new Date(b.time) - new Date(a.time);
  });

  const newest = [...data].sort((a,b)=> new Date(b.time) - new Date(a.time))[0];
  if(newest && newest.id !== lastWinId){
    playWinSound(newest.reward);
    lastWinId = newest.id;
  }

  let bekleyen = 0;

  document.getElementById("spinList").innerHTML = `
    <div class="tableWrap">
      <table>
        <tr><th>Masa</th><th>Ödül</th><th>Saat</th><th>Durum</th><th>İşlem</th></tr>
        ${data.map(s=>{
          if(!s.used) bekleyen++;
          const cls = s.used ? "kullanildi" : "";
          return `
            <tr class="${cls}">
              <td>${s.masa}${isVipMasa(s.masa) ? '<span class="vipTag">VIP</span>' : ''}</td>
              <td title="${escapeHtml(s.reward)}">${escapeHtml(s.reward)}</td>
              <td>

<div>${fmtTime(s.start_time)}</div>

<div style="margin-top:4px">

<input
id="start_${s.masa}"
type="time"
step="1"
value="${fmtTime(s.start_time)}"
style="width:95px"
onfocus="isEditingStartTime=true"
onblur="isEditingStartTime=false">

<button
class="purpleBtn btnSm"
onclick="setStartTime(${s.masa})">
Kaydet
</button>

</div>

</td>
              <td>${s.used ? "Kullanıldı" : "Bekliyor"}</td>
              <td>${!s.used ? `<button onclick="useSpin(${s.id})">Onayla</button>` : ""}</td>
            </tr>
          `;
        }).join("")}
      </table>

    </div>
  `;

  uiState.pendingCount = bekleyen;
  badge.innerHTML = "Bekleyen: " + bekleyen;
  badge.style.animation = bekleyen > 0 ? "pulseBadge 1.2s infinite" : "none";
  updateQuickSummary();
}

async function useSpin(id){
  const d = await fetchJSON("/admin/use",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({ id })
  });

  if(!d){
    alert("Onaylama başarısız");
    return;
  }

  if(d.ok && !d.alreadyUsed && (d.costApplied || 0) > 0){
    const tur = d.kind === "time" ? "Süre" : (d.kind === "item" ? "Ürün" : "Ödül");
    alert(`✅ Onaylandı\n${tur} maliyeti işlendi: ${d.costApplied} ₺`);
  }

  await refreshFastNow();
  await refreshMediumNow();
}

let rewards = [];

async function loadRewards(){
  const data = await fetchJSON("/admin/rewards");
  if(!data){
    document.getElementById("rewardList").innerHTML =
      `<div class="small statRed">Ödüller yüklenemedi.</div>`;
    return;
  }

  rewards = data;
  drawRewards();
}

function drawRewards(){
  const box = document.getElementById("rewardList");
  box.innerHTML = `
    <div class="tableWrap">
      <table>
        <tr><th>Ad</th><th>Ağırlık</th><th>Aktif</th><th>İşlem</th></tr>
        ${rewards.map(r=>`
          <tr data-id="${r.id}">
            <td><input class="rw-name" value="${escapeHtml(r.name)}"></td>
            <td><input class="rw-weight" type="number" value="${r.weight}" min="1"></td>
            <td><input class="rw-active" type="checkbox" ${r.active ? "checked" : ""}></td>
            <td><button class="red btnSm" onclick="deleteReward(${r.id})">Sil</button></td>
          </tr>
        `).join("")}
      </table>
    </div>
  `;

  box.querySelectorAll("tr[data-id]").forEach(tr=>{
    const id = parseInt(tr.getAttribute("data-id"),10);
    const nameInp = tr.querySelector(".rw-name");
    const weightInp = tr.querySelector(".rw-weight");
    const activeInp = tr.querySelector(".rw-active");

    nameInp.addEventListener("input", ()=>{
      const rr = rewards.find(x=>x.id===id);
      if(rr) rr.name = nameInp.value;
    });

    weightInp.addEventListener("input", ()=>{
      const rr = rewards.find(x=>x.id===id);
      if(rr) rr.weight = parseInt(weightInp.value,10) || 1;
    });

    activeInp.addEventListener("change", ()=>{
      const rr = rewards.find(x=>x.id===id);
      if(rr) rr.active = activeInp.checked ? 1 : 0;
    });
  });
}

async function addReward(){
  const name = (document.getElementById("newRewardName").value || "").trim();
  const weight = parseInt(document.getElementById("newRewardWeight").value, 10);
  const active = document.getElementById("newRewardActive").checked ? 1 : 0;

  if(!name){ alert("Ödül adı boş olamaz"); return; }
  if(!weight || weight < 1){ alert("Ağırlık 1 veya daha büyük olmalı"); return; }

  const d = await fetchJSON("/admin/reward/add",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ name, weight, active })
  });

  if(!d || !d.ok){
    alert((d && d.error) ? d.error : "Ödül eklenemedi");
    return;
  }

  document.getElementById("newRewardName").value = "";
  document.getElementById("newRewardWeight").value = "10";
  document.getElementById("newRewardActive").checked = true;

  await loadRewards();
  alert("Ödül eklendi");
}

async function deleteReward(id){
  if(!confirm("Bu ödül silinsin mi?")) return;

  const d = await fetchJSON("/admin/reward/delete",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ id })
  });

  if(!d || !d.ok){
    alert((d && d.error) ? d.error : "Silinemedi");
    return;
  }

  await loadRewards();
}

async function saveRewards(){
  for(const r of rewards){
    const d = await fetchJSON("/admin/reward/update",{
      method:"POST",
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({
        id: r.id,
        name: String(r.name || "").trim(),
        weight: parseInt(r.weight,10) || 1,
        active: (r.active ? 1 : 0)
      })
    });

    if(!d || !d.ok){
      alert("Kaydetme hatası: " + ((d && d.error) ? d.error : "Server/bağlantı"));
      return;
    }
  }

  alert("Kaydedildi ✅");
  await loadRewards();
}

function formatBackupDate(ts){
  const date = new Date(Number(ts) || Date.now());
  const pad = value => String(value).padStart(2,"0");
  return `${pad(date.getDate())}.${pad(date.getMonth()+1)}.${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

async function loadBackupStatus(){
  const status = document.getElementById("fullBackupStatus");
  const button = document.getElementById("fullBackupBtn");
  if(!status || !button) return;
  const d = await fetchJSON("/admin/backup/status");
  if(!d || !d.ok){ status.textContent = "Yedek durumu alınamadı"; return; }
  button.disabled = Boolean(d.running);
  if(d.running){ status.textContent = "⏳ Tam yedek hazırlanıyor…"; return; }
  const last = d.last || null;
  if(!last){ status.textContent = "Henüz admin panelinden yedek alınmadı."; return; }
  if(!last.ok){ status.innerHTML = `<span class="statRed">Son yedek başarısız: ${escapeHtml(last.error || "Bilinmeyen hata")}</span>`; return; }
  const sizeMb = ((Number(last.size)||0) / 1048576).toFixed(2);
  status.innerHTML = `✅ Son yedek: <b>${escapeHtml(last.fileName || "-")}</b> • ${sizeMb} MB • ${formatBackupDate(last.time)}`;
}

async function createFullBackup(){
  if(!confirm("KafePin projesinin tam ZIP yedeği şimdi alınsın mı?")) return;
  const status = document.getElementById("fullBackupStatus");
  const button = document.getElementById("fullBackupBtn");
  if(button) button.disabled = true;
  if(status) status.textContent = "⏳ Veritabanı ve proje dosyaları ZIP'e hazırlanıyor…";
  const d = await fetchJSON("/admin/backup/full", {method:"POST"});
  if(button) button.disabled = false;
  if(!d || !d.ok){
    if(status) status.innerHTML = `<span class="statRed">Yedek alınamadı: ${escapeHtml((d && d.error) || "Sunucu bağlantısı")}</span>`;
    return;
  }
  const sizeMb = ((Number(d.size)||0) / 1048576).toFixed(2);
  if(status) status.innerHTML = `✅ Yedek tamamlandı: <b>${escapeHtml(d.fileName || "-")}</b> • ${sizeMb} MB`;
  alert(`Tam yedek alındı.\n${d.fileName}\n${sizeMb} MB`);
  await loadLiveLog();
}

async function resetSystem(){
  if(!confirm("Masalar sıfırlanacak.\nBugünkü spin kayıtları da silinir.\nEmin misiniz?")) return;

  const d = await fetchJSON("/admin/reset",{ method:"POST" });
  if(!d || !d.ok){
    if(showPendingRewardWarning(d)) return;
    alert("Reset başarısız");
    return;
  }

  alert("Reset yapıldı");
  await refreshFastNow();
  await refreshMediumNow();
  await refreshSlowNow();
}

async function resetTodaySpins(){
  if(!confirm("Sadece BUGÜNKÜ (20:00 bazlı) spin kayıtları silinecek.\nEmin misiniz?")) return;

  const d = await fetchJSON("/admin/reset-spins-today",{ method:"POST" });
  if(!d || !d.ok){
    if(showPendingRewardWarning(d)) return;
    alert("Silme başarısız");
    return;
  }

  alert("Bugünkü spinler silindi");
  await refreshFastNow();
  await refreshMediumNow();
}

async function resetAll(){
  if(!confirm("HER ŞEY SIFIRLANACAK!\nSpins + Masalar + Sessions silinir.\nEmin misiniz?")) return;

  const d = await fetchJSON("/admin/reset-all",{ method:"POST" });
  if(!d || !d.ok){
    if(showPendingRewardWarning(d)) return;
    alert("Sıfırlama başarısız: " + ((d && d.error) ? d.error : "Bilinmeyen"));
    return;
  }

  alert("Tam sıfırlama yapıldı");
  await refreshFastNow();
  await refreshMediumNow();
  await refreshSlowNow();
}

async function clearSessionHistory(){
  if(!confirm("TÜM SESSION GEÇMİŞİ SİLİNECEK!\nEmin misiniz?")) return;

  const d = await fetchJSON("/admin/session-history/clear", {
    method: "POST"
  });

  if(!d || !d.ok){
    alert((d && d.error) ? d.error : "Silme başarısız");
    return;
  }

  alert("✅ Session geçmişi tamamen silindi");
  await loadSessionHistory();
}

function clearHistoryFilter(){
  const masa = document.getElementById("historyMasaFilter");
  const limit = document.getElementById("historyLimitFilter");
  const day = document.getElementById("historyDayFilter");
  const showZero = document.getElementById("historyShowZeroChk");

  if(masa) masa.value = "";
  if(limit) limit.value = "50";
  if(day) day.value = "today";
  if(showZero) showZero.checked = false;

  loadSessionHistory();
}

async function deleteSessionHistory(id){
  if(!confirm("Bu session kaydı silinsin mi?")) return;

  const d = await fetchJSON("/admin/session-history/delete",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ id })
  });

  if(!d || !d.ok){
    alert((d && d.error) ? d.error : "Silme başarısız");
    return;
  }

  alert("✅ Session kaydı silindi");
  await loadSessionHistory();
}

async function refreshFastNow(){
  await Promise.all([
    loadAktifMasalar(),
    loadSessions(),
    loadSpins(),
    loadStats()
  ]);
  markRefresh();
}

async function transferSession() {

  const from = parseInt(
    document.getElementById("transferFrom").value,
    10
  );

  const to = parseInt(
    document.getElementById("transferTo").value,
    10
  );

  if (!from || !to) {
    alert("Masa numarası gir");
    return;
  }

  if (from === to) {
    alert("Aynı masa olamaz");
    return;
  }

  try {

    const r = await fetch("/admin/transfer-session", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from,
        to
      })
    });

    const data = await r.json();

    if (!data.ok) {
      alert(data.error || "Transfer başarısız");
      return;
    }

    alert(`Masa ${from} → ${to} taşındı`);
await refreshFastNow();
await refreshMediumNow();

  } catch (e) {

    alert("Bağlantı hatası");

  }

}
async function transferSession() {

  const from = parseInt(
    document.getElementById("transferFrom").value,
    10
  );

  const to = parseInt(
    document.getElementById("transferTo").value,
    10
  );

  if (!from || !to) {
    alert("Masa numarası gir");
    return;
  }

  if (from === to) {
    alert("Aynı masa olamaz");
    return;
  }

  try {

    const r = await fetch("/admin/transfer-session", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from,
        to
      })
    });

    const data = await r.json();

    if (!data.ok) {
      alert(data.error || "Transfer başarısız");
      return;
    }

    alert(`✅ Masa ${from} → ${to} taşındı`);

    await refreshFastNow();

  } catch (e) {

    alert("Bağlantı hatası");

  }

}
async function refreshMediumNow(){
  await Promise.all([
    loadMaintenanceMode(),
    loadDashboardStats(),
    loadSystemHealth(),
    loadDailyComparison(),
    loadRolloverStatus(),
    loadFreeMasalar(),
    loadTodayGivenRewards(),
    loadTodayEmptyRewards(),
    loadTodaySpins(),
    loadLiveLog(),
    loadEveryCafeStatus(),
    loadEveryCafeDaySplits(),
    loadProductSalesSummary(),
    loadPaymentSummary(),
    loadDailyPaymentComparison(),
    loadCashReconciliation(),
    loadAccountingSummary(),
    loadBackupStatus()
  ]);
}

async function refreshSlowNow(){
  await loadSessionHistory();
}

async function fullInitialLoad(){
  renderDynamicPricingBadges();
  await loadMaintenanceMode();
  await refreshFastNow();
  await refreshMediumNow();
  await refreshSlowNow();
  await loadRewards();
  await loadProductCatalog();
  await loadProductSalesSummary();
  await loadProductSalesHistory();
  await loadPaymentSummary();
  syncProductSaleMode();
}

function startAutoRefresh(){
  clearAllIntervals();

registerInterval(updateRolloverCountdown, 1000);

registerInterval(() => {

    if(isPageHidden()) return;

    if(isEditingFee) return;

    if(isEditingStartTime) return;

    runGuardedRefresh("fast", refreshFastNow);

}, 5000);

  registerInterval(() => {
    if(isPageHidden()) return;
    runGuardedRefresh("medium", refreshMediumNow);
  }, 15000);

  registerInterval(() => {
    if(isPageHidden()) return;
    runGuardedRefresh("slow", refreshSlowNow);
  }, 30000);
registerInterval(() => {
  if(isPageHidden()) return;
  loadDiagnostics();
}, 3000);
registerInterval(() => {
  if(isPageHidden()) return;
  loadDailyReport();
}, 30000);
}

document.addEventListener("visibilitychange", () => {
  if(!document.hidden){
    runGuardedRefresh("fast", refreshFastNow);
    runGuardedRefresh("medium", refreshMediumNow);
  }
});

const adminPanelStorageKey = "kafepin_admin_active_panel_v1";
const adminPanelScrollStorageKey = "kafepin_admin_panel_scroll_positions_v1";

function getAdminPanelScrollPositions(){
  try {
    const saved = JSON.parse(localStorage.getItem(adminPanelScrollStorageKey) || "{}");
    return saved && typeof saved === "object" ? saved : {};
  } catch(_err) {
    return {};
  }
}

function saveAdminPanelScrollPosition(panel, top){
  if(!["cafe", "everycafe", "finance"].includes(panel)) return;
  try {
    const positions = getAdminPanelScrollPositions();
    positions[panel] = Math.max(0, Math.round(Number(top) || 0));
    localStorage.setItem(adminPanelScrollStorageKey, JSON.stringify(positions));
  } catch(_err) {}
}

function setAdminPanel(panel, scrollTop){
  const selected = ["cafe", "everycafe", "finance"].includes(panel) ? panel : "cafe";
  const previous = document.body.dataset.adminPanel;
  if(previous && previous !== selected) saveAdminPanelScrollPosition(previous, window.scrollY);
  document.body.dataset.adminPanel = selected;
  try { localStorage.setItem(adminPanelStorageKey, selected); } catch(_err) {}
  document.querySelectorAll(".card.admin-section").forEach(card => {
    card.classList.toggle("panel-hidden", card.dataset.adminPanel !== selected);
  });
  document.querySelectorAll("#adminPanelSwitcher button[data-panel]").forEach(button => {
    button.classList.toggle("active", button.dataset.panel === selected);
  });
  document.querySelectorAll('#adminQuickNav a[href^="#"]').forEach(link => {
    const target = document.querySelector(link.getAttribute("href"));
    const card = target && target.closest(".card.admin-section");
    const isMaintenanceLink = link.getAttribute("href") === "#maintenanceModeBox";
    link.classList.toggle("panel-link-hidden", !isMaintenanceLink && Boolean(card && card.dataset.adminPanel !== selected));
  });
  if(previous !== selected){
    const positions = getAdminPanelScrollPositions();
    const targetTop = Math.max(0, Number(positions[selected]) || 0);
    requestAnimationFrame(()=> window.scrollTo({top:targetTop, behavior:scrollTop ? "smooth" : "auto"}));
  }
}

// KafePin Pro ana penceresinde Yonetim Merkezi/Monitor sekmesine gecilirken
// aktif Admin panelinin (ozellikle Kafe & Cark) kendi kaydirma konumunu da
// sakla. Dis iframe konumu tek basina dinamik panel yerlesimi icin yeterli
// olmayabiliyor.
function saveCurrentAdminPanelScroll(){
  const panel = document.body.dataset.adminPanel || "cafe";
  saveAdminPanelScrollPosition(panel, window.scrollY);
}
function restoreCurrentAdminPanelScroll(){
  const panel = document.body.dataset.adminPanel || "cafe";
  const positions = getAdminPanelScrollPositions();
  const targetTop = Math.max(0, Number(positions[panel]) || 0);
  const restore = () => window.scrollTo({ top: targetTop, behavior: "auto" });
  restore(); setTimeout(restore, 160); setTimeout(restore, 650);
}
window.addEventListener("kafepin-pro-before-hide", saveCurrentAdminPanelScroll);
window.addEventListener("kafepin-pro-after-show", restoreCurrentAdminPanelScroll);
window.addEventListener("pagehide", saveCurrentAdminPanelScroll);

function goToMaintenanceMode(event){
  if(event){
    event.preventDefault();
    event.stopPropagation();
  }
  setAdminPanel("finance", false);
  requestAnimationFrame(() => {
    const target = document.getElementById("maintenanceModeBox");
    const card = target && target.closest(".card.admin-section");
    if(card && card.classList.contains("admin-collapsed")){
      card.classList.remove("admin-collapsed");
      const button = card.querySelector(":scope > h2 .section-collapse-btn");
      if(button) button.textContent = "KÜÇÜLT";
    }
    if(target) target.scrollIntoView({behavior:"smooth", block:"center"});
  });
  return false;
}

async function organizeAdminLayout(){
  const nav = document.getElementById("adminQuickNav");
  if(!nav) return;

  const collapseStorageKey = "kafepin_admin_collapsed_sections_v1";
  let collapsedSections = new Set();
  try {
    const saved = JSON.parse(localStorage.getItem(collapseStorageKey) || "[]");
    if(Array.isArray(saved)) collapsedSections = new Set(saved.map(String));
  } catch(_err) {
    collapsedSections = new Set();
  }
  try {
    const serverPrefs = await fetchJSON("/admin/preferences/collapsed-sections");
    if(serverPrefs && serverPrefs.ok && serverPrefs.saved){
      collapsedSections = new Set((serverPrefs.sections || []).map(String));
      localStorage.setItem(collapseStorageKey, JSON.stringify(Array.from(collapsedSections)));
    } else if(serverPrefs && serverPrefs.ok && collapsedSections.size){
      fetchJSON("/admin/preferences/collapsed-sections", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({sections:Array.from(collapsedSections)})
      });
    }
  } catch(_err) {}
  const saveCollapsedSections = () => {
    try {
      localStorage.setItem(collapseStorageKey, JSON.stringify(Array.from(collapsedSections)));
    } catch(_err) {}
    fetchJSON("/admin/preferences/collapsed-sections", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({sections:Array.from(collapsedSections)})
    }).catch(()=>{});
  };

  const cards = Array.from(document.querySelectorAll(".card"));
  const usedCards = new Set();
  const findCard = (text) => cards.find(card => {
    if(usedCards.has(card)) return false;
    const heading = card.querySelector(":scope > h2");
    return heading && heading.textContent.includes(text);
  });

  const layout = [
    ["Dashboard", "section-dashboard"],
    ["Aktif Masalar", "section-active"],
    ["Gerçek Masa Geliri", "section-revenue"],
    ["Ürün ve Hizmet Satışı", "section-products"],
    ["EveryCafe Entegrasyon", "section-everycafe"],
    ["Kasa ve Ödemeler", "paymentDashboardCard"],
    ["Tüm Zamanlar", "section-alltime"],
    ["Muhasebe", "section-accounting"],
    ["Ücretsiz Masalar", "section-free"],
    ["Masa Transfer", "section-transfer"],
    ["İstatistikler", "section-stats"],
    ["Gün Sonu Raporu", "section-report"],
    ["Kazanan Ödüller", "section-winners"],
    ["Bugün Verilen Ödüller", "section-given"],
    ["Bugün Boş Ödüller", "section-empty"],
    ["Günlük Haklar", "section-rights"],
    ["Session Geçmişi", "section-history"],
    ["Ödüller", "section-rewards"],
    ["Sistem", "section-settings"]
  ];

  let insertAfter = nav;
  layout.forEach(([title, id]) => {
    const card = findCard(title);
    if(!card) return;
    usedCards.add(card);
    card.id = id;
    card.classList.add("admin-section");
    insertAfter.insertAdjacentElement("afterend", card);
    insertAfter = card;

    const heading = card.querySelector(":scope > h2");
    if(!heading || heading.querySelector(".section-collapse-btn")) return;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "section-collapse-btn";
    const startsCollapsed = collapsedSections.has(id);
    if(startsCollapsed) card.classList.add("admin-collapsed");
    button.textContent = startsCollapsed ? "AÇ" : "KÜÇÜLT";
    button.title = "Bu bölümü küçült veya aç";
    button.addEventListener("click", () => {
      const collapsed = card.classList.toggle("admin-collapsed");
      button.textContent = collapsed ? "AÇ" : "KÜÇÜLT";
      if(collapsed) collapsedSections.add(card.id);
      else collapsedSections.delete(card.id);
      saveCollapsedSections();
    });
    heading.appendChild(button);
  });

  const financeSectionIds = new Set([
    "paymentDashboardCard",
    "section-accounting",
    "section-stats",
    "section-report",
    "section-alltime",
    "section-settings"
  ]);
  const everyCafeSectionIds = new Set(["section-everycafe"]);
  document.querySelectorAll(".card.admin-section").forEach(card => {
    card.dataset.adminPanel = everyCafeSectionIds.has(card.id)
      ? "everycafe"
      : financeSectionIds.has(card.id) ? "finance" : "cafe";
  });
  let savedPanel = "cafe";
  try { savedPanel = localStorage.getItem(adminPanelStorageKey) || "cafe"; } catch(_err) {}
  setAdminPanel(savedPanel, false);

  nav.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", () => {
      const target = document.querySelector(link.getAttribute("href"));
      const card = target && target.closest(".card.admin-collapsed");
      if(!card) return;
      card.classList.remove("admin-collapsed");
      collapsedSections.delete(card.id);
      saveCollapsedSections();
      const button = card.querySelector(":scope > h2 .section-collapse-btn");
      if(button) button.textContent = "KÜÇÜLT";
    });
  });
}

document.addEventListener("DOMContentLoaded", async ()=>{
  await organizeAdminLayout();
  const directSalesSummary = document.getElementById("kafepinDirectSalesSummary");
  const directSalesQuickTarget = document.getElementById("kafepinDirectSalesQuickTarget");
  if (directSalesSummary && directSalesQuickTarget) directSalesQuickTarget.appendChild(directSalesSummary);
  renderDynamicPricingBadges();
  const monthlyReportMonth = document.getElementById("monthlyReportMonth");
  if(monthlyReportMonth && !monthlyReportMonth.value){
    monthlyReportMonth.value = getIstanbulMonthValue();
  }
  const yearlyReportYear = document.getElementById("yearlyReportYear");
  if(yearlyReportYear && !yearlyReportYear.value){
    yearlyReportYear.value = getIstanbulYear();
  }
  const financialReportStart = document.getElementById("financialReportStart");
  const financialReportEnd = document.getElementById("financialReportEnd");
  if(financialReportStart && !financialReportStart.value) financialReportStart.value = getIstanbulDateValue();
  if(financialReportEnd && !financialReportEnd.value) financialReportEnd.value = getIstanbulDateValue();

  const scrollTopBtn = document.getElementById("scrollTopBtn");
  function updateScrollTopButton(){
    if(!scrollTopBtn) return;
    scrollTopBtn.classList.toggle("visible", (window.scrollY || 0) > 350);
  }
  if(scrollTopBtn){
    scrollTopBtn.addEventListener("click", ()=>{
      window.scrollTo({ top:0, behavior:"smooth" });
    });
    window.addEventListener("scroll", updateScrollTopButton, { passive:true });
    updateScrollTopButton();
  }

  const badge = document.getElementById("badge");
  badge.addEventListener("click", ()=>{
    setAdminPanel("cafe",false);
    setTimeout(()=>{
      const el = document.getElementById("section-winners");
      if(el) el.scrollIntoView({ behavior:"smooth", block:"start" });
    },30);
  });

  const paymentBadge = document.getElementById("paymentBadge");
  if(paymentBadge){
    paymentBadge.addEventListener("click", ()=>{
      setAdminPanel("finance",false);
      setTimeout(()=>{
        const el = document.getElementById("paymentDashboardCard");
        if(el) el.scrollIntoView({ behavior:"smooth", block:"start" });
      },30);
    });
  }

  const header = document.getElementById("header");
  const cashMismatchBadge = document.getElementById("cashMismatchBadge");
  if(cashMismatchBadge){
    cashMismatchBadge.addEventListener("click", ()=>{
      setAdminPanel("finance",false);
      setTimeout(()=>{
        const el = document.getElementById("paymentDashboardCard");
        if(el) el.scrollIntoView({behavior:"smooth",block:"start"});
      },30);
    });
  }
  function updateBadgeFloat(){
    const y = window.scrollY || 0;
    const limit = header ? header.offsetHeight : 120;
    if(y > limit) badge.classList.add("floating");
    else badge.classList.remove("floating");
    if(paymentBadge){
      if(y > limit) paymentBadge.classList.add("floating");
      else paymentBadge.classList.remove("floating");
    }
    if(cashMismatchBadge){
      if(y > limit) cashMismatchBadge.classList.add("floating");
      else cashMismatchBadge.classList.remove("floating");
    }
  }
  window.addEventListener("scroll", updateBadgeFloat, { passive:true });
  updateBadgeFloat();

  const onlyChk = document.getElementById("onlyOnlineChk");
  if(onlyChk) onlyChk.addEventListener("change", loadSessions);

  const freeShow = document.getElementById("freeShowListChk");
  if(freeShow){
    freeShow.addEventListener("change", ()=>{
      const box = document.getElementById("freeBox");
      box.style.display = freeShow.checked ? "block" : "none";
      loadFreeMasalar();
    });
  }


  const hakChk = document.getElementById("hakOnlyUsedChk");
  if(hakChk) hakChk.addEventListener("change", loadTodaySpins);

  const historyShowZeroChk = document.getElementById("historyShowZeroChk");
  if(historyShowZeroChk){
    historyShowZeroChk.addEventListener("change", loadSessionHistory);
  }

  const masaSearch = document.getElementById('masaSearchInput');
  const vipChk = document.getElementById('onlyVipGlobalChk');
  const probChk = document.getElementById('onlyProblemChk');

  [masaSearch, vipChk, probChk].forEach(el=>{
    if(el) el.addEventListener('input', ()=>{ loadAktifMasalar(); loadSessions(); });
    if(el) el.addEventListener('change', ()=>{ loadAktifMasalar(); loadSessions(); });
  });

await fullInitialLoad();

await loadDiagnostics();

await loadDailyReport();
// ================= Dashboard Modal =================

const dashModal = document.getElementById("dashModal");
const closeDashModal = document.getElementById("closeDashModal");
const revenueCard = document.getElementById("revenueCard");
const sessionCard = document.getElementById("sessionCard");
const avgFeeCard = document.getElementById("avgFeeCard");
const avgMinuteCard = document.getElementById("avgMinuteCard");
const busyCard = document.getElementById("busyCard");
const bestRevenueCard = document.getElementById("bestRevenueCard");
const onlineCard = document.getElementById("onlineCard");
const todaySpinCostCard = document.getElementById("todaySpinCostCard");
const freeCard = document.getElementById("freeCard");
const problemCard = document.getElementById("problemCard");
const pendingCard = document.getElementById("pendingCard");
const readyCard = document.getElementById("readyCard");
const allTimeSessionsCard = document.getElementById("allTimeSessionsCard");
const allTimeRevenueCard = document.getElementById("allTimeRevenueCard");
const allTimeAvgFeeCard = document.getElementById("allTimeAvgFeeCard");
const allTimeAvgMinuteCard = document.getElementById("allTimeAvgMinuteCard");
const allTimeBusyCard = document.getElementById("allTimeBusyCard");
const allTimeBestRevenueCard = document.getElementById("allTimeBestRevenueCard");
const allTimeMaxFeeCard = document.getElementById("allTimeMaxFeeCard");
const longestSessionCard = document.getElementById("longestSessionCard");
const thisMonthRevenueCard = document.getElementById("thisMonthRevenueCard");
const last30RevenueCard = document.getElementById("last30RevenueCard");
const bestDailyRevenueCard = document.getElementById("bestDailyRevenueCard");
const avgLeaderCard = document.getElementById("avgLeaderCard");

if (dashModal && closeDashModal) {

    closeDashModal.onclick = () => {
        dashModal.classList.remove("show");
    };

    dashModal.onclick = (e) => {
        if (e.target === dashModal) {
            dashModal.classList.remove("show");
        }
    };

}

if (revenueCard) revenueCard.onclick = () => openDashboardModal("revenue");
if (sessionCard) sessionCard.onclick = () => openDashboardModal("sessions");
if (avgFeeCard) avgFeeCard.onclick = () => openDashboardModal("avgFee");
if (avgMinuteCard) avgMinuteCard.onclick = () => openDashboardModal("avgMinute");
if (busyCard) busyCard.onclick = () => openDashboardModal("busy");
if (bestRevenueCard) bestRevenueCard.onclick = () => openDashboardModal("bestRevenue");

if (onlineCard) onlineCard.onclick = () => openDashboardModal("online");
if (todaySpinCostCard) todaySpinCostCard.onclick = () => document.getElementById("section-stats")?.scrollIntoView({behavior:"smooth",block:"start"});
if (freeCard) freeCard.onclick = () => openDashboardModal("free");
if (problemCard) problemCard.onclick = () => openDashboardModal("problem");
if (pendingCard) pendingCard.onclick = () => openDashboardModal("pending");
if (readyCard) readyCard.onclick = () => openDashboardModal("ready");
if (allTimeSessionsCard) allTimeSessionsCard.onclick = () => openDashboardModal("sessions");
if (allTimeRevenueCard) allTimeRevenueCard.onclick = () => openDashboardModal("revenue");
if (allTimeAvgFeeCard) allTimeAvgFeeCard.onclick = () => openDashboardModal("avgFee");
if (allTimeAvgMinuteCard) allTimeAvgMinuteCard.onclick = () => openDashboardModal("avgMinute");
if (allTimeBusyCard) allTimeBusyCard.onclick = () => openDashboardModal("busy");
if (allTimeBestRevenueCard) allTimeBestRevenueCard.onclick = () => openDashboardModal("bestRevenue");
if (allTimeMaxFeeCard) allTimeMaxFeeCard.onclick = () => openDashboardModal("maxFee");
if (longestSessionCard) longestSessionCard.onclick = () => openDashboardModal("longestSession");
if (thisMonthRevenueCard) thisMonthRevenueCard.onclick = () => openDashboardModal("thisMonthRevenue");
if (last30RevenueCard) last30RevenueCard.onclick = () => openDashboardModal("last30Revenue");
if (bestDailyRevenueCard) bestDailyRevenueCard.onclick = () => openDashboardModal("bestDailyRevenue");
if (avgLeaderCard) avgLeaderCard.onclick = () => openDashboardModal("avgLeader");


startAutoRefresh();
});
async function smartFee(masa, currentFee, inputId){
  const inp = document.getElementById(inputId);
  if(!inp){
    alert("input yok");
    return;
  }

  let val = inp.value.trim().replace(",", ".");
  if(!val){
    alert("Değer gir");
    return;
  }

  let diff = 0;
  let target = 0;

  if(val.startsWith("+") || val.startsWith("-")){
    diff = parseFloat(val);
    target = currentFee + diff;
  } else {
    target = parseFloat(val);
    diff = target - currentFee;
  }

  if(isNaN(diff)){
    alert("Hatalı değer");
    return;
  }

  if(!Number.isFinite(target) || !Number.isFinite(diff)){
    alert("Geçerli bir sayı gir");
    return;
  }

  diff = Math.round(diff * 100) / 100;
  target = Math.round(target * 100) / 100;

  if(!confirm(`Yeni değer: ${target.toFixed(2)} ₺`)) return;

  // 🔥 BURASI ÖNEMLİ
  const res = await fetch("/admin/fee-adjust",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ masa, amount: Number(diff) })
  });

  const data = await res.json(); // ✅ cevap oku

  if(!res.ok || !data.ok){
    alert(data?.error || "Server hata verdi");
    return;
  }

  alert(`✅ ${currentFee} → ${target} ₺ yapıldı`);

  inp.value = "";

  // 🔥 gecikmeli refresh (input kaybolma fix)
  setTimeout(() => {
    refreshFastNow();
  }, 300);
}
async function setStartTime(masa){

    const saat=document.getElementById("start_"+masa).value;

    if(!saat){
        alert("Saat giriniz");
        return;
    }

    const r=await fetch("/admin/set-start-time",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify({
            masa,
            saat
        })

    });

    const j=await r.json();

    if(!j.ok){
        alert(j.error||"Hata");
        return;
    }

    await refreshFastNow();

}
// ===== Tema Sistemi =====
const themeSelect = document.getElementById("themeSelect");

if (themeSelect) {

    // Kaydedilmiş tema varsa yükle
    const savedTheme = localStorage.getItem("kafepinTheme");

    if (savedTheme) {
        document.body.className = savedTheme;
        themeSelect.value = savedTheme;
    }

    themeSelect.addEventListener("change", function () {

        document.body.className = this.value;

        localStorage.setItem("kafepinTheme", this.value);

    });

}

// ===== Sadece İzleme Modu =====
const viewOnlyToggle = document.getElementById("viewOnlyToggle");

function setViewOnlyMode(enabled){
    const active = Boolean(enabled);
    document.body.dataset.viewOnly = active ? "true" : "false";
    localStorage.setItem("kafepinViewOnly", active ? "1" : "0");

    if(viewOnlyToggle){
        viewOnlyToggle.textContent = active
            ? "🔒 Sadece İzleme"
            : "🔓 Yönetim Açık";
        viewOnlyToggle.setAttribute("aria-pressed", active ? "true" : "false");
        viewOnlyToggle.title = active
            ? "İşlem düğmelerini yeniden aç"
            : "Kritik işlem düğmelerini kilitle";
    }
}

setViewOnlyMode(localStorage.getItem("kafepinViewOnly") === "1");

if(viewOnlyToggle){
    viewOnlyToggle.addEventListener("click", function(){
        const currentlyActive = document.body.dataset.viewOnly === "true";

        if(currentlyActive){
            if(!confirm("Yönetim işlemleri yeniden açılsın mı?")) return;
            setViewOnlyMode(false);
        }else{
            setViewOnlyMode(true);
        }
    });
}

document.addEventListener("click", function(event){
    if(document.body.dataset.viewOnly !== "true") return;

    const button = event.target.closest("button");
    if(!button) return;
    if(button.id === "viewOnlyToggle" ||
       button.id === "closeDashModal" ||
       button.classList.contains("section-collapse-btn") ||
       button.closest("#adminPanelSwitcher")) return;

    event.preventDefault();
    event.stopImmediatePropagation();
}, true);
