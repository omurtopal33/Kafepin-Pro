@echo off
setlocal
set "HOSTPS=%~dp0KafePin_YaziciPRO_ServiceHost.ps1"
if not exist "%HOSTPS%" exit /b 24
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%HOSTPS%" -InstallRoot "%~dp0"
exit /b %errorlevel%
