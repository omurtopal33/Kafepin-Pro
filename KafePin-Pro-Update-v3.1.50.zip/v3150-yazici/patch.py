from __future__ import annotations
import argparse, json, py_compile, sys
from pathlib import Path

REVENUE = r'''from __future__ import annotations
import json, subprocess, threading, time, urllib.request
from pathlib import Path
from config import DATA_DIR

STATE_PATH = DATA_DIR / "revenue-state.json"
KAFEPIN_DIRECT_URL = "http://127.0.0.1:3000/admin/product-sales/add-custom-direct"
PRINT_LOG = "Microsoft-Windows-PrintService/Operational"
VIRTUAL_WORDS=("microsoft print to pdf","microsoft xps","fax","onenote","pdfcreator","adobe pdf")

def _empty_state(last=0): return {"last_record_id":int(last or 0),"jobs":{},"sales":{}}
def _load_state():
    try:
        d=json.loads(STATE_PATH.read_text(encoding="utf-8")); return d if isinstance(d,dict) else _empty_state()
    except Exception: return _empty_state()
def _save_state(s):
    DATA_DIR.mkdir(parents=True,exist_ok=True); tmp=STATE_PATH.with_suffix('.tmp')
    tmp.write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(STATE_PATH)
def _physical(name):
    low=str(name or '').strip().lower(); return bool(low) and not any(x in low for x in VIRTUAL_WORDS)

def post_direct_sale(name,unit_price,quantity,payment_method,sale_id):
    state=_load_state(); known=state.get('sales',{}).get(sale_id,{})
    if known.get('status')=='sold': return known
    if known.get('status') in {'posting','uncertain'}:
        raise RuntimeError('Bu satışın önceki sonucu belirsiz. Çift kayıt oluşmaması için otomatik tekrar engellendi; KafePin Doğrudan Satış ekranını kontrol et.')
    # Ambiguous timeout after HTTP POST must not auto-retry and risk double money entry.
    state.setdefault('sales',{})[sale_id]={'status':'posting','time':time.time(),'name':name,'quantity':int(quantity),'unit_price':float(unit_price),'payment_method':payment_method}
    _save_state(state)
    payload=json.dumps({'name':str(name),'unitPrice':float(unit_price),'quantity':int(quantity),'paymentMethod':'CARD' if str(payment_method).upper()=='CARD' else 'CASH'},ensure_ascii=False).encode('utf-8')
    req=urllib.request.Request(KAFEPIN_DIRECT_URL,data=payload,headers={'Content-Type':'application/json'},method='POST')
    try:
        with urllib.request.urlopen(req,timeout=6) as r: result=json.loads(r.read().decode('utf-8','replace') or '{}')
    except Exception as exc:
        state=_load_state(); state.setdefault('sales',{})[sale_id]={'status':'uncertain','time':time.time(),'error':str(exc),'name':name,'quantity':int(quantity),'unit_price':float(unit_price),'payment_method':payment_method}; _save_state(state)
        raise RuntimeError('KafePin satış cevabı alınamadı. Çift kayıt oluşmaması için otomatik tekrar yapılmadı; Doğrudan Satış ekranını kontrol et.') from exc
    if not result.get('ok'):
        state=_load_state(); state.setdefault('sales',{}).pop(sale_id,None); _save_state(state)
        raise RuntimeError(result.get('error') or 'KafePin doğrudan satış kabul etmedi.')
    state=_load_state(); state.setdefault('sales',{})[sale_id]={'status':'sold','time':time.time(),'name':name,'quantity':int(quantity),'unit_price':float(unit_price),'payment_method':payment_method,'total':result.get('total'),'kafepin_id':result.get('id')}; _save_state(state)
    return state['sales'][sale_id]

def list_downloads():
    folder=Path.home()/'Downloads'; exts={'.pdf','.jpg','.jpeg','.png','.bmp','.tif','.tiff','.webp','.doc','.docx'}; rows=[]
    if not folder.exists(): return rows
    for p in folder.iterdir():
        try:
            if not p.is_file() or p.suffix.lower() not in exts: continue
            pages=None
            if p.suffix.lower()=='.pdf':
                try:
                    from pypdf import PdfReader; pages=len(PdfReader(str(p),strict=False).pages)
                except Exception: pass
            elif p.suffix.lower() in {'.jpg','.jpeg','.png','.bmp','.tif','.tiff','.webp'}: pages=1
            rows.append({'name':p.name,'size':p.stat().st_size,'mtime':p.stat().st_mtime,'pages':pages})
        except Exception: pass
    rows.sort(key=lambda x:x['mtime'],reverse=True); return rows[:100]
def resolve_download(name):
    folder=(Path.home()/'Downloads').resolve(); p=(folder/str(name)).resolve()
    if p.parent!=folder or not p.is_file(): raise ValueError('İndirilenler dosyası bulunamadı.')
    return p

def read_print_events(after_record_id=0):
    script=("$ErrorActionPreference='SilentlyContinue';" + "$events=Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-PrintService/Operational';Id=307} -MaxEvents 100;" + "$out=@();foreach($e in $events){if($e.RecordId -le " + str(int(after_record_id)) + "){continue};try{$x=[xml]$e.ToXml();$d=$x.Event.UserData.DocumentPrinted;$out += [pscustomobject]@{record_id=[int64]$e.RecordId;time=$e.TimeCreated.ToString('o');document=[string]$d.Param2;printer=[string]$d.Param5;pages=[int]$d.Param8}}catch{}};$out|Sort-Object record_id|ConvertTo-Json -Compress")
    cp=subprocess.run(['powershell.exe','-NoProfile','-Command',script],capture_output=True,text=True,encoding='utf-8',errors='replace',creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),timeout=12)
    if cp.returncode!=0 or not cp.stdout.strip(): return []
    try: data=json.loads(cp.stdout)
    except Exception: return []
    if isinstance(data,dict): data=[data]
    return data if isinstance(data,list) else []

class PrintRevenueQueue:
    def __init__(self):
        self.lock=threading.RLock(); self.stop=False
        if not STATE_PATH.exists():
            try:
                old=read_print_events(0); _save_state(_empty_state(max([int(x.get('record_id') or 0) for x in old] or [0])))
            except Exception: _save_state(_empty_state())
        threading.Thread(target=self._loop,daemon=True,name='KafePinPrintRevenue').start()
    def _loop(self):
        while not self.stop:
            try:self.poll()
            except Exception:pass
            time.sleep(4)
    def poll(self):
        with self.lock:
            state=_load_state(); last=int(state.get('last_record_id') or 0)
            for e in read_print_events(last):
                rid=str(e.get('record_id') or '')
                if not rid: continue
                state['last_record_id']=max(int(state.get('last_record_id') or 0),int(rid))
                doc=str(e.get('document') or ''); printer=str(e.get('printer') or '')
                if doc.startswith('KafePinYaziciPRO|') or not _physical(printer): continue
                state.setdefault('jobs',{}).setdefault(rid,{'record_id':int(rid),'time':e.get('time'),'document':doc,'printer':printer,'pages':max(1,int(e.get('pages') or 1)),'status':'pending'})
            jobs=state.get('jobs',{})
            if len(jobs)>300:
                keys=sorted(jobs,key=lambda k:int(k))[-300:]; state['jobs']={k:jobs[k] for k in keys}
            _save_state(state)
    def list_jobs(self):
        self.poll(); rows=list(_load_state().get('jobs',{}).values()); rows.sort(key=lambda x:int(x.get('record_id') or 0),reverse=True); return rows[:100]
    def close_job(self,record_id,service_type,prices,payment_method,free=False):
        with self.lock:
            state=_load_state(); key=str(record_id); job=state.get('jobs',{}).get(key)
            if not job: raise ValueError('Yazdırma işi bulunamadı.')
            if job.get('status')!='pending': return job
            pages=max(1,int(job.get('pages') or 1)); labels={'bw':'Yazıcı Geliri - S/B Çıktı','color':'Yazıcı Geliri - Renkli Çıktı','identity':'Yazıcı Geliri - Kimlik Fotokopisi','photo':'Yazıcı Geliri - Fotoğraf Çıktısı'}; pkeys={'bw':'price_bw','color':'price_color','identity':'price_identity','photo':'price_photo'}; typ=service_type if service_type in labels else 'bw'
            if free:
                job.update({'status':'free','service_type':typ,'closed_at':time.time(),'total':0}); _save_state(state); return job
            unit=float(prices.get(pkeys[typ]) or 0)
            if unit<=0: raise ValueError('Bu çıktı türü için geçerli fiyat gir.')
            sale_id='print-event-'+key; post_direct_sale(labels[typ],unit,pages,payment_method,sale_id)
            state=_load_state(); job=state.setdefault('jobs',{}).get(key,job); job.update({'status':'sold','service_type':typ,'closed_at':time.time(),'unit_price':unit,'total':unit*pages,'payment_method':payment_method,'sale_id':sale_id}); state['jobs'][key]=job; _save_state(state); return job
queue=PrintRevenueQueue()
'''
APP_ADDON = r'''setTimeout(()=>{const nav=document.querySelector('.tabs'),main=document.querySelector('main'),printBtn=document.querySelector('#printBtn');if(!nav||!main||document.querySelector('#revenueTab'))return;
const mk=(id,text)=>{const b=document.createElement('button');b.id=id;b.className='tab';b.type='button';b.textContent=text;nav.insertBefore(b,nav.querySelector('.spacer'));return b};
const quickTab=mk('quickTab','📲 WHATSAPP / HIZLI ÇIKTI'),queueTab=mk('queueTab','🧾 SON YAZDIRMALAR'),revenueTab=mk('revenueTab','💰 YAZICI GELİRİ');
const box=(id,html)=>{const s=document.createElement('section');s.id=id;s.className='mode';s.innerHTML=html;main.insertBefore(s,document.querySelector('.preview-card'));return s};
const quick=box('quickMode','<div class="card"><h2>WhatsApp / Hızlı Çıktı</h2><p class="note">WhatsApp dosyaları zaten İndirilenler’e gelir. En yeni dosyayı seç, tür/ödeme seç ve yazdır.</p><button id="downloadsRefresh" class="btn">↻ İNDİRİLENLERİ YENİLE</button><div id="downloadList" class="count">İndirilenler okunuyor…</div><div class="device-grid"><label>Tür<select id="quickType"><option value="bw">S/B Çıktı</option><option value="color">Renkli Çıktı</option><option value="identity">Kimlik Fotokopisi</option><option value="photo">Fotoğraf Çıktısı</option></select></label><label>Ödeme<select id="quickPay"><option value="CASH">Nakit</option><option value="CARD">Kart</option></select></label><label><input id="quickFree" type="checkbox"> Ücretsiz yazdır</label><label>Kopya<input id="quickCopies" type="number" min="1" max="99" value="1"></label></div><button id="quickPrint" class="btn big accent" disabled>SEÇİLİ DOSYAYI YAZDIR</button><p class="note">Başarılı baskıdan sonra dosya İndirilenler’den otomatik silinebilir. Hata olursa silinmez.</p></div>');
const queueBox=box('queueMode','<div class="card"><h2>Son Yazdırmalar</h2><p class="note">Word, Chrome, Adobe vb. ana makineden tamamlanan fiziksel baskılar burada görünür. Kendi çıktını ÜCRETSİZ kapat.</p><button id="queueRefresh" class="btn">↻ YENİLE</button><div id="queueList" class="count">Henüz okunmadı</div></div>');
const revenue=box('revenueMode','<div class="card"><h2>Yazıcı Geliri Ayarları</h2><div class="device-grid"><label>S/B sayfa fiyatı<input id="priceBw" type="number" min="0" step="0.5"></label><label>Renkli sayfa fiyatı<input id="priceColor" type="number" min="0" step="0.5"></label><label>Kimlik fotokopi fiyatı<input id="priceIdentity" type="number" min="0" step="0.5"></label><label>Fotoğraf sayfa fiyatı<input id="pricePhoto" type="number" min="0" step="0.5"></label><label>Varsayılan ödeme<select id="revenuePay"><option value="CASH">Nakit</option><option value="CARD">Kart</option></select></label><label><input id="deleteDownloads" type="checkbox"> Hızlı çıktı sonrası İndirilenler’den sil</label></div><button id="saveRevenue" class="btn big accent">AYARLARI KAYDET</button><p class="note">Ücretli işlemler yalnız KafePin Doğrudan Satış’a gider. EveryCafe ve masa hesabına yazılmaz.</p></div>');
const custom=[quick,queueBox,revenue];const show=(s,b)=>{document.querySelectorAll('.mode').forEach(x=>x.classList.remove('visible'));document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));s.classList.add('visible');b.classList.add('active')};
document.querySelectorAll('.tab[data-mode],#photoTab,#multiScanTab').forEach(b=>b.addEventListener('click',()=>custom.forEach(x=>x.classList.remove('visible'))));
let selected='';async function loadCfg(){const d=await api('/api/state'),c=d.config||{};priceBw.value=c.price_bw??5;priceColor.value=c.price_color??10;priceIdentity.value=c.price_identity??5;pricePhoto.value=c.price_photo??10;revenuePay.value=c.payment_method||'CASH';quickPay.value=c.payment_method||'CASH';deleteDownloads.checked=c.delete_download_after_print!==false}
async function loadDownloads(){const d=await api('/api/downloads'),el=document.querySelector('#downloadList'),files=d.files||[];el.innerHTML=files.length?files.map(f=>`<button class="btn dl" data-file="${encodeURIComponent(f.name)}" style="display:block;width:100%;margin:5px 0;text-align:left">${f.name}${f.pages?' • '+f.pages+' sayfa':''}</button>`).join(''):'İndirilenler’de yazdırılabilir dosya yok.';el.querySelectorAll('.dl').forEach(b=>b.onclick=()=>{selected=decodeURIComponent(b.dataset.file);el.querySelectorAll('.dl').forEach(x=>x.classList.remove('accent'));b.classList.add('accent');quickPrint.disabled=false;status('Seçildi: '+selected)})}
async function loadQueue(){const d=await api('/api/revenue/queue'),el=document.querySelector('#queueList'),jobs=(d.jobs||[]).filter(j=>j.status==='pending');el.innerHTML=jobs.length?jobs.map(j=>`<div style="padding:10px;border:1px solid #344;margin:7px 0;border-radius:8px"><b>${j.pages} sayfa • ${j.printer||'Yazıcı'}</b><div class="note">${j.document||'Belge'}</div><button class="btn q" data-id="${j.record_id}" data-t="bw">S/B ÜCRETLİ</button> <button class="btn q" data-id="${j.record_id}" data-t="color">RENKLİ</button> <button class="btn q" data-id="${j.record_id}" data-t="identity">KİMLİK</button> <button class="btn qfree" data-id="${j.record_id}">ÜCRETSİZ</button></div>`).join(''):'Bekleyen yazdırma işi yok.';el.querySelectorAll('.q').forEach(b=>b.onclick=()=>safe(b,async()=>{await post('/api/revenue/queue/'+b.dataset.id+'/close',{service_type:b.dataset.t,payment_method:revenuePay.value});await loadQueue();status('Yazıcı Geliri KafePin Doğrudan Satış’a eklendi.')}));el.querySelectorAll('.qfree').forEach(b=>b.onclick=()=>safe(b,async()=>{await post('/api/revenue/queue/'+b.dataset.id+'/close',{free:true,service_type:'bw'});await loadQueue();status('Yazdırma ücretsiz kapatıldı.')}))}
quickTab.onclick=()=>safe(quickTab,async()=>{show(quick,quickTab);await loadCfg();await loadDownloads()});queueTab.onclick=()=>safe(queueTab,async()=>{show(queueBox,queueTab);await loadCfg();await loadQueue()});revenueTab.onclick=()=>safe(revenueTab,async()=>{show(revenue,revenueTab);await loadCfg()});queueRefresh.onclick=()=>safe(queueRefresh,loadQueue);downloadsRefresh.onclick=()=>safe(downloadsRefresh,loadDownloads);
saveRevenue.onclick=()=>safe(saveRevenue,async()=>{await post('/api/config',{price_bw:+priceBw.value,price_color:+priceColor.value,price_identity:+priceIdentity.value,price_photo:+pricePhoto.value,payment_method:revenuePay.value,delete_download_after_print:deleteDownloads.checked});quickPay.value=revenuePay.value;status('Yazıcı Geliri ayarları kaydedildi.')});
quickPrint.onclick=()=>safe(quickPrint,async()=>{if(!selected)return;const d=await post('/api/quick/print',{name:selected,printer:document.querySelector('#printer').value,copies:+quickCopies.value||1,service_type:quickType.value,payment_method:quickPay.value,free:quickFree.checked});selected='';quickPrint.disabled=true;await loadDownloads();status(d.status||'Hızlı çıktı tamamlandı.')});
if(printBtn&&!document.querySelector('#printFree')){const host=printBtn.parentElement,free=document.createElement('label');free.innerHTML='<input id="printFree" type="checkbox"> Bu çıktı ÜCRETSİZ';host.insertBefore(free,printBtn);const typ=document.createElement('select');typ.id='printServiceType';typ.innerHTML='<option value="bw">S/B Çıktı</option><option value="color">Renkli Çıktı</option><option value="photo">Fotoğraf Çıktısı</option>';host.insertBefore(typ,printBtn);printBtn.addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();safe(printBtn,async()=>{await saveConfig();const active=document.querySelector('.tab.active'),isPhoto=active?.id==='photoTab',m=isPhoto?'photos':(active?.dataset.mode==='identity'?'identity':'normal'),layout=isPhoto?`${document.querySelector('#photoPaper').value}|${document.querySelector('#photoTemplate').value}|${document.querySelector('#photoFit').value}`:cfg().identity_layout,st=m==='identity'?'identity':(m==='photos'?'photo':typ.value);renderState(await post('/api/document/print',{mode:m,...cfg(),copies:+document.querySelector('#copies').value||1,layout,service_type:st,payment_method:revenuePay.value||'CASH',free:document.querySelector('#printFree').checked}))})},true)}
loadCfg().catch(()=>{})},700);'''


def read(path: Path) -> str:
    return path.read_text(encoding='utf-8-sig')

def write(path: Path, text: str) -> None:
    path.write_text(text, encoding='utf-8')

def must_replace(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        return text
    if old not in text:
        raise RuntimeError(f'{label} anchor bulunamadi')
    return text.replace(old, new, 1)

def patch(target: Path) -> None:
    required=['config.py','web_service.py','print_image.ps1','requirements.txt','web/app.js','pdf_engine.py']
    for rel in required:
        if not (target/rel).is_file():
            raise RuntimeError(f'Yazici PRO dosyasi eksik: {rel}')

    # config.py
    p=target/'config.py'; t=read(p)
    anchor='    "identity_layout": "side_by_side",\n'
    add=(anchor+'    "price_bw": 5.0,\n    "price_color": 10.0,\n    "price_identity": 5.0,\n'
         '    "price_photo": 10.0,\n    "payment_method": "CASH",\n'
         '    "delete_download_after_print": True,\n')
    if '"price_bw"' not in t:
        t=must_replace(t,anchor,add,'config defaults')
    write(p,t)

    # requirements.txt
    p=target/'requirements.txt'; t=read(p)
    if 'PyMuPDF' not in t:
        t=t.rstrip()+"\nPyMuPDF>=1.24,<2\n"
    write(p,t)

    # print_image.ps1 job name
    p=target/'print_image.ps1'; t=read(p)
    if '[string]$JobName' not in t:
        t=must_replace(t,'  [int]$Copies = 1\n)', '  [int]$Copies = 1,\n  [string]$JobName = "KafePin Yazici PRO"\n)','print param')
    if '$document.DocumentName = $JobName' not in t:
        t=must_replace(t,'$document = New-Object System.Drawing.Printing.PrintDocument\n', '$document = New-Object System.Drawing.Printing.PrintDocument\n$document.DocumentName = $JobName\n','print document name')
    write(p,t)

    # revenue module
    write(target/'revenue.py', REVENUE)

    # web_service.py
    p=target/'web_service.py'; t=read(p)
    t=t.replace('from config import APP_DIR, APP_NAME, documents_dir, load_config, save_config',
                'from config import APP_DIR, APP_NAME, DATA_DIR, documents_dir, load_config, save_config')
    t=t.replace('from pdf_engine import SUPPORTED_EXTENSIONS, merge_to_pdf',
                'from pdf_engine import SUPPORTED_EXTENSIONS, merge_to_pdf, source_as_pdf\nfrom revenue import list_downloads, resolve_download, post_direct_sale, queue as revenue_queue')
    t=t.replace('APP_VERSION = "3.1.48-cumulative"','APP_VERSION = "3.1.50-test"')
    old_keys='for key in ("printer", "scanner_id", "dpi", "color_mode", "identity_layout"):'
    new_keys='for key in ("printer", "scanner_id", "dpi", "color_mode", "identity_layout", "price_bw", "price_color", "price_identity", "price_photo", "payment_method", "delete_download_after_print"):'
    if new_keys not in t:
        t=must_replace(t,old_keys,new_keys,'config keys')
    old_print='''        for image in print_images:\n            _run_powershell(PS_PRINT, "-ImagePath", str(image), "-PrinterName", printer, "-Copies", str(copies), timeout=90)\n        with self.lock:\n            page_note = f" ({len(print_images)} sayfa)" if len(print_images) > 1 else ""\n            self.status = "Yazdırma Windows kuyruğuna gönderildi" + page_note + ". Geçici görüntüler Kaydet/TEMİZLE ile silinir."\n            return self.state()\n'''
    new_print='''        free = bool(data.get("free"))\n        payment = "CARD" if str(data.get("payment_method") or self.cfg.get("payment_method") or "CASH").upper() == "CARD" else "CASH"\n        service_type = str(data.get("service_type") or ("identity" if mode == "identity" else "photo" if mode == "photos" else "bw"))\n        prices = dict(self.cfg)\n        price_keys = {"bw":"price_bw","color":"price_color","identity":"price_identity","photo":"price_photo"}\n        labels = {"bw":"Yazıcı Geliri - S/B Çıktı","color":"Yazıcı Geliri - Renkli Çıktı","identity":"Yazıcı Geliri - Kimlik Fotokopisi","photo":"Yazıcı Geliri - Fotoğraf Çıktısı"}\n        if service_type not in labels: service_type = "bw"\n        job_id = uuid.uuid4().hex\n        for index, image in enumerate(print_images, start=1):\n            job_name = f"KafePinYaziciPRO|{job_id}|{service_type}|{index}"\n            _run_powershell(PS_PRINT, "-ImagePath", str(image), "-PrinterName", printer, "-Copies", str(copies), "-JobName", job_name, timeout=90)\n        quantity = len(print_images) * copies\n        if not free:\n            unit = float(prices.get(price_keys[service_type]) or 0)\n            if unit <= 0: raise ValueError("Bu çıktı türü için Yazıcı Geliri sekmesinden fiyat gir.")\n            post_direct_sale(labels[service_type], unit, quantity, payment, "yazici-pro-" + job_id)\n        with self.lock:\n            page_note = f" ({quantity} sayfa)" if quantity > 1 else ""\n            self.status = ("Ücretsiz yazdırıldı" if free else "Yazdırıldı ve KafePin Doğrudan Satış'a eklendi") + page_note + "."\n            return {**self.state(), "revenue": {"free": free, "quantity": quantity, "service_type": service_type}}\n'''
    if 'yazici-pro-" + job_id' not in t:
        t=must_replace(t,old_print,new_print,'print_document')

    routes='''

@app.get("/api/revenue/queue")\ndef revenue_queue_list():\n    return jsonify({"ok": True, "jobs": revenue_queue.list_jobs()})\n\n@app.post("/api/revenue/queue/<record_id>/close")\ndef revenue_queue_close(record_id: str):\n    try:\n        data=request.get_json(silent=True) or {}\n        cfg=core.config()\n        job=revenue_queue.close_job(record_id,str(data.get("service_type") or "bw"),cfg,str(data.get("payment_method") or cfg.get("payment_method") or "CASH"),bool(data.get("free")))\n        return jsonify({"ok":True,"job":job})\n    except Exception as exc:\n        return jsonify({"ok":False,"error":str(exc)}),400\n\n@app.get("/api/downloads")\ndef downloads_list():\n    return jsonify({"ok":True,"files":list_downloads()})\n\n@app.post("/api/quick/print")\ndef quick_print():\n    folder=None\n    try:\n        data=request.get_json(silent=True) or {}\n        source=resolve_download(str(data.get("name") or ""))\n        printer=str(data.get("printer") or core.cfg.get("printer") or "").strip()\n        if not printer: raise ValueError("Önce yazıcı seç.")\n        copies=max(1,min(99,int(data.get("copies") or 1)))\n        typ=str(data.get("service_type") or "bw")\n        if typ not in {"bw","color","identity","photo"}: typ="bw"\n        free=bool(data.get("free"))\n        payment="CARD" if str(data.get("payment_method") or core.cfg.get("payment_method") or "CASH").upper()=="CARD" else "CASH"\n        folder=TEMP_ROOT/("quick_"+uuid.uuid4().hex); folder.mkdir(parents=True,exist_ok=False)\n        pdf=source_as_pdf(source,folder,PS_DOCX_TO_PDF)\n        import fitz\n        doc=fitz.open(str(pdf)); pages=[]\n        try:\n            for i,page in enumerate(doc):\n                target=folder/f"page_{i+1:03d}.png"\n                pix=page.get_pixmap(matrix=fitz.Matrix(1.7,1.7),alpha=False)\n                pix.save(str(target)); pages.append(target)\n        finally:\n            doc.close()\n        if not pages: raise ValueError("Dosyada yazdırılabilir sayfa bulunamadı.")\n        job_id=uuid.uuid4().hex\n        for i,image in enumerate(pages,1):\n            _run_powershell(PS_PRINT,"-ImagePath",str(image),"-PrinterName",printer,"-Copies",str(copies),"-JobName",f"KafePinYaziciPRO|{job_id}|{typ}|{i}",timeout=90)\n        quantity=len(pages)*copies\n        if not free:\n            key={"bw":"price_bw","color":"price_color","identity":"price_identity","photo":"price_photo"}[typ]\n            label={"bw":"Yazıcı Geliri - S/B Çıktı","color":"Yazıcı Geliri - Renkli Çıktı","identity":"Yazıcı Geliri - Kimlik Fotokopisi","photo":"Yazıcı Geliri - Fotoğraf Çıktısı"}[typ]\n            unit=float(core.cfg.get(key) or 0)\n            if unit<=0: raise ValueError("Yazıcı Geliri sekmesinden fiyat gir.")\n            post_direct_sale(label,unit,quantity,payment,"quick-"+job_id)\n        deleted=False\n        if bool(core.cfg.get("delete_download_after_print",True)):\n            source.unlink(missing_ok=False); deleted=True\n        core.status=("Ücretsiz hızlı çıktı tamamlandı" if free else "Hızlı çıktı tamamlandı ve satışa eklendi")+f" — {quantity} sayfa"\n        return jsonify({"ok":True,"quantity":quantity,"deleted":deleted,"status":core.status})\n    except Exception as exc:\n        return jsonify({"ok":False,"error":str(exc)}),400\n    finally:\n        if folder:\n            try: shutil.rmtree(folder,ignore_errors=True)\n            except Exception: pass\n'''
    if '@app.get("/api/revenue/queue")' not in t:
        anchor='if __name__ == "__main__":'
        if anchor not in t: raise RuntimeError('route anchor bulunamadi')
        t=t.replace(anchor,routes+'\n\n'+anchor,1)
    write(p,t)

    # UI addon appended, idempotent
    p=target/'web'/'app.js'; t=read(p)
    if 'id="revenueTab"' not in t and "#revenueTab" not in t:
        t=t.rstrip()+"\n"+APP_ADDON+"\n"
    write(p,t)

    # version metadata
    vp=target/'yazici-pro-version.json'
    try: vd=json.loads(read(vp)) if vp.exists() else {}
    except Exception: vd={}
    vd.update({'version':'3.1.50-test','displayVersion':'v3.1.50 TEST','releaseChannel':'test'})
    features=list(vd.get('features') or [])
    for f in ['Yazıcı Geliri ve KafePin Doğrudan Satış entegrasyonu','WhatsApp / Hızlı Çıktı ve baskı sonrası otomatik silme','Son Yazdırmalar / Windows PrintService kuyruk takibi','S/B, renkli, kimlik, fotoğraf fiyatları ve Ücretsiz Yazdır']:
        if f not in features: features.append(f)
    vd['features']=features
    write(vp,json.dumps(vd,ensure_ascii=False,indent=2)+'\n')

    # compile Python modules that can compile cross-platform
    for name in ['config.py','pdf_engine.py','revenue.py','web_service.py']:
        py_compile.compile(str(target/name),doraise=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--target',required=True); args=ap.parse_args()
    patch(Path(args.target).resolve())
    print('KafePin Yazici PRO v3.1.50 TEST patch OK')
