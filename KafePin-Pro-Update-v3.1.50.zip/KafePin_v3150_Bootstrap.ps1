param([string]$InstallRoot='C:\KafePin')
$ErrorActionPreference='Stop'
$LogDir=Join-Path $env:ProgramData 'KafePinPro\logs'
$Log=Join-Path $LogDir 'v3150-yazici.log'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
function Log([string]$m){ try{ Add-Content -LiteralPath $Log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss')+' '+$m) -Encoding UTF8 }catch{} }
$Marker=Join-Path $env:ProgramData 'KafePinPro\v3150-yazici-installed.json'
try { if(Test-Path $Marker){$m=Get-Content $Marker -Raw|ConvertFrom-Json;if([string]$m.version -eq '3.1.50'){Log 'Marker mevcut; atlandi.';exit 0}} } catch{}
try {
  Log 'v3.1.50 TEST bootstrap basladi.'
  $tmp=Join-Path $env:TEMP ('KafePin-v3150-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $tmp|Out-Null
  $zip=Join-Path $tmp 'v3149.zip'
  $url='https://raw.githubusercontent.com/omurtopal33/Kafepin-Pro/main/KafePin-Pro-Update-v3.1.49.zip'
  Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $zip -TimeoutSec 90
  $sha=(Get-FileHash -Algorithm SHA256 -LiteralPath $zip).Hash.ToLowerInvariant()
  if($sha -ne '9eb3468b4991476ae7850be0556315f05a4430ae3b94264cc53238b69fc2b34e'){throw ('v3.1.49 SHA256 uyusmuyor: '+$sha)}
  $base=Join-Path $tmp 'v3149';Expand-Archive -LiteralPath $zip -DestinationPath $base -Force
  $info=Get-Content (Join-Path $base 'update.json') -Raw -Encoding UTF8|ConvertFrom-Json
  if([string]$info.version -ne '3.1.49'){throw 'v3.1.49 paket tanimi gecersiz'}
  foreach($rel in @($info.files)){
    $r=[string]$rel
    if($r -in @('KafePin_Manager_Ensure.ps1','kafepin-pro-version.json','update.json')){continue}
    $src=Join-Path $base $r;if(-not(Test-Path -LiteralPath $src -PathType Leaf)){throw ('v3.1.49 eksik dosya: '+$r)}
    $dst=Join-Path $InstallRoot $r;$parent=Split-Path -Parent $dst;if($parent){New-Item -ItemType Directory -Force -Path $parent|Out-Null};Copy-Item -LiteralPath $src -Destination $dst -Force
  }
  Log 'v3.1.49 kumulatif dosyalari dogrulandi/tazelendi.'
  $py=(Get-Command python.exe -ErrorAction SilentlyContinue).Source
  if(-not $py){$py=(Get-Command py.exe -ErrorAction SilentlyContinue).Source}
  if(-not $py){throw 'Python 3 bulunamadi; Yazici PRO v3.1.50 yukseltilemedi.'}
  $patch=Join-Path $InstallRoot 'v3150-yazici\patch.py'
  $component=Join-Path $InstallRoot 'pro-components\yazici-pro.zip'
  if(-not(Test-Path $component)){throw 'pro-components\yazici-pro.zip bulunamadi.'}
  $compDir=Join-Path $tmp 'yazici-component';Expand-Archive -LiteralPath $component -DestinationPath $compDir -Force
  & $py $patch --target $compDir
  if($LASTEXITCODE -ne 0){throw 'Yazici PRO component patch basarisiz.'}
  Remove-Item -LiteralPath $component -Force
  Compress-Archive -Path (Join-Path $compDir '*') -DestinationPath $component -CompressionLevel Optimal -Force
  Log 'Secilebilir Yazici PRO component ZIP v3.1.50 TEST yapildi.'
  $target=Join-Path $InstallRoot 'KafePinYaziciPRO'
  $targetBackup=Join-Path $tmp 'installed-yazici-backup'
  if(Test-Path -LiteralPath $target -PathType Container){
    Copy-Item -LiteralPath $target -Destination $targetBackup -Recurse -Force
    try{Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" -ErrorAction SilentlyContinue|Where-Object{[string]$_.CommandLine -like ('*'+$target+'*web_service.py*')}|ForEach-Object{Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue}}catch{}
    & $py $patch --target $target
    if($LASTEXITCODE -ne 0){throw 'Kurulu Yazici PRO patch basarisiz.'}
    try{& wevtutil.exe sl 'Microsoft-Windows-PrintService/Operational' /e:true|Out-Null;Log 'PrintService Operational aktif.'}catch{Log ('PrintService log acilamadi: '+$_.Exception.Message)}
    $kur=Join-Path $target 'KURULUM.cmd';if(Test-Path $kur){$p=Start-Process -FilePath 'cmd.exe' -ArgumentList @('/c','"'+$kur+'" /silent') -WorkingDirectory $target -Wait -PassThru -WindowStyle Hidden;if($p.ExitCode -ne 0){Log ('KURULUM.cmd exit '+$p.ExitCode)}}
    $start=Join-Path $target 'START_YAZICI_PRO.cmd';if(Test-Path $start){Start-Process -FilePath $start -WorkingDirectory $target -WindowStyle Hidden}
    Log 'Kurulu Yazici PRO v3.1.50 TEST yukseltildi.'
  } else { Log 'Yazici PRO kurulu degil; component ZIP gelecekteki kurulum icin v3.1.50 yapildi.' }
  [ordered]@{version='3.1.50';channel='test';mode='cumulative-test';baseVersion='3.1.29';installedAt=(Get-Date).ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $InstallRoot 'kafepin-pro-version.json') -Encoding UTF8
  [ordered]@{version='3.1.50';channel='test';installedAt=(Get-Date).ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath $Marker -Encoding UTF8
  Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
  Log 'v3.1.50 TEST bootstrap BASARILI.'
  exit 0
} catch {
  try {
    if($targetBackup -and (Test-Path -LiteralPath $targetBackup -PathType Container) -and $target){
      if(Test-Path -LiteralPath $target){Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction SilentlyContinue}
      Copy-Item -LiteralPath $targetBackup -Destination $target -Recurse -Force
      Log 'Yazici PRO mevcut surumu geri yuklendi.'
    }
    $stableComponent=Join-Path $base 'pro-components\yazici-pro.zip'
    if($base -and (Test-Path -LiteralPath $stableComponent -PathType Leaf) -and $component){Copy-Item -LiteralPath $stableComponent -Destination $component -Force}
  } catch { Log ('ROLLBACK HATA: '+$_.Exception.Message) }
  Log ('HATA: '+$_.Exception.Message); Write-Error $_.Exception.Message; exit 50
}
