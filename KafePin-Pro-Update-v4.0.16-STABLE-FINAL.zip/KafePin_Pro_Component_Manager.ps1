﻿param(
  [ValidateSet('status','install','repair','remove')][string]$Action = 'status',
  [ValidateSet('mp3-bot-pro','yazici-pro','teknik-servis-pro','client-performans-pro','cv-olustur-pro')][string]$Component = 'mp3-bot-pro'
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$InstallRoot = 'C:\KafePin'
$ProRoot = 'C:\KafePinPro'
$ArchiveRoot = Join-Path $InstallRoot 'pro-components'
$RecoveryRoot = Join-Path $ProRoot '_kaldirilanlar'
$PreserveNames = @('.env','state.json','favorites.json','saved_locations.json','settings.json','user-settings.json')

$Components = @{
  'mp3-bot-pro' = @{ Name='MP3 Bot PRO'; Folder='MP3BotPRO'; Archive='mp3-bot-pro.zip'; Setup='KURULUM.cmd'; Start='mp3' }
  'yazici-pro' = @{ Name='Yazici PRO'; Folder='YaziciPRO'; Archive='yazici-pro.zip'; Setup='KURULUM.cmd'; Start='yazici' }
  'teknik-servis-pro' = @{ Name='Teknik Servis PRO'; Folder='TeknikServisPRO'; Archive='teknik-servis-pro.zip'; Setup='START_TEKNIK_SERVIS_PRO.cmd'; Start='teknik' }
  'client-performans-pro' = @{ Name='Client Performans PRO'; Folder='ClientPerformansPRO'; Archive='client-performans-pro.zip'; Setup=''; Start='performance' }
  'cv-olustur-pro' = @{ Name='CV Olustur PRO'; Folder='CVOlusturPRO'; Archive='cv-olustur-pro.zip'; Setup=''; Start='cv' }
}

function Test-EveryCafePresent {
  $candidates = @(
    'C:\Program Files (x86)\EveryCafe', 'C:\Program Files\EveryCafe',
    'C:\Program Files (x86)\EveryCafeManager', 'C:\Program Files (x86)\EveryCafeManager\EveryCafeManager.exe',
    'C:\Program Files\EveryCafeManager', 'C:\Program Files\EveryCafeManager\EveryCafeManager.exe',
    'C:\EveryCafe', 'C:\ecmdata.ecm',
    (Join-Path $InstallRoot 'everycafe-path.txt'),
    (Join-Path $InstallRoot 'config\everycafe.json')
  )
  return [bool]($candidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1)
}

function Get-ComponentInfo([string]$Key) {
  $item = $Components[$Key]
  $target = Join-Path $ProRoot $item.Folder
  $archive = Join-Path $ArchiveRoot $item.Archive
  [pscustomobject]@{
    id=$Key; name=$item.Name; installed=(Test-Path -LiteralPath $target); available=(Test-Path -LiteralPath $archive)
    target=$target; clientRequiresEveryCafe=($Key -in @('client-performans-pro')); everyCafePresent=(Test-EveryCafePresent)
  }
}

function Copy-ComponentFiles([string]$Source,[string]$Target,[bool]$Preserve) {
  New-Item -ItemType Directory -Force -Path $Target | Out-Null
  Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
    $destination = Join-Path $Target $_.Name
    if ($Preserve -and $PreserveNames -contains $_.Name -and (Test-Path -LiteralPath $destination)) { return }
    if ($_.PSIsContainer) {
      Copy-Item -LiteralPath $_.FullName -Destination $destination -Recurse -Force
    } else {
      Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
    }
  }
}

function Start-Component([string]$Key,[string]$Target) {
  $item=$Components[$Key]
  if($item.Start -eq 'mp3') {
    # MP3 arayüzü ve kullanıcı verisi Session 0'da çalışamaz. Bu yönetici
    # SYSTEM oturumundan çağrıldıysa servis burada başlatılmaz; KafePin
    # masaüstündeki MP3 sekmesi START_WEB.ps1 ile interaktif kullanıcıda açar.
    $sessionId = [int][System.Diagnostics.Process]::GetCurrentProcess().SessionId
    if($sessionId -le 0) { return $false }
    $launcher=Join-Path $Target 'START_WEB.ps1'
    if(Test-Path -LiteralPath $launcher){
      Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',$launcher) -WorkingDirectory $Target -WindowStyle Hidden | Out-Null
      return $true
    }
    return $false
  } elseif($item.Start -eq 'yazici') {
    $serviceHostPath=Join-Path $Target 'KafePin_YaziciPRO_ServiceHost.ps1'
    if(Test-Path -LiteralPath $serviceHostPath){ Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',$serviceHostPath,'-InstallRoot',$Target) -WindowStyle Hidden | Out-Null }
  } elseif($item.Start -eq 'teknik') {
    $starter=Join-Path $Target 'START_TEKNIK_SERVIS_PRO.cmd'
    if(Test-Path -LiteralPath $starter){ Start-Process -FilePath 'cmd.exe' -ArgumentList @('/d','/c',$starter) -WorkingDirectory $Target -WindowStyle Hidden | Out-Null }
  } elseif($item.Start -eq 'cv') {
    $service=Join-Path $Target 'web_service.py'
    $pyw=(Get-Command pythonw.exe -ErrorAction SilentlyContinue)
    if(-not $pyw){ $pyw=(Get-Command python.exe -ErrorAction SilentlyContinue) }
    if($pyw -and (Test-Path -LiteralPath $service)){ Start-Process -FilePath $pyw.Source -ArgumentList @('-B',$service) -WorkingDirectory $Target -WindowStyle Hidden | Out-Null; return $true }
    return $false
  } elseif($item.Start -eq 'performance') {
    # Bu panel EveryCafe DB'yi doğrudan salt-okunur kullanır ve Libre Hardware Monitor'un yerel JSON verisini birleştirir.
    # Port zaten dinleniyorsa ikinci Python prosesi baslatma.
    try {
      $alreadyListening = $false
      foreach($line in @(& netstat.exe -ano -p tcp 2>$null)) {
        $parts=@(([string]$line).Trim() -split '\s+')
        if($parts.Count -ge 5 -and $parts[0].ToUpperInvariant() -eq 'TCP' -and $parts[1].EndsWith(':17896') -and $parts[3].ToUpperInvariant() -eq 'LISTENING') { $alreadyListening=$true; break }
      }
      if($alreadyListening){ return $true }
    } catch {}
    $service=Join-Path $Target 'web_service.py'
    $py=Get-Command py.exe -ErrorAction SilentlyContinue
    if($py -and (Test-Path -LiteralPath $service)) {
      Start-Process -FilePath $py.Source -ArgumentList @('-3','-B',$service) -WorkingDirectory $Target -WindowStyle Hidden | Out-Null
      return $true
    }
    return $false
  }
}

function Install-Or-Repair([string]$Key) {
  $info=Get-ComponentInfo $Key
  if(-not $info.available){ throw "$($info.name) kurulum paketi bulunamadı." }
  if($Key -in @('client-performans-pro') -and -not $info.everyCafePresent -and -not $info.installed){ throw "$($info.name) yalniz EveryCafe bu bilgisayarda algilaninca eklenebilir." }
  $temp=Join-Path ([IO.Path]::GetTempPath()) ('kafepin-component-'+[Guid]::NewGuid().ToString('N'))
  try {
    New-Item -ItemType Directory -Force -Path $temp | Out-Null
    Expand-Archive -LiteralPath (Join-Path $ArchiveRoot $Components[$Key].Archive) -DestinationPath $temp -Force
    Copy-ComponentFiles $temp $info.target ([bool]$info.installed)
    $setup=Join-Path $info.target $Components[$Key].Setup
    if($Key -in @('mp3-bot-pro','yazici-pro') -and (Test-Path -LiteralPath $setup)) {
      # Repair akisi mevcut calisan runtime'i yeniden bootstrap etmez. Ozellikle
      # Yazici PRO update aktivasyonu SYSTEM/Session 0 altindan calisabildigi icin
      # her repair'de `py -3 -m venv` / pip calistirmak saha ortaminda gereksiz
      # exit 1 uretebiliyordu. Mevcut .venv varsa payload exact kopyalanir ve
      # ServiceHost ayni runtime ile yeni kodu baslatir. Runtime yoksa kurulum
      # yine fail-closed olarak bir kez calisir.
      $skipSetupForHealthyRepair = $false
      if($Action -eq 'repair' -and $info.installed) {
        if($Key -eq 'yazici-pro') {
          $runtime = Join-Path $info.target '.venv\Scripts\python.exe'
          $runtimeW = Join-Path $info.target '.venv\Scripts\pythonw.exe'
          $skipSetupForHealthyRepair = (Test-Path -LiteralPath $runtime -PathType Leaf) -and (Test-Path -LiteralPath $runtimeW -PathType Leaf)
        } elseif($Key -eq 'mp3-bot-pro') {
          $runtime = Join-Path $info.target '.venv\Scripts\python.exe'
          $skipSetupForHealthyRepair = Test-Path -LiteralPath $runtime -PathType Leaf
        }
      }
      if(-not $skipSetupForHealthyRepair) {
        $p=Start-Process -FilePath 'cmd.exe' -ArgumentList @('/d','/c',('"'+$setup+'" /silent')) -WorkingDirectory $info.target -WindowStyle Hidden -Wait -PassThru
        if($p.ExitCode -ne 0){ throw "$($info.name) hazırlığı çıkış kodu $($p.ExitCode) verdi." }
      }
    }
    $started = Start-Component $Key $info.target
    $verb = $(if($info.installed){'onarildi'}else{'eklendi'})
    $message = $info.name+' güvenli şekilde '+$verb+' ve başlatıldı.'
    if($Key -eq 'mp3-bot-pro' -and $started -eq $false) {
      $message = $info.name+' güvenli şekilde '+$verb+'. Servis Session 0 yerine KafePin masaüstündeki MP3 Bot PRO sekmesinden kullanıcı oturumunda başlatılacak.'
    }
    return [pscustomobject]@{ok=$true; message=$message; installed=$true}
  } finally { if(Test-Path -LiteralPath $temp){ Remove-Item -LiteralPath $temp -Force -Recurse -ErrorAction SilentlyContinue } }
}

function Remove-Component([string]$Key) {
  $info=Get-ComponentInfo $Key
  if(-not $info.installed){ return [pscustomobject]@{ok=$true;message=($info.name+' zaten kurulu değil.');installed=$false} }
  if($Key -eq 'mp3-bot-pro') {
    $py=Join-Path $info.target '.venv\Scripts\python.exe'; $ctl=Join-Path $info.target 'service_control.py'
    if((Test-Path -LiteralPath $py) -and (Test-Path -LiteralPath $ctl)){ & $py $ctl stop 2>$null | Out-Null }
  }
  New-Item -ItemType Directory -Force -Path $RecoveryRoot | Out-Null
  $backup=Join-Path $RecoveryRoot ($Key+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
  Move-Item -LiteralPath $info.target -Destination $backup -Force
  return [pscustomobject]@{ok=$true;message=($info.name+' kaldırıldı; geri alınabilir klasöre taşındı.');installed=$false;recovery=$backup}
}

try {
  if($Action -eq 'status') {
    $items=@($Components.Keys | Sort-Object | ForEach-Object { Get-ComponentInfo $_ })
    [pscustomobject]@{ok=$true;components=$items;everyCafePresent=(Test-EveryCafePresent)} | ConvertTo-Json -Depth 5 -Compress
  } elseif($Action -in @('install','repair')) {
    Install-Or-Repair $Component | ConvertTo-Json -Compress
  } else {
    Remove-Component $Component | ConvertTo-Json -Compress
  }
} catch {
  [pscustomobject]@{ok=$false;error=$_.Exception.Message} | ConvertTo-Json -Compress
  exit 1
}
