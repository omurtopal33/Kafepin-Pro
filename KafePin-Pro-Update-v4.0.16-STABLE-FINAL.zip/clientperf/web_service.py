from __future__ import annotations

import base64
import concurrent.futures
import json
import re
import socket
import sqlite3
import subprocess
import threading
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os
from urllib.request import Request, urlopen
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web"
PORT = 17896
KAFEPIN_MASALAR_URL = "http://127.0.0.1:3000/api/masalar"
EVERYCAFE_DB = Path(r"C:\Program Files (x86)\EveryCafeManager\ecmdata.ecm")
PRO_EVENT_URL = "http://127.0.0.1:3000/admin/pro-event"
ALLOWED_ACTIONS = {"wake", "restart", "terminate_apps"}
REACHABILITY_CACHE_SECONDS = 3.0
_reachability_cache: dict[str, tuple[float, bool | None]] = {}
_reachability_lock = threading.Lock()
LIBRE_PORT = 8085
WEB_LIMIT_AGENT_PORT = 17906
WEB_LIMIT_DOWN_MBPS = 50.0
WEB_LIMIT_UP_MBPS = 10.0
WEB_LIMIT_KEY_FILE = Path(r"C:\ProgramData\KafePin\WebLimit\control.key")
WEB_LIMIT_SETTINGS_FILE = Path(r"C:\ProgramData\KafePin\ClientPerformansPRO\web-limit-settings.json")
WEB_LIMIT_SETTINGS_FALLBACK = Path(os.environ.get("LOCALAPPDATA") or str(Path.home())) / "KafePin" / "ClientPerformansPRO" / "web-limit-settings.json"
WEB_LIMIT_GLOBAL_KEY = "__global__"
_web_limit_settings_active_file = WEB_LIMIT_SETTINGS_FILE
_web_limit_settings_lock = threading.Lock()
SAMPLE_CACHE_SECONDS = 2.5
_cache: dict[str, tuple[float, dict]] = {}
_agent_reachable: dict[str, bool] = {}
HARDWARE_CACHE_SECONDS = 10 * 60.0
_hardware_cache: dict[str, tuple[float, dict]] = {}
HARDWARE_INVENTORY_FILE = Path(r"C:\ProgramData\KafePin\ClientPerformansPRO\hardware-inventory.json")
_hardware_inventory_lock = threading.Lock()


def fetch_json(url: str, timeout: float = 1.8) -> object:
    request = Request(url, headers={"Accept": "application/json", "Cache-Control": "no-cache"})
    with urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8-sig"))



def everycafe_connection() -> sqlite3.Connection:
    if not EVERYCAFE_DB.is_file():
        raise FileNotFoundError(f"EveryCafe veritabanı bulunamadı: {EVERYCAFE_DB}")
    conn = sqlite3.connect(f"file:{EVERYCAFE_DB.as_posix()}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA query_only=ON")
        conn.execute("PRAGMA busy_timeout=650")
    except Exception:
        pass
    return conn


def probe_reachable(ip: str) -> bool | None:
    target = str(ip or "").strip()
    if not target:
        return False
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        result = subprocess.run(["ping.exe", "-n", "1", "-w", "500", target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=1.2, check=False, creationflags=flags)
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return None


def live_reachability(ips: list[str]) -> dict[str, bool | None]:
    now = time.monotonic()
    unique = list(dict.fromkeys(str(ip or "").strip() for ip in ips if str(ip or "").strip()))
    resolved: dict[str, bool | None] = {}
    stale: list[str] = []
    with _reachability_lock:
        for ip in unique:
            cached = _reachability_cache.get(ip)
            if cached and now - cached[0] < REACHABILITY_CACHE_SECONDS:
                resolved[ip] = cached[1]
            else:
                stale.append(ip)
    if stale:
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(16, len(stale))) as pool:
            checked = dict(zip(stale, pool.map(probe_reachable, stale)))
        checked_at = time.monotonic()
        with _reachability_lock:
            for ip, reachable in checked.items():
                _reachability_cache[ip] = (checked_at, reachable)
                resolved[ip] = reachable
    return resolved


def list_everycafe_clients() -> list[dict]:
    sql = """
        SELECT c.ClientName,c.ClientGuid,c.ClientIP,c.ClientMac,
               COALESCE(c.ClientStatus,0) AS ClientStatus,
               COALESCE(c.ClientIsActive,0) AS ClientIsActive,
               s.SessionID,s.StartDate,s.EndDate,s.SessionType,s.SessionTypeText,
               s.SessionDetailDataText,s.GiftTime
          FROM Clients c
          LEFT JOIN Sessions s
            ON s.ClientGuid=c.ClientGuid
           AND COALESCE(s.IsActive,0)=1
           AND COALESCE(s.Deleted,0)=0
         WHERE COALESCE(c.ClientIsDeleted,0)=0
           AND TRIM(COALESCE(c.ClientIP,''))<>''
         ORDER BY c.ClientName COLLATE NOCASE
    """
    with everycafe_connection() as conn:
        rows = conn.execute(sql).fetchall()
    reachability = live_reachability([str(row["ClientIP"] or "") for row in rows])
    result: list[dict] = []
    for row in rows:
        item = dict(row)
        status = int(item.get("ClientStatus") or 0)
        active = bool(item.get("SessionID"))
        live = reachability.get(str(item.get("ClientIP") or "").strip())
        item["deviceOnline"] = live if live is not None else status in (1, 2)
        item["sessionOpen"] = active
        item["sessionMode"] = str(item.get("SessionTypeText") or item.get("SessionDetailDataText") or "-") if active else "-"
        item["sessionStart"] = int(item.get("StartDate") or 0) * 1000
        item["sessionEnd"] = int(item.get("EndDate") or 0) * 1000
        item["status"] = "Oturum açık" if active else ("Beklemede" if item["deviceOnline"] and status == 2 else ("Online" if item["deviceOnline"] else "Kapalı"))
        result.append(item)
    def natural_name(value: object):
        return [(0, int(part)) if part.isdigit() else (1, part.casefold()) for part in re.split(r"(\d+)", str(value or ""))]
    result.sort(key=lambda item: (0 if item.get("deviceOnline") else 1, natural_name(item.get("ClientName"))))
    return result


def normalise_mac(value: str) -> bytes:
    raw = "".join(ch for ch in str(value or "") if ch in "0123456789abcdefABCDEF")
    if len(raw) != 12:
        raise ValueError("Bu masa için geçerli MAC adresi bulunamadı.")
    return bytes.fromhex(raw)


def directed_broadcast(ip: str) -> str:
    parts = str(ip or "").split(".")
    if len(parts) == 4 and all(part.isdigit() and 0 <= int(part) <= 255 for part in parts):
        return ".".join(parts[:3] + ["255"])
    return "255.255.255.255"


def find_client(client_name: str) -> dict:
    client = next((item for item in list_everycafe_clients() if item.get("ClientName") == client_name), None)
    if not client:
        raise ValueError("Masa bulunamadı.")
    return client


def wake_client(client_name: str) -> dict:
    client = find_client(client_name)
    mac = normalise_mac(client.get("ClientMac", ""))
    packet = b"\xff" * 6 + mac * 16
    target = directed_broadcast(client.get("ClientIP", ""))
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.sendto(packet, (target, 9)); sock.sendto(packet, (target, 7))
    return {"client": client_name, "broadcast": target}


def send_client_command(client_name: str, command: str) -> dict:
    client = find_client(client_name)
    ip = str(client.get("ClientIP") or "").strip()
    if not ip:
        raise ValueError("Bu masa için geçerli IP adresi bulunamadı.")
    packet = base64.b64encode(command.encode("utf-8"))
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.sendto(packet, (ip, 45456))
    return {"client": client_name, "command": command.split(":", 1)[0]}


def restart_client(client_name: str) -> dict:
    return send_client_command(client_name, "RESTARTCLIENT:NoData")


def terminate_client_apps(client_name: str) -> dict:
    return send_client_command(client_name, "TERMINATEALLAPPS:NoData")


def emit_live_event(event_type: str, text: str) -> None:
    def _send():
        try:
            raw = json.dumps({"source":"Client Performans PRO","type":event_type,"text":text}, ensure_ascii=False).encode("utf-8")
            req = Request(PRO_EVENT_URL, data=raw, headers={"Content-Type":"application/json"}, method="POST")
            urlopen(req, timeout=1.2).read()
        except Exception:
            pass
    threading.Thread(target=_send, daemon=True).start()

def web_limit_key() -> str:
    import os
    env = os.environ.get("KAFEPIN_WEB_LIMIT_KEY", "").strip()
    if env:
        return env
    try:
        return WEB_LIMIT_KEY_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def fetch_agent_health(ip: str, timeout: float = 0.7) -> dict:
    key = web_limit_key()
    if not ip or not key:
        return {"reachable": False, "enabled": False, "error": "agent key yok" if not key else "IP yok"}
    try:
        req = Request(f"http://{ip}:{WEB_LIMIT_AGENT_PORT}/api/health", headers={"Accept":"application/json", "X-KafePin-Token": key, "Cache-Control":"no-cache"})
        with urlopen(req, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8-sig"))
        if not isinstance(data, dict) or not data.get("ok"):
            return {"reachable": False, "enabled": False, "error": str((data or {}).get("error") if isinstance(data, dict) else "bad response")}
        return {
            "reachable": True,
            "enabled": bool(data.get("enabled")),
            "downMbps": float(data.get("downMbps") or 0),
            "upMbps": float(data.get("upMbps") or 0),
            "mode": str(data.get("mode") or ""),
            "failOpen": bool(data.get("failOpen", True)),
            "version": str(data.get("version") or ""),
            "error": str(data.get("lastError") or ""),
        }
    except Exception as exc:
        return {"reachable": False, "enabled": False, "error": str(exc)}


def control_agent(ip: str, enable: bool, down: float = WEB_LIMIT_DOWN_MBPS, up: float = WEB_LIMIT_UP_MBPS, timeout: float = 2.0) -> dict:
    key = web_limit_key()
    if not ip:
        return {"ok": False, "error": "IP yok"}
    if not key:
        return {"ok": False, "error": "KAFEPIN_WEB_LIMIT_KEY ayarlı değil"}
    body = json.dumps({"action": "enable" if enable else "disable", "downMbps": down, "upMbps": up}).encode("utf-8")
    req = Request(f"http://{ip}:{WEB_LIMIT_AGENT_PORT}/api/control", data=body, method="POST", headers={"Content-Type":"application/json", "Accept":"application/json", "X-KafePin-Token": key})
    try:
        with urlopen(req, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8-sig"))
        return data if isinstance(data, dict) else {"ok": False, "error": "bad response"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def _normalise_limit(value: object, default: float) -> float:
    try:
        number = float(str(value).replace(",", "."))
    except Exception:
        return default
    if not (0.1 <= number <= 10000.0):
        raise ValueError("Web limit değeri 0.1 ile 10000 Mbps arasında olmalı.")
    return round(number, 2)


def _web_limit_settings_candidates() -> list[Path]:
    # v4.0.11 R3: ProgramData'daki eski dosya bazı saha kurulumlarında updater ACL'i
    # nedeniyle salt-okunur kalabiliyor. Önce eski/ortak yolu koru; yazılamıyorsa
    # servis kullanıcısının LOCALAPPDATA alanına güvenli şekilde düş.
    paths = [WEB_LIMIT_SETTINGS_FILE, WEB_LIMIT_SETTINGS_FALLBACK]
    unique = []
    seen = set()
    for item in paths:
        key = str(item).lower()
        if key not in seen:
            seen.add(key); unique.append(item)
    return unique


def load_web_limit_settings() -> dict:
    global _web_limit_settings_active_file
    with _web_limit_settings_lock:
        merged = {}
        # v4.0.11 R4: ProgramData eski/varsayilan kaynak, LOCALAPPDATA ise
        # izin sorunu yasayan makinelerde yeni yazilabilir kaynaktir. Bu nedenle
        # ProgramData once okunur, fallback SONRA okunur ve ayni IP kaydinda
        # fallback her zaman kazanir. Boylece eski 50/10 kaydi yeni 70/20 veya
        # KAPALI tercihini geri ezemez.
        loaded_paths = []
        for path in _web_limit_settings_candidates():
            try:
                data = json.loads(path.read_text(encoding="utf-8-sig"))
                if isinstance(data, dict):
                    merged.update(data)
                    loaded_paths.append(path)
            except Exception:
                pass
        if loaded_paths:
            _web_limit_settings_active_file = loaded_paths[-1]
        return merged


def _write_web_limit_settings_file(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())


def save_web_limit_settings(settings: dict) -> None:
    """Persist WebLimit state even when the packaged ProgramData file is read-only.

    R1 failed on rename-over-existing; R2 proved the installed JSON itself can also be
    read-only (PermissionError 13). R3 first preserves the historical ProgramData path,
    then transparently falls back to the current service user's LOCALAPPDATA state file.
    No ACL is broadened and no unrelated file is changed.
    """
    global _web_limit_settings_active_file
    payload = json.dumps(settings, ensure_ascii=False, indent=2)
    last_error = None
    with _web_limit_settings_lock:
        # Prefer the file that last loaded successfully, then try both canonical paths.
        candidates = [_web_limit_settings_active_file] + _web_limit_settings_candidates()
        tried = set()
        for path in candidates:
            key = str(path).lower()
            if key in tried:
                continue
            tried.add(key)
            try:
                _write_web_limit_settings_file(path, payload)
                _web_limit_settings_active_file = path
                # Clean only a stale temp from R1 next to the same state file.
                tmp = path.with_suffix(".tmp")
                try:
                    if tmp.exists(): tmp.unlink()
                except Exception:
                    pass
                return
            except (PermissionError, OSError) as exc:
                last_error = exc
                continue
        raise PermissionError(f"WebLimit ayarı yazılamadı: {last_error}")


def desired_limit(ip: str) -> tuple[float, float]:
    settings = load_web_limit_settings()
    row = settings.get(str(ip or "").strip(), {})
    if not isinstance(row, dict) or not row:
        row = settings.get(WEB_LIMIT_GLOBAL_KEY, {})
    # A newly discovered workstation has no per-IP entry yet.  It must inherit
    # the operator's saved global value instead of showing the historical 50/10.
    if not isinstance(row, dict):
        row = {}
    return (_normalise_limit(row.get("downMbps"), WEB_LIMIT_DOWN_MBPS), _normalise_limit(row.get("upMbps"), WEB_LIMIT_UP_MBPS))


def global_limit_defaults() -> tuple[float, float]:
    row = load_web_limit_settings().get(WEB_LIMIT_GLOBAL_KEY, {})
    if not isinstance(row, dict):
        row = {}
    return (
        _normalise_limit(row.get("downMbps"), WEB_LIMIT_DOWN_MBPS),
        _normalise_limit(row.get("upMbps"), WEB_LIMIT_UP_MBPS),
    )


def desired_limit_enabled(ip: str) -> bool:
    """Return the persisted on/off choice for a client.

    Machines that have never been configured keep the historical default (ON 50/10).
    Once the operator presses Kapat, False is persisted and reconnects must stay unlimited.
    """
    row = load_web_limit_settings().get(str(ip or "").strip(), {})
    if not isinstance(row, dict) or "enabled" not in row:
        return True
    return bool(row.get("enabled"))


def remember_limit(ip: str, down: object, up: object, enabled: bool = True) -> tuple[float, float]:
    target = str(ip or "").strip()
    if not target:
        raise ValueError("IP yok")
    down_value = _normalise_limit(down, WEB_LIMIT_DOWN_MBPS)
    up_value = _normalise_limit(up, WEB_LIMIT_UP_MBPS)
    settings = load_web_limit_settings()
    settings[target] = {
        "enabled": bool(enabled),
        "downMbps": down_value,
        "upMbps": up_value,
        "updatedAt": int(time.time() * 1000),
    }
    save_web_limit_settings(settings)
    return down_value, up_value


def auto_enable_agent(ip: str, health: dict) -> dict:
    """Re-apply the persisted WebLimit state when an agent appears/reconnects.

    New/unconfigured machines preserve the historical 50/10 default.
    A manual Kapat is persistent: reconnecting the agent must remain unlimited.
    """
    if not ip:
        return health
    down, up = desired_limit(ip)
    should_enable = desired_limit_enabled(ip)
    health = dict(health)
    health["desiredDownMbps"] = down
    health["desiredUpMbps"] = up
    health["desiredEnabled"] = should_enable
    reachable = bool(health.get("reachable"))
    was_reachable = _agent_reachable.get(ip, False)
    _agent_reachable[ip] = reachable
    if reachable and not was_reachable:
        if not should_enable:
            if health.get("enabled"):
                result = control_agent(ip, False, down, up)
                if result.get("ok"):
                    refreshed = fetch_agent_health(ip)
                    refreshed["desiredDownMbps"] = down
                    refreshed["desiredUpMbps"] = up
                    refreshed["desiredEnabled"] = False
                    return refreshed
                health["error"] = str(result.get("error") or "kalıcı web limiti kapatma uygulanamadı")
            return health

        current_down = float(health.get("downMbps") or 0)
        current_up = float(health.get("upMbps") or 0)
        needs_apply = (not health.get("enabled") or abs(current_down-down) > 0.01 or abs(current_up-up) > 0.01)
        if needs_apply:
            result = control_agent(ip, True, down, up)
            if result.get("ok"):
                refreshed = fetch_agent_health(ip)
                refreshed["desiredDownMbps"] = down
                refreshed["desiredUpMbps"] = up
                refreshed["desiredEnabled"] = True
                return refreshed
            health["error"] = str(result.get("error") or f"otomatik {down:g}/{up:g} uygulanamadı")
    return health


def parse_number(value: object) -> float | None:
    match = re.search(r"[-+]?\d+(?:[.,]\d+)?", str(value or ""))
    return float(match.group(0).replace(",", ".")) if match else None


def to_mbps(value: object) -> float | None:
    number = parse_number(value)
    if number is None:
        return None
    text = str(value or "").lower().replace(" ", "")
    if "gb/s" in text or "gbit/s" in text:
        return number * 8000.0
    if "mb/s" in text or "mbit/s" in text:
        return number * 8.0
    if "kb/s" in text or "kbit/s" in text:
        return number * 0.008
    if "b/s" in text:
        return number * 0.000008
    return number


def flatten(node: dict, hardware: str = "", group: str = "") -> list[dict]:
    hardware = str(node.get("HardwareId") or hardware or "")
    text = str(node.get("Text") or "")
    next_group = text if str(node.get("ImageURL") or "").endswith(("temperature.png", "load.png", "throughput.png", "ram.png")) else group
    rows: list[dict] = []
    value = str(node.get("Value") or "")
    if value:
        rows.append({"hardware": hardware.lower(), "group": group.lower(), "name": text.lower(), "value": value})
    for child in node.get("Children") or []:
        if isinstance(child, dict):
            rows.extend(flatten(child, hardware, next_group))
    return rows


def clean_hardware_text(value: object) -> str:
    return re.sub(r"\s+", " ", str(value or "").replace("\x00", " ")).strip()


def hardware_nodes(node: dict, parent_text: str = "") -> list[dict]:
    """Collect model names already exposed by Libre Hardware Monitor."""
    text = clean_hardware_text(node.get("Text"))
    hardware_id = clean_hardware_text(node.get("HardwareId")).lower()
    rows: list[dict] = []
    image = clean_hardware_text(node.get("ImageURL")).lower()
    if hardware_id or image:
        rows.append({"id": hardware_id, "text": text, "parent": clean_hardware_text(parent_text), "image": image})
    for child in node.get("Children") or []:
        if isinstance(child, dict):
            rows.extend(hardware_nodes(child, text or parent_text))
    return rows


def first_hardware_name(nodes: list[dict], markers: tuple[str, ...]) -> str | None:
    for row in nodes:
        identity = row.get("id", "") + " " + row.get("image", "")
        if any(marker in identity for marker in markers):
            text = clean_hardware_text(row.get("text"))
            if text and text.casefold() not in {"cpu", "gpu", "memory", "ram", "network"}:
                return text
    return None


def value_in_gb(value: object) -> float | None:
    number = parse_number(value)
    if number is None:
        return None
    text = str(value or "").casefold().replace(" ", "")
    if "tb" in text:
        return number * 1024.0
    if "mb" in text:
        return number / 1024.0
    if "kb" in text:
        return number / (1024.0 * 1024.0)
    if "b" in text and "gb" not in text:
        return number / (1024.0 * 1024.0 * 1024.0)
    return number


def first_named_value(rows: list[dict], hardware_markers: tuple[str, ...], names: tuple[str, ...], converter=parse_number) -> float | None:
    for name in names:
        for row in rows:
            if any(marker in row["hardware"] for marker in hardware_markers) and name in row["name"]:
                parsed = converter(row["value"])
                if parsed is not None:
                    return parsed
    return None


def build_hardware_inventory(data: dict, agent_health: dict | None = None) -> dict:
    rows = flatten(data)
    nodes = hardware_nodes(data)
    used_ram = first_named_value(rows, ("/ram", "/memory"), ("memory used", "used memory"), value_in_gb)
    available_ram = first_named_value(rows, ("/ram", "/memory"), ("memory available", "available memory"), value_in_gb)
    total_ram = round(used_ram + available_ram, 1) if used_ram is not None and available_ram is not None else None
    agent_health = agent_health or {}
    return {
        "cpu": first_hardware_name(nodes, ("/intelcpu", "/amdcpu", "/cpu/")),
        "ramTotalGb": total_ram,
        "gpu": first_hardware_name(nodes, ("/gpu-nvidia", "/gpu-amd", "/gpu-intel", "/gpu/")),
        "motherboard": first_hardware_name(nodes, ("/mainboard", "/motherboard", "mainboard.png")),
        "networkAdapter": first_hardware_name(nodes, ("/nic/", "/network/", "nic.png")),
        "clientVersion": clean_hardware_text(agent_health.get("version")) or None,
    }


def load_saved_hardware() -> dict:
    try:
        data = json.loads(HARDWARE_INVENTORY_FILE.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_hardware(ip: str, name: str, hardware: dict) -> None:
    if not ip or not any(hardware.get(key) for key in ("cpu", "ramTotalGb", "gpu", "motherboard", "networkAdapter")):
        return
    with _hardware_inventory_lock:
        saved = load_saved_hardware()
        saved[ip] = {"name": name, "hardware": hardware, "updatedAt": int(time.time() * 1000)}
        HARDWARE_INVENTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
        temporary = HARDWARE_INVENTORY_FILE.with_suffix(".tmp")
        temporary.write_text(json.dumps(saved, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temporary, HARDWARE_INVENTORY_FILE)


def first_value(rows: list[dict], hardware_markers: tuple[str, ...], group: str, names: tuple[str, ...], converter=parse_number) -> float | None:
    for name in names:
        for row in rows:
            if any(marker in row["hardware"] for marker in hardware_markers) and group in row["group"] and name in row["name"]:
                parsed = converter(row["value"])
                if parsed is not None:
                    return parsed
    return None


def ping_ms(ip: str) -> float | None:
    """Read the ICMP reply time, never the process startup duration.

    Windows emits either ``time=2ms`` or Turkish ``süre=2ms``.  A reply of
    ``<1ms`` is represented as 0 so the browser can render it as ``<1 ms``.
    """
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        result = subprocess.run(
            ["ping.exe", "-n", "1", "-w", "650", ip],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=1.2,
            check=False,
            creationflags=flags,
        )
        if result.returncode != 0:
            return None
        output = bytes(result.stdout or b"").decode(errors="replace")
        match = re.search(r"(?:time|süre)\s*([=<])\s*(\d+(?:[.,]\d+)?)\s*ms", output, re.IGNORECASE)
        if not match:
            return None
        value = float(match.group(2).replace(",", "."))
        return 0.0 if match.group(1) == "<" else value
    except (OSError, subprocess.SubprocessError):
        return None


def client_masa_number(client: dict) -> int | None:
    for value in (client.get("ClientName"), client.get("ComputerName"), client.get("Name")):
        text = str(value or "").strip()
        match = re.search(r"(\d{1,3})\s*$", text)
        if match:
            number = int(match.group(1))
            if 1 <= number <= 999:
                return number
    return None


def read_client_sensor(client: dict, link_speeds: dict[int, float] | None = None) -> dict:
    ip = str(client.get("ClientIP") or "").strip()
    key = ip or str(client.get("ClientGuid") or client.get("ClientName") or "")
    now = time.monotonic()
    masa_no = client_masa_number(client)
    link_speed = float((link_speeds or {}).get(masa_no, 0) or 0) if masa_no else 0.0
    cached = _cache.get(key)
    if cached and now - cached[0] < SAMPLE_CACHE_SECONDS:
        value = dict(cached[1])
        value["linkSpeedMbps"] = link_speed or value.get("linkSpeedMbps")
        return value
    result = {
        "name": str(client.get("ClientName") or "Masa"), "ip": ip,
        "online": bool(client.get("deviceOnline")), "status": str(client.get("status") or ""), "sensorOnline": False,
        "sessionOpen": bool(client.get("sessionOpen")), "sessionMode": str(client.get("sessionMode") or "-"),
        "sessionStart": int(client.get("sessionStart") or 0), "sessionEnd": int(client.get("sessionEnd") or 0),
        "cpuLoad": None, "ramLoad": None, "cpuTemp": None, "gpuTemp": None, "downloadMbps": None, "uploadMbps": None, "pingMs": None,
        "linkSpeedMbps": link_speed or None, "message": "Libre Hardware Monitor verisi bekleniyor",
        "webLimit": {"reachable": False, "enabled": False, "error": "bekleniyor"},
    }
    if not ip or not result["online"]:
        result["message"] = "Client kapalı / ulaşılamıyor"
        health = fetch_agent_health(ip) if ip else {"reachable": False, "enabled": False, "error": "IP yok"}
        if ip:
            # Offline clients cannot answer the agent health endpoint, but their
            # persisted target must still be returned so their card does not
            # fall back to the obsolete UI default (50/10).
            down, up = desired_limit(ip)
            health = dict(health)
            health["desiredDownMbps"] = down
            health["desiredUpMbps"] = up
            health["desiredEnabled"] = desired_limit_enabled(ip)
            _agent_reachable[ip] = bool(health.get("reachable"))
        result["webLimit"] = health
        _cache[key] = (now, result)
        return dict(result)
    try:
        data = fetch_json(f"http://{ip}:{LIBRE_PORT}/data.json")
        rows = flatten(data)
        result.update({
            "sensorOnline": True,
            "cpuLoad": first_value(rows, ("/intelcpu", "/amdcpu"), "load", ("cpu total",)),
            "ramLoad": first_value(rows, ("/ram",), "load", ("memory",)),
            "cpuTemp": first_value(rows, ("/intelcpu", "/amdcpu"), "temperatures", ("cpu package", "core max", "cpu core")),
            "gpuTemp": first_value(rows, ("/gpu-",), "temperatures", ("gpu core", "gpu temperature")),
            "downloadMbps": first_value(rows, ("/nic/",), "throughput", ("download speed", "receive speed"), to_mbps),
            "uploadMbps": first_value(rows, ("/nic/",), "throughput", ("upload speed", "send speed"), to_mbps),
            "pingMs": ping_ms(ip), "message": "Libre Hardware Monitor bağlı",
        })
    except Exception:
        result["message"] = "Libre Hardware Monitor servisi kapalı (http://IP:8085)"
        result["pingMs"] = ping_ms(ip)
    result["webLimit"] = auto_enable_agent(ip, fetch_agent_health(ip))
    _cache[key] = (now, result)
    return dict(result)


def list_metrics() -> list[dict]:
    clients = list_everycafe_clients()
    link_speeds: dict[int, float] = {}
    try:
        masalar = fetch_json(KAFEPIN_MASALAR_URL, timeout=1.2)
        if isinstance(masalar, list):
            for row in masalar:
                if not isinstance(row, dict): continue
                masa_no = int(row.get("masa") or 0); speed = float(row.get("netSpeed") or 0)
                if masa_no > 0 and speed > 0: link_speeds[masa_no] = speed
    except Exception:
        pass
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(12, max(1, len(clients)))) as pool:
        return [future.result() for future in [pool.submit(read_client_sensor, client, link_speeds) for client in clients]]


def current_link_speeds() -> dict[int, float]:
    speeds: dict[int, float] = {}
    try:
        masalar = fetch_json(KAFEPIN_MASALAR_URL, timeout=1.2)
        if isinstance(masalar, list):
            for row in masalar:
                if not isinstance(row, dict):
                    continue
                masa_no = int(row.get("masa") or 0)
                speed = float(row.get("netSpeed") or 0)
                if masa_no > 0 and speed > 0:
                    speeds[masa_no] = speed
    except Exception:
        pass
    return speeds


def read_client_hardware(client: dict, link_speeds: dict[int, float], force: bool = False) -> dict:
    ip = clean_hardware_text(client.get("ClientIP"))
    name = clean_hardware_text(client.get("ClientName")) or "Masa"
    online = bool(client.get("deviceOnline"))
    masa_no = client_masa_number(client)
    result = {
        "name": name,
        "ip": ip,
        "online": online,
        "hardwareOnline": False,
        "linkSpeedMbps": link_speeds.get(masa_no) if masa_no else None,
        "hardware": {},
    }
    saved_row = load_saved_hardware().get(ip, {}) if ip else {}
    if isinstance(saved_row, dict) and isinstance(saved_row.get("hardware"), dict):
        result["hardware"] = dict(saved_row["hardware"])
        result["savedAt"] = int(saved_row.get("updatedAt") or 0)
    if not ip or not online:
        return result
    now = time.monotonic()
    cached = _hardware_cache.get(ip)
    if not force and cached and now - cached[0] < HARDWARE_CACHE_SECONDS:
        cached_result = dict(cached[1])
        cached_result["linkSpeedMbps"] = result["linkSpeedMbps"] or cached_result.get("linkSpeedMbps")
        return cached_result
    try:
        data = fetch_json(f"http://{ip}:{LIBRE_PORT}/data.json", timeout=2.2)
        if not isinstance(data, dict):
            raise ValueError("Libre donanım yanıtı geçersiz")
        health = fetch_agent_health(ip, timeout=0.8)
        hardware = build_hardware_inventory(data, health)
        result.update({"hardwareOnline": True, "hardware": hardware, "savedAt": int(time.time() * 1000)})
        save_hardware(ip, name, hardware)
    except Exception as exc:
        result["error"] = str(exc)
    _hardware_cache[ip] = (now, dict(result))
    return result


def list_hardware(force: bool = False) -> list[dict]:
    clients = list_everycafe_clients()
    link_speeds = current_link_speeds()
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, max(1, len(clients)))) as pool:
        return list(pool.map(lambda client: read_client_hardware(client, link_speeds, force), clients))


class Handler(SimpleHTTPRequestHandler):
    def log_message(self, *_args): pass
    def send_json(self, payload: dict, status: int = 200):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(body))); self.send_header("Cache-Control", "no-store"); self.send_header("X-KafePin-Performance-Isolation", "separate-loopback-service"); self.end_headers(); self.wfile.write(body)
    def serve_file(self, relative: str):
        requested = (WEB / relative).resolve()
        if WEB not in requested.parents or not requested.is_file(): return self.send_json({"ok": False, "error": "Bulunamadı"}, 404)
        content_type = {".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "application/javascript"}.get(requested.suffix, "application/octet-stream")
        body = requested.read_bytes(); self.send_response(200); self.send_header("Content-Type", content_type); self.send_header("Content-Length", str(len(body))); self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(body)
    def read_json_body(self):
        length = max(0, min(int(self.headers.get("Content-Length", "0") or 0), 65536))
        return json.loads(self.rfile.read(length).decode("utf-8") or "{}")
    def do_POST(self):
        try:
            path = urlparse(self.path).path; data = self.read_json_body()
            if path == "/api/web-limit":
                ip = str(data.get("ip") or "").strip(); enable = bool(data.get("enable"))
                down, up = desired_limit(ip)
                if enable:
                    down, up = remember_limit(ip, data.get("downMbps", down), data.get("upMbps", up), True)
                else:
                    # Kapat is a persistent operator choice. Save it before contacting the agent
                    # so a reconnect cannot resurrect the previous 50/10 (or custom) rule.
                    down, up = remember_limit(ip, down, up, False)
                result = control_agent(ip, enable, down, up)
                if result.get("ok") and ip:
                    _agent_reachable[ip] = True
                result = dict(result); result.update({"downMbps": down, "upMbps": up, "saved": True, "enabled": enable})
                return self.send_json(result, 200 if result.get("ok") else 502)
            if path == "/api/web-limit/all":
                enable = bool(data.get("enable")); clients = list_everycafe_clients(); outcomes = []
                requested_down = _normalise_limit(data.get("downMbps", WEB_LIMIT_DOWN_MBPS), WEB_LIMIT_DOWN_MBPS)
                requested_up = _normalise_limit(data.get("upMbps", WEB_LIMIT_UP_MBPS), WEB_LIMIT_UP_MBPS)

                # v4.0.11 R4: Toplu alan kendi ayaridir. TUM MASALARA UYGULA
                # denildiginde ekrandaki global degerler her masanin kaydini
                # ayni degerle kesin olarak ezer. Tek-masa alanlari ise yalniz
                # o masayi degistirir. Toplu kayit tek seferde yazilir; arada
                # eski ProgramData/fallback birlesimi degerleri geri getiremez.
                settings = load_web_limit_settings()
                targets = []
                now_ms = int(time.time() * 1000)
                settings[WEB_LIMIT_GLOBAL_KEY] = {
                    "downMbps": requested_down,
                    "upMbps": requested_up,
                    "updatedAt": now_ms,
                }
                for client in clients:
                    ip = str(client.get("ClientIP") or "").strip(); name = str(client.get("ClientName") or client.get("ComputerName") or ip or "Masa")
                    if not ip:
                        outcomes.append({"name": name, "ip": ip, "ok": False, "skipped": True, "error": "IP yok"}); continue
                    current = settings.get(ip, {}) if isinstance(settings.get(ip, {}), dict) else {}
                    if enable:
                        down, up = requested_down, requested_up
                    else:
                        down = _normalise_limit(current.get("downMbps"), WEB_LIMIT_DOWN_MBPS)
                        up = _normalise_limit(current.get("upMbps"), WEB_LIMIT_UP_MBPS)
                    settings[ip] = {
                        "enabled": enable,
                        "downMbps": down,
                        "upMbps": up,
                        "updatedAt": now_ms,
                    }
                    targets.append((client, name, ip, down, up))
                save_web_limit_settings(settings)

                for client, name, ip, down, up in targets:
                    if not bool(client.get("deviceOnline")):
                        outcomes.append({"name": name, "ip": ip, "ok": True, "skipped": True, "saved": True, "enabled": enable, "downMbps": down, "upMbps": up, "error": "offline; ayar kaydedildi"}); continue
                    r = control_agent(ip, enable, down, up)
                    if r.get("ok"):
                        _agent_reachable[ip] = True
                    outcomes.append({"name": name, "ip": ip, "downMbps": down, "upMbps": up, "saved": True, "enabled": enable, **r})
                return self.send_json({"ok": True, "enable": enable, "downMbps": requested_down, "upMbps": requested_up, "results": outcomes})
            if path == "/api/action":
                action = str(data.get("action") or "").strip().lower(); client = str(data.get("client") or "").strip()
                if action not in ALLOWED_ACTIONS:
                    raise ValueError("Desteklenmeyen client komutu.")
                handler = {"wake": wake_client, "restart": restart_client, "terminate_apps": terminate_client_apps}[action]
                result = handler(client)
                emit_live_event("client_action", f"{client} • {action} komutu tamamlandı")
                return self.send_json({"ok": True, "result": result})
            return self.send_json({"ok": False, "error": "Bulunamadı"}, 404)
        except Exception as exc:
            return self.send_json({"ok": False, "error": str(exc)}, 500)
    def do_GET(self):
        try:
            path = urlparse(self.path).path
            if path == "/api/health": return self.send_json({"ok": True, "app": "Client Performans PRO", "port": PORT, "source": "Libre Hardware Monitor + EveryCafe read-only", "everyCafeReadOnly": True, "clientControlIntegrated": True, "autoWebLimitOnReconnect": True, "persistentWebLimit": True, "persistentWebLimitDisable": True})
            if path == "/api/web-limit/settings":
                down, up = global_limit_defaults()
                return self.send_json({"ok": True, "downMbps": down, "upMbps": up, "persistent": True})
            if path == "/api/hardware":
                force = "refresh=1" in urlparse(self.path).query.lower()
                hardware = list_hardware(force=force)
                return self.send_json({"ok": True, "source": "Libre Hardware Monitor", "diskless": True, "updatedAt": int(time.time() * 1000), "clients": hardware})
            if path == "/api/metrics":
                metrics = list_metrics(); return self.send_json({"ok": True, "source": "Libre Hardware Monitor + EveryCafe read-only", "everyCafeReadOnly": True, "clientControlIntegrated": True, "autoWebLimitOnReconnect": True, "persistentWebLimit": True, "persistentWebLimitDisable": True, "updatedAt": int(time.time() * 1000), "clients": metrics})
            self.serve_file("index.html" if path in ("/", "/index.html") else path.lstrip("/"))
        except Exception as exc:
            self.send_json({"ok": False, "error": str(exc)}, 500)


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
