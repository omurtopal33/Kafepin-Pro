﻿$ErrorActionPreference = 'Stop'

$TaskName = 'KafePin Pro Server Manager'
$SystemRoot = Join-Path $env:ProgramData 'KafePinPro'
$JobPath = Join-Path $SystemRoot 'restore-worker-job.json'
$ResultFile = Join-Path $SystemRoot 'restore-result.json'
$LastRestoreFile = Join-Path $SystemRoot 'last-restore.json'
$MaintenanceFile = Join-Path $SystemRoot 'maintenance.lock'
$ManualStopFile = Join-Path $SystemRoot 'server.manual-stop'
$PidFile = Join-Path $SystemRoot 'server.pid'
$ApplyResult = Join-Path $SystemRoot 'restore-apply-result.json'
$LogDir = Join-Path $SystemRoot 'logs'
$LogFile = Join-Path $LogDir 'restore-worker.log'
$SelfTestFlag = Join-Path $SystemRoot 'restore-worker-selftest.flag'
$SelfTestOk = Join-Path $SystemRoot 'restore-worker-selftest.ok'

New-Item -ItemType Directory -Force -Path $SystemRoot,$LogDir | Out-Null

function Log([string]$Message) {
  try {
    Add-Content -LiteralPath $LogFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' [RESTORE-WORKER] ' + $Message) -Encoding UTF8
  } catch {}
}

function Write-Result([bool]$Ok,[string]$Phase,[string]$Message,[bool]$RolledBack,[string]$Backup,[int]$ServerPid=0) {
  $obj = [ordered]@{
    ok=$Ok
    phase=$Phase
    message=$Message
    rolledBack=$RolledBack
    sourceBackup=$Backup
    serverPid=$ServerPid
    restoreEngine='scheduled-direct-v2'
    time=(Get-Date).ToString('o')
  }
  try { $obj | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $ResultFile -Encoding UTF8 } catch {}
  try { $obj | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $LastRestoreFile -Encoding UTF8 } catch {}
}

function Get-KafePinServerProcesses([string]$ServerJs) {
  $full=''
  try { $full=[IO.Path]::GetFullPath($ServerJs) } catch { $full=$ServerJs }
  @(
    Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue |
      Where-Object {
        try {
          $cmd=[string]$_.CommandLine
          if (-not $cmd) { return $false }
          if ($cmd.IndexOf($full,[StringComparison]::OrdinalIgnoreCase) -ge 0) { return $true }
          # Bazi kurulumlarda Node "server.js" goreli yoluyla acilir.
          return ($cmd.IndexOf('server.js',[StringComparison]::OrdinalIgnoreCase) -ge 0 -and
                  $cmd.IndexOf('KafePin',[StringComparison]::OrdinalIgnoreCase) -ge 0)
        } catch { $false }
      }
  )
}

function Get-Port3000ProcessIds {
  $ids = New-Object System.Collections.Generic.HashSet[int]
  try {
    $conns = @(Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue)
    foreach($c in $conns) { try { if([int]$c.OwningProcess -gt 0){ [void]$ids.Add([int]$c.OwningProcess) } } catch {} }
  } catch {}
  if($ids.Count -eq 0) {
    try {
      foreach($line in @(& netstat.exe -ano -p tcp 2>$null)) {
        $txt=[string]$line
        if($txt -match '^\s*TCP\s+\S+:3000\s+\S+\s+LISTENING\s+(\d+)\s*$') {
          try { [void]$ids.Add([int]$Matches[1]) } catch {}
        }
      }
    } catch {}
  }
  return @($ids)
}

function Kill-ProcessTree([int]$Id) {
  if($Id -le 0 -or $Id -eq $PID) { return }
  try {
    $out=& taskkill.exe /PID $Id /T /F 2>&1
    Log ('taskkill PID=' + $Id + ' sonuc=' + (($out -join ' ') -replace '\r|\n',' '))
  } catch {
    try { Stop-Process -Id $Id -Force -ErrorAction SilentlyContinue; Log ('Stop-Process PID=' + $Id) } catch {}
  }
}

function Stop-KafePinServer([string]$ServerJs,[int]$SourcePid=0) {
  # Restore Worker bagimsiz SYSTEM gorevidir. Burada yalniz sunucu surecini kapatir;
  # Manager ve worker kesinlikle sonlandirilmaz.
  $deadline=(Get-Date).AddSeconds(30)
  while((Get-Date) -lt $deadline) {
    $ids = New-Object System.Collections.Generic.HashSet[int]
    if ($SourcePid -gt 0) { [void]$ids.Add($SourcePid) }
    try {
      if (Test-Path -LiteralPath $PidFile) {
        $raw=(Get-Content -LiteralPath $PidFile -Raw -ErrorAction SilentlyContinue).Trim()
        $pidValue=0
        if ([int]::TryParse($raw,[ref]$pidValue) -and $pidValue -gt 0) { [void]$ids.Add($pidValue) }
      }
    } catch {}
    foreach($p in @(Get-KafePinServerProcesses $ServerJs)) {
      try { [void]$ids.Add([int]$p.ProcessId) } catch {}
    }
    foreach($id in @(Get-Port3000ProcessIds)) { try { [void]$ids.Add([int]$id) } catch {} }

    foreach($id in @($ids)) { Kill-ProcessTree ([int]$id) }
    Remove-Item -LiteralPath $PidFile -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 350

    $portIds=@(Get-Port3000ProcessIds)
    $serverProcs=@(Get-KafePinServerProcesses $ServerJs)
    $sourceAlive=$false
    if($SourcePid -gt 0) { try { $sourceAlive = $null -ne (Get-Process -Id $SourcePid -ErrorAction SilentlyContinue) } catch {} }
    if($portIds.Count -eq 0 -and $serverProcs.Count -eq 0 -and -not $sourceAlive) {
      Log 'server tamamen durdu; port 3000 bos.'
      return $true
    }
  }
  Log ('server durdurulamadi; portPID=' + ((@(Get-Port3000ProcessIds)) -join ',') + ' nodePID=' + ((@(Get-KafePinServerProcesses $ServerJs) | ForEach-Object {$_.ProcessId}) -join ','))
  return $false
}

function Start-ServerDirect([string]$Node,[string]$ServerJs,[string]$InstallRoot) {
  # maintenance.lock burada bilerek KALIR: Manager bu sirada ikinci server baslatamaz.
  $existing=@(Get-Port3000ProcessIds)
  if($existing.Count -gt 0) { Log ('Start-ServerDirect: port 3000 zaten dolu PID=' + ($existing -join ',')); return [int]$existing[0] }
  $psi=New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName=$Node
  $psi.Arguments='"' + $ServerJs + '"'
  $psi.WorkingDirectory=$InstallRoot
  $psi.UseShellExecute=$false
  $psi.CreateNoWindow=$true
  $proc=[Diagnostics.Process]::Start($psi)
  if(-not $proc) { throw 'Node server baslatilamadi' }
  try { $proc.Id | Set-Content -LiteralPath $PidFile -Encoding ASCII } catch {}
  Log ('server dogrudan restore worker tarafindan baslatildi PID=' + $proc.Id)
  return [int]$proc.Id
}

function Health([string]$WantedVersion='3.1.2') {
  try {
    $r=Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:3000/api/health?_restoreWorker=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 2 -Headers @{ 'Cache-Control'='no-cache' }
    if ($r.StatusCode -lt 200 -or $r.StatusCode -ge 300) { return $false }
    $j=$r.Content | ConvertFrom-Json
    if ($WantedVersion -and [string]$j.version -ne $WantedVersion) { return $false }
    return $true
  } catch { return $false }
}

function Wait-Stable([string]$WantedVersion='3.1.2',[int]$TimeoutSeconds=75,[int]$StableChecks=5) {
  $deadline=(Get-Date).AddSeconds($TimeoutSeconds)
  $stable=0
  while((Get-Date) -lt $deadline) {
    if (Health $WantedVersion) {
      $stable++
      if ($stable -ge $StableChecks) { return $true }
    } else { $stable=0 }
    Start-Sleep -Seconds 1
  }
  return $false
}

function Ensure-ManagerRunning {
  Remove-Item -LiteralPath $ManualStopFile -Force -ErrorAction SilentlyContinue
  try {
    $out=& schtasks.exe /Run /TN $TaskName 2>&1
    if ($LASTEXITCODE -eq 0) { Log 'Server Manager gorevi tetiklendi.' }
    else { Log ('Server Manager /Run sonucu: ' + ($out -join ' ')) }
  } catch { Log ('Server Manager tetikleme uyarisi: ' + $_.Exception.Message) }
}

function Run-Apply([string]$Node,[string]$ApplyScript,[string]$Job,[bool]$Rollback=$false) {
  Remove-Item -LiteralPath $ApplyResult -Force -ErrorAction SilentlyContinue
  $args=@($ApplyScript,$Job)
  if ($Rollback) { $args += '--rollback' }
  $output=& $Node @args 2>&1
  foreach($line in @($output)) { Log ('apply> ' + [string]$line) }
  if ($LASTEXITCODE -ne 0) { throw ('Restore apply cikis kodu ' + $LASTEXITCODE) }
  if (-not (Test-Path -LiteralPath $ApplyResult)) { throw 'Restore apply sonuc dosyasi olusmadi' }
  $r=Get-Content -LiteralPath $ApplyResult -Raw -Encoding UTF8 | ConvertFrom-Json
  if (-not [bool]$r.ok) { throw ('Restore apply basarisiz: ' + [string]$r.error) }
}

if (Test-Path -LiteralPath $SelfTestFlag) {
  try {
    Remove-Item -LiteralPath $SelfTestFlag -Force -ErrorAction SilentlyContinue
    ('ok ' + (Get-Date).ToString('o')) | Set-Content -LiteralPath $SelfTestOk -Encoding ASCII
    Log 'SELFTEST OK - Scheduled Task worker bagimsiz calisti.'
    exit 0
  } catch {
    Log ('SELFTEST HATA: ' + $_.Exception.Message)
    exit 9
  }
}

if (-not (Test-Path -LiteralPath $JobPath)) {
  Log 'Job yok; worker cikiyor.'
  exit 0
}

$job=$null
try {
  $job=Get-Content -LiteralPath $JobPath -Raw -Encoding UTF8 | ConvertFrom-Json
  if (-not $job -or [string]$job.type -ne 'KAFEPIN_DB_RESTORE_WORKER') { throw 'Restore worker job tipi gecersiz' }

  $InstallRoot=[string]$job.installRoot
  $Node=[string]$job.nodePath
  $ServerJs=Join-Path $InstallRoot 'server.js'
  $ApplyScript=Join-Path $InstallRoot 'KafePin_Restore_Apply.js'
  $Backup=[string]$job.sourceBackup

  if (-not (Test-Path -LiteralPath $Node)) { throw 'Node.exe bulunamadi' }
  if (-not (Test-Path -LiteralPath $ServerJs)) { throw 'server.js bulunamadi' }
  if (-not (Test-Path -LiteralPath $ApplyScript)) { throw 'KafePin_Restore_Apply.js bulunamadi' }

  Log ('BASLADI - ' + $Backup)
  Write-Result $false 'restoring' 'Geri yukleme worker tarafindan uygulanıyor' $false $Backup 0
  Start-Sleep -Milliseconds 1500

  # Manager acik kalir. maintenance.lock varken serveri yeniden baslatmaz.
  if (-not (Test-Path -LiteralPath $MaintenanceFile)) {
    Set-Content -LiteralPath $MaintenanceFile -Value ('restore-worker ' + (Get-Date).ToString('o')) -Encoding ASCII
  }

  if (-not (Stop-KafePinServer $ServerJs ([int]$job.sourceServerPid))) { throw 'KafePin server tamamen durdurulamadi' }
  Start-Sleep -Milliseconds 400

  Run-Apply $Node $ApplyScript $JobPath $false
  Log 'database.db atomik geri yuklendi ve SHA256 dogrulandi.'

  # Yeni DB hazir. Manager maintenance.lock nedeniyle bekler; serveri worker TEK KEZ aciyor.
  Remove-Item -LiteralPath $ManualStopFile -Force -ErrorAction SilentlyContinue
  $startedPid=Start-ServerDirect $Node $ServerJs $InstallRoot
  if (-not (Wait-Stable '3.1.2' 90 5)) { throw 'Yeni DB ile dogrudan baslatilan sunucu 5 ardisik health kontrolunden gecemedi' }
  # Sunucu stabil olduktan sonra kilidi kaldir. Manager artik sadece gozetmen olur.
  Remove-Item -LiteralPath $MaintenanceFile -Force -ErrorAction SilentlyContinue
  Ensure-ManagerRunning

  $serverPid=0
  try {
    $procs=@(Get-KafePinServerProcesses $ServerJs)
    if ($procs.Count -gt 0) { $serverPid=[int]$procs[0].ProcessId }
  } catch {}

  Write-Result $true 'complete' 'Yedekten geri yukleme tamamlandi; sunucu stabil' $false $Backup $serverPid
  Log ('BASARILI - sunucu stabil PID=' + $serverPid)

  try { Remove-Item -LiteralPath $JobPath,$ApplyResult -Force -ErrorAction SilentlyContinue } catch {}
  try { if ($job.stageDir -and (Test-Path -LiteralPath ([string]$job.stageDir))) { Remove-Item -LiteralPath ([string]$job.stageDir) -Recurse -Force -ErrorAction SilentlyContinue } } catch {}
  exit 0
}
catch {
  $message=$_.Exception.Message
  Log ('HATA: ' + $message)
  $rolledBack=$false
  $rollbackStable=$false
  $backupName=''
  try { if ($job) { $backupName=[string]$job.sourceBackup } } catch {}

  try {
    if ($job) {
      $InstallRoot=[string]$job.installRoot
      $Node=[string]$job.nodePath
      $ServerJs=Join-Path $InstallRoot 'server.js'
      $ApplyScript=Join-Path $InstallRoot 'KafePin_Restore_Apply.js'

      Set-Content -LiteralPath $MaintenanceFile -Value ('restore-worker-rollback ' + (Get-Date).ToString('o')) -Encoding ASCII
      Stop-KafePinServer $ServerJs 0 | Out-Null

      if ($job.safetyDb -and (Test-Path -LiteralPath ([string]$job.safetyDb))) {
        Run-Apply $Node $ApplyScript $JobPath $true
        $rolledBack=$true
        Log 'Emniyet database.db geri alindi.'
      }

      Remove-Item -LiteralPath $ManualStopFile -Force -ErrorAction SilentlyContinue
      Start-ServerDirect $Node $ServerJs $InstallRoot | Out-Null
      $rollbackStable=Wait-Stable '3.1.2' 90 5
      Remove-Item -LiteralPath $MaintenanceFile -Force -ErrorAction SilentlyContinue
      Ensure-ManagerRunning
      if ($rollbackStable) { Log 'Rollback sonrasi sunucu stabil.' } else { Log 'UYARI: Rollback sonrasi sunucu health gecemedi.' }
    }
  } catch {
    Log ('ROLLBACK HATA: ' + $_.Exception.Message)
  }

  Write-Result $false 'error' ($message + $(if($rolledBack){' - eski DB geri alindi'}else{''})) $rolledBack $backupName 0
  try { Remove-Item -LiteralPath $JobPath,$ApplyResult -Force -ErrorAction SilentlyContinue } catch {}
  try { if ($job -and $job.stageDir -and (Test-Path -LiteralPath ([string]$job.stageDir))) { Remove-Item -LiteralPath ([string]$job.stageDir) -Recurse -Force -ErrorAction SilentlyContinue } } catch {}
  try { Remove-Item -LiteralPath $MaintenanceFile -Force -ErrorAction SilentlyContinue } catch {}
  exit 22
}
