"use strict";
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
function die(message, code = 2) { try { console.error(message); } catch (_) {} process.exit(code); }
function sha256(file) { const h=crypto.createHash("sha256"); const fd=fs.openSync(file,"r"); const b=Buffer.alloc(1024*1024); try{while(true){const n=fs.readSync(fd,b,0,b.length,null);if(!n)break;h.update(b.subarray(0,n));}}finally{fs.closeSync(fd);} return h.digest("hex").toUpperCase(); }
function assertSqlite(file) { const st=fs.statSync(file); if(!st.isFile()||st.size<100) throw new Error("SQLite dosyasi bos/cok kucuk"); const fd=fs.openSync(file,"r"); const head=Buffer.alloc(16); try{fs.readSync(fd,head,0,16,0);}finally{fs.closeSync(fd);} if(!head.equals(Buffer.from("SQLite format 3\0","binary"))) throw new Error("SQLite basligi gecersiz"); return st.size; }
function under(child,parent){const c=path.resolve(child).toUpperCase();const pp=path.resolve(parent).toUpperCase();const p=pp.replace(/[\\/]+$/,"")+path.sep.toUpperCase();return c===pp||c.startsWith(p);}
const requestPath=process.argv[2]; const rollback=process.argv.includes("--rollback");
if(!requestPath||!fs.existsSync(requestPath)) die("restore-request.json bulunamadi",3);
let req; try{req=JSON.parse(fs.readFileSync(requestPath,"utf8").replace(/^\uFEFF/,""));}catch(e){die("restore-request okunamadi: "+e.message,4);}
const installRoot=path.resolve(String(req.installRoot||"")); const systemRoot=path.resolve(String(req.systemRoot||"")); const stageDir=path.resolve(String(req.stageDir||""));
const source=path.resolve(String(rollback?req.safetyDb:req.stagedDb)); const expectedHash=String(rollback?req.safetySha256:req.stagedSha256||"").toUpperCase();
const target=path.join(installRoot,"database.db"); const tmp=path.join(installRoot,`.database.restore-${process.pid}-${Date.now()}.tmp`);
try{
 if(!installRoot||!systemRoot||!stageDir) throw new Error("restore-request alanlari eksik");
 if(!under(stageDir,systemRoot)) throw new Error("StageDir ProgramData KafePinPro disinda");
 if(!under(source,stageDir)) throw new Error("Kaynak DB restore stage disinda");
 if(!fs.existsSync(source)) throw new Error("Kaynak DB bulunamadi");
 assertSqlite(source); const srcHash=sha256(source); if(expectedHash&&srcHash!==expectedHash) throw new Error(`Kaynak DB SHA256 uyusmuyor (${srcHash})`);
 try{fs.unlinkSync(tmp);}catch(_){} fs.copyFileSync(source,tmp); assertSqlite(tmp); const tmpHash=sha256(tmp); if(tmpHash!==srcHash) throw new Error("Gecici DB kopya SHA256 uyusmuyor");
 for(const f of [target+"-wal",target+"-shm"]){try{fs.unlinkSync(f);}catch(_){}}
 try{fs.unlinkSync(target);}catch(e){if(fs.existsSync(target)) throw new Error("Canli database.db silinemedi: "+e.message);}
 fs.renameSync(tmp,target); assertSqlite(target); const dstHash=sha256(target); if(dstHash!==srcHash) throw new Error("Hedef database.db SHA256 uyusmuyor");
 fs.writeFileSync(path.join(systemRoot,"restore-apply-result.json"),JSON.stringify({ok:true,rollback,target,sha256:dstHash,appliedAt:new Date().toISOString()},null,2),"utf8");
 console.log(`OK ${rollback?"ROLLBACK":"RESTORE"} ${dstHash}`); process.exit(0);
}catch(e){try{fs.unlinkSync(tmp);}catch(_){} try{fs.writeFileSync(path.join(systemRoot||path.dirname(requestPath),"restore-apply-result.json"),JSON.stringify({ok:false,rollback,error:e.message,time:new Date().toISOString()},null,2),"utf8");}catch(_){} die("RESTORE APPLY HATA: "+e.message,10);}
